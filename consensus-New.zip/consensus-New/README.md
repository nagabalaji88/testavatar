# PromptForge

**Multi-LLM consensus prompt engineering platform**

You describe a task once. Four model specialists draft a master prompt for it in parallel, a
deterministic evaluator scores all four against a ten-metric weighted matrix, a consensus
builder finds where they agree, disagree and collectively fall short, and a weaver merges the
strongest version of each section into one prompt that no single model wrote.

The rule that shapes the design: **the output is never a copy of one draft.** If one
specialist would win every section, the weaver hands the closest-fought sections to the
runner-up — otherwise running four models bought you nothing.

---

## Quick start

### Backend

```bash
cd backend
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

API at http://localhost:8000, interactive docs at `/docs`. First run creates `forge.db`
(SQLite) and seeds two completed workflow runs so every screen has real data.

### Frontend

```bash
cd frontend
npm install
npm run dev
```

http://localhost:5173. Vite proxies `/api` to the backend, so no CORS setup in development.

### Demo accounts

| Email | Role | Can do |
|---|---|---|
| `aarti.desai@forge.dev` | engineer | run workflows, create projects, edit prompts |
| `admin@forge.dev` | admin | everything, plus provider keys and settings |
| `viewer@forge.dev` | viewer | read-only |

Password for all: `forge1234`

### Tests

```bash
cd backend && python -m pytest tests -q     # 26 tests
cd frontend && npm run typecheck && npm run build
```

---

## It runs with no API keys

Every provider call goes through one gateway (`app/services/providers.py`). When a key is
missing — or when the circuit breaker has tripped after repeated failures — the call is served
by a local simulator that produces a **provider-distinct** draft rather than four identical
ones. Each specialist writes some sections deeply, some thinly, and genuinely skips others, so
scoring, consensus and weaving all have real material to work with offline.

Add keys to go live, either as environment variables or through the Settings screen:

```bash
export FORGE_OPENAI_API_KEY=sk-...
export FORGE_ANTHROPIC_API_KEY=sk-ant-...
export FORGE_GOOGLE_API_KEY=...
export FORGE_MOONSHOT_API_KEY=...
```

The status bar shows which providers are live and which are simulated at all times.

## Configuration

Environment variables, prefixed `FORGE_` (see `app/core/config.py`):

| Variable | Default | Purpose |
|---|---|---|
| `FORGE_DATABASE_URL` | `sqlite:///./forge.db` | Any SQLAlchemy URL, e.g. PostgreSQL |
| `FORGE_SECRET_KEY` | dev value | Signs tokens **and** seals stored keys — change it |
| `FORGE_RATE_LIMIT_PER_MINUTE` | `60` | Per-client request ceiling |
| `FORGE_MAX_RETRIES` | `2` | Retries before falling back to the simulator |
| `FORGE_CIRCUIT_BREAKER_FAILURES` | `3` | Failures before a provider is skipped |
| `FORGE_REQUEST_TIMEOUT_SECONDS` | `90` | Per-provider timeout |
| `FORGE_CORS_ORIGINS` | localhost:5173 | Comma-separated allowed origins |

## The screens

| Screen | What it shows |
|---|---|
| Dashboard | Prompts produced, average score, best model, consensus, cost |
| Workspace | The brief, specialist selection, and the run result |
| Workflow | React Flow graph of the run — status, tokens, duration, score per node |
| Agent monitor | Per-agent summary, confidence, warnings and recommendations |
| Comparison | All four drafts of any section, side by side, with the winner marked |
| Scores | Radar profile, weighted totals and a scorecard per specialist |
| Master prompt | Monaco editor, QA findings, provenance bar, export in seven formats |
| Library | Every prompt produced, ranked and starrable |
| History | Every run with tokens, cost and duration |
| Analytics | Spend, latency, per-specialist averages, audit trail |
| Settings | Provider status, encrypted key entry, runtime limits |

Further reading: [`ARCHITECTURE.md`](docs/ARCHITECTURE.md) ·
[`API_DOCUMENTATION.md`](docs/API_DOCUMENTATION.md) ·
[`DATABASE_SCHEMA.md`](docs/DATABASE_SCHEMA.md) ·
[`DEPLOYMENT.md`](docs/DEPLOYMENT.md) ·
[`PROJECT_PLAN.md`](docs/PROJECT_PLAN.md) · [`ACTIONS.md`](docs/ACTIONS.md)
