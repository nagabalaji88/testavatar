"""Regression cover for the provider gateway.

Each test here maps to a bug that made every provider silently run as the
simulator while the UI reported a key was stored.
"""
import time

import httpx
import pytest

from app.services import providers


@pytest.fixture(autouse=True)
def isolate_gateway(monkeypatch):
    """Every test starts with no env keys, an empty cache and a closed breaker."""
    for name in providers.PROVIDERS:
        monkeypatch.setitem(providers.CATALOG[name], "key", "")
    monkeypatch.setattr(providers, "_stored_keys", {}, raising=False)
    monkeypatch.setattr(providers, "_stored_keys_loaded_at", 0.0, raising=False)
    providers.breaker.failures.clear()
    providers.breaker.opened_at.clear()
    yield
    providers.breaker.failures.clear()
    providers.breaker.opened_at.clear()


# --- key resolution -------------------------------------------------------

def test_key_stored_in_the_database_is_actually_used(monkeypatch):
    """The original bug: CATALOG read env vars once at import, so a key saved
    through the admin UI never reached the gateway and the provider stayed
    simulated no matter what the settings page displayed."""
    monkeypatch.setattr(providers, "load_stored_keys", lambda db=None: {})
    monkeypatch.setattr(providers, "_stored_keys", {"openai": "sk-from-db"}, raising=False)
    monkeypatch.setattr(providers, "_stored_keys_loaded_at", time.time(), raising=False)

    assert providers.api_key("openai") == "sk-from-db"
    assert providers.is_live("openai")


def test_environment_key_wins_over_the_database(monkeypatch):
    """Deploy-time secrets must not be overridable by whatever someone typed
    into the UI."""
    monkeypatch.setitem(providers.CATALOG["openai"], "key", "sk-from-env")
    monkeypatch.setattr(providers, "_stored_keys", {"openai": "sk-from-db"}, raising=False)
    monkeypatch.setattr(providers, "_stored_keys_loaded_at", time.time(), raising=False)

    assert providers.api_key("openai") == "sk-from-env"


def test_no_key_anywhere_means_not_live(monkeypatch):
    monkeypatch.setattr(providers, "load_stored_keys", lambda db=None: {})
    monkeypatch.setattr(providers, "_stored_keys_loaded_at", time.time(), raising=False)
    assert providers.api_key("openai") == ""
    assert not providers.is_live("openai")


def test_stored_key_is_unsealed_when_loaded_from_the_database():
    """Keys are sealed at rest; loading must reverse that or the gateway sends
    ciphertext as the bearer token."""
    from sqlalchemy import select

    from app import models
    from app.core.database import SessionLocal
    from app.core.security import seal

    with SessionLocal() as db:
        row = db.scalar(select(models.Setting).where(models.Setting.key == "openai_api_key"))
        if row:
            row.value, row.encrypted = seal("sk-round-trip"), True
        else:
            db.add(models.Setting(key="openai_api_key", value=seal("sk-round-trip"),
                                  encrypted=True))
        db.commit()

    assert providers.load_stored_keys().get("openai") == "sk-round-trip"


# --- circuit breaker ------------------------------------------------------

def test_breaker_opens_after_the_threshold():
    for _ in range(providers.settings.circuit_breaker_failures):
        providers.breaker.record_failure("openai")
    assert providers.breaker.is_open("openai")


def test_breaker_recovers_after_the_cooldown():
    """The original bug: an open breaker made is_live() false, so no call was
    ever attempted, so no success was ever recorded to close it again — one
    outage stranded the provider on the simulator until a process restart."""
    breaker = providers.CircuitBreaker(threshold=2, cooldown_seconds=0)
    breaker.record_failure("openai")
    breaker.record_failure("openai")
    assert breaker.failures["openai"] >= breaker.threshold

    # Cooldown elapsed → half-open, one probe allowed through.
    assert not breaker.is_open("openai")


def test_breaker_stays_open_inside_the_cooldown():
    breaker = providers.CircuitBreaker(threshold=1, cooldown_seconds=300)
    breaker.record_failure("openai")
    assert breaker.is_open("openai")


def test_success_fully_resets_the_breaker():
    breaker = providers.CircuitBreaker(threshold=1, cooldown_seconds=300)
    breaker.record_failure("openai")
    breaker.record_success("openai")
    assert not breaker.is_open("openai")
    assert "openai" not in breaker.opened_at


# --- error reporting ------------------------------------------------------

def test_http_error_detail_includes_status_and_body():
    """Recording only the exception class name made a wrong key, a rate limit and
    an out-of-credit account all read as 'HTTPStatusError'."""
    response = httpx.Response(401, text='{"error":"Invalid Authentication"}',
                              request=httpx.Request("POST", "https://example.test"))
    detail = providers._describe(
        httpx.HTTPStatusError("boom", request=response.request, response=response)
    )
    assert "401" in detail
    assert "Invalid Authentication" in detail


def test_timeout_detail_is_named_as_a_timeout():
    assert "timeout" in providers._describe(httpx.ReadTimeout("slow"))


def test_completion_warns_when_no_key_is_configured(monkeypatch):
    monkeypatch.setattr(providers, "load_stored_keys", lambda db=None: {})
    monkeypatch.setattr(providers, "_stored_keys_loaded_at", time.time(), raising=False)
    result = providers.complete("openai", "sys", "user", simulator=lambda: "simulated")
    assert result.simulated
    assert any("no API key" in w for w in result.warnings)


def test_failed_live_call_falls_back_and_explains_why(monkeypatch):
    monkeypatch.setitem(providers.CATALOG["openai"], "key", "sk-broken")
    monkeypatch.setattr(providers.settings, "max_retries", 0)

    def explode(*args, **kwargs):
        response = httpx.Response(429, text='{"error":"quota exceeded"}',
                                  request=httpx.Request("POST", "https://example.test"))
        raise httpx.HTTPStatusError("rate limited", request=response.request, response=response)

    monkeypatch.setattr(httpx.Client, "post", explode)

    result = providers.complete("openai", "sys", "user", simulator=lambda: "simulated")
    assert result.simulated
    assert result.text == "simulated"
    assert any("429" in w and "quota" in w for w in result.warnings)
    assert any("fell back" in w for w in result.warnings)
