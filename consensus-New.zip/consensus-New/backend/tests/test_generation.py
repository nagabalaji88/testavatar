"""Regression cover for prompt generation.

Each test here maps to a defect where the pipeline produced a well-formed prompt
that was not actually about the caller's request.
"""
import pytest

from app.agents.analysis import IntentAnalyzer, classify, find_ambiguity
from app.agents.orchestrator import agent_registry, run_workflow
from app.agents.specialists import _merge_live
from app.agents.synthesis import Optimizer
from app.services import providers
from app.services.consensus import find_contradictions, quality_report, weave
from app.services.derivation import derive_inputs, derive_output_contract
from app.services.drafting import PROFILES, baseline_draft, draft_sections
from app.services.evaluation import WEIGHTS, evaluate, task_fidelity
from app.services.sections import SECTIONS, parse, render


@pytest.fixture(autouse=True)
def offline(monkeypatch):
    """No network: exercise the simulator path every provider falls back to."""
    monkeypatch.setattr(providers, "api_key", lambda provider: "")


EXTRACTION = {
    "problem_statement": "Extract invoice line items from scanned supplier PDFs and flag "
                         "mismatches against our purchase orders for the AP analyst.",
    "expected_output": "JSON array with sku, qty, unit_price, po_match",
    "constraints": ["Never guess a SKU", "Finish within five seconds"],
}
CLASSIFICATION = {
    "problem_statement": "Classify inbound support tickets by urgency so the triage team can "
                         "route them without reading each one.",
    "expected_output": "a single word: LOW, MEDIUM or HIGH",
}


# --- the output contract actually reflects the request --------------------

def test_requested_json_fields_reach_the_output_schema():
    """The schema used to be a hardcoded summary/items/warnings envelope, so a
    prompt promised one shape in Objective and specified another in Output schema."""
    state = run_workflow(EXTRACTION)
    schema = state["master_sections"]["output_schema"]
    for field in ("sku", "qty", "unit_price", "po_match"):
        assert field in schema, f"{field} was requested but never reached the schema"
    assert "```json" in schema
    assert "summary" not in schema


def test_enum_request_does_not_produce_a_json_envelope():
    state = run_workflow(CLASSIFICATION)
    schema = state["master_sections"]["output_schema"]
    assert "LOW" in schema and "MEDIUM" in schema and "HIGH" in schema
    assert "```json" not in schema


@pytest.mark.parametrize(
    ("expected", "fmt"),
    [
        ("JSON array with a, b", "json"),
        ("a single word: YES or NO", "enum"),
        ("CSV with name, email", "csv"),
        ("one JSON object per line", "json_lines"),
        ("markdown with headings", "markdown"),
        ("an XML document", "xml"),
    ],
)
def test_output_format_is_detected_from_the_request(expected, fmt):
    assert derive_output_contract(expected, "", "generation")["format"] == fmt


def test_field_names_and_types_are_inferred():
    contract = derive_output_contract("JSON with sku, qty, unit_price, po_match", "", "extraction")
    kinds = {f["name"]: f["type"] for f in contract["fields"]}
    assert kinds["sku"] == "string"
    assert kinds["qty"] == "number"
    assert kinds["po_match"] == "boolean"


def test_inputs_are_named_after_the_callers_domain_not_the_forge():
    """`{{problem_statement}}` is the forge's own input; the generated prompt has
    to declare the document it will actually be handed at runtime."""
    names = {i["name"] for i in derive_inputs(EXTRACTION["problem_statement"])}
    assert "invoice_document" in names
    assert "problem_statement" not in names

    state = run_workflow(EXTRACTION)
    inputs = state["master_sections"]["inputs"]
    assert "{{invoice_document}}" in inputs
    assert "{{problem_statement}}" not in inputs


# --- the score reflects the request ---------------------------------------

def test_weights_still_sum_to_one_hundred():
    assert sum(WEIGHTS.values()) == 100
    assert "task_fidelity" in WEIGHTS


def test_an_empty_request_cannot_score_like_a_real_one():
    """`problem_statement="x"` used to score 91.5/100 and pass QA, because no
    metric ever compared the prompt to what was asked."""
    real = run_workflow(EXTRACTION)
    thin = run_workflow({"problem_statement": "x"})
    assert thin["final_score"] < real["final_score"] - 10
    assert thin["qa_report"]["metrics"]["task_fidelity"] == 0.0
    assert real["qa_report"]["metrics"]["task_fidelity"] > 80


def test_fidelity_rewards_carrying_the_request_into_the_prompt():
    intent = IntentAnalyzer().run({**EXTRACTION, "logs": []})["intent"]
    faithful = run_workflow(EXTRACTION)["master_sections"]
    unrelated = dict.fromkeys(SECTIONS, "Write a haiku about the sea.")
    assert task_fidelity(faithful, intent) > task_fidelity(unrelated, intent)


def test_two_different_requests_do_not_score_identically():
    a = run_workflow(EXTRACTION)["final_score"]
    b = run_workflow({"problem_statement": "Write a bedtime haiku about a sleepy dragon "
                                           "for a four year old."})["final_score"]
    assert a != b


# --- specialists genuinely differ -----------------------------------------

def test_drafts_are_independent_texts_not_truncations_of_one():
    """Every draft used to be a prefix of the same hardcoded line list, so the
    shorter draft's text was always a subset of the longer one's."""
    intent = IntentAnalyzer().run({**EXTRACTION, "logs": []})["intent"]
    drafts = {p: draft_sections(p, intent, {}) for p in PROFILES}
    instructions = {p: drafts[p]["instructions"] for p in drafts}
    assert len(set(instructions.values())) == len(PROFILES)
    # No draft's instructions are contained in another's.
    for left in instructions:
        for right in instructions:
            if left != right:
                assert instructions[left] not in instructions[right]


def test_drafts_change_when_the_request_changes():
    a = IntentAnalyzer().run({**EXTRACTION, "logs": []})["intent"]
    b = IntentAnalyzer().run({**CLASSIFICATION, "logs": []})["intent"]
    assert draft_sections("openai", a, {}) != draft_sections("openai", b, {})


def test_section_winners_respond_to_the_kind_of_task():
    """Provenance was byte-identical for every request the tool had ever seen."""
    extraction = run_workflow(EXTRACTION)["provenance"]
    classification = run_workflow(CLASSIFICATION)["provenance"]
    assert extraction != classification


# --- contradictions are real ----------------------------------------------

def test_vendor_signatures_are_not_reported_as_contradictions():
    """Four cooperating drafts reported three contradictions on every run,
    because differing house style in `notes` counted as an incompatible claim."""
    intent = IntentAnalyzer().run({**EXTRACTION, "logs": []})["intent"]
    drafts = {p: draft_sections(p, intent, {}) for p in PROFILES}
    assert not [c for c in find_contradictions(drafts) if c["section"] == "notes"]


def test_a_genuine_conflict_is_reported():
    drafts = {
        "openai": {"instructions": "Always include a rationale for each decision."},
        "anthropic": {"instructions": "Never include a rationale for each decision."},
    }
    found = find_contradictions(drafts)
    assert found and found[0]["section"] == "instructions"
    assert found[0]["kind"] == "conflict"


# --- placeholders ----------------------------------------------------------

def test_declared_but_unreferenced_placeholders_are_reported():
    """Only the orphan direction was checked, so a prompt could declare knobs
    that no instruction ever read and still pass clean."""
    report = quality_report({
        "inputs": "- `{{ghost}}` — never used anywhere.",
        "instructions": "Do the thing.",
    })
    assert any(p["kind"] == "unused_placeholder" for p in report["problems"])


def test_the_generated_prompt_has_no_dead_or_orphan_placeholders():
    state = run_workflow(EXTRACTION)
    kinds = {p["kind"] for p in state["qa_report"]["problems"]}
    assert "unused_placeholder" not in kinds
    assert "placeholder" not in kinds


def test_qa_fails_when_the_schema_contradicts_the_request():
    intent = IntentAnalyzer().run({**EXTRACTION, "logs": []})["intent"]
    wrong = {"output_schema": "```json\n{\"summary\": \"string\"}\n```"}
    report = quality_report(wrong, intent)
    assert report["passed"] is False
    assert any(p["kind"] == "contract" for p in report["problems"])


# --- parser tolerance ------------------------------------------------------

@pytest.mark.parametrize(
    "text",
    [
        "## Role\nYou are X.\n## Objective\nDo Y.",
        "## 1. Role\nYou are X.\n## 2. Objective\nDo Y.",
        "**Role**\nYou are X.\n**Objective**\nDo Y.",
        "## Role & Persona\nYou are X.\n## Objective\nDo Y.",
        "```markdown\n## Role\nYou are X.\n## Objective\nDo Y.\n```",
        "### Step 1: Role\nYou are X.\n### Step 2: Goal\nDo Y.",
    ],
)
def test_parse_survives_the_ways_models_actually_write_headings(text):
    """A live reply whose headings were decorated parsed to nothing and was
    silently replaced by the template — a billed call, thrown away."""
    parsed = parse(text)
    assert parsed.get("role")
    assert parsed.get("objective")


def test_parse_ignores_headings_inside_fenced_blocks():
    parsed = parse('## Output schema\n```json\n{"# heading": 1}\n```')
    assert list(parsed) == ["output_schema"]
    assert "# heading" in parsed["output_schema"]


def test_section_round_trip_still_holds():
    sections = {"role": "You are a tester.", "objective": "Verify the parser."}
    assert parse(render(sections)) == sections


# --- live merge ------------------------------------------------------------

def test_partial_live_output_is_kept_and_backfilled():
    baseline = {key: f"baseline {key}" for key in SECTIONS}
    merged, source, notes = _merge_live("## Role\nLive role text.", baseline)
    assert merged["role"] == "Live role text."
    assert merged["objective"] == "baseline objective"
    assert source == "partial"
    assert notes and "covered only" in notes[0]


def test_unparseable_live_output_is_reported_not_hidden():
    baseline = {key: f"baseline {key}" for key in SECTIONS}
    merged, source, notes = _merge_live("Sorry, I cannot help with that.", baseline)
    assert merged == baseline
    assert source == "fallback"
    assert notes and "matched no known section headings" in notes[0]


# --- resilience ------------------------------------------------------------

def test_a_failure_in_stage_one_does_not_kill_the_run():
    """Reading `state["intent"]` inside the thread pool put the lookup outside
    the per-agent guard, so agent 1 failing raised KeyError out of the request."""
    state = run_workflow({"problem_statement": ""})
    assert state["master_content"]
    assert state["degraded"] is True
    assert state["stage"] == "degraded"


def test_total_provider_failure_still_yields_a_real_prompt():
    """The weaver used to emit eighteen "no draft supplied" stubs and score them."""
    intent = IntentAnalyzer().run({**EXTRACTION, "logs": []})["intent"]
    woven = weave({}, {}, intent, {})
    assert set(woven["sections"]) == set(SECTIONS)
    assert not any("synthesised by the weaver" in body for body in woven["sections"].values())
    assert "sku" in woven["sections"]["output_schema"]


def test_baseline_draft_is_complete():
    intent = IntentAnalyzer().run({**EXTRACTION, "logs": []})["intent"]
    assert set(baseline_draft(intent, {})) == set(SECTIONS)


def test_registry_lists_every_agent_that_runs():
    listed = {agent["name"] for agent in agent_registry()}
    ran = {log["agent"] for log in run_workflow(EXTRACTION)["logs"]}
    assert ran - listed == set()
    assert "Optimizer" in listed


# --- optimizer safety ------------------------------------------------------

def test_optimizer_never_strips_a_constraint():
    """Cross-section dedup deleted any line over 25 characters it had already
    seen, quietly removing requirements from checklists and constraint lists."""
    sections = {
        "instructions": "Never fabricate identifiers that the input does not contain.",
        "negative_constraints": "Never fabricate identifiers that the input does not contain.",
        "quality_checklist": "Never fabricate identifiers that the input does not contain.",
    }
    state = Optimizer().run({"master_sections": dict(sections), "logs": []})
    assert state["master_sections"]["negative_constraints"] == sections["negative_constraints"]
    assert state["master_sections"]["quality_checklist"] == sections["quality_checklist"]


def test_optimizer_never_empties_a_section():
    sections = {
        "role": "You are a careful reviewer of supplied documents.",
        "notes": "You are a careful reviewer of supplied documents.",
    }
    state = Optimizer().run({"master_sections": sections, "logs": []})
    assert state["master_sections"]["notes"].strip()


# --- intent analysis -------------------------------------------------------

def test_word_boundaries_stop_substring_false_positives():
    """'sketch' matched the marker 'etc' and 'goods' matched 'good'."""
    assert find_ambiguity("sketch the pipeline") == []
    assert find_ambiguity("deliver the goods") == []
    assert "etc" in find_ambiguity("handle invoices, receipts, etc")


def test_classification_still_recognises_real_verbs():
    assert classify("classify and route these tickets") == "classification"
    assert classify("summarise the thread") == "summarisation"
    assert classify("extract the fields") == "extraction"


def test_the_whole_problem_statement_survives_analysis():
    """The objective was `problem.split("\\n")[0][:220]`, so a multi-paragraph
    brief lost everything after its first line before any agent saw it."""
    statement = (
        "Extract invoice line items from supplier PDFs.\n"
        "The AP analyst then reconciles them against purchase orders.\n"
        "Anything over the agreed tolerance must be escalated to the controller."
    )
    intent = IntentAnalyzer().run({"problem_statement": statement, "logs": []})["intent"]
    assert "controller" in intent["objective"]
    assert intent["problem_statement"] == statement


def test_dropped_constraints_are_reported_not_silently_lost():
    many = [f"constraint number {i}" for i in range(20)]
    state = IntentAnalyzer().run({
        "problem_statement": "Do the work carefully for the analyst.",
        "constraints": many, "logs": [],
    })
    assert state["intent"]["dropped_constraints"]
    assert any("were not carried" in w for w in state["logs"][0]["warnings"])


def test_a_verbless_request_is_flagged_rather_than_guessed():
    state = IntentAnalyzer().run({"problem_statement": "Something about dogs.", "logs": []})
    assert state["intent"]["task_confidence"] == 0.0
    assert any("guess" in c for c in state["intent"]["clarifications"])


# --- end to end ------------------------------------------------------------

def test_the_generated_prompt_is_about_the_request():
    state = run_workflow(EXTRACTION)
    content = state["master_content"].lower()
    assert "invoice" in content
    assert "sku" in content
    assert "never guess a sku" in content
    assert state["qa_report"]["passed"]
    assert state["stage"] == "complete"
    assert evaluate(state["master_sections"], state["intent"])["total"] > 85
