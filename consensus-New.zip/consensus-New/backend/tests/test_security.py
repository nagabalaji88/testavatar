"""Coverage for the auth, RBAC and hardening behaviour, not the happy path."""
from fastapi.testclient import TestClient

from app.core import security
from app.core.config import DEFAULT_SECRET_KEY, ConfigError, Settings, _validate
from app.main import app, init_db

init_db()
client = TestClient(app)

ADMIN = {"email": "admin@forge.dev", "password": "forge1234"}
VIEWER = {"email": "viewer@forge.dev", "password": "forge1234"}


def _token(creds=ADMIN) -> str:
    response = client.post("/api/auth/login", json=creds)
    assert response.status_code == 200, response.text
    return response.json()["access_token"]


def _headers(creds=ADMIN) -> dict:
    return {"Authorization": f"Bearer {_token(creds)}"}


# --- password hashing -----------------------------------------------------

def test_hash_is_salted_so_equal_passwords_differ():
    assert security.hash_password("same-password") != security.hash_password("same-password")


def test_legacy_weak_hash_still_verifies_but_is_flagged_for_rehash():
    weak = security.hashlib.pbkdf2_hmac("sha256", b"secret", b"0" * 16, 1_000)
    stored = f"pbkdf2$1000${(b'0' * 16).hex()}${weak.hex()}"
    assert security.verify_password("secret", stored)
    assert security.needs_rehash(stored)
    assert not security.needs_rehash(security.hash_password("secret"))


def test_login_transparently_upgrades_a_weak_hash(monkeypatch):
    """A user seeded under the old cost must be re-hashed on their next sign-in."""
    from sqlalchemy import select

    from app import models
    from app.core.database import SessionLocal

    with SessionLocal() as db:
        user = db.scalar(select(models.User).where(models.User.email == VIEWER["email"]))
        salt = b"1" * 16
        digest = security.hashlib.pbkdf2_hmac("sha256", b"forge1234", salt, 1_000)
        user.password_hash = f"pbkdf2$1000${salt.hex()}${digest.hex()}"
        db.commit()

    assert client.post("/api/auth/login", json=VIEWER).status_code == 200

    with SessionLocal() as db:
        user = db.scalar(select(models.User).where(models.User.email == VIEWER["email"]))
        assert not security.needs_rehash(user.password_hash)


# --- tokens ---------------------------------------------------------------

def test_tampered_token_is_rejected():
    token = _token()
    body, sig = token.split(".")
    assert client.get("/api/auth/me", headers={"Authorization": f"Bearer {body}.{sig[:-2]}xx"}
                      ).status_code == 401


def test_expired_token_is_rejected(monkeypatch):
    monkeypatch.setattr(security.settings, "token_ttl_seconds", -1)
    token = security.create_token({"sub": "whoever", "ver": 0})
    monkeypatch.undo()
    assert client.get("/api/auth/me", headers={"Authorization": f"Bearer {token}"}
                      ).status_code == 401


def test_logout_revokes_every_outstanding_token():
    headers = _headers()
    assert client.get("/api/auth/me", headers=headers).status_code == 200
    assert client.post("/api/auth/logout", headers=headers).status_code == 204
    # Same token, now carrying a stale token_version.
    assert client.get("/api/auth/me", headers=headers).status_code == 401


def test_password_change_revokes_existing_sessions():
    creds = {"email": "rotate@forge.dev", "password": "initial-password-1"}
    admin = _headers()
    client.post("/api/users", headers=admin, json={
        "email": creds["email"], "full_name": "Rotate", "password": creds["password"],
    })
    headers = _headers(creds)
    assert client.post("/api/auth/password", headers=headers, json={
        "current_password": creds["password"], "new_password": "a-different-password-2",
    }).status_code == 204
    assert client.get("/api/auth/me", headers=headers).status_code == 401


# --- rate limiting --------------------------------------------------------

def test_login_is_rate_limited_after_repeated_failures():
    bad = {"email": "admin@forge.dev", "password": "wrong"}
    codes = [client.post("/api/auth/login", json=bad).status_code for _ in range(8)]
    assert 429 in codes, "brute-force attempts must eventually be throttled"


# --- RBAC and provisioning ------------------------------------------------

def test_non_admin_cannot_list_or_create_users():
    viewer = _headers(VIEWER)
    assert client.get("/api/users", headers=viewer).status_code == 403
    assert client.post("/api/users", headers=viewer, json={
        "email": "x@forge.dev", "full_name": "X", "password": "long-enough-pw-1",
    }).status_code == 403


def test_admin_can_provision_and_the_new_user_can_sign_in():
    admin = _headers()
    created = client.post("/api/users", headers=admin, json={
        "email": "New.Person@forge.dev", "full_name": "New Person",
        "password": "provisioned-pw-99", "role": "engineer",
    })
    assert created.status_code == 201, created.text
    assert created.json()["email"] == "new.person@forge.dev", "email must be normalised"

    assert client.post("/api/auth/login", json={
        "email": "new.person@forge.dev", "password": "provisioned-pw-99",
    }).status_code == 200


def test_duplicate_email_is_rejected():
    admin = _headers()
    payload = {"email": "dupe@forge.dev", "full_name": "Dupe", "password": "duplicate-pw-11"}
    assert client.post("/api/users", headers=admin, json=payload).status_code == 201
    assert client.post("/api/users", headers=admin, json=payload).status_code == 409


def test_deactivated_user_cannot_log_in():
    admin = _headers()
    created = client.post("/api/users", headers=admin, json={
        "email": "gone@forge.dev", "full_name": "Gone", "password": "deactivate-pw-1",
    }).json()
    client.patch(f"/api/users/{created['id']}", headers=admin, json={"is_active": False})
    assert client.post("/api/auth/login", json={
        "email": "gone@forge.dev", "password": "deactivate-pw-1",
    }).status_code == 401


def test_admin_cannot_deactivate_themselves():
    admin_headers = _headers()
    me = client.get("/api/auth/me", headers=admin_headers).json()
    assert client.patch(f"/api/users/{me['id']}", headers=admin_headers,
                        json={"is_active": False}).status_code == 400


def test_short_password_is_rejected():
    assert client.post("/api/users", headers=_headers(), json={
        "email": "weak@forge.dev", "full_name": "Weak", "password": "short",
    }).status_code == 422


# --- input limits ---------------------------------------------------------

def test_oversized_problem_statement_is_rejected():
    assert client.post("/api/generate", headers=_headers(), json={
        "problem_statement": "x" * 20_001,
    }).status_code == 422


def test_unknown_export_format_is_rejected_not_500():
    assert client.post("/api/export", headers=_headers(), json={
        "master_prompt_id": "whatever", "format": "exe",
    }).status_code == 422


def test_missing_resources_return_404_not_200():
    headers = _headers()
    assert client.get("/api/sessions/does-not-exist", headers=headers).status_code == 404
    assert client.get("/api/library/does-not-exist", headers=headers).status_code == 404


# --- response hardening ---------------------------------------------------

def test_security_headers_are_present():
    headers = client.get("/api/health").headers
    assert headers["X-Content-Type-Options"] == "nosniff"
    assert headers["X-Frame-Options"] == "DENY"


def test_metrics_endpoint_exposes_request_counters():
    client.get("/api/health")
    assert "forge_requests_total" in client.get("/metrics").text


# --- startup guards -------------------------------------------------------

def test_production_rejects_default_secret_and_sqlite():
    unsafe = Settings(env="production", secret_key=DEFAULT_SECRET_KEY,
                      database_url="sqlite:///./forge.db", cors_origins="*")
    try:
        _validate(unsafe)
    except ConfigError as exc:
        message = str(exc)
        assert "FORGE_SECRET_KEY" in message
        assert "SQLite" in message
        assert "wildcard" in message
    else:
        raise AssertionError("production config guard did not fire")


def test_development_defaults_are_allowed():
    _validate(Settings(env="development"))
