import os
import tempfile

os.environ.setdefault("FORGE_DATABASE_URL", f"sqlite:///{tempfile.mkdtemp()}/test.db")

import pytest  # noqa: E402

from app.api import deps  # noqa: E402


@pytest.fixture(autouse=True)
def reset_rate_limiter():
    """The limiter is process-global; without this one test's logins exhaust another's budget."""
    deps._hits.clear()
    yield
    deps._hits.clear()
