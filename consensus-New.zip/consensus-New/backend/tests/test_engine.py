import json

from app.agents.analysis import IntentAnalyzer, PromptPlanner, classify, find_ambiguity
from app.agents.orchestrator import run_workflow
from app.core.security import mask, seal, unseal
from app.services.consensus import agreement_matrix, jaccard, quality_report, weave
from app.services.drafting import draft_sections
from app.services.evaluation import WEIGHTS, evaluate
from app.services.export import FORMATS, render_export
from app.services.providers import PROVIDERS, estimate_cost, estimate_tokens
from app.services.sections import SECTIONS, parse, render

PAYLOAD = {
    "problem_statement": "Extract structured invoice fields from scanned PDFs and flag "
                         "anomalies for the finance team to reconcile.",
    "expected_output": "JSON with line items and a confidence per field",
    "constraints": ["never guess a total", "finish within three seconds"],
    "target_models": ["gpt-4o"],
}


def test_weights_sum_to_one_hundred():
    assert sum(WEIGHTS.values()) == 100


def test_intent_classification_and_ambiguity():
    assert classify("classify and route these tickets") == "classification"
    assert classify("summarise the thread") == "summarisation"
    assert "etc" in find_ambiguity("handle invoices, receipts, etc")


def test_intent_agent_asks_for_missing_output_shape():
    state = IntentAnalyzer().run({"problem_statement": "Do the thing well", "logs": []})
    intent = state["intent"]
    assert intent["clarifications"]
    assert intent["risks"]
    assert state["logs"][0]["confidence"] < 0.9


def test_specialists_produce_different_drafts():
    intent = IntentAnalyzer().run({**PAYLOAD, "logs": []})["intent"]
    plan = PromptPlanner().run({"intent": intent, "target_models": [], "logs": []})["plan"]
    drafts = {p: draft_sections(p, intent, plan) for p in PROVIDERS}
    rendered = {p: render(s) for p, s in drafts.items()}
    assert len(set(rendered.values())) == len(PROVIDERS)
    # Each vendor genuinely omits something, so the gaps are real.
    assert any(len(s) < len(SECTIONS) for s in drafts.values())


def test_evaluation_is_deterministic_and_bounded():
    intent = {"task_type": "extraction", "objective": "x", "constraints": [], "expected_output": ""}
    sections = draft_sections("openai", intent, {})
    first, second = evaluate(sections), evaluate(sections)
    assert first == second
    assert 0 <= first["total"] <= 100
    assert set(first["metrics"]) == set(WEIGHTS)


def test_richer_prompt_scores_higher():
    intent = {"task_type": "extraction", "objective": "x", "constraints": ["a"],
              "expected_output": ""}
    full = draft_sections("openai", intent, {})
    stripped = {"role": full["role"]}
    assert evaluate(full)["total"] > evaluate(stripped)["total"]


def test_jaccard_and_agreement_bounds():
    assert jaccard({"a", "b"}, {"a", "b"}) == 1.0
    assert jaccard({"a"}, {"b"}) == 0.0
    intent = {"task_type": "analysis", "objective": "x", "constraints": [], "expected_output": ""}
    drafts = {p: draft_sections(p, intent, {}) for p in PROVIDERS}
    matrix = agreement_matrix(drafts)
    assert 0 <= matrix["agreement"] <= 1
    assert len(matrix["pairs"]) == 6


def test_weaver_never_returns_a_single_draft():
    state = run_workflow(PAYLOAD)
    sources = set(state["provenance"].values())
    assert len(sources) > 1, "the master prompt must be a hybrid, not a copy"
    assert set(state["master_sections"]) == set(SECTIONS), "every section must be present"


def test_weaver_forces_diversity_when_one_draft_dominates():
    intent = {"task_type": "extraction", "objective": "x", "constraints": [], "expected_output": ""}
    strong = draft_sections("openai", intent, {})
    weak = dict(strong)
    drafts = {"openai": strong, "anthropic": weak}
    scores = {"openai": evaluate(strong), "anthropic": evaluate(weak)}
    scores["anthropic"]["metrics"] = {k: v - 20 for k, v in scores["anthropic"]["metrics"].items()}
    woven = weave(drafts, scores, intent)
    assert len(set(woven["provenance"].values())) > 1


def test_consensus_reports_gaps_and_unique_contributions():
    state = run_workflow(PAYLOAD)
    consensus = state["consensus"]
    assert 0 <= consensus["agreement"] <= 1
    assert consensus["unique_contributions"]
    assert all(p in consensus["unique_contributions"] for p in PROVIDERS)


def test_quality_report_flags_broken_json_and_orphan_placeholders():
    broken = {"output_schema": '```json\n{"a": }\n```', "instructions": "Use {{undeclared_var}}"}
    report = quality_report(broken)
    kinds = {p["kind"] for p in report["problems"]}
    assert "json" in kinds
    assert "placeholder" in kinds
    assert report["passed"] is False


def test_full_workflow_shape():
    state = run_workflow(PAYLOAD)
    assert state["stage"] == "complete"
    assert len(state["logs"]) == 11, "eleven agent steps, no duplicates from the parallel stage"
    assert [log["agent"] for log in state["logs"]][0] == "Intent Analyzer"
    assert state["total_tokens"] > 0
    assert state["qa_report"]["passed"]
    assert 0 < state["final_score"] <= 100


def test_every_export_format_renders():
    state = run_workflow(PAYLOAD)
    for fmt in FORMATS:
        body = render_export(fmt, "Test prompt", state["master_sections"], {"score": 90})
        assert body.strip()
    parsed = json.loads(render_export("json", "t", state["master_sections"], {}))
    assert parsed["sections"]


def test_section_round_trip():
    sections = {"role": "You are a tester.", "objective": "Verify the parser."}
    assert parse(render(sections)) == sections


def test_token_and_cost_estimation():
    assert estimate_tokens("hello world") > 0
    assert estimate_cost("openai", 1_000_000, 0) == 0.15


def test_secret_sealing_round_trip_and_masking():
    secret = "sk-proj-abcdef123456"  # noqa: S105 — fake key for a round-trip assertion
    sealed = seal(secret)
    assert secret not in sealed
    assert unseal(sealed) == secret
    assert unseal(sealed[:-2] + "xx") is None
    assert mask(secret).startswith("sk-p") and secret[6:12] not in mask(secret)
