"""Demo users, a project and one completed workflow run."""
from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from . import models
from .agents.orchestrator import run_workflow
from .core.security import hash_password
from .services.persistence import persist_run

USERS = [
    ("aarti.desai@forge.dev", "Aarti Desai", "engineer"),
    ("admin@forge.dev", "System Admin", "admin"),
    ("viewer@forge.dev", "Read Only", "viewer"),
]

DEMO_RUNS = [
    {
        "title": "Invoice field extraction",
        "problem_statement": "Extract structured invoice fields from scanned supplier PDFs, "
                             "flag anomalies such as duplicate invoice numbers or totals that "
                             "do not match the line items, and hand the result to the finance "
                             "team's reconciliation job.",
        "expected_output": "A JSON object with line items, totals and a confidence per field",
        "constraints": ["Never guess a total that is not printed on the document",
                        "Must complete within three seconds per document",
                        "No supplier PII in the warnings array"],
        "target_models": ["gpt-4o", "claude-sonnet"],
    },
    {
        "title": "Support ticket triage",
        "problem_statement": "Classify inbound support tickets by urgency and product area, "
                             "then route each one to the right on-call rota and summarise the "
                             "customer's problem in one sentence for the engineer who picks it up.",
        "expected_output": "JSON with urgency, product_area, rota and a one-line summary",
        "constraints": ["Never invent a product area that is not in the supplied list",
                        "Redact customer email addresses from the summary"],
        "target_models": ["gemini", "kimi"],
    },
]


def seed_if_empty(db: Session) -> None:
    if db.scalar(select(models.User).limit(1)):
        return

    users = {}
    for email, name, role in USERS:
        user = models.User(
            email=email, full_name=name, password_hash=hash_password("forge1234"), role=role
        )
        db.add(user)
        users[role] = user
    db.commit()

    project = models.Project(
        name="Finance automation",
        description="Prompts backing the invoice and ticket pipelines.",
        owner_id=users["engineer"].id,
    )
    db.add(project)
    db.commit()

    for payload in DEMO_RUNS:
        state = run_workflow(payload)
        persist_run(db, state, {**payload, "project_id": project.id}, users["engineer"])
