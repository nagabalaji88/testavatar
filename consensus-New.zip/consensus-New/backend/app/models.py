"""Relational model for the consensus platform."""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import JSON, Boolean, DateTime, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .core.database import Base


def _uid() -> str:
    return uuid.uuid4().hex[:16]


def _now() -> datetime:
    return datetime.now(timezone.utc)


class User(Base):
    __tablename__ = "users"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_uid)
    email: Mapped[str] = mapped_column(String(160), unique=True, index=True)
    full_name: Mapped[str] = mapped_column(String(160))
    password_hash: Mapped[str] = mapped_column(String(255))
    role: Mapped[str] = mapped_column(String(32), default="engineer")  # engineer | admin | viewer
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    # Bumped on logout, password change or forced revocation; tokens carrying an
    # older value are rejected, which is what makes a leaked token cancellable.
    token_version: Mapped[int] = mapped_column(Integer, default=0, server_default="0")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)

    projects: Mapped[list["Project"]] = relationship(back_populates="owner")


class Project(Base):
    __tablename__ = "projects"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_uid)
    name: Mapped[str] = mapped_column(String(160))
    description: Mapped[str] = mapped_column(Text, default="")
    owner_id: Mapped[Optional[str]] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)

    owner: Mapped[Optional["User"]] = relationship(back_populates="projects")
    sessions: Mapped[list["PromptSession"]] = relationship(
        back_populates="project", cascade="all, delete-orphan"
    )


class PromptSession(Base):
    """One full run of the ten-agent workflow."""

    __tablename__ = "prompt_sessions"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_uid)
    project_id: Mapped[Optional[str]] = mapped_column(ForeignKey("projects.id"))
    user_id: Mapped[Optional[str]] = mapped_column(String(32))
    title: Mapped[str] = mapped_column(String(200))
    problem_statement: Mapped[str] = mapped_column(Text)
    expected_output: Mapped[str] = mapped_column(Text, default="")
    constraints: Mapped[list] = mapped_column(JSON, default=list)
    target_models: Mapped[list] = mapped_column(JSON, default=list)
    # queued | running | complete | failed
    stage: Mapped[str] = mapped_column(String(32), default="queued", index=True)
    intent: Mapped[dict] = mapped_column(JSON, default=dict)
    plan: Mapped[dict] = mapped_column(JSON, default=dict)
    total_tokens: Mapped[int] = mapped_column(Integer, default=0)
    total_cost_usd: Mapped[float] = mapped_column(Float, default=0.0)
    duration_ms: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now, index=True)

    project: Mapped[Optional["Project"]] = relationship(back_populates="sessions")
    drafts: Mapped[list["PromptDraft"]] = relationship(
        back_populates="session", cascade="all, delete-orphan"
    )
    logs: Mapped[list["AgentLog"]] = relationship(
        back_populates="session", cascade="all, delete-orphan"
    )
    master: Mapped[Optional["MasterPrompt"]] = relationship(
        back_populates="session", cascade="all, delete-orphan", uselist=False
    )


class PromptDraft(Base):
    __tablename__ = "prompt_drafts"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_uid)
    session_id: Mapped[str] = mapped_column(ForeignKey("prompt_sessions.id"), index=True)
    provider: Mapped[str] = mapped_column(String(32))  # openai | anthropic | google | moonshot
    agent: Mapped[str] = mapped_column(String(60))
    content: Mapped[str] = mapped_column(Text)
    sections: Mapped[dict] = mapped_column(JSON, default=dict)
    tokens: Mapped[int] = mapped_column(Integer, default=0)
    cost_usd: Mapped[float] = mapped_column(Float, default=0.0)
    duration_ms: Mapped[int] = mapped_column(Integer, default=0)
    simulated: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)

    session: Mapped[PromptSession] = relationship(back_populates="drafts")
    score: Mapped[Optional["Score"]] = relationship(
        back_populates="draft", cascade="all, delete-orphan", uselist=False
    )


class Score(Base):
    __tablename__ = "scores"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_uid)
    draft_id: Mapped[str] = mapped_column(ForeignKey("prompt_drafts.id"), index=True)
    metrics: Mapped[dict] = mapped_column(JSON, default=dict)   # metric -> raw 0-100
    weighted: Mapped[dict] = mapped_column(JSON, default=dict)  # metric -> contribution
    total: Mapped[float] = mapped_column(Float, default=0.0)
    rank: Mapped[int] = mapped_column(Integer, default=0)
    notes: Mapped[list] = mapped_column(JSON, default=list)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)

    draft: Mapped[PromptDraft] = relationship(back_populates="score")


class ConsensusResult(Base):
    __tablename__ = "consensus_results"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_uid)
    session_id: Mapped[str] = mapped_column(String(32), index=True)
    agreement: Mapped[float] = mapped_column(Float, default=0.0)
    common_strengths: Mapped[list] = mapped_column(JSON, default=list)
    shared_gaps: Mapped[list] = mapped_column(JSON, default=list)
    contradictions: Mapped[list] = mapped_column(JSON, default=list)
    unique_contributions: Mapped[dict] = mapped_column(JSON, default=dict)
    section_winners: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)


class MasterPrompt(Base):
    __tablename__ = "master_prompts"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_uid)
    session_id: Mapped[str] = mapped_column(ForeignKey("prompt_sessions.id"), index=True)
    title: Mapped[str] = mapped_column(String(200))
    content: Mapped[str] = mapped_column(Text)
    sections: Mapped[dict] = mapped_column(JSON, default=dict)
    provenance: Mapped[dict] = mapped_column(JSON, default=dict)  # section -> source provider
    score: Mapped[float] = mapped_column(Float, default=0.0)
    qa_report: Mapped[dict] = mapped_column(JSON, default=dict)
    version: Mapped[int] = mapped_column(Integer, default=1)
    starred: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)

    session: Mapped[PromptSession] = relationship(back_populates="master")


class VersionHistory(Base):
    __tablename__ = "version_history"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_uid)
    master_prompt_id: Mapped[str] = mapped_column(String(32), index=True)
    version: Mapped[int] = mapped_column(Integer, default=1)
    content: Mapped[str] = mapped_column(Text)
    change_note: Mapped[str] = mapped_column(String(300), default="")
    author: Mapped[str] = mapped_column(String(160), default="system")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)


class AgentLog(Base):
    __tablename__ = "agent_logs"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_uid)
    session_id: Mapped[str] = mapped_column(ForeignKey("prompt_sessions.id"), index=True)
    agent: Mapped[str] = mapped_column(String(80))
    stage: Mapped[str] = mapped_column(String(40))
    status: Mapped[str] = mapped_column(String(24), default="complete")
    summary: Mapped[str] = mapped_column(Text, default="")
    input_digest: Mapped[str] = mapped_column(Text, default="")
    output_digest: Mapped[str] = mapped_column(Text, default="")
    tokens: Mapped[int] = mapped_column(Integer, default=0)
    cost_usd: Mapped[float] = mapped_column(Float, default=0.0)
    duration_ms: Mapped[int] = mapped_column(Integer, default=0)
    confidence: Mapped[float] = mapped_column(Float, default=0.0)
    warnings: Mapped[list] = mapped_column(JSON, default=list)
    recommendations: Mapped[list] = mapped_column(JSON, default=list)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)

    session: Mapped[PromptSession] = relationship(back_populates="logs")


class Setting(Base):
    __tablename__ = "settings"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_uid)
    key: Mapped[str] = mapped_column(String(80), unique=True)
    value: Mapped[str] = mapped_column(Text, default="")
    encrypted: Mapped[bool] = mapped_column(Boolean, default=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=_now, onupdate=_now)


class AuditEvent(Base):
    __tablename__ = "audit_events"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_uid)
    actor: Mapped[str] = mapped_column(String(160), default="system")
    action: Mapped[str] = mapped_column(String(80))
    target: Mapped[str] = mapped_column(String(200), default="")
    detail: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)
