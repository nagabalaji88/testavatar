"""PromptForge — multi-LLM consensus prompt engineering platform."""
import logging
import time
import uuid
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from prometheus_client import CONTENT_TYPE_LATEST, Counter, Histogram, generate_latest

from .api import admin, auth, library, workflow
from .core.config import settings
from .core.database import Base, SessionLocal, engine
from .seed import seed_if_empty

logging.basicConfig(
    level=logging.INFO,
    format='{"ts":"%(asctime)s","level":"%(levelname)s","logger":"%(name)s","msg":"%(message)s"}',
)
logger = logging.getLogger("forge")

REQUESTS = Counter("forge_requests_total", "HTTP requests", ["method", "path", "status"])
LATENCY = Histogram("forge_request_seconds", "HTTP request latency", ["method", "path"])


def init_db() -> None:
    """Dev convenience only. Production schema changes go through Alembic —
    `create_all` cannot alter an existing table and will silently skip changes."""
    if settings.is_production:
        logger.info("production mode: skipping create_all, run `alembic upgrade head`")
        return
    Base.metadata.create_all(bind=engine)
    with SessionLocal() as db:
        seed_if_empty(db)


@asynccontextmanager
async def lifespan(_: FastAPI):
    init_db()
    # Pick up provider keys stored through the admin UI before serving traffic,
    # so the first run is not silently simulated.
    from .services.providers import load_stored_keys
    load_stored_keys()
    yield


app = FastAPI(
    lifespan=lifespan,
    title=settings.app_name,
    version="1.0.0",
    description="Generate a master prompt by consensus across four model specialists.",
    docs_url=None if settings.is_production else "/docs",
    redoc_url=None if settings.is_production else "/redoc",
    openapi_url=None if settings.is_production else "/openapi.json",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def trace_requests(request: Request, call_next):
    """Structured access log with a correlation id — the seam for OpenTelemetry."""
    trace_id = request.headers.get("x-trace-id") or uuid.uuid4().hex[:16]
    started = time.perf_counter()
    response = await call_next(request)
    elapsed = time.perf_counter() - started

    # Template, not the raw path, so /sessions/{id} is one metric label rather than
    # one per session id.
    route = request.scope.get("route")
    label = getattr(route, "path", "unmatched")
    REQUESTS.labels(request.method, label, response.status_code).inc()
    LATENCY.labels(request.method, label).observe(elapsed)

    response.headers["x-trace-id"] = trace_id
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    if settings.is_production:
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    logger.info(
        "%s %s -> %s in %sms [%s]",
        request.method, request.url.path, response.status_code,
        int(elapsed * 1000), trace_id,
    )
    return response


for router in (auth.router, workflow.router, library.router, admin.router):
    app.include_router(router, prefix=settings.api_prefix)


@app.get("/api/status")
def status() -> dict:
    from .services.providers import CATALOG, PROVIDERS, is_live

    return {
        "status": "online",
        "app": settings.app_name,
        "providers": {
            provider: {
                "label": CATALOG[provider]["label"],
                "mode": "live" if is_live(provider) else "simulated",
            }
            for provider in PROVIDERS
        },
    }


@app.get("/api/health")
def health() -> dict:
    return {"status": "ok"}


@app.get("/metrics", include_in_schema=False)
def metrics() -> Response:
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)
