"""Password hashing and signed bearer tokens (stdlib only, no extra deps)."""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import time
from typing import Optional

from .config import settings

_ITERATIONS = 600_000  # OWASP 2023 guidance for PBKDF2-HMAC-SHA256


def hash_password(password: str, salt: Optional[bytes] = None) -> str:
    salt = salt or os.urandom(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, _ITERATIONS)
    return f"pbkdf2${_ITERATIONS}${salt.hex()}${digest.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        _, iterations, salt_hex, digest_hex = stored.split("$")
        digest = hashlib.pbkdf2_hmac(
            "sha256", password.encode(), bytes.fromhex(salt_hex), int(iterations)
        )
    except (ValueError, TypeError):
        return False
    return hmac.compare_digest(digest.hex(), digest_hex)


def needs_rehash(stored: str) -> bool:
    """True when a hash was made with a weaker cost than we now require."""
    try:
        _, iterations, _, _ = stored.split("$")
        return int(iterations) < _ITERATIONS
    except (ValueError, TypeError):
        return True


def _b64(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).decode().rstrip("=")


def _unb64(raw: str) -> bytes:
    return base64.urlsafe_b64decode(raw + "=" * (-len(raw) % 4))


def create_token(payload: dict) -> str:
    body = dict(payload)
    body["exp"] = int(time.time()) + settings.token_ttl_seconds
    encoded = _b64(json.dumps(body, separators=(",", ":")).encode())
    signature = hmac.new(settings.secret_key.encode(), encoded.encode(), hashlib.sha256).digest()
    return f"{encoded}.{_b64(signature)}"


def decode_token(token: str) -> Optional[dict]:
    try:
        encoded, signature = token.split(".")
        expected = hmac.new(
            settings.secret_key.encode(), encoded.encode(), hashlib.sha256
        ).digest()
        if not hmac.compare_digest(_unb64(signature), expected):
            return None
        payload = json.loads(_unb64(encoded))
    except (ValueError, TypeError, json.JSONDecodeError):
        return None
    if payload.get("exp", 0) < time.time():
        return None
    return payload


# --- Provider key storage -------------------------------------------------
# Keys are never stored in plaintext. This is a keystream cipher derived from
# the app secret; in production, swap `seal`/`unseal` for a KMS or Vault call.

def _keystream(nonce: bytes, length: int) -> bytes:
    stream, counter = b"", 0
    while len(stream) < length:
        stream += hashlib.sha256(
            settings.secret_key.encode() + nonce + counter.to_bytes(4, "big")
        ).digest()
        counter += 1
    return stream[:length]


def seal(plaintext: str) -> str:
    nonce = os.urandom(12)
    raw = plaintext.encode()
    cipher = bytes(a ^ b for a, b in zip(raw, _keystream(nonce, len(raw))))
    tag = hmac.new(settings.secret_key.encode(), nonce + cipher, hashlib.sha256).digest()[:16]
    return f"{_b64(nonce)}.{_b64(cipher)}.{_b64(tag)}"


def unseal(sealed: str) -> Optional[str]:
    try:
        nonce_b64, cipher_b64, tag_b64 = sealed.split(".")
        nonce, cipher = _unb64(nonce_b64), _unb64(cipher_b64)
        expected = hmac.new(
            settings.secret_key.encode(), nonce + cipher, hashlib.sha256
        ).digest()[:16]
        if not hmac.compare_digest(_unb64(tag_b64), expected):
            return None
        return bytes(a ^ b for a, b in zip(cipher, _keystream(nonce, len(cipher)))).decode()
    except (ValueError, TypeError, UnicodeDecodeError):
        return None


def mask(secret: str) -> str:
    """What the UI shows: enough to recognise a key, not enough to use it."""
    if len(secret) <= 8:
        return "•" * len(secret)
    return f"{secret[:4]}{'•' * 8}{secret[-4:]}"
