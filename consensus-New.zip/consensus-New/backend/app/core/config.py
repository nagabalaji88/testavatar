"""Settings. Every value is overridable through AEGIS-style env vars (prefix FORGE_)."""
from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict

DEFAULT_SECRET_KEY = "forge-dev-secret-change-me"  # noqa: S105 — a placeholder, not a credential


class Settings(BaseSettings):
    app_name: str = "PromptForge"
    api_prefix: str = "/api"
    env: str = "development"  # development | production
    database_url: str = "sqlite:///./forge.db"
    secret_key: str = DEFAULT_SECRET_KEY
    token_ttl_seconds: int = 60 * 60 * 12

    # Provider credentials. Any that are absent fall back to the local simulator,
    # so the full consensus workflow runs with no keys at all.
    openai_api_key: str = ""
    anthropic_api_key: str = ""
    google_api_key: str = ""
    moonshot_api_key: str = ""

    openai_model: str = "gpt-4o-mini"
    anthropic_model: str = "claude-sonnet-4-5"
    google_model: str = "gemini-2.0-flash"
    moonshot_model: str = "moonshot-v1-32k"

    request_timeout_seconds: int = 90
    max_retries: int = 2
    circuit_breaker_failures: int = 3
    rate_limit_per_minute: int = 60
    login_rate_limit_per_minute: int = 5

    cors_origins: str = "http://localhost:5173,http://127.0.0.1:5173"

    model_config = SettingsConfigDict(env_file=".env", env_prefix="FORGE_", extra="ignore")

    @property
    def is_production(self) -> bool:
        return self.env.lower() in {"production", "prod"}

    @property
    def cors_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]


class ConfigError(RuntimeError):
    """Raised at import time so a misconfigured deploy fails to boot, not silently degrades."""


def _validate(settings: "Settings") -> None:
    if not settings.is_production:
        return
    problems = []
    if settings.secret_key == DEFAULT_SECRET_KEY:
        problems.append("FORGE_SECRET_KEY is still the built-in default")
    if len(settings.secret_key) < 32:
        problems.append("FORGE_SECRET_KEY must be at least 32 characters")
    if settings.database_url.startswith("sqlite"):
        problems.append(
            "FORGE_DATABASE_URL points at SQLite, which cannot serve concurrent workers"
        )
    if not settings.cors_list or "*" in settings.cors_list:
        problems.append("FORGE_CORS_ORIGINS must list explicit origins, not a wildcard")
    if problems:
        raise ConfigError(
            "Refusing to start with FORGE_ENV=production:\n  - " + "\n  - ".join(problems)
        )


@lru_cache
def get_settings() -> Settings:
    settings = Settings()
    _validate(settings)
    return settings


settings = get_settings()
