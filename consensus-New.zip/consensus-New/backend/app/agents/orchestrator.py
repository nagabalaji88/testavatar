"""LangGraph-shaped workflow: ten stages, one of which fans out across providers."""
from __future__ import annotations

import logging
import time
from typing import Optional

from ..services.providers import PROVIDERS
from ..services.sections import SECTIONS
from .analysis import IntentAnalyzer, PromptPlanner
from .base import State
from .specialists import Specialist, run_specialists
from .synthesis import ConsensusBuilder, MasterWeaver, Optimizer, PromptEvaluator, QualityAssurance

logger = logging.getLogger("forge.workflow")

STAGES = [
    "input_analysis", "intent", "planning", "drafting", "evaluation",
    "consensus", "weaving", "validation", "optimization", "export",
]


def agent_registry() -> list[dict]:
    """Used by the Agent Monitor screen and the /agents endpoint."""
    agents = [IntentAnalyzer(), PromptPlanner(), *[Specialist(p) for p in PROVIDERS],
              PromptEvaluator(), ConsensusBuilder(), MasterWeaver(), QualityAssurance(),
              # The Optimizer runs in every workflow and writes a log entry, but was
              # absent here, so the monitor listed ten agents against eleven logs.
              Optimizer()]
    return [
        {"index": index, "name": a.name, "stage": a.stage, "description": a.description}
        for index, a in enumerate(agents, start=1)
    ]


def _degraded_intent(payload: dict, reason: str) -> dict:
    """A minimal but usable intent, so a failure in stage 1 does not end the run."""
    from ..services.derivation import derive_inputs, derive_output_contract, derive_variables

    problem = (payload.get("problem_statement") or "").strip() or "(no problem statement supplied)"
    contract = derive_output_contract(payload.get("expected_output", ""), problem, "generation")
    return {
        "objective": problem[:600],
        "problem_statement": problem,
        "task_type": "generation",
        "task_confidence": 0.0,
        "constraints": [c for c in (payload.get("constraints") or []) if str(c).strip()],
        "dropped_constraints": [],
        "expected_output": payload.get("expected_output", ""),
        "output_contract": contract,
        "inputs": derive_inputs(problem, payload.get("context", "")),
        "variables": derive_variables(contract, payload.get("constraints") or []),
        "context": payload.get("context", ""),
        "business_goal": payload.get("business_goal", ""),
        "ambiguities": [],
        "risks": [f"intent analysis degraded: {reason}"],
        "clarifications": ["Intent analysis failed; review every section by hand."],
        "degraded": True,
    }


def _degraded_plan(intent: dict, payload: dict) -> dict:
    targets = payload.get("target_models") or []
    return {
        "sections": SECTIONS,
        "persona": f"a specialist in {intent['task_type']} work",
        "target_models": targets,
        "target_label": ", ".join(targets) if targets else "provider-neutral",
        "must_include": ["output_schema", "negative_constraints", "edge_cases"],
        "open_questions": intent.get("clarifications", []),
        "output_format": intent["output_contract"]["format"],
        "input_names": [i["name"] for i in intent["inputs"]],
        "variable_names": [v["name"] for v in intent["variables"]],
        "degraded": True,
    }


def run_workflow(payload: dict, providers: Optional[list[str]] = None) -> State:
    started = time.perf_counter()
    providers = [p for p in (providers or PROVIDERS) if p in PROVIDERS] or PROVIDERS

    state: State = {
        "problem_statement": payload.get("problem_statement", ""),
        "expected_output": payload.get("expected_output", ""),
        "constraints": payload.get("constraints", []),
        "target_models": payload.get("target_models", []),
        "context": payload.get("context", ""),
        "business_goal": payload.get("business_goal", ""),
        "logs": [],
    }
    warnings: list[str] = []

    state = IntentAnalyzer().run(state)
    if not state.get("intent"):
        # `Agent.run` swallows the exception and logs it, but every later stage
        # reads `state["intent"]` — including the thread pool, where the KeyError
        # escaped the guard entirely and failed the request.
        reason = state["logs"][-1]["summary"] if state["logs"] else "unknown error"
        logger.warning("intent analysis failed (%s); continuing degraded", reason)
        state["intent"] = _degraded_intent(payload, reason)
        warnings.append(f"intent analysis failed: {reason}")

    state = PromptPlanner().run(state)
    if not state.get("plan"):
        reason = state["logs"][-1]["summary"] if state["logs"] else "unknown error"
        state["plan"] = _degraded_plan(state["intent"], payload)
        warnings.append(f"planning failed: {reason}")

    try:
        state = run_specialists(state, providers)
    except Exception as exc:  # noqa: BLE001 — the weaver can still write from intent
        logger.warning("every specialist failed: %s", exc)
        warnings.append(f"drafting stage failed: {type(exc).__name__}: {exc}")
        state.setdefault("drafts", {})
        state.setdefault("draft_meta", {})

    state = PromptEvaluator().run(state)
    state = ConsensusBuilder().run(state)
    state = MasterWeaver().run(state)
    state = QualityAssurance().run(state)
    state = Optimizer().run(state)

    if not state.get("master_content"):
        # Weaving or optimisation fell over; emit the provider-neutral draft so
        # the caller still receives a prompt rather than an empty payload.
        from ..services.drafting import baseline_draft
        from ..services.sections import render

        state["master_sections"] = baseline_draft(state["intent"], state["plan"])
        state["provenance"] = dict.fromkeys(state["master_sections"], "weaver")
        state["master_content"] = render(state["master_sections"])
        state.setdefault("qa_report", {"passed": False, "problems": [], "score": 0,
                                       "metrics": {}, "weights": {}, "placeholders": []})
        state["final_score"] = state["qa_report"].get("score", 0)
        warnings.append("synthesis failed; returned the provider-neutral baseline prompt")

    # Everything downstream (persistence, the API response, the UI) indexes these
    # directly, so guarantee them rather than letting a degraded run 500 later.
    state.setdefault("drafts", {})
    state.setdefault("draft_meta", {})
    state.setdefault("scores", {})
    state.setdefault("ranking", [])
    state.setdefault("provenance", {})
    state.setdefault("master_sections", {})
    state.setdefault("final_score", 0.0)
    state.setdefault("consensus", {
        "agreement": 0.0, "pairs": {}, "common_strengths": [], "shared_gaps": [],
        "contradictions": [], "unique_contributions": {},
    })
    state.setdefault("qa_report", {"passed": False, "problems": [], "score": 0,
                                   "metrics": {}, "weights": {}, "placeholders": []})

    meta = state.get("draft_meta", {})
    state["total_tokens"] = sum(m["tokens"] for m in meta.values())
    state["total_cost_usd"] = round(sum(m["cost_usd"] for m in meta.values()), 6)
    state["duration_ms"] = int((time.perf_counter() - started) * 1000)
    state["warnings"] = warnings
    state["degraded"] = bool(warnings)
    state["stage"] = "degraded" if warnings else "complete"
    return state
