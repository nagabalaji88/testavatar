"""Agents 7-10 — evaluation, consensus, weaving and quality assurance."""
from __future__ import annotations

from ..services.consensus import analyse, quality_report, weave
from ..services.evaluation import evaluate
from ..services.sections import render
from .base import Agent, State


class PromptEvaluator(Agent):
    name = "Prompt Evaluator"
    stage = "evaluation"
    description = "Scores every draft against the ten-metric weighted matrix."

    def handle(self, state: State):
        intent = state.get("intent")
        scores = {
            p: evaluate(sections, intent) for p, sections in state.get("drafts", {}).items()
        }
        ranking = sorted(scores.items(), key=lambda kv: kv[1]["total"], reverse=True)
        for rank, (_provider, score) in enumerate(ranking, start=1):
            score["rank"] = rank
        state["scores"] = scores
        state["ranking"] = [p for p, _ in ranking]
        if not ranking:
            return state, {
                "summary": "No drafts to score — every specialist failed.",
                "output_digest": "",
                "confidence": 0.0,
                "warnings": ["scoring skipped: no provider produced a draft"],
            }
        leader = ranking[0]
        spread = round(ranking[0][1]["total"] - ranking[-1][1]["total"], 1)
        return state, {
            "summary": f"{leader[0]} leads at {leader[1]['total']}/100; "
                       f"spread across drafts is {spread} points.",
            "output_digest": " > ".join(state["ranking"]),
            "confidence": 0.92,
            "recommendations": ranking[-1][1]["notes"][:2],
        }


class ConsensusBuilder(Agent):
    name = "Consensus Builder"
    stage = "consensus"
    description = "Finds shared strengths, shared gaps, contradictions and unique ideas."

    def handle(self, state: State):
        result = analyse(state.get("drafts", {}), state.get("scores", {}))
        state["consensus"] = result
        return state, {
            "summary": f"Agreement {result['agreement']:.0%} across drafts; "
                       f"{len(result['contradictions'])} contradictions and "
                       f"{len(result['shared_gaps'])} shared gaps found.",
            "output_digest": ", ".join(g["metric"] for g in result["shared_gaps"][:4]),
            "confidence": 0.85 if state.get("drafts") else 0.0,
            "warnings": [
                f"{c['section']}: {c['detail']}" for c in result["contradictions"][:3]
            ],
        }


class MasterWeaver(Agent):
    name = "Master Weaver"
    stage = "weaving"
    description = "Merges the strongest section from each draft into one hybrid prompt."

    def handle(self, state: State):
        woven = weave(
            state.get("drafts", {}), state.get("scores", {}),
            state["intent"], state.get("plan", {}),
        )
        state["master_sections"] = woven["sections"]
        state["provenance"] = woven["provenance"]
        sources = {v for v in woven["provenance"].values() if v != "weaver"}
        warnings = []
        if not sources:
            warnings.append(
                "no provider draft survived — the whole prompt was written from the intent"
            )
        return state, {
            "summary": f"Wove {len(woven['sections'])} sections from {len(sources)} providers; "
                       f"{len(woven['filled'])} sections synthesised where no draft supplied one.",
            "output_digest": ", ".join(sorted(sources)),
            "confidence": 0.9 if sources else 0.5,
            "warnings": warnings,
            "recommendations": [f"synthesised: {s}" for s in woven["filled"][:3]],
        }


class QualityAssurance(Agent):
    name = "Quality Assurance"
    stage = "validation"
    description = "Validates JSON, XML, markdown, placeholders and hallucination risk."

    def handle(self, state: State):
        report = quality_report(state["master_sections"], state.get("intent"))
        state["qa_report"] = report
        blocking = [p for p in report["problems"]
                    if p["kind"] in {"json", "xml", "markdown", "contract"}]
        return state, {
            "summary": f"{'Passed' if report['passed'] else 'Failed'} structural validation "
                       f"with {len(report['problems'])} finding(s); score {report['score']}/100.",
            "output_digest": ", ".join(p["kind"] for p in report["problems"][:5]),
            "confidence": 0.95 if report["passed"] else 0.6,
            "warnings": [f"{p['kind']}: {p['detail']}" for p in blocking],
            "recommendations": [
                p["detail"] for p in report["problems"] if p["kind"] not in
                {"json", "xml", "markdown", "contract"}
            ][:3],
        }


class Optimizer(Agent):
    """Stage 9 — token trimming without losing an instruction."""

    name = "Optimizer"
    stage = "optimization"
    description = "Removes duplicated lines across sections and reports the token saving."

    # Repetition is load-bearing in these sections: a checklist item that restates
    # an instruction is the point of a checklist, and a constraint repeated as a
    # negative constraint is a deliberate belt-and-braces. Cross-section dedup
    # used to strip them, quietly deleting requirements from the final prompt.
    PROTECTED = {
        "constraints", "negative_constraints", "validation_rules",
        "quality_checklist", "edge_cases", "output_schema", "inputs", "variables",
    }

    def handle(self, state: State):
        sections = state["master_sections"]
        seen: set[str] = set()
        removed: list[str] = []
        for key in list(sections):
            body = sections[key]
            if key in self.PROTECTED:
                # Still register the lines so later sections dedup against them.
                for line in body.splitlines():
                    if line.strip():
                        seen.add(line.strip().lower())
                continue
            kept: list[str] = []
            for line in body.splitlines():
                normalised = line.strip().lower()
                is_duplicate = (
                    normalised
                    and normalised in seen
                    and len(normalised) > 25
                    and not normalised.startswith("```")
                )
                if is_duplicate:
                    removed.append(f"{key}: {line.strip()[:60]}")
                    continue
                if normalised:
                    seen.add(normalised)
                kept.append(line)
            trimmed = "\n".join(kept).strip()
            # Never empty a section out entirely — a section that exists but says
            # nothing is worse than a redundant line.
            sections[key] = trimmed or body.strip()

        state["master_sections"] = sections
        state["master_content"] = render(sections)
        state["final_score"] = evaluate(sections, state.get("intent"))["total"]
        return state, {
            "summary": f"Removed {len(removed)} duplicated line(s); final prompt scores "
                       f"{state['final_score']}/100.",
            "output_digest": f"{len(state['master_content'].split())} words",
            "confidence": 0.9,
            "recommendations": removed[:3],
        }
