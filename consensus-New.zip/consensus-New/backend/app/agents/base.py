"""Agent contract shared by all ten agents."""
from __future__ import annotations

import time
from typing import Any

State = dict[str, Any]


class Agent:
    name: str = "agent"
    stage: str = "stage"
    description: str = ""

    def handle(self, state: State) -> tuple[State, dict]:
        """Return (state, log payload). Log payload keys are optional."""
        raise NotImplementedError

    def run(self, state: State) -> State:
        started = time.perf_counter()
        try:
            state, log = self.handle(state)
            status = "complete"
        except Exception as exc:  # noqa: BLE001 - one bad agent must not kill the run
            log = {"summary": f"{type(exc).__name__}: {exc}", "confidence": 0.0}
            status = "failed"
        entry = {
            "agent": self.name,
            "stage": self.stage,
            "status": status,
            "summary": log.get("summary", ""),
            "input_digest": log.get("input_digest", ""),
            "output_digest": log.get("output_digest", ""),
            "tokens": log.get("tokens", 0),
            "cost_usd": log.get("cost_usd", 0.0),
            "duration_ms": int((time.perf_counter() - started) * 1000),
            "confidence": log.get("confidence", 0.75),
            "warnings": log.get("warnings", []),
            "recommendations": log.get("recommendations", []),
        }
        state.setdefault("logs", []).append(entry)
        return state
