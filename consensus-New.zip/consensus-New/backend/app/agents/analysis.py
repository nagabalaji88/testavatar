"""Agents 1 and 2 — intent extraction and prompt planning."""
from __future__ import annotations

import re

from ..services.derivation import derive_inputs, derive_output_contract, derive_variables
from ..services.sections import SECTIONS
from .base import Agent, State

TASK_SIGNALS = {
    "extraction": ["extract", "parse", "pull out", "identify fields", "scrape", "capture"],
    "classification": ["classify", "categorise", "categorize", "label", "triage", "route",
                       "tag", "sort into"],
    "generation": ["write", "draft", "generate", "compose", "create", "author"],
    "summarisation": ["summarise", "summarize", "condense", "tl;dr", "digest", "brief",
                      "one page", "recap"],
    "transformation": ["convert", "translate", "rewrite", "reformat", "migrate", "normalise",
                       "normalize"],
    "analysis": ["analyse", "analyze", "evaluate", "assess", "compare", "review", "audit"],
    "agentic": ["tool", "function call", "agent", "workflow", "orchestrate", "multi-step"],
}

AMBIGUITY_MARKERS = [
    "etc", "and so on", "something like", "appropriate", "as needed", "reasonable",
    "good", "nice", "better", "handle it", "figure out", "as appropriate", "or similar",
    "make sense", "properly", "correctly",
]

# Substring matching used to fire on any word that merely contained a marker —
# "sketch" counted as "etc", "goods" as "good", "Recreate" as "create". Every
# lookup below is anchored to word boundaries instead.
_TASK_PATTERNS = {
    task: [re.compile(rf"\b{re.escape(marker)}\b", re.I) for marker in markers]
    for task, markers in TASK_SIGNALS.items()
}
_AMBIGUITY_PATTERNS = [
    (marker, re.compile(rf"\b{re.escape(marker)}\b", re.I)) for marker in AMBIGUITY_MARKERS
]

# Consulted when two task types tie on hit count, so the winner is a documented
# choice rather than whichever key `TASK_SIGNALS` happened to declare first.
_TASK_PRIORITY = [
    "agentic", "extraction", "classification", "summarisation",
    "transformation", "analysis", "generation",
]


def classify(text: str) -> str:
    """Best task type for the request. Ties break by specificity, not dict order."""
    return classify_with_confidence(text)[0]


def classify_with_confidence(text: str) -> tuple[str, float, dict[str, int]]:
    """Task type plus how strongly the evidence supports it."""
    hits = {
        task: sum(1 for pattern in patterns if pattern.search(text))
        for task, patterns in _TASK_PATTERNS.items()
    }
    best = max(hits.values())
    if best == 0:
        # Nothing matched: "generation" is the default, and the caller deserves
        # to know it was a fallback rather than a finding.
        return "generation", 0.0, hits
    tied = [task for task, count in hits.items() if count == best]
    winner = min(tied, key=lambda task: _TASK_PRIORITY.index(task))
    total = sum(hits.values())
    confidence = round(best / total, 2) if total else 0.0
    if len(tied) > 1:
        confidence = round(confidence * 0.7, 2)
    return winner, confidence, hits


def find_ambiguity(text: str) -> list[str]:
    return [marker for marker, pattern in _AMBIGUITY_PATTERNS if pattern.search(text)]


def _objective(problem: str) -> str:
    """The whole request, whitespace-collapsed.

    Taking `split("\\n")[0][:220]` silently discarded everything after the first
    line, so a multi-paragraph brief lost most of its content before any agent
    ever saw it.
    """
    collapsed = re.sub(r"\s+", " ", (problem or "").strip())
    if len(collapsed) <= 600:
        return collapsed
    # Cut on a sentence boundary rather than mid-word.
    head = collapsed[:600]
    cut = max(head.rfind(". "), head.rfind("? "), head.rfind("! "))
    return (head[: cut + 1] if cut > 300 else head.rstrip()) + " […]"


MAX_CONSTRAINTS = 12


class IntentAnalyzer(Agent):
    name = "Intent Analyzer"
    stage = "intent"
    description = "Extracts objective, constraints, risks and the questions worth asking."

    def handle(self, state: State):
        problem = (state.get("problem_statement") or "").strip()
        if not problem:
            raise ValueError("problem_statement is empty — there is nothing to analyse")
        constraints = [c for c in (state.get("constraints") or []) if str(c).strip()]
        task_type, task_confidence, _hits = classify_with_confidence(problem)
        vague = find_ambiguity(problem)
        expected_output = state.get("expected_output", "")

        contract = derive_output_contract(expected_output, problem, task_type)
        inputs = derive_inputs(problem, state.get("context", ""))
        variables = derive_variables(contract, constraints)

        clarifications: list[str] = []
        if not expected_output:
            clarifications.append("What exact output format should the caller receive?")
        if not constraints:
            clarifications.append("What must the answer never do?")
        if vague:
            clarifications.append(
                f"These terms are open to interpretation: {', '.join(vague[:4])}."
            )
        if not re.search(r"\b(user|customer|team|analyst|engineer|caller|reviewer|agent)\b",
                         problem, re.I):
            clarifications.append("Who consumes the output, and what do they do with it?")
        if task_confidence == 0.0:
            clarifications.append(
                "The request does not name an action verb, so the task type is a guess."
            )
        for note in contract["notes"]:
            clarifications.append(f"Output contract: {note}.")

        risks = []
        if task_type in {"extraction", "analysis"}:
            risks.append("Fabricated values when the source lacks the requested field.")
        if len(problem.split()) < 25:
            risks.append("The statement is short; the model will fill gaps with assumptions.")
        if not expected_output:
            risks.append("Undefined output shape makes downstream parsing unreliable.")
        if task_confidence and task_confidence < 0.5:
            risks.append(
                f"Task type '{task_type}' was inferred from mixed signals; confirm it."
            )

        dropped = constraints[MAX_CONSTRAINTS:]
        warnings = [f"ambiguous wording: {v}" for v in vague[:3]]
        if dropped:
            warnings.append(
                f"{len(dropped)} constraint(s) beyond the first {MAX_CONSTRAINTS} were not "
                f"carried into the prompt: {'; '.join(dropped)[:160]}"
            )

        intent = {
            "objective": _objective(problem),
            "problem_statement": problem,
            "task_type": task_type,
            "task_confidence": task_confidence,
            "constraints": constraints[:MAX_CONSTRAINTS],
            "dropped_constraints": dropped,
            "expected_output": expected_output,
            "output_contract": contract,
            "inputs": inputs,
            "variables": variables,
            "context": state.get("context", ""),
            "business_goal": state.get("business_goal", ""),
            "ambiguities": vague,
            "risks": risks,
            "clarifications": clarifications,
        }
        state["intent"] = intent
        confidence = round(max(0.35, 0.95 - 0.1 * len(clarifications) - 0.04 * len(vague)), 2)
        return state, {
            "summary": f"Classified as a {task_type} task with {len(intent['constraints'])} "
                       f"explicit constraints, a {contract['format']} output contract and "
                       f"{len(clarifications)} open questions.",
            "input_digest": problem[:280],
            "output_digest": f"task={task_type} format={contract['format']} risks={len(risks)}",
            "confidence": confidence,
            "warnings": warnings,
            "recommendations": clarifications[:3],
        }


class PromptPlanner(Agent):
    name = "Prompt Planner"
    stage = "planning"
    description = "Turns intent into the modular section brief every specialist writes against."

    def handle(self, state: State):
        intent = state["intent"]
        targets = state.get("target_models") or []
        contract = intent["output_contract"]
        plan = {
            "sections": SECTIONS,
            "persona": f"a specialist in {intent['task_type']} work",
            "target_models": targets,
            "target_label": ", ".join(targets) if targets else "provider-neutral",
            "must_include": ["output_schema", "negative_constraints", "edge_cases"],
            "open_questions": intent["clarifications"],
            "output_format": contract["format"],
            "input_names": [i["name"] for i in intent["inputs"]],
            "variable_names": [v["name"] for v in intent["variables"]],
        }
        state["plan"] = plan
        return state, {
            "summary": f"Planned {len(SECTIONS)} sections for {plan['target_label']} targets "
                       f"around a {contract['format']} output contract.",
            "output_digest": ", ".join(plan["must_include"]),
            "confidence": 0.88,
            "recommendations": ["Resolve open questions before shipping the prompt."]
            if plan["open_questions"] else [],
        }
