"""Agents 3-6 — the four provider specialists, run in parallel."""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor

from ..services.drafting import PROFILES, draft_sections
from ..services.providers import CATALOG, complete
from ..services.sections import HEADINGS, SECTIONS, coverage, parse, render
from .base import Agent, State

SYSTEM = (
    "You are a prompt engineering specialist. You write reusable master prompts that other "
    "systems will run unattended.\n"
    "Return markdown only. Use one `## ` heading per section, taken verbatim from the list you "
    "are given, in the order given. Write the body of every section — never leave one empty and "
    "never add a section that is not on the list. Do not wrap the whole reply in a code fence "
    "and do not write anything before the first heading or after the last section."
)

# Below this share of the canonical sections a live reply is treated as partial:
# what parsed is kept, the rest is backfilled from the local draft.
MIN_LIVE_COVERAGE = 0.5

_SECTION_BRIEF = {
    "role": "who the model is and what it refuses to do",
    "objective": "what success means, in one or two lines",
    "context": "the operating environment and how untrusted input is treated",
    "business_goal": "why this matters to the business",
    "inputs": "each runtime placeholder, named and described",
    "variables": "tunable knobs with defaults, each one referenced elsewhere in the prompt",
    "execution_plan": "the ordered procedure the model follows",
    "instructions": "the specific directives for this task",
    "reasoning_strategy": "how to think, and what to keep private",
    "constraints": "hard requirements, one per line",
    "negative_constraints": "what must never happen, one per line",
    "validation_rules": "what the model checks before answering",
    "output_schema": "the exact output contract, fenced if it is a data format",
    "examples": "one worked example and one counter-example",
    "edge_cases": "empty, contradictory, oversized and adversarial input",
    "quality_checklist": "a short pre-flight checklist",
    "failure_recovery": "what to do when the contract cannot be met",
    "notes": "anything the maintainer of this prompt needs to know",
}


def _user_message(intent: dict, plan: dict, provider: str) -> str:
    """Everything the specialist needs.

    The live call used to receive the objective, the constraints and a bare list
    of section keys — less information than the local simulator had, which is why
    live drafts scored no better than simulated ones.
    """
    contract = intent.get("output_contract") or {}
    inputs = intent.get("inputs") or []
    variables = intent.get("variables") or []
    constraints = intent.get("constraints") or []

    lines = [
        f"Task type: {intent.get('task_type', 'generation')}",
        f"Objective: {intent.get('objective', '')}",
        f"Original request: {intent.get('problem_statement', '')}",
    ]
    if intent.get("context"):
        lines.append(f"Operating context: {intent['context']}")
    if intent.get("business_goal"):
        lines.append(f"Business goal: {intent['business_goal']}")
    lines.append(
        f"Required output format: {contract.get('format', 'text')}"
        + (f" — {contract['stated']}" if contract.get("stated") else "")
    )
    if contract.get("fields"):
        lines.append(
            "Required fields: "
            + ", ".join(f"{f['name']} ({f['type']})" for f in contract["fields"])
        )
    if contract.get("enum_values"):
        lines.append(f"Allowed labels: {', '.join(contract['enum_values'])}")
    lines.append(
        "Exact output schema to reproduce in the Output schema section:\n"
        f"{contract.get('schema', '(none derived — define one)')}"
    )
    if inputs:
        lines.append(
            "Runtime placeholders this prompt must declare and use: "
            + ", ".join(f"{{{{{i['name']}}}}} ({i['description']})" for i in inputs)
        )
    if variables:
        lines.append(
            "Tunable variables (declare each, and reference each at least once elsewhere): "
            + ", ".join(f"{{{{{v['name']}}}}} default {v['default']}" for v in variables)
        )
    if constraints:
        lines.append("Hard constraints:\n" + "\n".join(f"- {c}" for c in constraints))
    if intent.get("ambiguities"):
        lines.append(
            "Ambiguous wording to pin down rather than repeat: "
            + ", ".join(intent["ambiguities"][:6])
        )
    if intent.get("risks"):
        lines.append("Known risks to defend against:\n"
                     + "\n".join(f"- {r}" for r in intent["risks"]))
    lines.append(f"Emphasise, as this is your specialism: {', '.join(PROFILES[provider]['deep'])}")
    lines.append(f"Target models: {plan.get('target_label', 'provider-neutral')}")
    lines.append(
        "Write these sections, in this order, using exactly these headings:\n"
        + "\n".join(
            f"## {HEADINGS[key]} — {_SECTION_BRIEF.get(key, '')}"
            for key in plan.get("sections", SECTIONS)
        )
    )
    return "\n\n".join(lines)


class Specialist(Agent):
    """One vendor's draft. Live when a key is configured, simulated otherwise."""

    provider: str = "openai"
    stage = "drafting"

    def __init__(self, provider: str) -> None:
        self.provider = provider
        spec = CATALOG[provider]
        self.name = f"{spec['label']} Specialist"
        self.description = f"Optimises for {', '.join(spec['strengths'])}."

    def handle(self, state: State):
        intent, plan = state["intent"], state["plan"]
        baseline = draft_sections(self.provider, intent, plan)

        user = _user_message(intent, plan, self.provider)
        result = complete(self.provider, SYSTEM, user, simulator=lambda: render(baseline))
        warnings = list(result.warnings)

        if result.simulated:
            sections, source = baseline, "simulated"
        else:
            sections, source, notes = _merge_live(result.text, baseline)
            warnings.extend(notes)

        state.setdefault("drafts", {})[self.provider] = sections
        state.setdefault("draft_meta", {})[self.provider] = {
            "tokens": result.tokens,
            "cost_usd": result.cost_usd,
            "duration_ms": result.duration_ms,
            "simulated": result.simulated,
            "source": source,
            "agent": self.name,
            "content": render(sections),
        }
        return state, {
            "summary": f"Drafted {len(sections)} sections ({source} inference).",
            "output_digest": ", ".join(list(sections)[:6]),
            "tokens": result.tokens,
            "cost_usd": result.cost_usd,
            "confidence": 0.7 if result.simulated else (0.9 if source == "live" else 0.8),
            "warnings": warnings,
        }


def _merge_live(text: str, baseline: dict[str, str]) -> tuple[dict[str, str], str, list[str]]:
    """Keep whatever the provider actually returned; backfill the rest.

    A live reply whose headings did not match was previously discarded whole and
    replaced by the template, with no warning — the call was billed and the
    result thrown away. Anything parseable is now kept, and the shortfall is
    reported rather than hidden.
    """
    parsed = parse(text)
    notes: list[str] = []
    if not parsed:
        notes.append(
            "live reply matched no known section headings — the local draft was used instead; "
            "check the model's output format"
        )
        return baseline, "fallback", notes

    got = coverage(parsed)
    if got >= MIN_LIVE_COVERAGE:
        missing = [s for s in SECTIONS if not parsed.get(s) and baseline.get(s)]
        if missing:
            merged = dict(parsed)
            for key in missing:
                merged[key] = baseline[key]
            notes.append(
                f"live reply covered {got:.0%} of the sections; backfilled from the local draft: "
                f"{', '.join(missing)}"
            )
            return merged, "live+backfill", notes
        return parsed, "live", notes

    merged = dict(baseline)
    merged.update(parsed)
    notes.append(
        f"live reply covered only {got:.0%} of the sections; kept {len(parsed)} live section(s) "
        f"and used the local draft for the rest"
    )
    return merged, "partial", notes


def run_specialists(state: State, providers: list[str]) -> State:
    """Stage 4 runs the four vendors concurrently — they do not depend on each other."""
    if not state.get("intent") or not state.get("plan"):
        # Reading these inside the worker put the lookup outside `Agent.run`'s
        # guard, so a failure in agent 1 surfaced as a KeyError from the thread
        # pool and took the whole request down with it.
        raise ValueError("run_specialists needs both `intent` and `plan` in state")

    agents = [Specialist(provider) for provider in providers]
    # Each specialist gets its own slice of state so the threads never share a
    # mutable list; only its own draft and log entry are merged back.
    def _isolated(agent: Specialist) -> State:
        return agent.run({"intent": state["intent"], "plan": state["plan"], "logs": []})

    with ThreadPoolExecutor(max_workers=len(agents) or 1) as pool:
        results = list(pool.map(_isolated, agents))

    for partial in results:
        state.setdefault("drafts", {}).update(partial.get("drafts", {}))
        state.setdefault("draft_meta", {}).update(partial.get("draft_meta", {}))
        state.setdefault("logs", []).extend(partial.get("logs", []))
    return state
