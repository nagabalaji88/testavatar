"""Operator commands. Run with `python -m app.cli <command>`.

Production skips the demo seed, so `create-admin` is how the first account exists at all.
"""
from __future__ import annotations

import argparse
import getpass
import sys
from typing import Optional

from sqlalchemy import select

from . import models
from .core.database import SessionLocal
from .core.security import hash_password

MIN_PASSWORD_LENGTH = 12


def create_admin(email: str, full_name: str, password: Optional[str]) -> int:
    password = password or getpass.getpass("Password: ")
    if len(password) < MIN_PASSWORD_LENGTH:
        print(f"Password must be at least {MIN_PASSWORD_LENGTH} characters.", file=sys.stderr)
        return 1
    with SessionLocal() as db:
        if db.scalar(select(models.User).where(models.User.email == email.lower())):
            print(f"{email} already has an account.", file=sys.stderr)
            return 1
        db.add(models.User(
            email=email.lower(), full_name=full_name, role="admin",
            password_hash=hash_password(password),
        ))
        db.add(models.AuditEvent(actor="cli", action="user.create", target=email.lower()))
        db.commit()
    print(f"Created admin {email}")
    return 0


def reset_password(email: str, password: Optional[str]) -> int:
    password = password or getpass.getpass("New password: ")
    if len(password) < MIN_PASSWORD_LENGTH:
        print(f"Password must be at least {MIN_PASSWORD_LENGTH} characters.", file=sys.stderr)
        return 1
    with SessionLocal() as db:
        user = db.scalar(select(models.User).where(models.User.email == email.lower()))
        if not user:
            print(f"No account for {email}.", file=sys.stderr)
            return 1
        user.password_hash = hash_password(password)
        user.token_version += 1
        db.add(models.AuditEvent(actor="cli", action="user.password_reset", target=user.email))
        db.commit()
    print(f"Reset password for {email}; existing sessions were revoked.")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(prog="app.cli")
    sub = parser.add_subparsers(dest="command", required=True)

    admin = sub.add_parser("create-admin", help="create the first admin account")
    admin.add_argument("--email", required=True)
    admin.add_argument("--name", required=True)
    admin.add_argument("--password",
                       help="omit to be prompted, which keeps it out of shell history")

    reset = sub.add_parser("reset-password", help="reset any account's password")
    reset.add_argument("--email", required=True)
    reset.add_argument("--password", help="omit to be prompted")

    args = parser.parse_args()
    if args.command == "create-admin":
        return create_admin(args.email, args.name, args.password)
    return reset_password(args.email, args.password)


if __name__ == "__main__":
    raise SystemExit(main())
