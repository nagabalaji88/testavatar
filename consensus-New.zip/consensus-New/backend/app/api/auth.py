from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import models, schemas
from ..core.database import get_db
from ..core.security import create_token, hash_password, needs_rehash, verify_password
from .deps import current_user, login_rate_limit

router = APIRouter(prefix="/auth", tags=["auth"])


@router.post("/login", response_model=schemas.TokenResponse,
             dependencies=[Depends(login_rate_limit)])
def login(payload: schemas.LoginRequest, db: Session = Depends(get_db)):
    user = db.scalar(select(models.User).where(models.User.email == payload.email.lower()))
    if not user or not user.is_active or not verify_password(payload.password, user.password_hash):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Email or password is incorrect.")
    if needs_rehash(user.password_hash):
        user.password_hash = hash_password(payload.password)
        db.commit()
    token = create_token({"sub": user.id, "role": user.role, "ver": user.token_version})
    return {"access_token": token, "user": user}


@router.post("/logout", status_code=status.HTTP_204_NO_CONTENT)
def logout(db: Session = Depends(get_db), user: models.User = Depends(current_user)):
    """Invalidates every token issued to this user, not just the one presented."""
    user.token_version += 1
    db.commit()


@router.post("/password", status_code=status.HTTP_204_NO_CONTENT)
def change_password(payload: schemas.PasswordChange, db: Session = Depends(get_db),
                    user: models.User = Depends(current_user)):
    if not verify_password(payload.current_password, user.password_hash):
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Current password is incorrect.")
    user.password_hash = hash_password(payload.new_password)
    user.token_version += 1
    db.add(models.AuditEvent(actor=user.email, action="auth.password_change", target=user.email))
    db.commit()


@router.get("/me", response_model=schemas.UserOut)
def me(user: models.User = Depends(current_user)):
    return user
