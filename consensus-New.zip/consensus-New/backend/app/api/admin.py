"""Users, projects, settings, provider keys and the audit trail."""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import models, schemas
from ..core.config import settings as app_settings
from ..core.database import get_db
from ..core.security import hash_password, mask, seal, unseal
from ..services.providers import (
    CATALOG,
    PROVIDERS,
    api_key,
    breaker,
    complete,
    is_live,
    load_stored_keys,
)
from .deps import current_user, require_roles

router = APIRouter(tags=["admin"])


@router.get("/users", response_model=list[schemas.UserOut])
def list_users(db: Session = Depends(get_db),
               admin: models.User = Depends(require_roles("admin"))):
    return db.scalars(select(models.User).order_by(models.User.created_at)).all()


@router.post("/users", response_model=schemas.UserOut, status_code=status.HTTP_201_CREATED)
def create_user(payload: schemas.UserCreate, db: Session = Depends(get_db),
                admin: models.User = Depends(require_roles("admin"))):
    email = payload.email.lower()
    if db.scalar(select(models.User).where(models.User.email == email)):
        raise HTTPException(status.HTTP_409_CONFLICT, "That email already has an account.")
    user = models.User(
        email=email, full_name=payload.full_name, role=payload.role,
        password_hash=hash_password(payload.password),
    )
    db.add(user)
    db.add(models.AuditEvent(actor=admin.email, action="user.create", target=email))
    db.commit()
    db.refresh(user)
    return user


@router.patch("/users/{user_id}", response_model=schemas.UserOut)
def update_user(user_id: str, payload: schemas.UserUpdate, db: Session = Depends(get_db),
                admin: models.User = Depends(require_roles("admin"))):
    user = db.get(models.User, user_id)
    if not user:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "No such user.")
    if user.id == admin.id and payload.is_active is False:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "You cannot deactivate your own account.")
    if payload.full_name is not None:
        user.full_name = payload.full_name
    if payload.role is not None:
        user.role = payload.role
    if payload.is_active is not None:
        user.is_active = payload.is_active
    # Role or activation changes must not leave an old token with the old privileges.
    user.token_version += 1
    db.add(models.AuditEvent(actor=admin.email, action="user.update", target=user.email,
                             detail=payload.model_dump(exclude_none=True)))
    db.commit()
    db.refresh(user)
    return user


@router.post("/users/{user_id}/password", status_code=status.HTTP_204_NO_CONTENT)
def reset_password(user_id: str, payload: schemas.PasswordReset, db: Session = Depends(get_db),
                   admin: models.User = Depends(require_roles("admin"))):
    user = db.get(models.User, user_id)
    if not user:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "No such user.")
    user.password_hash = hash_password(payload.new_password)
    user.token_version += 1
    db.add(models.AuditEvent(actor=admin.email, action="user.password_reset", target=user.email))
    db.commit()


@router.get("/projects")
def projects(db: Session = Depends(get_db), user: models.User = Depends(current_user)):
    rows = db.scalars(select(models.Project)).all()
    return [
        {"id": p.id, "name": p.name, "description": p.description,
         "sessions": len(p.sessions), "created_at": p.created_at}
        for p in rows
    ]


@router.post("/projects")
def create_project(payload: schemas.ProjectCreate, db: Session = Depends(get_db),
                   user: models.User = Depends(require_roles("engineer"))):
    project = models.Project(name=payload.name, description=payload.description, owner_id=user.id)
    db.add(project)
    db.commit()
    db.refresh(project)
    return {"id": project.id, "name": project.name}


@router.get("/settings")
def get_settings(db: Session = Depends(get_db), user: models.User = Depends(current_user)):
    rows = db.scalars(select(models.Setting)).all()
    stored = [
        {
            "key": s.key,
            "value": mask(unseal(s.value) or "") if s.encrypted else s.value,
            "encrypted": s.encrypted,
            "updated_at": s.updated_at,
        }
        for s in rows
    ]
    return {
        "settings": stored,
        "runtime": {
            "rate_limit_per_minute": app_settings.rate_limit_per_minute,
            "max_retries": app_settings.max_retries,
            "circuit_breaker_failures": app_settings.circuit_breaker_failures,
            "request_timeout_seconds": app_settings.request_timeout_seconds,
            "database": app_settings.database_url.split(":")[0],
        },
        "providers": [
            {
                "id": provider,
                "label": CATALOG[provider]["label"],
                "model": CATALOG[provider]["model"],
                "color": CATALOG[provider]["color"],
                "mode": "live" if is_live(provider) else "simulated",
                "circuit_open": breaker.is_open(provider),
                "input_cost_per_mtok": CATALOG[provider]["in_cost"],
                "output_cost_per_mtok": CATALOG[provider]["out_cost"],
            }
            for provider in PROVIDERS
        ],
    }


@router.put("/settings")
def upsert_setting(payload: schemas.SettingUpdate, db: Session = Depends(get_db),
                   user: models.User = Depends(require_roles("admin"))):
    """Secrets are sealed before they touch the database and masked on the way out."""
    row = db.scalar(select(models.Setting).where(models.Setting.key == payload.key))
    value = seal(payload.value) if payload.encrypted else payload.value
    if row:
        row.value, row.encrypted = value, payload.encrypted
    else:
        db.add(models.Setting(key=payload.key, value=value, encrypted=payload.encrypted))
    db.add(models.AuditEvent(actor=user.full_name, action="settings.update", target=payload.key))
    db.commit()
    # A provider key is useless until the gateway picks it up; do it now rather
    # than leaving the caller to wonder why the provider is still simulated.
    load_stored_keys(db)
    if payload.key.endswith("_api_key"):
        breaker.record_success(payload.key.removesuffix("_api_key"))
    return {"key": payload.key, "stored": True, "encrypted": payload.encrypted}


@router.post("/providers/{provider}/test")
def test_provider(provider: str, user: models.User = Depends(require_roles("admin"))):
    """Make one real call and report exactly what came back.

    Without this, a misconfigured provider is indistinguishable from a working one:
    the workflow silently degrades to the simulator and the run still succeeds.
    """
    if provider not in PROVIDERS:
        raise HTTPException(status.HTTP_404_NOT_FOUND, f"Unknown provider: {provider}")
    if not api_key(provider):
        return {
            "provider": provider, "ok": False, "reason": "no_key",
            "detail": "No key found in the environment or the settings table.",
        }
    result = complete(
        provider,
        "You are a connectivity check. Reply with exactly: OK",
        "Reply with exactly: OK",
        simulator=lambda: "",
    )
    return {
        "provider": provider,
        "ok": not result.simulated,
        "reason": "ok" if not result.simulated else "call_failed",
        "model": CATALOG[provider]["model"],
        "reply": result.text[:200],
        "duration_ms": result.duration_ms,
        "warnings": result.warnings,
    }


@router.get("/audit")
def audit(limit: int = 100, db: Session = Depends(get_db),
          user: models.User = Depends(current_user)):
    rows = db.scalars(
        select(models.AuditEvent).order_by(models.AuditEvent.created_at.desc()).limit(limit)
    ).all()
    return [
        {"id": e.id, "actor": e.actor, "action": e.action, "target": e.target,
         "detail": e.detail, "created_at": e.created_at}
        for e in rows
    ]


@router.get("/agent-logs")
def agent_logs(limit: int = 200, db: Session = Depends(get_db),
               user: models.User = Depends(current_user)):
    rows = db.scalars(
        select(models.AgentLog).order_by(models.AgentLog.created_at.desc()).limit(limit)
    ).all()
    return [
        {
            "id": log.id, "session_id": log.session_id, "agent": log.agent, "stage": log.stage,
            "status": log.status, "summary": log.summary, "tokens": log.tokens,
            "cost_usd": log.cost_usd, "duration_ms": log.duration_ms,
            "confidence": log.confidence, "warnings": log.warnings,
            "recommendations": log.recommendations, "created_at": log.created_at,
        }
        for log in rows
    ]
