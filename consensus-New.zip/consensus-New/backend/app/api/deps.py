"""Auth, RBAC and a small in-process rate limiter."""
from __future__ import annotations

import time
from collections import defaultdict, deque

from fastapi import Depends, Header, HTTPException, Request, status
from sqlalchemy.orm import Session

from .. import models
from ..core.config import settings
from ..core.database import get_db
from ..core.security import decode_token

# NOTE: per-process state. With multiple workers the effective limit is
# multiplied by the worker count — see docs/DEPLOYMENT.md before scaling out.
_hits: dict[str, deque] = defaultdict(deque)


def _fixed_window(key: str, limit: int, message: str) -> None:
    now = time.time()
    window = _hits[key]
    while window and now - window[0] > 60:
        window.popleft()
    if len(window) >= limit:
        raise HTTPException(status.HTTP_429_TOO_MANY_REQUESTS, message)
    window.append(now)


def _client(request: Request) -> str:
    return request.client.host if request.client else "anonymous"


def rate_limit(request: Request) -> None:
    _fixed_window(
        f"api:{_client(request)}",
        settings.rate_limit_per_minute,
        f"Rate limit of {settings.rate_limit_per_minute} requests per minute reached.",
    )


def login_rate_limit(request: Request) -> None:
    """Tighter budget than the general API, so the login form is not a password oracle."""
    _fixed_window(
        f"login:{_client(request)}",
        settings.login_rate_limit_per_minute,
        "Too many sign-in attempts. Wait a minute and try again.",
    )


def current_user(
    authorization: str = Header(default=""),
    db: Session = Depends(get_db),
) -> models.User:
    if not authorization.lower().startswith("bearer "):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Sign in to continue.")
    payload = decode_token(authorization.split(" ", 1)[1])
    if not payload:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Session expired. Sign in again.")
    user = db.get(models.User, payload.get("sub", ""))
    if not user or not user.is_active:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Account is not active.")
    if payload.get("ver", 0) != user.token_version:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Session was revoked. Sign in again.")
    return user


def require_roles(*roles: str):
    def guard(user: models.User = Depends(current_user)) -> models.User:
        if roles and user.role not in roles and user.role != "admin":
            raise HTTPException(
                status.HTTP_403_FORBIDDEN, f"This action needs one of: {', '.join(roles)}."
            )
        return user

    return guard
