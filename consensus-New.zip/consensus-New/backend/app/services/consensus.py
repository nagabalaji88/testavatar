"""Consensus analysis and master weaving."""
from __future__ import annotations

import re

from .drafting import _FALLBACK_VOICE, write_section
from .evaluation import METRICS, WEIGHTS, evaluate, validate_payloads
from .sections import SECTIONS

STOPWORDS = {
    "the", "and", "for", "with", "that", "this", "from", "your", "you", "not", "are", "its",
    "into", "each", "every", "when", "than", "then", "there", "which", "will", "must", "never",
    "always", "output", "input", "use", "using", "based",
}


def _tokens(text: str) -> set[str]:
    return {
        word for word in re.findall(r"[a-zA-Z][a-zA-Z0-9_\-]{2,}", text.lower())
        if word not in STOPWORDS
    }


def jaccard(a: set[str], b: set[str]) -> float:
    if not a and not b:
        return 1.0
    return round(len(a & b) / len(a | b), 4) if (a | b) else 0.0


def agreement_matrix(drafts: dict[str, dict[str, str]]) -> dict:
    """Pairwise similarity between every pair of drafts, plus the overall agreement."""
    token_sets = {
        provider: _tokens("\n".join(sections.values())) for provider, sections in drafts.items()
    }
    providers = list(drafts)
    pairs: dict[str, float] = {}
    scores: list[float] = []
    for index, left in enumerate(providers):
        for right in providers[index + 1:]:
            value = jaccard(token_sets[left], token_sets[right])
            pairs[f"{left}|{right}"] = value
            scores.append(value)
    overall = round(sum(scores) / len(scores), 4) if scores else 0.0
    return {"pairs": pairs, "agreement": overall}


# A draft's own house style is not a disagreement. `notes` carries each vendor's
# signature line, `role` and `objective` carry its voice — comparing those by word
# overlap reported four cooperating drafts as three contradictions on every run.
_STYLE_SECTIONS = {"notes", "role", "objective", "context", "business_goal", "examples"}

_FORBID = re.compile(
    r"\b(never|do not|don'?t|avoid|refuse to|must not|no\b)\s+(.{3,80}?)(?:[.;\n]|$)", re.I
)
_REQUIRE = re.compile(
    r"\b(always|must|should|ensure(?: that)?|make sure(?: to)?|be sure to)\s+"
    r"(.{3,80}?)(?:[.;\n]|$)",
    re.I,
)


def _directives(body: str) -> tuple[list[set[str]], list[set[str]]]:
    """Split a section into what it forbids and what it requires."""
    forbid = [_tokens(m.group(2)) for m in _FORBID.finditer(body)]
    require = [_tokens(m.group(2)) for m in _REQUIRE.finditer(body)]
    return [f for f in forbid if f], [r for r in require if r]


def find_contradictions(drafts: dict[str, dict[str, str]]) -> list[dict]:
    """Real disagreements only: one draft forbids what another requires.

    The previous rule flagged any pair of sections whose word overlap fell below
    0.12, which fired on drafts that merely said different true things — and
    could never fire on an actual conflict expressed in shared vocabulary.
    """
    providers = list(drafts)
    found: list[dict] = []
    for section in SECTIONS:
        present = [p for p in providers if drafts[p].get(section)]
        if len(present) < 2 or section in _STYLE_SECTIONS:
            continue
        parsed = {p: _directives(drafts[p][section]) for p in present}
        for index, left in enumerate(present):
            for right in present[index + 1:]:
                clash = _polarity_clash(parsed[left], parsed[right])
                if clash:
                    found.append({
                        "section": section,
                        "between": [left, right],
                        "kind": "conflict",
                        "overlap": clash[0],
                        "detail": f"{left} forbids what {right} requires: “{clash[1]}”",
                    })
    return found


def _polarity_clash(left: tuple, right: tuple) -> tuple[float, str] | None:
    """A forbid on one side matching a require on the other is a genuine conflict."""
    for forbid_set, require_sets, in ((left[0], right[1]), (right[0], left[1])):
        for forbidden in forbid_set:
            for required in require_sets:
                overlap = jaccard(forbidden, required)
                if overlap >= 0.6 and len(forbidden & required) >= 2:
                    return overlap, " ".join(sorted(forbidden & required))
    return None


def analyse(drafts: dict[str, dict[str, str]], scores: dict[str, dict]) -> dict:
    """Common strengths, shared gaps, contradictions, unique contributions, winners."""
    providers = list(drafts)
    matrix = agreement_matrix(drafts)

    common_strengths, shared_gaps = [], []
    for metric in METRICS:
        values = [scores[p]["metrics"][metric] for p in providers]
        if min(values) >= 70:
            common_strengths.append({"metric": metric, "floor": min(values)})
        if max(values) < 55:
            shared_gaps.append({"metric": metric, "ceiling": max(values)})

    # A section every draft omits is a gap the weaver has to fill itself.
    for section in SECTIONS:
        if all(not drafts[p].get(section) for p in providers):
            shared_gaps.append({"metric": f"section:{section}", "ceiling": 0})

    contradictions = find_contradictions(drafts)

    unique: dict[str, list[str]] = {}
    for provider in providers:
        others: set[str] = set()
        for other in providers:
            if other != provider:
                others |= _tokens("\n".join(drafts[other].values()))
        own = _tokens("\n".join(drafts[provider].values()))
        unique[provider] = sorted(own - others)[:12]

    return {
        "agreement": matrix["agreement"],
        "pairs": matrix["pairs"],
        "common_strengths": common_strengths,
        "shared_gaps": shared_gaps,
        "contradictions": contradictions[:12],
        "unique_contributions": unique,
    }


# Which evaluation metrics a given section actually moves. Used to pick a winner
# per section instead of handing the whole prompt to the best overall draft.
SECTION_METRICS: dict[str, list[str]] = {
    "role": ["clarity", "portability"],
    "objective": ["clarity", "completeness"],
    "context": ["completeness", "hallucination_resistance"],
    "business_goal": ["completeness"],
    "inputs": ["structure", "completeness"],
    "variables": ["structure", "portability"],
    "execution_plan": ["reasoning", "clarity"],
    "instructions": ["clarity", "reasoning"],
    "reasoning_strategy": ["reasoning"],
    "constraints": ["constraints"],
    "negative_constraints": ["constraints", "hallucination_resistance"],
    "validation_rules": ["structure", "constraints"],
    "output_schema": ["structure"],
    "examples": ["few_shot"],
    "edge_cases": ["edge_cases"],
    "quality_checklist": ["completeness", "structure"],
    "failure_recovery": ["edge_cases"],
    "notes": ["token_efficiency"],
}


def _section_strength(provider: str, section: str, drafts, scores, intent=None) -> float:
    """Score this section on its own merits, not on the draft's global average.

    Reading `scores[provider]["metrics"][m]` alone meant a draft won a section
    because its *other* sections were strong — Anthropic took `execution_plan`
    on the strength of its reasoning score, whatever its execution plan said.
    The section's own text is now scored directly, with the draft-wide figure
    kept only as a tie-breaker.
    """
    body = drafts[provider].get(section)
    if not body:
        return -1.0
    metrics = SECTION_METRICS.get(section, ["clarity"])

    local = evaluate({section: body}, intent)["metrics"]
    local_score = sum(local[m] for m in metrics) / len(metrics)

    provider_metrics = (scores.get(provider) or {}).get("metrics") or {}
    global_score = (
        sum(provider_metrics.get(m, 50.0) for m in metrics) / len(metrics)
        if provider_metrics else 50.0
    )

    # Reward substance, but not padding. This was worth up to 20 points and line
    # count is fixed by the profile depth table, so it silently re-decided every
    # section for the same provider no matter what the request said.
    detail = min(len([line for line in body.splitlines() if line.strip()]), 4) * 2

    return round(
        0.7 * local_score + 0.3 * global_score + detail + _section_fidelity(section, body, intent),
        3,
    )


def _section_fidelity(section: str, body: str, intent: dict | None) -> float:
    """How much of *this* request the section actually carries. Worth up to 15.

    Without an input-dependent term, section winners were decided entirely by
    fixed per-provider traits, so the same provider won the same section for
    every request the tool had ever seen.
    """
    if not intent:
        return 0.0
    lowered = body.lower()
    contract = intent.get("output_contract") or {}
    signals: list[float] = []

    fields = [f["name"] for f in contract.get("fields", [])]
    if fields:
        signals.append(sum(1 for f in fields if f.lower() in lowered) / len(fields))
    labels = contract.get("enum_values") or []
    if labels:
        signals.append(sum(1 for v in labels if v.lower() in lowered) / len(labels))

    constraints = [c for c in intent.get("constraints", []) if str(c).strip()]
    if constraints and section in {"constraints", "negative_constraints", "validation_rules",
                                   "instructions", "quality_checklist"}:
        signals.append(
            sum(1 for c in constraints if str(c).strip().lower().rstrip(".") in lowered)
            / len(constraints)
        )

    declared = {i["name"] for i in intent.get("inputs", [])}
    declared |= {v["name"] for v in intent.get("variables", [])}
    if declared:
        signals.append(min(sum(1 for n in declared if n in lowered) / len(declared) * 2, 1.0))

    keywords = {
        w for w in re.findall(r"[a-zA-Z][a-zA-Z0-9_\-]{3,}",
                              (intent.get("problem_statement") or "").lower())
        if w not in STOPWORDS
    }
    if keywords:
        signals.append(min(len(keywords & set(re.findall(r"[a-z][a-z0-9_\-]{3,}", lowered)))
                           / len(keywords) * 2, 1.0))

    return round(15 * (sum(signals) / len(signals)), 3) if signals else 0.0


def weave(drafts: dict[str, dict[str, str]], scores: dict[str, dict], intent: dict,
          plan: dict | None = None) -> dict:
    """Pick the strongest version of every section, then guarantee a real hybrid.

    If one provider would win every section, the runner-up takes the sections
    where its margin of loss was smallest — the output is never a copy of a
    single draft, which is the whole point of running four of them.
    """
    providers = list(drafts)
    strengths = {
        section: {p: _section_strength(p, section, drafts, scores, intent) for p in providers}
        for section in SECTIONS
    }

    provenance: dict[str, str] = {}
    for section in SECTIONS:
        ranked = sorted(strengths[section].items(), key=lambda kv: kv[1], reverse=True)
        if ranked and ranked[0][1] >= 0:
            provenance[section] = ranked[0][0]

    winners = set(provenance.values())
    if len(winners) == 1 and len(providers) > 1:
        dominant = winners.pop()
        margins = []
        for section, source in provenance.items():
            alternatives = [
                (p, strengths[section][p]) for p in providers
                if p != dominant and strengths[section][p] >= 0
            ]
            if alternatives:
                best_other = max(alternatives, key=lambda kv: kv[1])
                margins.append((strengths[section][source] - best_other[1], section, best_other[0]))
        for _, section, challenger in sorted(margins)[: max(1, len(margins) // 3)]:
            provenance[section] = challenger

    sections = {section: drafts[source][section] for section, source in provenance.items()}

    # Fill sections nobody wrote, so the master prompt is always complete.
    filled: list[str] = []
    for section in SECTIONS:
        if section not in sections:
            body = _fallback(section, intent, plan)
            if not body:
                continue
            sections[section] = body
            provenance[section] = "weaver"
            filled.append(section)

    return {"sections": sections, "provenance": provenance, "filled": filled}


def _fallback(section: str, intent: dict, plan: dict | None = None) -> str:
    """Write the missing section from the intent rather than leaving a stub.

    A total provider outage used to yield eighteen
    `_(synthesised by the weaver — no draft supplied X)_` lines that still passed
    QA and still carried a score. The weaver now writes real content, in the
    provider-neutral voice, from the same intent the specialists were given.
    """
    return write_section(_FALLBACK_VOICE.get(section, "anthropic"), section, intent, plan or {})


_PLACEHOLDER_RE = re.compile(r"\{\{\s*([a-zA-Z_][\w]*)\s*\}\}")

# Declaring a knob nothing reads is as broken as reading a knob nothing declares,
# but only the second direction was ever checked.
_DECLARING_SECTIONS = ("inputs", "variables")


def quality_report(sections: dict[str, str], intent: dict | None = None) -> dict:
    """Agent 10: structural validation of the woven prompt."""
    problems = validate_payloads(sections)
    body = "\n".join(sections.values())

    declared = set(_PLACEHOLDER_RE.findall(
        "\n".join(sections.get(key, "") for key in _DECLARING_SECTIONS)
    ))
    used_elsewhere = set(_PLACEHOLDER_RE.findall(
        "\n".join(value for key, value in sections.items() if key not in _DECLARING_SECTIONS)
    ))
    all_placeholders = set(_PLACEHOLDER_RE.findall(body))

    orphans = sorted(used_elsewhere - declared)
    if orphans:
        problems.append({
            "kind": "placeholder",
            "detail": f"used but never declared in Inputs or Variables: {', '.join(orphans)}",
        })

    unused = sorted(declared - used_elsewhere)
    if unused:
        problems.append({
            "kind": "unused_placeholder",
            "detail": f"declared but never referenced by any instruction: {', '.join(unused)}",
        })

    missing = [s for s in SECTIONS if not sections.get(s)]
    if missing:
        problems.append({"kind": "completeness", "detail": f"missing: {', '.join(missing)}"})

    risky = re.findall(
        r"(?i)\b(latest|current|today|recent|as of now|up to date)\b", body
    )
    if risky:
        problems.append({
            "kind": "hallucination_risk",
            "detail": f"{len(risky)} time-relative phrase(s) that will silently go stale",
        })

    problems += _contract_problems(sections, intent)

    evaluation = evaluate(sections, intent)
    return {
        "passed": not [p for p in problems
                       if p["kind"] in {"json", "xml", "markdown", "contract"}],
        "problems": problems,
        "score": evaluation["total"],
        "metrics": evaluation["metrics"],
        "weights": WEIGHTS,
        "placeholders": sorted(all_placeholders),
    }


def _contract_problems(sections: dict[str, str], intent: dict | None) -> list[dict]:
    """Does the prompt's Output schema actually deliver what the caller asked for?"""
    if not intent:
        return []
    contract = intent.get("output_contract") or {}
    if not contract:
        return []
    schema = sections.get("output_schema", "")
    problems: list[dict] = []
    if not schema.strip():
        return [{"kind": "contract", "detail": "the prompt declares no output schema"}]

    fmt = contract.get("format")
    if fmt in {"json", "json_lines"} and "```json" not in schema:
        problems.append({
            "kind": "contract",
            "detail": f"a {fmt} output was requested but the schema block is not JSON",
        })
    if fmt == "enum":
        values = contract.get("enum_values") or []
        absent = [v for v in values if v not in schema]
        if absent:
            problems.append({
                "kind": "contract",
                "detail": f"requested labels missing from the schema: {', '.join(absent)}",
            })
    missing_fields = [
        f["name"] for f in contract.get("fields", []) if f["name"] not in schema
    ]
    if missing_fields:
        problems.append({
            "kind": "contract",
            "detail": f"requested fields absent from the schema: {', '.join(missing_fields)}",
        })
    return problems
