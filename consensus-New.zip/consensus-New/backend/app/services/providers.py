"""LiteLLM-style provider gateway.

One `complete()` signature for every vendor, with retries, a circuit breaker and
token/cost accounting. When a provider has no API key configured, the call is
served by the local simulator instead, so the whole ten-agent workflow runs
offline with provider-distinct output rather than four identical drafts.
"""
from __future__ import annotations

import logging
import re
import time
from dataclasses import dataclass, field

import httpx

from ..core.config import settings

logger = logging.getLogger("forge.providers")

# Per-million-token prices used for the cost estimate shown in the UI.
CATALOG: dict[str, dict] = {
    "openai": {
        "label": "GPT", "model": settings.openai_model, "key": settings.openai_api_key,
        "url": "https://api.openai.com/v1/chat/completions",
        "in_cost": 0.15, "out_cost": 0.60, "color": "#10B981",
        "strengths": ["structure", "output_schema", "function calling"],
    },
    "anthropic": {
        "label": "Claude", "model": settings.anthropic_model, "key": settings.anthropic_api_key,
        "url": "https://api.anthropic.com/v1/messages",
        "in_cost": 3.00, "out_cost": 15.00, "color": "#F59E0B",
        "strengths": ["reasoning", "edge cases", "safety"],
    },
    "google": {
        "label": "Gemini", "model": settings.google_model, "key": settings.google_api_key,
        "url": "https://generativelanguage.googleapis.com/v1beta/models",
        "in_cost": 0.10, "out_cost": 0.40, "color": "#3B82F6",
        "strengths": ["long context", "grounding", "multimodal"],
    },
    "moonshot": {
        "label": "Kimi", "model": settings.moonshot_model, "key": settings.moonshot_api_key,
        "url": "https://api.moonshot.cn/v1/chat/completions",
        "in_cost": 0.60, "out_cost": 0.60, "color": "#A855F7",
        "strengths": ["conciseness", "cross-language", "long context"],
    },
}

PROVIDERS = list(CATALOG)

# Keys entered through the admin UI live in the `settings` table, sealed. They are
# cached here rather than read per call, and the TTL lets a second worker pick up a
# key another worker stored without needing a restart.
_KEY_CACHE_TTL_SECONDS = 30
_stored_keys: dict[str, str] = {}
_stored_keys_loaded_at = 0.0


def load_stored_keys(db=None) -> dict[str, str]:
    """Read UI-managed provider keys out of the database and refresh the cache."""
    global _stored_keys, _stored_keys_loaded_at
    from sqlalchemy import select

    from .. import models
    from ..core.database import SessionLocal
    from ..core.security import unseal

    owns_session = db is None
    session = SessionLocal() if owns_session else db
    try:
        rows = session.scalars(select(models.Setting)).all()
        found = {}
        for row in rows:
            for provider in PROVIDERS:
                if row.key == f"{provider}_api_key":
                    value = unseal(row.value) if row.encrypted else row.value
                    if value:
                        found[provider] = value
        _stored_keys = found
        _stored_keys_loaded_at = time.time()
        logger.info("loaded %s provider key(s) from the database", len(found))
    except Exception as exc:  # noqa: BLE001 — a missing table on first boot is not fatal
        logger.warning("could not load stored provider keys: %s", exc)
    finally:
        if owns_session:
            session.close()
    return _stored_keys


def api_key(provider: str) -> str:
    """Environment wins over the database, so a deploy-time secret is never
    silently overridden by something typed into the UI."""
    from_env = CATALOG[provider]["key"]
    if from_env:
        return str(from_env)
    if time.time() - _stored_keys_loaded_at > _KEY_CACHE_TTL_SECONDS:
        load_stored_keys()
    return _stored_keys.get(provider, "")


@dataclass
class Completion:
    provider: str
    text: str
    tokens: int
    cost_usd: float
    duration_ms: int
    simulated: bool
    warnings: list[str] = field(default_factory=list)


class CircuitBreaker:
    """Stops hammering a provider that keeps failing; falls back to the simulator.

    The breaker re-closes on its own. Without the cooldown below it latches open
    forever: an open breaker makes `is_live` false, so no further call is ever
    attempted, so no success is ever recorded to reset it — one transient outage
    would strand the provider on the simulator until the process restarted.
    """

    def __init__(self, threshold: int, cooldown_seconds: int = 60) -> None:
        self.threshold = threshold
        self.cooldown_seconds = cooldown_seconds
        self.failures: dict[str, int] = {}
        self.opened_at: dict[str, float] = {}

    def is_open(self, provider: str) -> bool:
        if self.failures.get(provider, 0) < self.threshold:
            return False
        # Cooldown elapsed: go half-open and let exactly one probe through.
        if time.time() - self.opened_at.get(provider, 0.0) >= self.cooldown_seconds:
            logger.info("circuit for %s is half-open, retrying", provider)
            self.failures[provider] = self.threshold - 1
            return False
        return True

    def record_failure(self, provider: str) -> None:
        self.failures[provider] = self.failures.get(provider, 0) + 1
        if self.failures[provider] >= self.threshold:
            self.opened_at[provider] = time.time()

    def record_success(self, provider: str) -> None:
        self.failures[provider] = 0
        self.opened_at.pop(provider, None)


breaker = CircuitBreaker(settings.circuit_breaker_failures)


def estimate_tokens(text: str) -> int:
    """Cheap approximation — good enough for budgeting, no tokenizer dependency."""
    return max(1, int(len(text) / 4) + len(re.findall(r"\s+", text)) // 8)


def estimate_cost(provider: str, prompt_tokens: int, output_tokens: int) -> float:
    spec = CATALOG[provider]
    return round(
        (prompt_tokens * spec["in_cost"] + output_tokens * spec["out_cost"]) / 1_000_000, 6
    )


def is_live(provider: str) -> bool:
    return bool(api_key(provider)) and not breaker.is_open(provider)


def _payload(provider: str, system: str, user: str) -> tuple[str, dict, dict]:
    spec = CATALOG[provider]
    key = api_key(provider)
    if provider == "anthropic":
        return (
            spec["url"],
            {"x-api-key": key, "anthropic-version": "2023-06-01"},
            {"model": spec["model"], "max_tokens": 4000, "system": system,
             "messages": [{"role": "user", "content": user}]},
        )
    if provider == "google":
        return (
            f"{spec['url']}/{spec['model']}:generateContent",
            {"x-goog-api-key": key},
            {"system_instruction": {"parts": [{"text": system}]},
             "contents": [{"parts": [{"text": user}]}]},
        )
    return (
        spec["url"],
        {"Authorization": f"Bearer {key}"},
        {"model": spec["model"], "messages": [
            {"role": "system", "content": system}, {"role": "user", "content": user}]},
    )


def _describe(exc: Exception) -> str:
    """Surface what actually went wrong. Recording only the exception class name
    makes a wrong key, a rate limit and a bad model name look identical."""
    if isinstance(exc, httpx.HTTPStatusError):
        body = exc.response.text[:180].replace("\n", " ").strip()
        return f"HTTP {exc.response.status_code}: {body}"
    if isinstance(exc, httpx.TimeoutException):
        return f"timeout after {settings.request_timeout_seconds}s"
    return f"{type(exc).__name__}: {exc}"


def _extract(provider: str, body: dict) -> str:
    if provider == "anthropic":
        return "".join(block.get("text", "") for block in body.get("content", []))
    if provider == "google":
        parts = body["candidates"][0]["content"]["parts"]
        return "".join(part.get("text", "") for part in parts)
    return body["choices"][0]["message"]["content"]


def complete(provider: str, system: str, user: str, simulator=None) -> Completion:
    """Call the provider, or fall back to `simulator()` when live inference is unavailable."""
    started = time.perf_counter()
    warnings: list[str] = []

    if not api_key(provider):
        warnings.append("no API key configured — using the local simulator")
    elif breaker.is_open(provider):
        warnings.append("circuit open after repeated failures — using the local simulator")

    if is_live(provider):
        url, headers, body = _payload(provider, system, user)
        for attempt in range(settings.max_retries + 1):
            try:
                with httpx.Client(timeout=settings.request_timeout_seconds) as client:
                    response = client.post(url, json=body, headers=headers)
                    response.raise_for_status()
                    text = _extract(provider, response.json())
                breaker.record_success(provider)
                prompt_tokens = estimate_tokens(system + user)
                output_tokens = estimate_tokens(text)
                return Completion(
                    provider=provider, text=text,
                    tokens=prompt_tokens + output_tokens,
                    cost_usd=estimate_cost(provider, prompt_tokens, output_tokens),
                    duration_ms=int((time.perf_counter() - started) * 1000),
                    simulated=False, warnings=warnings,
                )
            except Exception as exc:  # noqa: BLE001
                detail = _describe(exc)
                warnings.append(f"attempt {attempt + 1} failed — {detail}")
                logger.warning("%s call failed (attempt %s): %s", provider, attempt + 1, detail)
                breaker.record_failure(provider)
                if attempt < settings.max_retries:
                    time.sleep(0.2 * (attempt + 1))
        warnings.append("fell back to the local simulator")

    text = simulator() if simulator else ""
    prompt_tokens = estimate_tokens(system + user)
    output_tokens = estimate_tokens(text)
    return Completion(
        provider=provider, text=text,
        tokens=prompt_tokens + output_tokens,
        cost_usd=estimate_cost(provider, prompt_tokens, output_tokens),
        duration_ms=int((time.perf_counter() - started) * 1000),
        simulated=True, warnings=warnings,
    )
