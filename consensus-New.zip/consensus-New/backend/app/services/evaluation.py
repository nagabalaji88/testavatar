"""Deterministic prompt evaluation against the weighted matrix.

Every metric is a pure function from the section map to 0-100, so scores are
reproducible and testable — no model is asked to grade its own homework.
"""
from __future__ import annotations

import json
import re

from .sections import SECTIONS

WEIGHTS: dict[str, int] = {
    "clarity": 12,
    "reasoning": 13,
    "constraints": 9,
    "completeness": 12,
    "portability": 8,
    "token_efficiency": 5,
    "structure": 9,
    "few_shot": 5,
    "edge_cases": 9,
    "hallucination_resistance": 5,
    # Every other metric scores the prompt's *shape*. Without this one a prompt
    # for `problem_statement="x"` scored the same as a real one, because nothing
    # in the matrix ever compared the prompt to what was actually asked for.
    "task_fidelity": 13,
}

VENDOR_TOKENS = re.compile(
    r"\b(gpt|openai|claude|anthropic|gemini|google|kimi|moonshot|chatgpt)\b", re.I
)
HEDGES = re.compile(r"\b(maybe|probably|might|possibly|as far as i know|i think)\b", re.I)
GROUNDING = re.compile(
    r"\b(do not fabricate|never fabricate|only use|supplied context|cite|ground|evidence|"
    r"assume nothing|state assumptions)\b", re.I
)


def _text(sections: dict[str, str]) -> str:
    return "\n".join(sections.values())


def _scale(value: float, low: float, high: float) -> float:
    """Map a raw measurement onto 0-100, clamped."""
    if high == low:
        return 50.0
    return round(max(0.0, min((value - low) / (high - low), 1.0)) * 100, 1)


def clarity(sections: dict[str, str]) -> float:
    body = _text(sections)
    sentences = [s for s in re.split(r"[.\n]", body) if len(s.strip()) > 4]
    if not sentences:
        return 0.0
    average_words = sum(len(s.split()) for s in sentences) / len(sentences)
    # 8-18 words per sentence is the readable band; penalise both extremes.
    penalty = abs(average_words - 13) / 13
    imperatives = len(re.findall(r"(?m)^\s*(?:\d+\.|-|\u2022)?\s*[A-Z][a-z]+\b", body))
    return round(max(0.0, min((1 - penalty) * 85 + min(imperatives, 15), 100)), 1)


def reasoning(sections: dict[str, str]) -> float:
    present = sum(
        1 for key in ("reasoning_strategy", "execution_plan", "instructions") if sections.get(key)
    )
    depth = len(sections.get("reasoning_strategy", "").splitlines())
    return round(min(present / 3 * 60 + depth * 13, 100), 1)


def constraints(sections: dict[str, str]) -> float:
    positive = len(sections.get("constraints", "").splitlines())
    negative = len(sections.get("negative_constraints", "").splitlines())
    return round(min(positive * 12 + negative * 16, 100), 1)


def completeness(sections: dict[str, str]) -> float:
    return round(len([s for s in SECTIONS if sections.get(s)]) / len(SECTIONS) * 100, 1)


def portability(sections: dict[str, str]) -> float:
    body = _text(sections)
    vendor_mentions = len(VENDOR_TOKENS.findall(body))
    return round(max(0.0, 100 - vendor_mentions * 18), 1)


def token_efficiency(sections: dict[str, str]) -> float:
    words = len(_text(sections).split())
    # 250-700 words is the sweet spot for a reusable master prompt.
    if words < 250:
        return _scale(words, 0, 250)
    if words > 700:
        return round(max(0.0, 100 - (words - 700) / 12), 1)
    return 100.0


def structure(sections: dict[str, str]) -> float:
    body = _text(sections)
    has_schema = bool(sections.get("output_schema"))
    fenced = body.count("```") >= 2
    bulleted = len(re.findall(r"(?m)^\s*[-*\d]", body))
    return round(min(has_schema * 40 + fenced * 25 + min(bulleted, 7) * 5, 100), 1)


def few_shot(sections: dict[str, str]) -> float:
    examples = sections.get("examples", "")
    return round(min(len([line for line in examples.splitlines() if line.strip()]) * 34, 100), 1)


def edge_cases(sections: dict[str, str]) -> float:
    lines = len([line for line in sections.get("edge_cases", "").splitlines() if line.strip()])
    recovery = 25 if sections.get("failure_recovery") else 0
    return round(min(lines * 25 + recovery, 100), 1)


def hallucination_resistance(sections: dict[str, str]) -> float:
    body = _text(sections)
    guards = len(GROUNDING.findall(body))
    hedges = len(HEDGES.findall(body))
    return round(max(0.0, min(guards * 22 - hedges * 10, 100)), 1)


_CONTENT_WORD = re.compile(r"[a-zA-Z][a-zA-Z0-9_\-]{2,}")
_FIDELITY_STOPWORDS = {
    "the", "and", "for", "with", "that", "this", "from", "your", "you", "not", "are", "its",
    "into", "each", "every", "when", "than", "then", "there", "which", "will", "must", "never",
    "always", "output", "input", "use", "using", "based", "should", "would", "could", "them",
    "they", "have", "has", "our", "their", "can", "any", "all", "one", "out",
}

_FORMAT_EVIDENCE = {
    "json": re.compile(r"```json|\bjson\b", re.I),
    "json_lines": re.compile(r"```json|\bjsonl?\b|per line", re.I),
    "csv": re.compile(r"```csv|\bcsv\b|header row", re.I),
    "xml": re.compile(r"```xml|</[a-z_]", re.I),
    "yaml": re.compile(r"```yaml|\byaml\b", re.I),
    "enum": re.compile(r"exactly one of|one of these labels", re.I),
    "table": re.compile(r"\|\s*-{2,}|markdown table", re.I),
    "markdown": re.compile(r"\bmarkdown\b|headings?|bullets?", re.I),
    "number": re.compile(r"single number|numeric", re.I),
    "boolean": re.compile(r"`?true`? or `?false`?|yes or no", re.I),
    "text": re.compile(r"prose|no preamble", re.I),
}


def _keywords(text: str) -> set[str]:
    return {
        word.lower() for word in _CONTENT_WORD.findall(text or "")
        if word.lower() not in _FIDELITY_STOPWORDS
    }


def task_fidelity(sections: dict[str, str], intent: dict | None = None) -> float:
    """How much of the request actually survived into the prompt.

    Three things are checked: the caller's own vocabulary appears in the prompt,
    every stated constraint is represented, and the output section matches the
    format that was asked for.
    """
    body = _text(sections)
    if not body.strip():
        return 0.0

    if not intent:
        # Called without intent (stage endpoints, ad-hoc scoring): fall back to
        # internal consistency — does the prompt's own objective survive into the
        # rest of the prompt? Neutral-to-positive, never a free 100.
        objective = sections.get("objective", "")
        if not objective.strip():
            return 40.0
        rest = "\n".join(v for k, v in sections.items() if k != "objective")
        wanted = _keywords(objective)
        return round(min(60 + 40 * _coverage(wanted, _keywords(rest)), 100), 1)

    statement = intent.get("problem_statement") or intent.get("objective", "")
    wanted = _keywords(statement)
    present = _keywords(body)
    stated_constraints = [c for c in intent.get("constraints", []) if str(c).strip()]
    contract = intent.get("output_contract") or {}

    # A prompt cannot be faithful to a request that said nothing. Matching an
    # empty request scored a perfect 1.0 on every component, which handed
    # `problem_statement="x"` the same fidelity as a fully specified brief.
    specificity = min(1.0, (
        0.5 * min(len(wanted) / 8, 1.0)
        + 0.3 * bool(contract.get("stated"))
        + 0.2 * bool(stated_constraints)
    ))
    if specificity == 0.0:
        return 0.0

    topical = _coverage(wanted, present)

    if stated_constraints:
        covered = sum(
            1 for c in stated_constraints if _coverage(_keywords(str(c)), present) >= 0.6
        )
        constraint_score = covered / len(stated_constraints)
    else:
        constraint_score = topical

    fmt = contract.get("format", "text")
    evidence = _FORMAT_EVIDENCE.get(fmt)
    schema_present = bool(sections.get("output_schema", "").strip())
    format_score = 1.0 if (schema_present and evidence and evidence.search(body)) else (
        0.5 if schema_present else 0.0
    )
    # An inferred contract is a guess the caller never confirmed; it should not
    # score as highly as one they actually specified.
    if not contract.get("stated"):
        format_score *= 0.5

    # Field names the caller named explicitly are the strongest signal of all.
    fields = [f["name"] for f in contract.get("fields", [])]
    if fields:
        hit = sum(1 for name in fields if name.lower() in body.lower())
        field_score = hit / len(fields)
    else:
        field_score = format_score

    blend = (0.30 * topical + 0.25 * constraint_score
             + 0.20 * format_score + 0.25 * field_score)
    return round(min(100, 100 * specificity * blend), 1)


def _coverage(wanted: set[str], present: set[str]) -> float:
    if not wanted:
        return 1.0
    return len(wanted & present) / len(wanted)


METRICS = {
    "clarity": clarity,
    "reasoning": reasoning,
    "constraints": constraints,
    "completeness": completeness,
    "portability": portability,
    "token_efficiency": token_efficiency,
    "structure": structure,
    "few_shot": few_shot,
    "edge_cases": edge_cases,
    "hallucination_resistance": hallucination_resistance,
    "task_fidelity": task_fidelity,
}

# Metrics that also accept the intent, so `evaluate` can pass it selectively.
_INTENT_AWARE = {"task_fidelity"}


def evaluate(sections: dict[str, str], intent: dict | None = None) -> dict:
    raw = {
        name: (fn(sections, intent) if name in _INTENT_AWARE else fn(sections))
        for name, fn in METRICS.items()
    }
    weighted = {
        name: round(value * WEIGHTS[name] / 100, 2) for name, value in raw.items()
    }
    total = round(sum(weighted.values()), 1)
    notes: list[str] = []
    for name, value in sorted(raw.items(), key=lambda kv: kv[1])[:3]:
        if value < 60:
            notes.append(f"{name.replace('_', ' ')} is weak at {value:.0f}/100")
    missing = [s for s in SECTIONS if not sections.get(s)]
    if missing:
        notes.append(f"missing sections: {', '.join(missing)}")
    return {"metrics": raw, "weighted": weighted, "total": total, "notes": notes}


def validate_payloads(sections: dict[str, str]) -> list[dict]:
    """QA support: check that every fenced JSON block actually parses."""
    problems: list[dict] = []
    body = "\n".join(sections.values())
    for block in re.findall(r"```json\s*(.*?)```", body, re.S):
        try:
            json.loads(block.strip())
        except json.JSONDecodeError as exc:
            problems.append({"kind": "json", "detail": str(exc)})
    if body.count("```") % 2 != 0:
        problems.append({"kind": "markdown", "detail": "unbalanced code fence"})
    opened = re.findall(r"<([a-zA-Z_][\w\-]*)>", body)
    closed = re.findall(r"</([a-zA-Z_][\w\-]*)>", body)
    for tag in set(opened) - set(closed):
        problems.append({"kind": "xml", "detail": f"<{tag}> is never closed"})
    return problems
