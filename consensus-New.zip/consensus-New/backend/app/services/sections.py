"""The canonical section list every draft and the master prompt are built from."""
from __future__ import annotations

import re
from typing import Optional

SECTIONS: list[str] = [
    "role", "objective", "context", "business_goal", "inputs", "variables",
    "execution_plan", "instructions", "reasoning_strategy", "constraints",
    "negative_constraints", "validation_rules", "output_schema", "examples",
    "edge_cases", "quality_checklist", "failure_recovery", "notes",
]

HEADINGS: dict[str, str] = {
    "role": "Role",
    "objective": "Objective",
    "context": "Context",
    "business_goal": "Business goal",
    "inputs": "Inputs",
    "variables": "Variables",
    "execution_plan": "Execution plan",
    "instructions": "Step-by-step instructions",
    "reasoning_strategy": "Reasoning strategy",
    "constraints": "Constraints",
    "negative_constraints": "Negative constraints",
    "validation_rules": "Validation rules",
    "output_schema": "Output schema",
    "examples": "Examples",
    "edge_cases": "Edge cases",
    "quality_checklist": "Quality checklist",
    "failure_recovery": "Failure recovery",
    "notes": "Final notes",
}


def render(sections: dict[str, str]) -> str:
    """Turn a section map into the markdown prompt users copy out."""
    blocks = []
    for key in SECTIONS:
        body = (sections.get(key) or "").strip()
        if not body:
            continue
        blocks.append(f"## {HEADINGS[key]}\n{body}")
    return "\n\n".join(blocks)


# Real models decorate headings: "## 1. Role", "**Role**", "### Role & Persona",
# "Step 3: Instructions". Matching only the exact rendered form meant a paid,
# successful completion parsed to nothing and was silently replaced by the
# template. Each alias below is matched after the decoration is stripped.
ALIASES: dict[str, str] = {
    "persona": "role", "role and persona": "role", "system role": "role", "you are": "role",
    "goal": "objective", "goals": "objective", "task": "objective", "purpose": "objective",
    "background": "context", "situation": "context", "context and background": "context",
    "business objective": "business_goal", "business context": "business_goal",
    "why this matters": "business_goal",
    "input": "inputs", "input variables": "inputs", "input data": "inputs",
    "parameters": "variables", "template variables": "variables", "placeholders": "variables",
    "plan": "execution_plan", "approach": "execution_plan", "procedure": "execution_plan",
    "workflow": "execution_plan", "steps": "execution_plan",
    "instructions": "instructions", "step by step instructions": "instructions",
    "step-by-step instructions": "instructions", "directions": "instructions",
    "rules": "instructions",
    "reasoning": "reasoning_strategy", "thinking": "reasoning_strategy",
    "chain of thought": "reasoning_strategy", "reasoning approach": "reasoning_strategy",
    "requirements": "constraints", "hard constraints": "constraints", "limits": "constraints",
    "prohibitions": "negative_constraints", "do not": "negative_constraints",
    "what not to do": "negative_constraints", "anti-patterns": "negative_constraints",
    "never do": "negative_constraints",
    "validation": "validation_rules", "checks": "validation_rules",
    "output format": "output_schema", "output": "output_schema", "schema": "output_schema",
    "response format": "output_schema", "format": "output_schema",
    "example": "examples", "few shot examples": "examples", "sample output": "examples",
    "edge case handling": "edge_cases", "corner cases": "edge_cases",
    "checklist": "quality_checklist", "quality bar": "quality_checklist",
    "self check": "quality_checklist", "self-check": "quality_checklist",
    "error handling": "failure_recovery", "fallback": "failure_recovery",
    "on failure": "failure_recovery", "recovery": "failure_recovery",
    "notes": "notes", "final notes": "notes", "additional notes": "notes",
    "remarks": "notes",
}

_HEADING_LINE = re.compile(
    r"""^\s*
    (?:\#{1,6}\s*)                  # ## Heading
    |^\s*(?:\*\*|__)(?=[^*_])       # **Heading**
    """,
    re.X,
)
_DECORATION = re.compile(
    r"^\s*(?:\#{1,6}\s*)?"                       # leading hashes
    r"(?:\*\*|__|\*|_)?\s*"                      # bold/italic open
    r"(?:step\s*)?(?:\d+\s*[.):\-]\s*)?"         # "3.", "Step 2:", "1)"
    r"(.*?)"                                     # the heading text
    r"\s*(?:\*\*|__|\*|_)?\s*:?\s*$",            # bold close, trailing colon
    re.I,
)


def _normalise_heading(raw: str) -> str:
    text = _DECORATION.sub(r"\1", raw.strip()).strip()
    text = re.sub(r"[`*_#]", "", text)
    # "Role & Persona" / "Role (system)" → "role"
    text = re.sub(r"\((.*?)\)", " ", text)
    text = re.sub(r"[^\w\s&/-]", " ", text)
    return re.sub(r"\s+", " ", text).strip().lower()


def _match_heading(raw: str) -> Optional[str]:
    canonical = {v.lower(): k for k, v in HEADINGS.items()}
    text = _normalise_heading(raw)
    if not text or len(text) > 60:
        return None
    if text in canonical:
        return canonical[text]
    if text in ALIASES:
        return ALIASES[text]
    if text in SECTIONS:
        return text
    underscored = text.replace(" ", "_").replace("-", "_")
    if underscored in SECTIONS:
        return underscored
    # "Role & Persona", "Output format (JSON)" — take the leading phrase.
    head = re.split(r"\s*(?:&|/|,|:| and | - )\s*", text)[0].strip()
    if head and head != text:
        return canonical.get(head) or ALIASES.get(head) or (head if head in SECTIONS else None)
    return None


def _strip_outer_fence(text: str) -> str:
    """Models often wrap the whole prompt in a ```markdown fence."""
    stripped = text.strip()
    match = re.match(r"^```[a-zA-Z]*\s*\n(.*)\n?```\s*$", stripped, re.S)
    return match.group(1) if match else text


def parse(text: str) -> dict[str, str]:
    """Best-effort inverse of `render`, used when a live provider returns markdown."""
    if not text:
        return {}
    found: dict[str, str] = {}
    current: Optional[str] = None
    in_fence = False
    for line in _strip_outer_fence(text).splitlines():
        stripped = line.strip()
        if stripped.startswith("```"):
            in_fence = not in_fence
            if current:
                found[current] += line + "\n"
            continue
        # A "## " inside a fenced block is content, not a heading.
        if not in_fence and _HEADING_LINE.match(line):
            matched = _match_heading(stripped)
            if matched:
                current = matched
                found.setdefault(current, "")
                continue
            # An unrecognised heading ends the previous section rather than
            # silently absorbing an unrelated block into it.
            current = None
            continue
        if current:
            found[current] += line + "\n"
    return {key: value.strip() for key, value in found.items() if value.strip()}


def coverage(sections: dict[str, str]) -> float:
    """Share of the canonical section list a parse actually recovered."""
    return round(len([s for s in SECTIONS if sections.get(s)]) / len(SECTIONS), 3)
