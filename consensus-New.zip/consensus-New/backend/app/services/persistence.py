"""Writes a completed workflow run into the database."""
from __future__ import annotations

from typing import Optional

from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import models


def record_audit(db: Session, actor: str, action: str, target: str = "",
                 detail: Optional[dict] = None):
    db.add(models.AuditEvent(actor=actor, action=action, target=target, detail=detail or {}))


def persist_run(db: Session, state: dict, payload: dict,
                user: Optional[models.User]) -> models.PromptSession:
    session = models.PromptSession(
        project_id=payload.get("project_id"),
        user_id=user.id if user else None,
        title=payload.get("title") or state["intent"]["objective"][:120],
        problem_statement=payload["problem_statement"],
        expected_output=payload.get("expected_output", ""),
        constraints=payload.get("constraints", []),
        target_models=payload.get("target_models", []),
        stage=state["stage"],
        intent=state["intent"],
        plan=state["plan"],
        total_tokens=state["total_tokens"],
        total_cost_usd=state["total_cost_usd"],
        duration_ms=state["duration_ms"],
    )
    db.add(session)
    db.flush()

    for provider, sections in state["drafts"].items():
        meta = state["draft_meta"][provider]
        draft = models.PromptDraft(
            session_id=session.id,
            provider=provider,
            agent=meta["agent"],
            content=meta["content"],
            sections=sections,
            tokens=meta["tokens"],
            cost_usd=meta["cost_usd"],
            duration_ms=meta["duration_ms"],
            simulated=meta["simulated"],
        )
        db.add(draft)
        db.flush()
        score = state["scores"][provider]
        db.add(models.Score(
            draft_id=draft.id,
            metrics=score["metrics"],
            weighted=score["weighted"],
            total=score["total"],
            rank=score.get("rank", 0),
            notes=score["notes"],
        ))

    consensus = state["consensus"]
    db.add(models.ConsensusResult(
        session_id=session.id,
        agreement=consensus["agreement"],
        common_strengths=consensus["common_strengths"],
        shared_gaps=consensus["shared_gaps"],
        contradictions=consensus["contradictions"],
        unique_contributions=consensus["unique_contributions"],
        section_winners=state["provenance"],
    ))

    master = models.MasterPrompt(
        session_id=session.id,
        title=session.title,
        content=state["master_content"],
        sections=state["master_sections"],
        provenance=state["provenance"],
        score=state["final_score"],
        qa_report=state["qa_report"],
        version=1,
    )
    db.add(master)
    db.flush()
    db.add(models.VersionHistory(
        master_prompt_id=master.id, version=1, content=master.content,
        change_note="Initial synthesis", author=user.full_name if user else "system",
    ))

    for log in state["logs"]:
        db.add(models.AgentLog(session_id=session.id, **log))

    record_audit(db, user.full_name if user else "system", "workflow.run", session.id,
                 {"score": state["final_score"], "cost": state["total_cost_usd"]})
    db.commit()
    db.refresh(session)
    return session


def revise_master(db: Session, master_id: str, content: str, note: str, author: str):
    master = db.get(models.MasterPrompt, master_id)
    if not master:
        return None
    master.version += 1
    master.content = content
    db.add(models.VersionHistory(
        master_prompt_id=master.id, version=master.version,
        content=content, change_note=note or "Manual edit", author=author,
    ))
    record_audit(db, author, "master.revise", master.id, {"version": master.version})
    db.commit()
    db.refresh(master)
    return master


def analytics_snapshot(db: Session) -> dict:
    sessions = db.scalars(select(models.PromptSession)).all()
    masters = db.scalars(select(models.MasterPrompt)).all()
    drafts = db.scalars(select(models.PromptDraft)).all()
    scores = db.scalars(select(models.Score)).all()

    by_provider: dict[str, list[float]] = {}
    for draft in drafts:
        score = next((s for s in scores if s.draft_id == draft.id), None)
        if score:
            by_provider.setdefault(draft.provider, []).append(score.total)

    provider_rows: list[dict] = [
        {"provider": provider, "average": round(sum(values) / len(values), 1),
         "runs": len(values), "best": max(values)}
        for provider, values in by_provider.items()
    ]
    provider_rows.sort(key=lambda r: float(r["average"]), reverse=True)

    consensus_rows = db.scalars(select(models.ConsensusResult)).all()
    return {
        "total_sessions": len(sessions),
        "total_prompts": len(masters),
        "average_score": round(sum(m.score for m in masters) / len(masters), 1) if masters else 0,
        "best_model": provider_rows[0]["provider"] if provider_rows else "n/a",
        "consensus_score": round(
            sum(c.agreement for c in consensus_rows) / len(consensus_rows), 3
        ) if consensus_rows else 0,
        "average_duration_ms": round(
            sum(s.duration_ms for s in sessions) / len(sessions)
        ) if sessions else 0,
        "total_tokens": sum(s.total_tokens for s in sessions),
        "total_cost_usd": round(sum(s.total_cost_usd for s in sessions), 4),
        "prompt_versions": sum(m.version for m in masters),
        "success_rate": round(
            len([m for m in masters if m.qa_report.get("passed")]) / len(masters), 3
        ) if masters else 0,
        "top_prompt": max(
            ({"id": m.id, "title": m.title, "score": m.score} for m in masters),
            key=lambda m: m["score"], default=None,  # type: ignore[arg-type,return-value]
        ),
        "by_provider": provider_rows,
        "recent": [
            {"id": s.id, "title": s.title, "score": next(
                (m.score for m in masters if m.session_id == s.id), 0),
             "created_at": s.created_at, "duration_ms": s.duration_ms}
            for s in sorted(sessions, key=lambda s: s.created_at, reverse=True)[:10]
        ],
    }
