"""Turns the caller's request into the concrete parts of a prompt.

The rest of the pipeline used to emit a fixed output schema, fixed placeholders
and fixed examples no matter what was asked for, so a request for
`"a single word: LOW, MEDIUM or HIGH"` still produced a JSON envelope with
`summary`/`items`/`warnings`. Everything specific to a request is derived here,
once, and every specialist writes against the same contract.
"""
from __future__ import annotations

import json
import re

# --- output contract ------------------------------------------------------

# Ordered: the first pattern that matches wins, so the more specific formats are
# tested before the generic "mentions json" case.
_FORMAT_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("json_lines", re.compile(
        r"\b(jsonl|ndjson|json lines?|one json (object|record) per line)\b", re.I)),
    ("enum", re.compile(r"\b(single (word|label|token)|one of|exactly one of|classify (it )?as|"
                        r"pick one|choose one)\b", re.I)),
    ("json", re.compile(r"\bjson\b", re.I)),
    ("csv", re.compile(
        r"\b(csv|tsv|comma[- ]separated|tab[- ]separated|spreadsheet|columns?)\b", re.I)),
    ("xml", re.compile(r"\b(xml|html|<[a-z_][\w\-]*>)\b", re.I)),
    ("yaml", re.compile(r"\byaml\b", re.I)),
    ("table", re.compile(r"\b(markdown table|table with)\b", re.I)),
    ("markdown", re.compile(r"\b(markdown|bullet(ed)? (list|points)|headings?)\b", re.I)),
    ("number", re.compile(
        r"\b(a (single )?(number|score|integer|percentage|float)|numeric score)\b", re.I)),
    ("boolean", re.compile(r"\b(true or false|yes or no|boolean)\b", re.I)),
]

_ARRAY_MARKERS = re.compile(
    r"\b(array|list|each|per (row|line|item|record|email|invoice|ticket|document|file)|"
    r"one (per|for each)|multiple|rows?|items?|records?|entries)\b", re.I
)

# "with sku, qty and unit_price", "containing a, b, c", "fields: a, b", "keys a and b"
_FIELD_LEAD = re.compile(
    r"\b(?:with|containing|including|comprising|fields?|keys?|columns?|properties|attributes)\b"
    r"\s*:?\s*(.+)$", re.I | re.S
)

_TYPE_HINTS: list[tuple[re.Pattern, str]] = [
    (re.compile(r"^(is|has|was|should|can|must)_|_(flag|match|matched|valid|present|required)$|"
                r"^(flag|match|valid|approved|rejected|duplicate)$", re.I), "boolean"),
    (re.compile(r"(qty|quantity|count|number|num|total|amount|price|cost|score|confidence|"
                r"rate|percent|weight|age|len|length|size|units?)", re.I), "number"),
    (re.compile(r"(_at$|_on$|date|time|timestamp|deadline|due)", re.I), "string (ISO-8601)"),
    (re.compile(
        r"(_ids$|_list$|tags|labels|categories|reasons|warnings|items|lines|errors)$", re.I),
     "array of string"),
]

_STOP_FIELDS = {
    "a", "an", "the", "and", "or", "each", "every", "per", "of", "for", "with", "plus", "also",
    "its", "their", "that", "which", "value", "values", "field", "fields", "one", "some",
}


def _split_fields(blob: str) -> list[str]:
    """Split a human field list — 'sku, qty and unit_price' — into names."""
    blob = re.split(r"[.;\n]", blob)[0]
    parts = re.split(r",|\band\b|\bplus\b|\balong with\b|/", blob, flags=re.I)
    names: list[str] = []
    for part in parts:
        # Prefer a backticked or quoted name, then a snake_case/camelCase token.
        quoted = re.search(r"[`\"']([a-zA-Z_][\w\- ]{0,40})[`\"']", part)
        token = quoted.group(1) if quoted else part
        token = re.sub(r"\([^)]*\)", " ", token)
        token = re.sub(r"[^\w\s\-]", " ", token).strip()
        if not token:
            continue
        words = [w for w in token.split() if w.lower() not in _STOP_FIELDS]
        if not words:
            continue
        name = "_".join(words[-3:]).lower()
        name = re.sub(r"[\s\-]+", "_", name).strip("_")
        if name and name not in names and not name.isdigit() and len(name) <= 40:
            names.append(name)
    return names[:14]


def _field_type(name: str) -> str:
    for pattern, kind in _TYPE_HINTS:
        if pattern.search(name):
            return kind
    return "string"


_INTEGER_HINT = re.compile(r"(?:^|_)(qty|quantity|count|number|num|units|index|rank|age|len|"
                           r"length|size)(?:$|_)", re.I)


def _sample_value(kind: str, name: str):
    if kind == "boolean":
        return True
    if kind == "number":
        return 0 if _INTEGER_HINT.search(name) else 0.0
    if kind.startswith("array"):
        return []
    if "ISO-8601" in kind:
        return "2026-01-31"
    return "…"


def _enum_values(text: str) -> list[str]:
    """Pull LOW / MEDIUM / HIGH style label sets out of the request."""
    upper = re.findall(r"\b([A-Z][A-Z_]{1,20})\b", text)
    upper = [u for u in upper if u not in {"JSON", "CSV", "XML", "YAML", "TSV", "PDF", "API",
                                           "ID", "URL", "HTML", "UI", "LLM", "CRM", "PO"}]
    if len(upper) >= 2:
        seen: list[str] = []
        for value in upper:
            if value not in seen:
                seen.append(value)
        return seen[:12]
    after = re.search(r"\b(?:one of|single (?:word|label|token)|either)\b\s*:?\s*(.+)$", text, re.I)
    if after:
        values = [
            v.strip(" .`\"'")
            for v in re.split(r",|\bor\b|\band\b|/|\|", after.group(1), flags=re.I)
        ]
        values = [v for v in values if v and len(v) <= 30][:12]
        if len(values) >= 2:
            return values
    return []


def derive_output_contract(expected_output: str, problem_statement: str = "",
                           task_type: str = "generation") -> dict:
    """Work out what shape the answer must take, and render a schema for it.

    Returns a contract the drafting layer renders into `Output schema`, the
    examples writer builds samples from, and QA validates the final prompt
    against.
    """
    stated = (expected_output or "").strip()
    haystack = stated or problem_statement or ""

    fmt = "text"
    for name, pattern in _FORMAT_PATTERNS:
        if pattern.search(haystack):
            fmt = name
            break
    # Classification with nothing else stated is an enum by nature.
    if fmt == "text" and task_type == "classification":
        fmt = "enum"

    contract: dict = {
        "format": fmt,
        "stated": stated,
        "derived": bool(stated),
        "fields": [],
        "enum_values": [],
        "is_array": bool(_ARRAY_MARKERS.search(haystack)),
        "notes": [],
    }

    if fmt == "enum":
        values = _enum_values(haystack) or ["LABEL_A", "LABEL_B"]
        contract["enum_values"] = values
        if not _enum_values(haystack):
            contract["notes"].append(
                "the label set was not stated — replace LABEL_A/LABEL_B with the real labels"
            )
        contract["schema"] = "\n".join([
            "Return exactly one of these labels and nothing else:",
            ", ".join(values),
        ])
        contract["schema_lang"] = ""
    elif fmt in {"json", "json_lines"}:
        lead = _FIELD_LEAD.search(haystack)
        names = _split_fields(lead.group(1)) if lead else []
        if not names:
            names = _default_fields(task_type)
            contract["notes"].append(
                "no field list was stated — these are inferred, confirm them before shipping"
            )
        contract["fields"] = [{"name": n, "type": _field_type(n)} for n in names]
        obj = {f["name"]: _sample_value(f["type"], f["name"]) for f in contract["fields"]}
        if fmt == "json_lines":
            contract["schema"] = json.dumps(obj, ensure_ascii=False)
            contract["notes"].append("one object per line, no enclosing array")
        elif contract["is_array"]:
            contract["schema"] = json.dumps([obj], indent=2, ensure_ascii=False)
        else:
            contract["schema"] = json.dumps(obj, indent=2, ensure_ascii=False)
        contract["schema_lang"] = "json"
    elif fmt == "csv":
        lead = _FIELD_LEAD.search(haystack)
        names = _split_fields(lead.group(1)) if lead else _default_fields(task_type)
        contract["fields"] = [{"name": n, "type": _field_type(n)} for n in names]
        header = ",".join(names)
        contract["schema"] = f"{header}\n" + ",".join(
            "true" if _field_type(n) == "boolean" else ("0" if _field_type(n) == "number" else "…")
            for n in names
        )
        contract["schema_lang"] = "csv"
        contract["notes"].append("emit the header row exactly once, then one row per record")
    elif fmt == "xml":
        lead = _FIELD_LEAD.search(haystack)
        names = _split_fields(lead.group(1)) if lead else _default_fields(task_type)
        contract["fields"] = [{"name": n, "type": _field_type(n)} for n in names]
        inner = "\n".join(f"  <{n}>…</{n}>" for n in names)
        contract["schema"] = f"<result>\n{inner}\n</result>"
        contract["schema_lang"] = "xml"
    elif fmt == "yaml":
        lead = _FIELD_LEAD.search(haystack)
        names = _split_fields(lead.group(1)) if lead else _default_fields(task_type)
        contract["fields"] = [{"name": n, "type": _field_type(n)} for n in names]
        contract["schema"] = "\n".join(f"{n}: …" for n in names)
        contract["schema_lang"] = "yaml"
    elif fmt in {"number", "boolean"}:
        contract["schema"] = (
            "Return a single number and nothing else." if fmt == "number"
            else "Return exactly `true` or `false` and nothing else."
        )
        contract["schema_lang"] = ""
    elif fmt == "table":
        contract["schema"] = ("| column | column |\n| --- | --- |\n| … | … |")
        contract["schema_lang"] = ""
        contract["notes"].append("a markdown table, header row included, no prose around it")
    elif fmt == "markdown":
        contract["schema"] = (stated or "A markdown document.") + \
            "\nUse headings and bullets; no preamble and no sign-off."
        contract["schema_lang"] = ""
    else:
        contract["schema"] = (
            stated or "Plain prose answering the request directly."
        ) + "\nNo preamble, no restatement of the question, no sign-off."
        contract["schema_lang"] = ""
        if not stated:
            contract["notes"].append(
                "no output format was stated — the caller should pin one down"
            )

    return contract


def _default_fields(task_type: str) -> list[str]:
    return {
        "extraction": ["source_id", "field", "value", "confidence"],
        "classification": ["label", "confidence", "rationale"],
        "summarisation": ["summary", "key_points", "omitted"],
        "analysis": ["finding", "evidence", "severity"],
        "transformation": ["original", "converted", "notes"],
        "agentic": ["action", "arguments", "expected_effect"],
    }.get(task_type, ["result", "rationale", "confidence"])


def render_schema_block(contract: dict) -> str:
    """The `Output schema` body: a fenced block when the format has a language."""
    lang = contract.get("schema_lang") or ""
    body = contract.get("schema", "")
    lines = []
    if lang:
        lines += [f"```{lang}", body, "```"]
    else:
        lines.append(body)
    for note in contract.get("notes", []):
        lines.append(f"_Note: {note}._")
    return "\n".join(lines)


# --- input placeholders ---------------------------------------------------

# Concrete artifacts a prompt is likely to be handed at runtime. The generated
# prompt must declare the caller's nouns, not the forge's own request fields.
_ARTIFACTS: list[tuple[re.Pattern, str, str]] = [
    (re.compile(r"\b(invoice|bill)s?\b", re.I), "invoice_document", "the invoice to process"),
    (re.compile(r"\b(purchase order|\bpo\b)s?\b", re.I), "purchase_order",
     "the purchase order to reconcile against"),
    (re.compile(r"\b(receipt)s?\b", re.I), "receipt_document", "the receipt to process"),
    (re.compile(r"\b(resume|resumé|cv)s?\b", re.I), "resume_document", "the candidate resume"),
    (re.compile(r"\b(contract|agreement)s?\b", re.I), "contract_document", "the contract text"),
    (re.compile(r"\b(ticket|issue|case)s?\b", re.I), "ticket", "the ticket to handle"),
    (re.compile(r"\b(email|e-mail|message)s?\b", re.I), "email_message", "the raw email"),
    (re.compile(r"\b(transcript|call|meeting)s?\b", re.I), "transcript",
     "the conversation transcript"),
    (re.compile(r"\b(review|feedback|survey)s?\b", re.I), "review_text", "the customer review"),
    (re.compile(r"\b(log|trace|stacktrace)s?\b", re.I), "log_excerpt", "the log excerpt"),
    (re.compile(r"\b(article|blog|post|news)s?\b", re.I), "article_text", "the article body"),
    (re.compile(r"\b(code|diff|pull request|commit|repo)s?\b", re.I), "code_diff",
     "the code or diff under review"),
    (re.compile(r"\b(product|catalog|listing|sku)s?\b", re.I), "product_record",
     "the product record"),
    (re.compile(r"\b(query|question|search)\b", re.I), "user_query", "the end user's question"),
    (re.compile(r"\b(pdf|scan|scanned|image|document|file)s?\b", re.I), "source_document",
     "the source document, already converted to text"),
    (re.compile(r"\b(record|row|entry|dataset|table)s?\b", re.I), "input_record",
     "the record to process"),
]


# Catch-alls that describe *any* input. Declaring `source_document` next to
# `invoice_document` for "scanned invoice PDFs" names the same artifact twice, so
# these only apply when nothing specific matched.
_GENERIC_INPUTS = {"source_document", "input_record", "input_text"}


def derive_inputs(problem_statement: str, context: str = "") -> list[dict]:
    """Name the runtime inputs the generated prompt will actually be handed."""
    haystack = f"{problem_statement}\n{context}"
    found: list[dict] = []
    for pattern, name, description in _ARTIFACTS:
        if name in _GENERIC_INPUTS:
            continue
        if pattern.search(haystack) and not any(f["name"] == name for f in found):
            found.append({"name": name, "description": description, "required": True})
        if len(found) >= 3:
            break
    if not found:
        for pattern, name, description in _ARTIFACTS:
            if name in _GENERIC_INPUTS and pattern.search(haystack):
                found.append({"name": name, "description": description, "required": True})
                break
    if not found:
        found.append({
            "name": "input_text",
            "description": "the text to work on",
            "required": True,
        })
    found.append({
        "name": "reference_material",
        "description": "supporting context the answer may rely on; may be empty",
        "required": False,
    })
    return found


def derive_variables(contract: dict, constraints: list[str]) -> list[dict]:
    """Only variables the prompt body will genuinely reference.

    Declaring `{{tone}}` and then never mentioning it again produced prompts full
    of dead knobs, so each variable here is emitted with the section that uses it.
    """
    variables: list[dict] = [{
        "name": "strictness",
        "default": "strict",
        "description": "`strict` refuses on missing data; `lenient` returns partials with warnings",
        "used_in": "failure_recovery",
    }]
    if contract["format"] in {"json", "json_lines", "csv", "xml", "yaml"}:
        variables.append({
            "name": "max_records",
            "default": "50",
            "description": "hard cap on emitted records",
            "used_in": "constraints",
        })
    if contract["format"] in {"markdown", "text", "table"}:
        variables.append({
            "name": "max_words",
            "default": "400",
            "description": "hard cap on answer length",
            "used_in": "constraints",
        })
    if any(re.search(r"\blanguage|translat|locale\b", c, re.I) for c in constraints):
        variables.append({
            "name": "target_language",
            "default": "same as the input",
            "description": "language the answer is written in",
            "used_in": "constraints",
        })
    return variables
