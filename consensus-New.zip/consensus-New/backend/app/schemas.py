"""API contracts. Services below this layer speak plain dicts.

Every free-text field is bounded. These payloads fan out into paid LLM calls, so an
unbounded string is a cost-amplification vector, not just a large request.
"""
from __future__ import annotations

from datetime import datetime
from typing import Literal, Optional

from pydantic import BaseModel, ConfigDict, EmailStr, Field

ROLES = Literal["engineer", "admin", "viewer"]
EXPORT_FORMATS = Literal["markdown", "json", "yaml", "xml", "txt", "template", "html"]


class LoginRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=1, max_length=200)


class PasswordChange(BaseModel):
    current_password: str = Field(min_length=1, max_length=200)
    new_password: str = Field(min_length=12, max_length=200)


class UserOut(BaseModel):
    id: str
    email: str
    full_name: str
    role: str
    is_active: bool = True

    model_config = ConfigDict(from_attributes=True)


class UserCreate(BaseModel):
    email: EmailStr
    full_name: str = Field(min_length=1, max_length=160)
    password: str = Field(min_length=12, max_length=200)
    role: ROLES = "engineer"


class UserUpdate(BaseModel):
    full_name: Optional[str] = Field(default=None, min_length=1, max_length=160)
    role: Optional[ROLES] = None
    is_active: Optional[bool] = None


class PasswordReset(BaseModel):
    new_password: str = Field(min_length=12, max_length=200)


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"  # noqa: S105 — a scheme name, not a secret
    user: UserOut


class GenerateRequest(BaseModel):
    problem_statement: str = Field(min_length=15, max_length=20_000)
    expected_output: str = Field(default="", max_length=10_000)
    constraints: list[str] = Field(default=[], max_length=50)
    target_models: list[str] = Field(default=[], max_length=20)
    context: str = Field(default="", max_length=20_000)
    business_goal: str = Field(default="", max_length=5_000)
    providers: list[str] = Field(default=[], max_length=10)
    title: str = Field(default="", max_length=200)
    project_id: Optional[str] = Field(default=None, max_length=32)


class AnalyzeRequest(BaseModel):
    problem_statement: str = Field(min_length=15, max_length=20_000)
    expected_output: str = Field(default="", max_length=10_000)
    constraints: list[str] = Field(default=[], max_length=50)


class EvaluateRequest(BaseModel):
    sections: dict[str, str] = Field(max_length=40)


class ExportRequest(BaseModel):
    master_prompt_id: str = Field(max_length=32)
    format: EXPORT_FORMATS = "markdown"


class ReviseRequest(BaseModel):
    content: str = Field(min_length=1, max_length=200_000)
    change_note: str = Field(default="", max_length=300)


class ProjectCreate(BaseModel):
    name: str = Field(min_length=1, max_length=160)
    description: str = Field(default="", max_length=2_000)


class SettingUpdate(BaseModel):
    key: str = Field(min_length=1, max_length=80)
    value: str = Field(max_length=10_000)
    encrypted: bool = False


class SessionSummary(BaseModel):
    id: str
    title: str
    stage: str
    total_tokens: int
    total_cost_usd: float
    duration_ms: int
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)
