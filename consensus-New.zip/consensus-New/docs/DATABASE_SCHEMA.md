# Database schema

SQLAlchemy 2.0 declarative models in `backend/app/models.py`. IDs are 16-char hex strings.
SQLite by default; set `FORGE_DATABASE_URL` for PostgreSQL.

## Tables

### users
`id` PK · `email` unique+indexed · `full_name` · `password_hash` (PBKDF2-SHA256, per-user
salt, 120k iterations) · `role` (`engineer` · `admin` · `viewer`) · `is_active` · `created_at`

### projects
`id` PK · `name` · `description` · `owner_id` FK→users · `created_at`. Cascades to sessions.

### prompt_sessions
One full pass through the ten stages.

| Column | Notes |
|---|---|
| `id` | PK |
| `project_id` | FK→projects |
| `user_id` | who ran it |
| `title`, `problem_statement`, `expected_output` | the brief |
| `constraints`, `target_models` | JSON arrays |
| `stage` | **indexed** — `queued` · `running` · `complete` · `failed` |
| `intent`, `plan` | JSON, the output of agents 1 and 2 |
| `total_tokens`, `total_cost_usd`, `duration_ms` | run accounting |
| `created_at` | **indexed** — history is always sorted by it |

### prompt_drafts
`id` PK · `session_id` FK **indexed** · `provider` · `agent` · `content` · `sections` JSON ·
`tokens` · `cost_usd` · `duration_ms` · `simulated` · `created_at`.

`simulated` is stored per draft, not per run, because a single run can mix live and simulated
providers when only some keys are configured.

### scores
`id` PK · `draft_id` FK **indexed** · `metrics` JSON (metric → 0-100) · `weighted` JSON
(metric → weighted contribution) · `total` · `rank` · `notes` JSON · `created_at`.

Both raw and weighted values are stored so the scorecard can show the profile and the
contribution without recomputing, and so a future change to the weights does not
retroactively rewrite history.

### consensus_results
`id` PK · `session_id` **indexed** · `agreement` · `common_strengths` · `shared_gaps` ·
`contradictions` · `unique_contributions` · `section_winners` (all JSON) · `created_at`.

### master_prompts
`id` PK · `session_id` FK **indexed** · `title` · `content` · `sections` JSON ·
`provenance` JSON (section → provider) · `score` · `qa_report` JSON · `version` ·
`starred` · `created_at`. One per session.

### version_history
`id` PK · `master_prompt_id` **indexed** · `version` · `content` · `change_note` · `author` ·
`created_at`. Append-only: every revision writes a row, nothing is updated in place, so any
earlier version of a shipped prompt can be recovered.

### agent_logs
`id` PK · `session_id` FK **indexed** · `agent` · `stage` · `status` · `summary` ·
`input_digest` · `output_digest` · `tokens` · `cost_usd` · `duration_ms` · `confidence` ·
`warnings` JSON · `recommendations` JSON · `created_at`.

Digests are short summaries, never a model's private deliberation.

### settings
`id` PK · `key` unique · `value` · `encrypted` · `updated_at`. When `encrypted` is true the
value is sealed and the API returns it masked.

### audit_events
`id` PK · `actor` · `action` · `target` · `detail` JSON · `created_at`. Written on every
workflow run, revision and settings change.

## Relationships

```
users ──1:N──▶ projects ──1:N──▶ prompt_sessions ──1:N──▶ prompt_drafts ──1:1──▶ scores
                                        │
                                        ├──1:N──▶ agent_logs
                                        ├──1:1──▶ consensus_results
                                        └──1:1──▶ master_prompts ──1:N──▶ version_history
```

## Indexing

Indexed today: `users.email`, `prompt_sessions.stage`, `prompt_sessions.created_at`,
`prompt_drafts.session_id`, `scores.draft_id`, `master_prompts.session_id`,
`agent_logs.session_id`, `version_history.master_prompt_id`, `consensus_results.session_id`.

For PostgreSQL at volume, add a composite index on `prompt_sessions(project_id, created_at)`
for per-project history, and move the large JSON columns (`sections`, `metrics`) to `JSONB`
so they can be queried rather than only read.
