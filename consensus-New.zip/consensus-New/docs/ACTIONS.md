# Actions checklist

## Complete

### Backend
- [x] Environment-driven typed configuration
- [x] Ten tables: users, projects, sessions, drafts, scores, consensus, masters, versions, logs, settings
- [x] PBKDF2 password hashing, HMAC-signed bearer tokens
- [x] Authenticated key sealing with masked reads
- [x] Role guard (engineer / admin / viewer) and per-client rate limiting
- [x] Unified provider gateway across four vendor API shapes
- [x] Retries, circuit breaker, token estimation and cost accounting
- [x] Asymmetric offline simulator so drafts genuinely differ
- [x] Agents 1-10 plus the optimizer, with per-agent telemetry
- [x] Concurrent drafting stage with isolated state per thread
- [x] Deterministic ten-metric weighted evaluation matrix
- [x] Consensus: agreement matrix, shared gaps, contradictions, unique contributions
- [x] Weaver with per-section winners and enforced hybrid output
- [x] QA: JSON, XML, markdown, placeholder and staleness validation
- [x] Export in markdown, JSON, YAML, XML, text, template and HTML
- [x] Prompt versioning with append-only history
- [x] Analytics, audit trail, structured logging with correlation ids
- [x] Seed data: two complete runs so every screen has content
- [x] 26 tests covering the engine, the API, RBAC and secret handling

### Frontend
- [x] Design system where only the four specialist colours carry hue
- [x] Consensus bar — the signature element, one lane per section
- [x] App shell with collapsible nav and live provider status bar
- [x] Workspace: brief, constraints, specialist selection, results
- [x] Workflow graph on React Flow with per-node status, tokens, duration, score
- [x] Agent monitor with confidence, warnings and recommendations
- [x] Four-column section comparison with the chosen draft marked
- [x] Score dashboard: radar profile, weighted totals, per-specialist scorecards
- [x] Master prompt viewer in Monaco with QA panel and seven-format export
- [x] Library, history, analytics and settings screens
- [x] Route-level code splitting, typed API client, keyboard focus, reduced motion

### Tooling
- [x] README, ARCHITECTURE, API_DOCUMENTATION, DATABASE_SCHEMA, DEPLOYMENT, PROJECT_PLAN, ACTIONS
- [x] Docker Compose with PostgreSQL, both Dockerfiles
- [x] GitHub Actions CI: backend tests, frontend typecheck and build

## Pending

- [ ] Server-sent events so the workflow graph fills in live
- [ ] Celery + Redis once runs are long enough to need a queue
- [ ] Redis-backed rate limiting for multi-worker deployments
- [ ] Alembic migrations in place of `create_all`
- [ ] OpenTelemetry exporter in the tracing middleware
- [ ] Vitest coverage for the Workspace and Comparison flows
- [ ] RAG grounding for few-shot material in the planner
- [ ] A/B execution scoring — measure the prompt by running it, not only by analysing it
