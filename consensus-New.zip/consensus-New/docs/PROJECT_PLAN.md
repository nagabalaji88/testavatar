# Project plan

Five sprints, each ending with something runnable.

## Sprint 1 — Foundation ✅
Environment-driven config, ten SQLAlchemy tables, PBKDF2 hashing, HMAC-signed tokens, key
sealing, RBAC dependency, in-process rate limiter.

## Sprint 2 — Provider gateway and drafting ✅
One `complete()` across four vendor API shapes, with retries, a circuit breaker and token/cost
accounting. The asymmetric simulator, so the platform is fully demonstrable without keys.

## Sprint 3 — The ten agents ✅
Intent analyzer, planner, four specialists (concurrent), evaluator, consensus builder, weaver,
QA and optimizer. Deterministic evaluation matrix. Diversity enforcement in the weaver.

## Sprint 4 — API and persistence ✅
Four routers covering generation, stage-by-stage endpoints, library, versioning, export in
seven formats, analytics and audit. 26 tests including RBAC and secret masking.

## Sprint 5 — Interface ✅
Design system first — the four specialist colours are the only hues in the product — then the
eleven screens. Route-level splitting keeps Monaco, React Flow and Recharts out of the initial
bundle.

## What the next sprint would take on

- **Streaming.** Runs return complete today. SSE would let the Workflow graph light up stage
  by stage instead of appearing finished, which is the single biggest perceived-quality gap.
- **Celery + Redis.** Worth adding when runs get slow enough to need a job queue — realistically
  once live inference on four providers with long context puts runs past ~30 seconds. Today a
  run completes in well under a second, so a broker would be operational weight for nothing.
- **Redis-backed rate limiting**, replacing the per-process limiter.
- **Alembic migrations**, replacing `create_all` on boot.
- **Frontend tests.** Vitest and Testing Library on the Workspace and Comparison flows.
- **RAG grounding.** The brief lists "RAG ready"; the hook would be feeding retrieved
  domain examples into the planner so specialists draft against real few-shot material.
- **Prompt A/B execution.** Score the prompt by running it, not only by analysing its text —
  the honest limitation of deterministic scoring is that it measures prompt *craft*, not
  downstream task accuracy.
