# API reference

Base URL `http://localhost:8000/api` · interactive docs at `/docs`.
Everything except `/status`, `/health` and `/auth/login` needs `Authorization: Bearer <token>`.
Every response carries an `x-trace-id` header for log correlation.

## Auth

| Method | Path | Body → Returns |
|---|---|---|
| POST | `/auth/login` | `{email, password}` → `{access_token, token_type, user}` |
| GET | `/auth/me` | → current user |

## Workflow

| Method | Path | Notes |
|---|---|---|
| POST | `/generate` | Runs all ten stages. Rate limited. |
| POST | `/analyze` | Stages 1-3 only: intent and plan |
| POST | `/draft` | Stages 1-4: the four drafts, no scoring |
| POST | `/evaluate` | Score an arbitrary section map against the matrix |
| POST | `/consensus` | Stages 1-6: scores plus the consensus analysis |
| POST | `/weave` | Stages 1-7: the woven sections and their provenance |
| GET | `/workflow/meta` | Stages, agent registry, section list, weights, provider status |
| GET | `/sessions/{id}` | A stored run: drafts, scores, consensus, master, logs |

`POST /generate` body:

```json
{
  "problem_statement": "Extract invoice fields from scanned PDFs and flag anomalies.",
  "expected_output": "JSON with line items and a confidence per field",
  "constraints": ["never guess a total"],
  "target_models": ["gpt-4o"],
  "providers": ["openai", "anthropic", "google", "moonshot"],
  "title": "Invoice extraction"
}
```

Response (abridged):

```json
{
  "session_id": "3f8a…",
  "intent": {"task_type": "extraction", "risks": [], "clarifications": []},
  "drafts": {"openai": {"sections": {}, "content": "", "meta": {}, "score": {}}},
  "ranking": ["anthropic", "google", "moonshot", "openai"],
  "consensus": {"agreement": 0.63, "shared_gaps": [], "contradictions": [],
                "unique_contributions": {}},
  "master": {"id": "…", "content": "…", "sections": {}, "provenance": {}, "score": 92.6},
  "qa_report": {"passed": true, "problems": [], "placeholders": []},
  "logs": [{"agent": "Intent Analyzer", "duration_ms": 1, "confidence": 0.85}],
  "totals": {"tokens": 3373, "cost_usd": 0.0116, "duration_ms": 214}
}
```

`logs` always has eleven entries — the ten agents plus the optimizer — in execution order.
`provenance` maps each of the eighteen sections to the specialist that won it, or `weaver`
where the section had to be synthesised because no draft supplied one.

## Library, history, export

| Method | Path | Notes |
|---|---|---|
| GET | `/history` | Recent sessions with tokens, cost and duration |
| GET | `/library` | Master prompts ranked by score; `starred_only=true` filters |
| GET | `/library/{id}` | Prompt plus its full version history |
| POST | `/library/{id}/revise` | `{content, change_note}` — increments the version |
| POST | `/library/{id}/star` | Toggles the star |
| GET | `/export/formats` | The seven supported formats |
| POST | `/export` | `{master_prompt_id, format}` → file download with `Content-Disposition` |
| GET | `/analytics` | Totals, per-provider averages, recent runs, success rate |

Export formats: `markdown`, `json`, `yaml`, `xml`, `txt`, `template`, `html`.
The `template` format keeps `{{placeholders}}` intact and prepends a declared `@var` header.

## Projects, settings, audit

| Method | Path | Notes |
|---|---|---|
| GET | `/projects` | All projects with session counts |
| POST | `/projects` | **engineer or admin** — 403 for viewers |
| GET | `/settings` | Stored settings (secrets masked), runtime config, provider status |
| PUT | `/settings` | **admin only** — `{key, value, encrypted}`; sealed before storage |
| GET | `/audit` | Audit trail, newest first |
| GET | `/agent-logs` | Recent agent telemetry across all runs |

## Status

`GET /api/status` → `{status, app, providers: {id: {label, mode}}}` where mode is `live` or
`simulated`. `GET /api/health` → `{"status": "ok"}` for load balancer probes.

## Errors

| Code | When |
|---|---|
| 401 | Missing, malformed, expired or tampered token |
| 403 | Role lacks the permission (viewer creating a project, non-admin writing settings) |
| 422 | Body fails validation — e.g. a problem statement under 15 characters |
| 429 | Rate limit reached (default 60/minute per client) |
