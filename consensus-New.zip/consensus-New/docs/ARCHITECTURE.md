# Architecture

## Shape

```
React 19 + Vite (TypeScript)              FastAPI (Python 3.12)
┌────────────────────────────┐            ┌──────────────────────────────────────┐
│ 11 screens, lazily loaded  │            │ routers → agents → services          │
│ Zustand (run state, auth)  │   HTTPS    │ RBAC dependency + rate limiter       │
│ TanStack Query (server)    │ ─────────► │ provider gateway (4 vendors)         │
│ Axios client (+ token)     │            │ SQLAlchemy → SQLite / PostgreSQL     │
└────────────────────────────┘            └──────────────────────────────────────┘
                                                        │
                                       evaluation engine · consensus · export
```

## The ten stages

```
1 input analysis   ─┐
2 intent            ├─ Intent Analyzer      objective, constraints, risks, questions
3 planning          ┘  Prompt Planner       section brief every specialist writes to
                    
4 drafting             ┌── GPT Specialist      structure, schema, function calling
                       ├── Claude Specialist   reasoning, edge cases, safety
   (concurrent) ───────┤── Gemini Specialist   context, grounding, examples
                       └── Kimi Specialist     conciseness, cross-language, recovery

5 evaluation           Prompt Evaluator     10 metrics × fixed weights → 0-100
6 consensus            Consensus Builder    agreement, gaps, contradictions, unique ideas
7 weaving              Master Weaver        best section from each draft, diversity enforced
8 validation           Quality Assurance    JSON / XML / markdown / placeholders / staleness
9 optimization         Optimizer            de-duplicates lines, reports the final score
10 export              Export engine        markdown, json, yaml, xml, txt, template, html
```

Stage 4 is the only fan-out. It runs in a thread pool because the four calls are independent
and network-bound; every later stage needs all four drafts, so they are sequential.

## Design decisions worth knowing

**Scoring is deterministic, not model-judged.** Every one of the ten metrics is a pure
function of the draft's own text — sentence length for clarity, vendor-name mentions for
portability, guard phrases minus hedges for hallucination resistance. Two runs of the same
draft always produce the same score, which is what makes the ranking arguable rather than
mysterious, and what makes the test suite possible. Asking a model to grade prompts would
have been fewer lines and considerably less trustworthy.

**The weaver enforces diversity.** Sections are awarded on the metrics that section actually
moves (`SECTION_METRICS`), not overall draft rank. If a single provider still sweeps, the
sections with the smallest margin of loss are reassigned to the runner-up. There is a test
that fails if the master prompt ever comes from one source.

**The simulator is asymmetric on purpose.** Each provider profile marks sections as deep,
thin or skipped. A simulator that gave all four the same output would make consensus
meaningless — the gaps and contradictions the UI displays would be artefacts of nothing.

**One gateway, four vendors.** Anthropic's `x-api-key` plus system field, Google's URL-keyed
`generateContent`, and the two OpenAI-compatible endpoints are normalised in
`providers.py`. Retries, the circuit breaker, token estimation and cost accounting live
there once, not per agent.

**Secrets are sealed, never stored plain.** `seal()`/`unseal()` derive a keystream from the
app secret and authenticate it with HMAC; the API only ever returns a masked value. This is
adequate for a self-hosted deployment and deliberately isolated behind two functions so it
can be replaced with KMS or Vault without touching anything else.

**Plain dicts below the API boundary.** Pydantic models exist only in `schemas.py`. Agents
and services take and return dicts, which is why the evaluation and consensus functions are
directly unit-testable.

## Layout

```
backend/app/
  api/          routers: auth, workflow, library, admin (+ deps.py: RBAC, rate limit)
  agents/       base, analysis, specialists, synthesis, orchestrator
  services/     providers, drafting, sections, evaluation, consensus, export, persistence
  core/         config, database, security (hashing, tokens, key sealing)
  models.py     10 tables · schemas.py  API contracts · seed.py  demo runs
backend/tests/  26 tests across the engine and the API

frontend/src/
  components/   ui primitives, ConsensusBar (the signature element)
  layouts/      AppShell: sidebar, header, provider status bar
  pages/        11 screens
  services/     typed Axios client · store/ Zustand · types/ shared contracts
```

## Observability

Every request passes through middleware that assigns a correlation id, returns it as
`x-trace-id` and writes a structured JSON access line. Agent-level telemetry — duration,
tokens, cost, confidence, warnings — is persisted per run in `agent_logs` and surfaced in the
Agent Monitor. The middleware is the intended seam for an OpenTelemetry exporter; swapping
the logger for a tracer is a single-file change.

## Known deviations from the brief

Worth stating plainly rather than burying:

- **shadcn/ui** is not used. It is a code-generation CLI that copies Radix-based components
  into the repo; the equivalent primitives are hand-written in `components/ui.tsx` so the
  bundle stays small and there is no generated code nobody reviewed.
- **Celery, Redis and LiteLLM** are not dependencies. The gateway implements the LiteLLM
  surface that this app needs (one `complete()`, retries, breaker, cost) in ~150 lines, and
  runs complete in seconds, so a broker and worker would add operational weight for no gain.
  `PROJECT_PLAN.md` covers where they become worth it.
- **Streaming** is not implemented. Runs return complete; SSE is the first item in the next
  sprint.
