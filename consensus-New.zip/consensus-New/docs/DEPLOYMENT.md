# Deployment guide

## Local with Docker Compose

```bash
cat > .env <<'EOF'
POSTGRES_PASSWORD=<random value>
FORGE_SECRET_KEY=<python -c "import secrets;print(secrets.token_urlsafe(48))">
EOF
docker compose up --build
```

Frontend on 5173 (nginx serving a static build), backend on 8000, PostgreSQL internal to the
compose network. Compose refuses to start if `POSTGRES_PASSWORD` or `FORGE_SECRET_KEY` is unset.

## Configuration guard

Setting `FORGE_ENV=production` makes the app validate its own configuration at import time and
**refuse to boot** on any of:

- `FORGE_SECRET_KEY` left at the built-in default, or shorter than 32 characters
- `FORGE_DATABASE_URL` still pointing at SQLite
- `FORGE_CORS_ORIGINS` empty or set to `*`

This is deliberate: a silently-insecure production process is worse than a failed deploy.
Production also disables `/docs`, `/redoc` and `/openapi.json`.

## First run

Production skips the demo seed entirely, so create the first account explicitly:

```bash
python -m alembic upgrade head
python -m app.cli create-admin --email you@example.com --name "Your Name"
```

Omit `--password` and you will be prompted, which keeps the credential out of shell history.
Everyone else is provisioned through `POST /api/users` by an admin. `python -m app.cli
reset-password --email ...` is the break-glass path if an admin locks themselves out.

## Schema changes

Migrations are Alembic, not `create_all`:

```bash
alembic revision --autogenerate -m "what changed"   # review the generated file before committing
alembic upgrade head
```

`create_all` runs in development only. CI runs `alembic check` so a model edited without a
matching migration fails the build rather than the deploy.

## Production checklist

- [ ] `FORGE_ENV=production` (turns on every guard above)
- [ ] `FORGE_SECRET_KEY` random, 32+ bytes. It signs tokens *and* derives the key sealing stored
      provider keys — rotating it invalidates both, so rotate deliberately and re-enter provider
      keys afterwards.
- [ ] `FORGE_DATABASE_URL` pointing at PostgreSQL
- [ ] `FORGE_CORS_ORIGINS` set to your real frontend origin
- [ ] TLS terminated in front of the app. Tokens are bearer tokens; over plain HTTP they are
      readable in transit.
- [ ] Provider keys set as environment variables or through a secret manager, not through the
      UI, so they never reach the database.
- [ ] `/metrics` scraped by Prometheus, and reachable only from inside your network — it is not
      behind auth.

## Known limits before you scale out

These are correct for a single-worker, single-team deployment and become wrong past it.

**Rate limiter and circuit breaker are per-process.** Both live in module-level dicts. Run four
workers and the effective rate limit is four times what you configured, and each worker learns
about a failing provider independently. Move both to Redis before running more than one worker.

**`POST /api/generate` is synchronous.** The full ten-agent workflow runs inside the request.
Against the local simulator that is fast; against four live provider APIs a run can exceed a
typical 30–60s load-balancer timeout. Move it to a job queue with a polling or websocket
progress channel before putting real provider keys behind real users.

**Tokens are revocable but not refreshable.** `token_version` on the user row invalidates every
outstanding token for that user on logout, password change, role change or deactivation. There
is no refresh-token rotation, so the TTL (`FORGE_TOKEN_TTL_SECONDS`, default 12h) is the only
thing bounding a leaked token's life beyond an explicit revocation.

**The token lives in `localStorage`.** That means any XSS bug is an account takeover. Moving to
an httpOnly cookie requires adding CSRF protection at the same time — do both together or
neither.

## Backend image

```bash
docker build -t promptforge-api ./backend
docker run -p 8000:8000 \
  -e FORGE_ENV=production \
  -e FORGE_SECRET_KEY=... \
  -e FORGE_CORS_ORIGINS=https://app.example.com \
  -e FORGE_DATABASE_URL=postgresql+psycopg://user:pass@host/forge \
  promptforge-api
```

Runs as a non-root user (uid 10001). Serve with multiple workers only after addressing the
per-process state noted above.

## Frontend

The image is a multi-stage build: Vite compiles the app, nginx serves `dist/`. The API base URL
is baked in at build time, so it is a build arg, not a runtime env var:

```bash
docker build --build-arg VITE_API_BASE=https://api.example.com/api -t promptforge-web ./frontend
```

nginx already handles the SPA catch-all rewrite, so deep links resolve instead of 404ing.
Listens on 8080 as a non-root user.

## Health and readiness

- `GET /api/health` → liveness, no dependencies touched.
- `GET /api/status` → readiness plus which providers are live vs simulated.
- `GET /metrics` → Prometheus request counters and latency histograms, labelled by route
  template so `/sessions/{id}` is one series rather than one per session.

A provider being simulated is not an outage — the app degrades to local drafting rather than
failing the request, which is why status distinguishes the two.

## Backups

Everything worth keeping is in the database: prompts, versions, scores and audit trail. Back up
on the usual Postgres schedule. `version_history` is append-only, so a restore recovers every
revision, not just the current one.
