/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        // Neumorphism needs the page and its raised elements to share one base —
        // the form comes from light and shadow, not from a fill change. A faint
        // blue-grey is what lets the white highlight read at all; on pure white
        // there is nothing for the top-left light to be brighter than.
        ink: '#E8EDF5',
        panel: '#EDF1F8',
        raised: '#F3F6FB',
        sunken: '#E2E8F1',
        line: 'rgba(163,177,198,0.28)',

        brand: {
          DEFAULT: '#2563EB',
          deep: '#1D4ED8',
          soft: '#93C5FD',
          wash: '#DBEAFE',
        },
        signal: '#2563EB',
        // The shadow pair, exposed so components can build their own extrusions.
        shade: '#A3B1C6',

        // Four specialists, kept in the cool family the reference works in and
        // darkened until small labels clear 4.5:1 on the base.
        gpt: '#047857',
        claude: '#6D28D9',
        gemini: '#1D4ED8',
        kimi: '#BE185D',
      },
      fontFamily: {
        display: ['Outfit', 'system-ui', 'sans-serif'],
        body: ['"IBM Plex Sans"', 'system-ui', 'sans-serif'],
        mono: ['"IBM Plex Mono"', 'ui-monospace', 'monospace'],
      },
      borderRadius: {
        xl: '1rem',
        '2xl': '1.5rem',
        '3xl': '2rem',
      },
      boxShadow: {
        // The vocabulary: everything is either pushed out of the surface or
        // pressed into it.
        raised: '8px 8px 18px rgba(163,177,198,0.48), -8px -8px 18px rgba(255,255,255,0.95)',
        'raised-sm': '4px 4px 10px rgba(163,177,198,0.42), -4px -4px 10px rgba(255,255,255,0.92)',
        'raised-lg': '14px 14px 30px rgba(163,177,198,0.5), -14px -14px 30px rgba(255,255,255,0.96)',
        pressed: 'inset 4px 4px 9px rgba(163,177,198,0.52), inset -4px -4px 9px rgba(255,255,255,0.94)',
        'pressed-sm': 'inset 2px 2px 5px rgba(163,177,198,0.5), inset -2px -2px 5px rgba(255,255,255,0.92)',
      },
      keyframes: {
        shimmer: { '0%': { backgroundPosition: '-200% 0' }, '100%': { backgroundPosition: '200% 0' } },
        rise: { from: { opacity: '0', transform: 'translateY(8px)' }, to: { opacity: '1', transform: 'translateY(0)' } },
      },
      animation: { shimmer: 'shimmer 2.4s linear infinite', rise: 'rise 0.4s ease-out' },
    },
    colors: ({ colors }) => ({
      ...colors,
      // Low numbers stay "prominent", high stays "muted" — the ramp runs
      // dark-to-light. Cooled to a blue-grey so text belongs to the surface.
      zinc: {
        50: '#0F172A',
        100: '#1E293B',
        200: '#334155',
        300: '#475569',
        400: '#64748B',
        500: '#7C8AA0',
        600: '#94A3B8',
        700: '#AFBACB',
        800: '#CBD5E1',
        900: '#DFE5EE',
        950: '#EFF3F8',
      },
      emerald: {
        50: '#ECFDF5', 100: '#D1FAE5', 300: '#6EE7B7', 400: '#34D399',
        500: '#10B981', 600: '#059669', 700: '#047857', 800: '#065F46', 900: '#064E3B',
      },
      amber: {
        50: '#FFFBEB', 100: '#FEF3C7', 300: '#FCD34D', 400: '#FBBF24',
        500: '#F59E0B', 600: '#D97706', 700: '#B45309', 800: '#92400E', 900: '#78350F',
      },
      rose: {
        50: '#FFF1F2', 100: '#FFE4E6', 300: '#FDA4AF', 400: '#FB7185',
        500: '#F43F5E', 600: '#E11D48', 700: '#BE123C', 800: '#9F1239', 900: '#881337',
      },
    }),
  },
  plugins: [],
}
