import { motion } from 'framer-motion'
import type { ReactNode } from 'react'

/** Provider hues in the cool family the palette works in. `color` carries text
 *  and must clear 4.5:1 on the base; `tint` is the pastel fill behind it. */
export const PROVIDER_META: Record<string, { label: string; color: string; tint: string }> = {
  openai: { label: 'GPT', color: '#047857', tint: '#6EE7B7' },
  anthropic: { label: 'Claude', color: '#6D28D9', tint: '#C4B5FD' },
  google: { label: 'Gemini', color: '#1D4ED8', tint: '#93C5FD' },
  moonshot: { label: 'Kimi', color: '#BE185D', tint: '#F9A8D4' },
  weaver: { label: 'Weaver', color: '#475569', tint: '#CBD5E1' },
}

/** Fallback for a provenance source the palette does not know about. */
export const NEUTRAL_META = { label: 'Other', color: '#475569', tint: '#CBD5E1' }

export function Panel({
  children, className = '', delay = 0, solid = false,
}: { children: ReactNode; className?: string; delay?: number; solid?: boolean }) {
  return (
    <motion.section
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, delay, ease: [0.22, 1, 0.36, 1] }}
      className={`${solid ? 'card-raised' : 'card'} rounded-2xl p-6 ${className}`}
    >
      {children}
    </motion.section>
  )
}

export function Button({
  children, onClick, variant = 'primary', disabled, className = '', type = 'button',
}: {
  children: ReactNode
  onClick?: () => void
  variant?: 'primary' | 'ghost' | 'quiet'
  disabled?: boolean
  className?: string
  type?: 'button' | 'submit'
}) {
  const styles = {
    // The one solid-colour element on the page, so the primary action is never
    // ambiguous on a surface where everything else is the same grey.
    primary:
      'bg-brand text-white font-medium shadow-[4px_4px_10px_rgba(37,99,235,0.32),-4px_-4px_10px_rgba(255,255,255,0.85)] '
      + 'hover:bg-brand-deep active:shadow-[inset_3px_3px_7px_rgba(29,78,216,0.5),inset_-2px_-2px_6px_rgba(255,255,255,0.25)]',
    ghost:
      'bg-raised text-zinc-200 shadow-raised-sm hover:text-brand active:shadow-pressed-sm',
    quiet: 'text-zinc-400 hover:text-zinc-100',
  }[variant]
  return (
    <motion.button
      type={type}
      onClick={onClick}
      disabled={disabled}
      whileTap={{ scale: 0.985 }}
      className={`focus-ring rounded-2xl px-5 py-2.5 text-sm transition-all duration-150 disabled:opacity-45 ${styles} ${className}`}
    >
      {children}
    </motion.button>
  )
}

export function Stat({
  label, value, hint, delay = 0,
}: { label: string; value: string | number; hint?: string; delay?: number }) {
  return (
    <Panel delay={delay}>
      <p className="eyebrow">{label}</p>
      <p className="mt-2 font-display text-3xl font-semibold tracking-tight text-zinc-50">{value}</p>
      {hint && <p className="mt-1.5 text-xs text-zinc-500">{hint}</p>}
    </Panel>
  )
}

export function ProviderChip({ provider, muted = false }: { provider: string; muted?: boolean }) {
  const meta = PROVIDER_META[provider] ?? { ...NEUTRAL_META, label: provider }
  return (
    <span
      className="inline-flex items-center gap-1.5 rounded-full px-3 py-1 font-mono text-[10px] font-medium uppercase tracking-wider"
      style={{
        color: muted ? '#94A3B8' : meta.color,
        background: muted ? '#E2E8F1' : `${meta.tint}66`,
      }}
    >
      <span className="h-1.5 w-1.5 rounded-full" style={{ background: meta.color }} />
      {meta.label}
    </span>
  )
}

export function ScoreDial({ value, size = 56 }: { size?: number; value: number }) {
  const radius = size / 2 - 5
  const circumference = 2 * Math.PI * radius
  const pct = Math.max(0, Math.min(value / 100, 1))
  return (
    <svg width={size} height={size} className="shrink-0">
      <defs>
        <linearGradient id={`dial-${size}`} x1="0" y1="1" x2="1" y2="0">
          <stop offset="0%" stopColor="#2563EB" />
          <stop offset="100%" stopColor="#10B981" />
        </linearGradient>
        {/* The track is a groove in the sheet, so it needs the same two-light
            treatment the CSS surfaces get. */}
        <filter id={`groove-${size}`} x="-50%" y="-50%" width="200%" height="200%">
          <feDropShadow dx="1.5" dy="1.5" stdDeviation="1.5" floodColor="#A3B1C6" floodOpacity="0.55" />
          <feDropShadow dx="-1.5" dy="-1.5" stdDeviation="1.5" floodColor="#FFFFFF" floodOpacity="0.9" />
        </filter>
      </defs>
      <circle
        cx={size / 2} cy={size / 2} r={radius} fill="none"
        stroke="#E2E8F1" strokeWidth="5" filter={`url(#groove-${size})`}
      />
      <motion.circle
        cx={size / 2} cy={size / 2} r={radius} fill="none"
        stroke={`url(#dial-${size})`} strokeWidth="5"
        strokeLinecap="round" transform={`rotate(-90 ${size / 2} ${size / 2})`}
        strokeDasharray={circumference}
        initial={{ strokeDashoffset: circumference }}
        animate={{ strokeDashoffset: circumference * (1 - pct) }}
        transition={{ duration: 0.9, ease: 'easeOut' }}
      />
      <text x="50%" y="54%" textAnchor="middle"
        className="fill-zinc-100 font-display text-[12px] font-semibold">{value.toFixed(0)}</text>
    </svg>
  )
}

export function Loading({ label = 'Working' }: { label?: string }) {
  return (
    <div className="flex items-center gap-2.5 text-sm text-zinc-400">
      <span className="h-2.5 w-2.5 animate-pulse rounded-full bg-brand" />
      {label}
    </div>
  )
}

export function Empty({ title, action }: { title: string; action?: string }) {
  return (
    <div className="card rounded-2xl p-10 text-center">
      <p className="font-display text-lg font-medium text-zinc-100">{title}</p>
      {action && <p className="mt-1.5 text-sm text-zinc-500">{action}</p>}
    </div>
  )
}

export function PageHeading({ eyebrow, title, description, actions }: {
  eyebrow: string; title: string; description?: string; actions?: ReactNode
}) {
  return (
    <header className="mb-8 flex flex-wrap items-start justify-between gap-4">
      <div className="min-w-0">
        <p className="eyebrow">{eyebrow}</p>
        <h1 className="mt-1.5 font-display text-[2.25rem] font-bold leading-[1.15] tracking-tight text-zinc-50">
          {title}
        </h1>
        {description && (
          <p className="mt-2.5 max-w-2xl text-sm leading-relaxed text-zinc-500">{description}</p>
        )}
      </div>
      {actions && <div className="flex shrink-0 items-center gap-2">{actions}</div>}
    </header>
  )
}

/** Soft status pill: flat pastel fill, no extrusion — a label, not a control. */
export function StatusPill({ tone, children }: {
  tone: 'success' | 'active' | 'idle' | 'warn'
  children: ReactNode
}) {
  const styles = {
    success: 'bg-emerald-100 text-emerald-700',
    active: 'bg-brand-wash text-brand-deep',
    idle: 'bg-sunken text-zinc-400',
    warn: 'bg-amber-100 text-amber-700',
  }[tone]
  return (
    <span className={`inline-flex items-center rounded-full px-3.5 py-1.5 text-xs font-semibold ${styles}`}>
      {children}
    </span>
  )
}

/** Horizontal meter running in a groove cut into the sheet. */
export function Meter({ value, className = '' }: { value: number; className?: string }) {
  return (
    <div className={`track h-2 overflow-hidden rounded-full ${className}`}>
      <motion.div
        className="bar-gradient h-full rounded-full"
        initial={{ width: 0 }}
        animate={{ width: `${Math.max(0, Math.min(value, 100))}%` }}
        transition={{ duration: 0.7, ease: 'easeOut' }}
      />
    </div>
  )
}
