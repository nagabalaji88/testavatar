import { motion } from 'framer-motion'
import { PROVIDER_META, NEUTRAL_META } from './ui'

/**
 * The signature element: one lane per section of the master prompt, coloured by
 * which specialist won it. At a glance you can see the prompt is a genuine
 * hybrid rather than one model's draft with a new label.
 */
export function ConsensusBar({
  provenance, height = 44, showLegend = true,
}: { provenance: Record<string, string>; height?: number; showLegend?: boolean }) {
  const entries = Object.entries(provenance)
  const counts = entries.reduce<Record<string, number>>((acc, [, source]) => {
    acc[source] = (acc[source] ?? 0) + 1
    return acc
  }, {})

  return (
    <div>
      <div className="flex gap-1" style={{ height }}>
        {entries.map(([section, source], index) => {
          const meta = PROVIDER_META[source] ?? { ...NEUTRAL_META, label: source }
          return (
            <motion.div
              key={section}
              title={`${section} → ${meta.label}`}
              initial={{ scaleY: 0.2, opacity: 0 }}
              animate={{ scaleY: 1, opacity: 1 }}
              transition={{ delay: index * 0.025, duration: 0.35 }}
              className="flex-1 origin-bottom rounded-full"
              style={{ background: meta.tint }}
            />
          )
        })}
      </div>
      {showLegend && (
        <div className="mt-2 flex flex-wrap gap-3">
          {Object.entries(counts).map(([source, count]) => {
            const meta = PROVIDER_META[source] ?? { ...NEUTRAL_META, label: source }
            return (
              <span key={source} className="flex items-center gap-1.5 font-mono text-[10px] text-zinc-500">
                <span className="h-2 w-2 rounded-sm" style={{ background: meta.tint }} />
                {meta.label} · {count} section{count === 1 ? '' : 's'}
              </span>
            )
          })}
        </div>
      )}
    </div>
  )
}
