import axios from 'axios'
import type {
  Analytics, GenerateResponse, LibraryEntry, Provider, SessionSummary, User,
} from '../types'

export const api = axios.create({ baseURL: import.meta.env.VITE_API_BASE ?? '/api' })

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('forge_token')
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error?.response?.status === 401 && !location.pathname.startsWith('/login')) {
      localStorage.removeItem('forge_token')
      location.assign('/login')
    }
    return Promise.reject(error)
  },
)

export interface GeneratePayload {
  problem_statement: string
  expected_output?: string
  constraints?: string[]
  target_models?: string[]
  context?: string
  business_goal?: string
  providers?: string[]
  title?: string
}

export const auth = {
  login: (email: string, password: string) =>
    api.post<{ access_token: string; user: User }>('/auth/login', { email, password })
      .then((r) => r.data),
  me: () => api.get<User>('/auth/me').then((r) => r.data),
  logout: () => api.post('/auth/logout').then(() => undefined),
  changePassword: (current_password: string, new_password: string) =>
    api.post('/auth/password', { current_password, new_password }).then(() => undefined),
}

export const users = {
  list: () => api.get<User[]>('/users').then((r) => r.data),
  create: (payload: { email: string; full_name: string; password: string; role: string }) =>
    api.post<User>('/users', payload).then((r) => r.data),
  update: (id: string, payload: { full_name?: string; role?: string; is_active?: boolean }) =>
    api.patch<User>(`/users/${id}`, payload).then((r) => r.data),
  resetPassword: (id: string, new_password: string) =>
    api.post(`/users/${id}/password`, { new_password }).then(() => undefined),
}

export const workflow = {
  generate: (payload: GeneratePayload) =>
    api.post<GenerateResponse>('/generate', payload).then((r) => r.data),
  analyze: (payload: GeneratePayload) => api.post('/analyze', payload).then((r) => r.data),
  meta: () => api.get<{
    stages: string[]
    agents: { index: number; name: string; stage: string; description: string }[]
    sections: string[]
    weights: Record<string, number>
    providers: Provider[]
  }>('/workflow/meta').then((r) => r.data),
  session: (id: string) => api.get(`/sessions/${id}`).then((r) => r.data),
}

export const library = {
  list: (starredOnly = false) =>
    api.get<LibraryEntry[]>('/library', { params: { starred_only: starredOnly } })
      .then((r) => r.data),
  detail: (id: string) => api.get(`/library/${id}`).then((r) => r.data),
  revise: (id: string, content: string, change_note: string) =>
    api.post(`/library/${id}/revise`, { content, change_note }).then((r) => r.data),
  star: (id: string) => api.post(`/library/${id}/star`).then((r) => r.data),
  history: () => api.get<SessionSummary[]>('/history').then((r) => r.data),
  analytics: () => api.get<Analytics>('/analytics').then((r) => r.data),
  agentLogs: () => api.get('/agent-logs').then((r) => r.data),
}

export const exporter = {
  formats: () => api.get<{ formats: string[] }>('/export/formats').then((r) => r.data.formats),
  download: async (masterPromptId: string, format: string) => {
    const response = await api.post(
      '/export', { master_prompt_id: masterPromptId, format }, { responseType: 'blob' },
    )
    const disposition = String(response.headers['content-disposition'] ?? '')
    const match = disposition.match(/filename="?([^"]+)"?/)
    const url = URL.createObjectURL(response.data as Blob)
    const link = document.createElement('a')
    link.href = url
    link.download = match?.[1] ?? `master-prompt.${format}`
    link.click()
    URL.revokeObjectURL(url)
  },
}

export const settingsApi = {
  read: () => api.get('/settings').then((r) => r.data),
  write: (key: string, value: string, encrypted: boolean) =>
    api.put('/settings', { key, value, encrypted }).then((r) => r.data),
  audit: () => api.get('/audit').then((r) => r.data),
  projects: () => api.get('/projects').then((r) => r.data),
}

export const status = () => api.get('/status').then((r) => r.data)
