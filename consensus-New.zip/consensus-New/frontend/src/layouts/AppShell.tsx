import { AnimatePresence, motion } from 'framer-motion'
import {
  Activity, BarChart3, Cpu, FileText, GitCompare, History, Library,
  LayoutDashboard, LogOut, Menu, Search, Settings, Sparkles, Workflow, X,
} from 'lucide-react'
import { useEffect, useState } from 'react'
import { NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom'
import { status } from '../services/api'
import { useAuth } from '../store/useAuth'
import { useRun } from '../store/useRun'

/** The sections that earn a pill in the bar. Everything else lives behind the
 *  overflow menu, which is what keeps the bar readable at eleven routes. */
const PRIMARY = [
  { to: '/app', label: 'Home', icon: LayoutDashboard, end: true },
  { to: '/app/workflow', label: 'Workflow', icon: Workflow },
  { to: '/app/comparison', label: 'Comparison', icon: GitCompare },
  { to: '/app/scores', label: 'Scores', icon: BarChart3 },
  { to: '/app/master', label: 'Master', icon: FileText },
]

const SECONDARY = [
  { to: '/app/agents', label: 'Agent monitor', icon: Cpu },
  { to: '/app/library', label: 'Library', icon: Library },
  { to: '/app/history', label: 'History', icon: History },
  { to: '/app/analytics', label: 'Analytics', icon: Activity },
  { to: '/app/settings', label: 'Settings', icon: Settings },
]

export function AppShell() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [providers, setProviders] = useState<Record<string, { label: string; mode: string }>>({})
  const { user, signOut } = useAuth()
  const run = useRun((s) => s.run)
  const running = useRun((s) => s.running)
  const navigate = useNavigate()
  const location = useLocation()

  useEffect(() => {
    status().then((body) => setProviders(body.providers)).catch(() => undefined)
  }, [])

  // A route change should never leave the overflow panel hanging open.
  useEffect(() => { setMenuOpen(false) }, [location.pathname])

  const simulated = Object.values(providers).filter((p) => p.mode === 'simulated').length

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-30 px-4 pt-4 lg:px-8">
        <div className="card-raised flex items-center gap-3 rounded-full py-2.5 pl-5 pr-3">
          <button
            onClick={() => navigate('/app')}
            className="focus-ring flex shrink-0 items-center gap-2 rounded-full"
            aria-label="PromptForge home"
          >
            <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-brand font-display text-base font-bold text-white shadow-[3px_3px_8px_rgba(37,99,235,0.34),-3px_-3px_8px_rgba(255,255,255,0.85)]">
              P
            </span>
            <span className="font-display text-lg font-bold tracking-tight text-zinc-50">
              PromptForge
            </span>
          </button>

          <nav className="control ml-6 hidden items-center gap-1 rounded-full p-1.5 xl:flex">
            {PRIMARY.map(({ to, label, end }) => (
              <NavLink
                key={to}
                to={to}
                end={end}
                className={({ isActive }) =>
                  `focus-ring rounded-full px-4 py-2 text-sm transition-all duration-150 ${
                    isActive
                      ? 'bg-raised font-semibold text-brand shadow-raised-sm'
                      : 'text-zinc-400 hover:text-zinc-100'
                  }`
                }
              >
                {label}
              </NavLink>
            ))}
          </nav>

          {/* The one action surface, set apart the way the reference separates
              Playground from the rest of the bar. */}
          <NavLink
            to="/app/workspace"
            className={({ isActive }) =>
              `focus-ring hidden shrink-0 items-center gap-2 rounded-full px-4 py-2.5 text-sm font-semibold transition-all duration-150 sm:flex ${
                isActive
                  ? 'bg-brand text-white shadow-[4px_4px_10px_rgba(37,99,235,0.34),-4px_-4px_10px_rgba(255,255,255,0.85)]'
                  : 'bg-raised text-zinc-100 shadow-raised-sm hover:text-brand'
              }`
            }
          >
            <Sparkles className="h-3.5 w-3.5" />
            Workspace
          </NavLink>

          <div className="ml-auto flex items-center gap-2">
            {running && (
              <span className="hidden items-center gap-1.5 font-mono text-[11px] text-brand md:flex">
                <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-brand" />
                running…
              </span>
            )}
            {run && !running && (
              <span className="hidden font-mono text-[11px] text-zinc-500 lg:block">
                {run.master.score.toFixed(1)}/100 · {run.totals.tokens.toLocaleString()} tokens
              </span>
            )}

            <button
              onClick={() => navigate('/app/library')}
              aria-label="Search the library"
              className="focus-ring grid h-10 w-10 place-items-center rounded-xl bg-raised text-zinc-400 shadow-raised-sm transition-all duration-150 hover:text-brand active:shadow-pressed-sm"
            >
              <Search className="h-4 w-4" />
            </button>
            <button
              onClick={() => navigate('/app/settings')}
              aria-label="Settings"
              className="focus-ring hidden h-10 w-10 place-items-center rounded-xl bg-raised text-zinc-400 shadow-raised-sm transition-all duration-150 hover:text-brand active:shadow-pressed-sm sm:grid"
            >
              <Settings className="h-4 w-4" />
            </button>
            <button
              onClick={() => setMenuOpen((v) => !v)}
              aria-label={menuOpen ? 'Close menu' : 'Open menu'}
              aria-expanded={menuOpen}
              className="focus-ring grid h-10 w-10 place-items-center rounded-xl bg-raised text-zinc-400 shadow-raised-sm transition-all duration-150 hover:text-brand active:shadow-pressed-sm"
            >
              {menuOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
            </button>

            <span
              title={`${user?.full_name} · ${user?.role}`}
              className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-raised font-display text-sm font-bold text-brand shadow-raised-sm"
            >
              {user?.full_name?.[0] ?? 'U'}
            </span>
          </div>
        </div>

        <AnimatePresence>
          {menuOpen && (
            <>
              <div className="fixed inset-0 z-10" onClick={() => setMenuOpen(false)} aria-hidden />
              <motion.div
                initial={{ opacity: 0, y: -8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.2, ease: [0.22, 1, 0.36, 1] }}
                className="card absolute right-4 z-20 mt-3 w-64 rounded-2xl p-2.5 lg:right-8"
              >
                {/* Below xl the pill bar is hidden, so the primary routes have to
                    be reachable from here too. */}
                <div className="xl:hidden">
                  {PRIMARY.map(({ to, label, icon: Icon, end }) => (
                    <MenuLink key={to} to={to} label={label} Icon={Icon} end={end} />
                  ))}
                  <div className="my-2 h-px bg-line" />
                </div>
                <div className="sm:hidden">
                  <MenuLink to="/app/workspace" label="Workspace" Icon={Sparkles} />
                  <div className="my-2 h-px bg-line" />
                </div>
                {SECONDARY.map(({ to, label, icon: Icon }) => (
                  <MenuLink key={to} to={to} label={label} Icon={Icon} />
                ))}
                <div className="my-2 h-px bg-line" />
                <button
                  onClick={async () => { await signOut(); navigate('/login') }}
                  className="focus-ring flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-zinc-400 transition-colors hover:bg-sunken hover:text-zinc-100"
                >
                  <LogOut className="h-4 w-4 shrink-0" />
                  Sign out
                </button>
              </motion.div>
            </>
          )}
        </AnimatePresence>
      </header>

      <main className="min-w-0 flex-1 px-4 py-8 lg:px-8">
        <AnimatePresence mode="wait">
          <motion.div
            key={location.pathname}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.28 }}
          >
            <Outlet />
          </motion.div>
        </AnimatePresence>
      </main>

      <footer className="mt-auto flex flex-wrap items-center gap-x-5 gap-y-1.5 px-4 py-4 font-mono text-[10px] uppercase tracking-wider text-zinc-500 lg:px-8">
        {Object.entries(providers).map(([id, provider]) => (
          <span key={id} className="flex items-center gap-1.5">
            <span className={`h-2 w-2 rounded-full ${provider.mode === 'live' ? 'bg-emerald-500' : 'bg-zinc-700'}`} />
            {provider.label} {provider.mode}
          </span>
        ))}
        {simulated > 0 && (
          <span className="text-zinc-500">
            {simulated} provider{simulated === 1 ? '' : 's'} simulated — add keys in Settings
          </span>
        )}
      </footer>
    </div>
  )
}

function MenuLink({ to, label, Icon, end }: {
  to: string; label: string; Icon: typeof Settings; end?: boolean
}) {
  return (
    <NavLink
      to={to}
      end={end}
      className={({ isActive }) =>
        `focus-ring flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-colors ${
          isActive
            ? 'bg-brand-wash font-semibold text-brand-deep'
            : 'text-zinc-400 hover:bg-sunken hover:text-zinc-100'
        }`
      }
    >
      <Icon className="h-4 w-4 shrink-0" />
      {label}
    </NavLink>
  )
}
