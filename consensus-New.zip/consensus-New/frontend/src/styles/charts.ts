/** Shared Recharts theming for the neumorphic base. */

export const CHART = {
  /** Accent for a single-series line/area — the brand blue. */
  accent: '#2563EB',
  /** Second series, when a chart compares against the accent. */
  accentMuted: '#AFBACB',
  grid: 'rgba(163,177,198,0.35)',
  polarGrid: 'rgba(163,177,198,0.45)',
  /** Axis labels: muted but legible on the base. */
  tick: '#7C8AA0',
  tickStrong: '#475569',
  /** Hover band behind the tooltip. */
  cursor: 'rgba(163,177,198,0.18)',
} as const

/** Blue→green sweep, matching how the reference moves in-progress to approved. */
export const SWEEP = ['#2563EB', '#3B82F6', '#38BDF8', '#10B981'] as const

/** The tooltip is a raised tile, so it carries the same two-light extrusion
 *  every other floating surface does. */
export const tooltipStyle = {
  background: '#F3F6FB',
  border: 'none',
  borderRadius: 16,
  fontSize: 12,
  color: '#1E293B',
  padding: '10px 14px',
  boxShadow: '8px 8px 18px rgba(163,177,198,0.5), -8px -8px 18px rgba(255,255,255,0.95)',
} as const
