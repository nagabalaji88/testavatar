import { create } from 'zustand'
import type { GenerateResponse } from '../types'

interface RunState {
  run: GenerateResponse | null
  running: boolean
  activeStage: string | null
  setRun: (run: GenerateResponse | null) => void
  setRunning: (running: boolean) => void
  setStage: (stage: string | null) => void
}

/** The most recent workflow run, shared across Workspace, Workflow, Comparison and Scores. */
export const useRun = create<RunState>((set) => ({
  run: null,
  running: false,
  activeStage: null,
  setRun: (run) => set({ run }),
  setRunning: (running) => set({ running }),
  setStage: (activeStage) => set({ activeStage }),
}))
