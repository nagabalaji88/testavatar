import { create } from 'zustand'
import { auth } from '../services/api'
import type { User } from '../types'

interface AuthState {
  user: User | null
  loading: boolean
  error: string
  signIn: (email: string, password: string) => Promise<boolean>
  signOut: () => Promise<void>
  restore: () => Promise<void>
}

export const useAuth = create<AuthState>((set) => ({
  user: null,
  loading: true,
  error: '',
  signIn: async (email, password) => {
    set({ error: '' })
    try {
      const data = await auth.login(email, password)
      localStorage.setItem('forge_token', data.access_token)
      set({ user: data.user })
      return true
    } catch {
      set({ error: 'Email or password is incorrect.' })
      return false
    }
  },
  signOut: async () => {
    // Tell the server first so the token is revoked, not merely forgotten locally.
    try {
      await auth.logout()
    } catch {
      // An already-expired token is still a successful sign-out from the user's view.
    }
    localStorage.removeItem('forge_token')
    set({ user: null })
  },
  restore: async () => {
    if (!localStorage.getItem('forge_token')) return set({ loading: false })
    try {
      set({ user: await auth.me(), loading: false })
    } catch {
      localStorage.removeItem('forge_token')
      set({ user: null, loading: false })
    }
  },
}))
