import { useEffect, useState } from 'react'
import {
  Bar, BarChart, CartesianGrid, Cell, PolarAngleAxis, PolarGrid, Radar, RadarChart,
  ResponsiveContainer, Tooltip, XAxis, YAxis,
} from 'recharts'
import { useNavigate } from 'react-router-dom'
import { Button, Empty, PageHeading, Panel, ProviderChip, PROVIDER_META, ScoreDial } from '../components/ui'
import { workflow } from '../services/api'
import { useRun } from '../store/useRun'
import { CHART, tooltipStyle } from '../styles/charts'

export function Scores() {
  const run = useRun((s) => s.run)
  const [weights, setWeights] = useState<Record<string, number>>({})
  const navigate = useNavigate()

  useEffect(() => {
    workflow.meta().then((meta) => setWeights(meta.weights)).catch(() => undefined)
  }, [])

  if (!run) {
    return (
      <>
        <PageHeading eyebrow="Scores" title="Nothing scored yet" />
        <Empty title="Run the workflow to see the scorecards." />
        <div className="mt-4"><Button onClick={() => navigate('/app/workspace')}>Open Workspace</Button></div>
      </>
    )
  }

  const providers = Object.keys(run.drafts)
  const metrics = Object.keys(run.drafts[providers[0]].score.metrics)

  const radarData = metrics.map((metric) => ({
    metric: metric.replace(/_/g, ' '),
    ...Object.fromEntries(providers.map((p) => [p, run.drafts[p].score.metrics[metric]])),
  }))

  const totals = providers.map((provider) => ({
    provider,
    label: PROVIDER_META[provider].label,
    total: run.drafts[provider].score.total,
  })).sort((a, b) => b.total - a.total)

  return (
    <>
      <PageHeading
        eyebrow="Scores"
        title="Eleven metrics, fixed weights, no self-grading"
        description="Ten metrics are deterministic functions of the draft's own text; the eleventh measures how much of your actual request survived into it. Two runs of the same brief always score identically."
      />

      <div className="grid gap-4 lg:grid-cols-2">
        <Panel>
          <p className="eyebrow">Metric profile</p>
          <div className="mt-3 h-72">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart data={radarData}>
                <PolarGrid stroke={CHART.polarGrid} />
                <PolarAngleAxis dataKey="metric" tick={{ fill: CHART.tick, fontSize: 9 }} />
                {providers.map((provider) => (
                  <Radar
                    key={provider}
                    dataKey={provider}
                    stroke={PROVIDER_META[provider].color}
                    fill={PROVIDER_META[provider].tint}
                    fillOpacity={0.16}
                  />
                ))}
                <Tooltip contentStyle={tooltipStyle} />
              </RadarChart>
            </ResponsiveContainer>
          </div>
          <div className="flex flex-wrap gap-2">
            {providers.map((provider) => <ProviderChip key={provider} provider={provider} />)}
          </div>
        </Panel>

        <Panel delay={0.05}>
          <p className="eyebrow">Weighted total</p>
          <div className="mt-3 h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={totals} layout="vertical" margin={{ left: 8 }}>
                <CartesianGrid strokeDasharray="3 3" stroke={CHART.grid} />
                <XAxis type="number" domain={[0, 100]} tick={{ fill: CHART.tick, fontSize: 11 }} />
                <YAxis type="category" dataKey="label" tick={{ fill: CHART.tickStrong, fontSize: 11 }} width={64} />
                <Tooltip contentStyle={tooltipStyle} cursor={{ fill: CHART.cursor }} />
                <Bar dataKey="total" radius={[0, 6, 6, 0]} animationDuration={800}>
                  {totals.map((row) => (
                    <Cell key={row.provider} fill={PROVIDER_META[row.provider].tint} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Panel>
      </div>

      <div className="mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-4">
        {run.ranking.map((provider, index) => {
          const score = run.drafts[provider].score
          return (
            <Panel key={provider} delay={index * 0.05}>
              <div className="flex items-center gap-3">
                <ScoreDial value={score.total} />
                <div>
                  <ProviderChip provider={provider} />
                  <p className="mt-1 font-mono text-[10px] text-zinc-600">rank {index + 1} of {providers.length}</p>
                </div>
              </div>
              <ul className="mt-3 space-y-1">
                {Object.entries(score.metrics).map(([metric, value]) => (
                  <li key={metric} className="flex items-center gap-2">
                    <span className="w-28 truncate font-mono text-[10px] text-zinc-600">
                      {metric.replace(/_/g, ' ')}
                    </span>
                    <span className="h-1 flex-1 overflow-hidden rounded-full track">
                      <span
                        className="block h-full rounded-full"
                        style={{ width: `${value}%`, background: PROVIDER_META[provider].color }}
                      />
                    </span>
                    <span className="w-7 text-right font-mono text-[10px] text-zinc-500">{value.toFixed(0)}</span>
                  </li>
                ))}
              </ul>
              {score.notes.length > 0 && (
                <p className="mt-3 border-t border-line pt-2 text-[11px] text-zinc-600">
                  {score.notes[0]}
                </p>
              )}
            </Panel>
          )
        })}
      </div>

      <Panel className="mt-4">
        <p className="eyebrow">Weighting</p>
        <div className="mt-2 flex flex-wrap gap-2">
          {Object.entries(weights).map(([metric, weight]) => (
            <span key={metric} className="rounded-full bg-sunken px-3 py-1 font-mono text-[10px] text-zinc-500">
              {metric.replace(/_/g, ' ')} · {weight}
            </span>
          ))}
        </div>
      </Panel>
    </>
  )
}
