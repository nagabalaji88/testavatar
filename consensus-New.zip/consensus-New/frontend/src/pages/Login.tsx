import { motion } from 'framer-motion'
import { ArrowRight } from 'lucide-react'
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Button } from '../components/ui'
import { useAuth } from '../store/useAuth'

const DEMO = [
  ['aarti.desai@forge.dev', 'Engineer'],
  ['admin@forge.dev', 'Admin'],
  ['viewer@forge.dev', 'Viewer'],
]

export function Login() {
  const [email, setEmail] = useState('aarti.desai@forge.dev')
  const [password, setPassword] = useState('forge1234')
  const [busy, setBusy] = useState(false)
  const { signIn, error } = useAuth()
  const navigate = useNavigate()

  const submit = async () => {
    setBusy(true)
    const ok = await signIn(email, password)
    setBusy(false)
    if (ok) navigate('/app')
  }

  // No watermark behind the card: neumorphism reads as one continuous sheet of
  // material, and a giant ghosted wordmark breaks that surface.
  return (
    <div className="grid min-h-screen place-items-center px-5 py-10">
      <motion.div
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
        className="card relative w-full max-w-sm rounded-3xl p-8"
      >
        <div className="mb-7 flex items-center gap-2.5">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-brand font-display text-base font-bold text-white shadow-[3px_3px_8px_rgba(37,99,235,0.34),-3px_-3px_8px_rgba(255,255,255,0.85)]">
            P
          </span>
          <span className="font-display text-lg font-bold tracking-tight text-zinc-50">
            PromptForge
          </span>
        </div>

        <h1 className="font-display text-[2rem] font-bold leading-tight tracking-tight text-zinc-50">
          Sign in
        </h1>
        <p className="mt-1.5 text-sm text-zinc-500">Demo password: forge1234</p>

        <div className="mt-7 space-y-3">
          <input
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="field focus-ring"
            placeholder="Work email"
            autoComplete="username"
          />
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && submit()}
            className="field focus-ring"
            placeholder="Password"
            autoComplete="current-password"
          />
          {error && <p className="text-xs text-rose-700">{error}</p>}
          <Button
            onClick={submit}
            disabled={busy}
            className="flex w-full items-center justify-center gap-2"
          >
            {busy ? 'Signing in…' : 'Sign in'}
            {!busy && <ArrowRight className="h-4 w-4" />}
          </Button>
        </div>

        <div className="mt-7">
          <div className="mb-5 h-px bg-line" />
          <p className="eyebrow mb-2.5">Demo accounts</p>
          <div className="space-y-1.5">
            {DEMO.map(([demoEmail, role]) => (
              <button
                key={demoEmail}
                onClick={() => setEmail(demoEmail)}
                className={`focus-ring flex w-full items-center justify-between rounded-xl px-3.5 py-2.5 text-left text-[11px] transition-all duration-150 ${
                  email === demoEmail
                    ? 'bg-brand-wash text-brand-deep shadow-pressed-sm'
                    : 'bg-raised shadow-raised-sm hover:text-brand'
                }`}
              >
                <span className="text-zinc-300">{role}</span>
                <span className="font-mono text-[10px] text-zinc-600">{demoEmail}</span>
              </button>
            ))}
          </div>
        </div>
      </motion.div>
    </div>
  )
}
