import { motion } from 'framer-motion'
import { AlertTriangle, CheckCircle2, Lightbulb } from 'lucide-react'
import { useEffect, useState } from 'react'
import { Empty, PageHeading, Panel } from '../components/ui'
import { library, workflow } from '../services/api'
import { useRun } from '../store/useRun'
import type { AgentLog } from '../types'

export function AgentMonitor() {
  const run = useRun((s) => s.run)
  const [registry, setRegistry] = useState<{ index: number; name: string; stage: string; description: string }[]>([])
  const [historic, setHistoric] = useState<AgentLog[]>([])

  useEffect(() => {
    workflow.meta().then((meta) => setRegistry(meta.agents)).catch(() => undefined)
    library.agentLogs().then(setHistoric).catch(() => undefined)
  }, [])

  const logs = run?.logs ?? historic.slice(0, 11)

  return (
    <>
      <PageHeading
        eyebrow="Agent monitor"
        title="What each agent did, and what it cost"
        description="Summaries and conclusions only — the platform never surfaces a model's private deliberation."
      />

      <div className="grid gap-4 lg:grid-cols-[1fr_300px]">
        <div className="space-y-2">
          {logs.length === 0 && <Empty title="No agent activity yet." action="Run the workflow first." />}
          {logs.map((log, index) => (
            <motion.article
              key={`${log.agent}-${index}`}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.04 }}
              className="card rounded-xl p-4"
            >
              <div className="flex flex-wrap items-center gap-2">
                {log.status === 'complete'
                  ? <CheckCircle2 className="h-4 w-4 text-emerald-700" />
                  : <AlertTriangle className="h-4 w-4 text-rose-700" />}
                <h2 className="font-display text-sm text-zinc-50">{log.agent}</h2>
                <span className="rounded-full bg-sunken px-2 py-0.5 font-mono text-[9px] uppercase text-zinc-500">
                  {log.stage}
                </span>
                <span className="ml-auto font-mono text-[10px] text-zinc-600">
                  {log.duration_ms}ms · {log.tokens.toLocaleString()} tok · ${log.cost_usd.toFixed(5)}
                </span>
              </div>

              <p className="mt-2 text-sm text-zinc-400">{log.summary}</p>

              {log.output_digest && (
                <p className="mt-1.5 font-mono text-[10px] text-zinc-600">out: {log.output_digest}</p>
              )}

              <div className="mt-3 flex items-center gap-3">
                <div className="h-1 w-28 overflow-hidden rounded-full track">
                  <div className="h-full rounded-full bar-gradient" style={{ width: `${log.confidence * 100}%` }} />
                </div>
                <span className="font-mono text-[10px] text-zinc-600">
                  confidence {Math.round(log.confidence * 100)}%
                </span>
              </div>

              {log.warnings.length > 0 && (
                <ul className="mt-3 space-y-1">
                  {log.warnings.map((warning, i) => (
                    <li key={i} className="flex gap-1.5 text-[11px] text-amber-700">
                      <AlertTriangle className="mt-0.5 h-3 w-3 shrink-0" />{warning}
                    </li>
                  ))}
                </ul>
              )}
              {log.recommendations.length > 0 && (
                <ul className="mt-2 space-y-1">
                  {log.recommendations.map((rec, i) => (
                    <li key={i} className="flex gap-1.5 text-[11px] text-zinc-500">
                      <Lightbulb className="mt-0.5 h-3 w-3 shrink-0" />{rec}
                    </li>
                  ))}
                </ul>
              )}
            </motion.article>
          ))}
        </div>

        <Panel>
          <p className="eyebrow">Registry</p>
          <ol className="mt-3 space-y-2.5">
            {registry.map((agent) => (
              <li key={agent.name}>
                <div className="flex items-baseline gap-2">
                  <span className="font-mono text-[10px] text-zinc-600">
                    {String(agent.index).padStart(2, '0')}
                  </span>
                  <p className="text-xs text-zinc-200">{agent.name}</p>
                </div>
                <p className="ml-6 text-[11px] text-zinc-600">{agent.description}</p>
              </li>
            ))}
          </ol>
        </Panel>
      </div>
    </>
  )
}
