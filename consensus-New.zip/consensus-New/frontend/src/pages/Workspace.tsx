import { Plus, Play, X } from 'lucide-react'
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { ConsensusBar } from '../components/ConsensusBar'
import { Button, Loading, PageHeading, Panel, ProviderChip, ScoreDial } from '../components/ui'
import { workflow } from '../services/api'
import { useRun } from '../store/useRun'

const PROVIDERS = ['openai', 'anthropic', 'google', 'moonshot']
const EXAMPLE = 'Extract structured invoice fields from scanned supplier PDFs, flag anomalies such '
  + 'as duplicate invoice numbers or totals that do not match the line items, and hand the result '
  + 'to the finance reconciliation job.'

export function Workspace() {
  const [problem, setProblem] = useState('')
  const [expected, setExpected] = useState('')
  const [constraint, setConstraint] = useState('')
  const [constraints, setConstraints] = useState<string[]>([])
  const [selected, setSelected] = useState<string[]>(PROVIDERS)
  const [error, setError] = useState('')
  const { run, running, setRun, setRunning } = useRun()
  const navigate = useNavigate()

  const toggle = (provider: string) =>
    setSelected((current) =>
      current.includes(provider) ? current.filter((p) => p !== provider) : [...current, provider])

  const submit = async () => {
    if (problem.trim().length < 15) {
      setError('Describe the task in at least a sentence — the analyzer needs something to work with.')
      return
    }
    if (selected.length < 2) {
      setError('Pick at least two specialists. Consensus needs drafts to compare.')
      return
    }
    setError('')
    setRunning(true)
    try {
      const result = await workflow.generate({
        problem_statement: problem,
        expected_output: expected,
        constraints,
        providers: selected,
      })
      setRun(result)
    } catch {
      setError('The run did not complete. Check the backend is reachable and try again.')
    } finally {
      setRunning(false)
    }
  }

  return (
    <>
      <PageHeading
        eyebrow="Workspace"
        title="Describe the task once"
        description="Four specialists draft against your brief in parallel, an evaluator scores them on eleven weighted metrics, and the weaver merges the strongest sections into one prompt."
      />

      <div className="grid gap-4 lg:grid-cols-[1.05fr_0.95fr]">
        <Panel>
          <label className="eyebrow" htmlFor="problem">Problem statement</label>
          <textarea
            id="problem"
            value={problem}
            onChange={(e) => setProblem(e.target.value)}
            rows={7}
            placeholder="What should the prompt make the model do?"
            className="field focus-ring mt-2 leading-relaxed"
          />
          <button
            onClick={() => setProblem(EXAMPLE)}
            className="focus-ring mt-1.5 text-[11px] text-zinc-500 underline underline-offset-2 hover:text-zinc-300"
          >
            Use the example brief
          </button>

          <label className="eyebrow mt-4 block" htmlFor="expected">Expected output</label>
          <input
            id="expected"
            value={expected}
            onChange={(e) => setExpected(e.target.value)}
            placeholder="e.g. JSON with line items and a confidence per field"
            className="field focus-ring mt-2"
          />

          <label className="eyebrow mt-4 block" htmlFor="constraint">Constraints</label>
          <div className="mt-2 flex gap-2">
            <input
              id="constraint"
              value={constraint}
              onChange={(e) => setConstraint(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && constraint.trim()) {
                  setConstraints((c) => [...c, constraint.trim()])
                  setConstraint('')
                }
              }}
              placeholder="What must it never do?"
              className="field focus-ring"
            />
            <Button
              variant="ghost"
              onClick={() => {
                if (constraint.trim()) {
                  setConstraints((c) => [...c, constraint.trim()])
                  setConstraint('')
                }
              }}
            >
              <Plus className="h-4 w-4" />
            </Button>
          </div>
          <div className="mt-2 flex flex-wrap gap-1.5">
            {constraints.map((item, index) => (
              <span key={index} className="flex items-center gap-1.5 rounded-full bg-sunken px-3 py-1 text-[11px] text-zinc-300">
                {item}
                <button
                  onClick={() => setConstraints((c) => c.filter((_, i) => i !== index))}
                  className="focus-ring text-zinc-600 hover:text-zinc-200"
                  aria-label={`Remove ${item}`}
                >
                  <X className="h-3 w-3" />
                </button>
              </span>
            ))}
          </div>

          <p className="eyebrow mt-4">Specialists</p>
          <div className="mt-2 flex flex-wrap gap-2">
            {PROVIDERS.map((provider) => (
              <button
                key={provider}
                onClick={() => toggle(provider)}
                className={`focus-ring rounded-xl border px-2.5 py-1.5 transition-opacity ${
                  selected.includes(provider) ? 'bg-raised shadow-raised-sm' : 'opacity-45 shadow-pressed-sm'
                }`}
              >
                <ProviderChip provider={provider} muted={!selected.includes(provider)} />
              </button>
            ))}
          </div>

          {error && <p className="mt-4 text-xs text-rose-700">{error}</p>}

          <div className="mt-5 flex items-center gap-3">
            <Button onClick={submit} disabled={running} className="flex items-center gap-2">
              <Play className="h-3.5 w-3.5" /> {running ? 'Running ten stages…' : 'Generate master prompt'}
            </Button>
            {running && <Loading label="Drafting in parallel" />}
          </div>
        </Panel>

        <div className="space-y-4">
          {!run && !running && (
            <Panel>
              <p className="eyebrow">Result</p>
              <p className="mt-2 text-sm text-zinc-500">
                Run the workflow and the master prompt, per-model scores and the full agent trace
                appear here.
              </p>
            </Panel>
          )}

          {run && (
            <>
              <Panel>
                <div className="flex items-center gap-4">
                  <ScoreDial value={run.master.score} size={64} />
                  <div className="min-w-0">
                    <p className="eyebrow">Master prompt</p>
                    <p className="truncate font-display text-lg text-zinc-50">{run.master.title}</p>
                    <p className="font-mono text-[11px] text-zinc-500">
                      {run.totals.tokens.toLocaleString()} tokens · ${run.totals.cost_usd.toFixed(4)} ·
                      {' '}{run.totals.duration_ms}ms
                    </p>
                  </div>
                </div>
                <div className="mt-4">
                  <p className="eyebrow mb-2">Which specialist won each section</p>
                  <ConsensusBar provenance={run.master.provenance} />
                </div>
                <div className="mt-4 flex flex-wrap gap-2">
                  <Button onClick={() => navigate('/app/master')}>Open the prompt</Button>
                  <Button variant="ghost" onClick={() => navigate('/app/comparison')}>Compare drafts</Button>
                  <Button variant="ghost" onClick={() => navigate('/app/workflow')}>See the run</Button>
                </div>
              </Panel>

              <Panel>
                <p className="eyebrow">What the analyzer asked</p>
                {run.intent.clarifications.length === 0 ? (
                  <p className="mt-2 text-sm text-zinc-500">The brief was complete enough to work from.</p>
                ) : (
                  <ul className="mt-2 space-y-1.5">
                    {run.intent.clarifications.map((question) => (
                      <li key={question} className="text-sm text-zinc-400">— {question}</li>
                    ))}
                  </ul>
                )}
                {run.intent.risks.length > 0 && (
                  <>
                    <p className="eyebrow mt-4">Risks it flagged</p>
                    <ul className="mt-2 space-y-1.5">
                      {run.intent.risks.map((risk) => (
                        <li key={risk} className="text-sm text-amber-700">— {risk}</li>
                      ))}
                    </ul>
                  </>
                )}
              </Panel>
            </>
          )}
        </div>
      </div>
    </>
  )
}
