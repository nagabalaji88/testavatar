import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { Suspense, lazy, useEffect } from 'react'
import { Navigate, Route, Routes } from 'react-router-dom'
import { Loading } from './components/ui'
import { AppShell } from './layouts/AppShell'
import { Login } from './pages/Login'
import { useAuth } from './store/useAuth'

// Route-level splitting: the charts, flow canvas and Monaco editor are the three
// heavy dependencies, and each loads only when its screen is opened.
const Dashboard = lazy(() => import('./pages/Dashboard').then((m) => ({ default: m.Dashboard })))
const Workspace = lazy(() => import('./pages/Workspace').then((m) => ({ default: m.Workspace })))
const WorkflowView = lazy(() => import('./pages/WorkflowView').then((m) => ({ default: m.WorkflowView })))
const AgentMonitor = lazy(() => import('./pages/AgentMonitor').then((m) => ({ default: m.AgentMonitor })))
const Comparison = lazy(() => import('./pages/Comparison').then((m) => ({ default: m.Comparison })))
const Scores = lazy(() => import('./pages/Scores').then((m) => ({ default: m.Scores })))
const MasterPrompt = lazy(() => import('./pages/MasterPrompt').then((m) => ({ default: m.MasterPrompt })))
const LibraryPage = lazy(() => import('./pages/LibraryPage').then((m) => ({ default: m.LibraryPage })))
const HistoryPage = lazy(() => import('./pages/HistoryPage').then((m) => ({ default: m.HistoryPage })))
const AnalyticsPage = lazy(() => import('./pages/AnalyticsPage').then((m) => ({ default: m.AnalyticsPage })))
const SettingsPage = lazy(() => import('./pages/SettingsPage').then((m) => ({ default: m.SettingsPage })))

const queryClient = new QueryClient({
  defaultOptions: { queries: { staleTime: 30_000, refetchOnWindowFocus: false, retry: 1 } },
})

function Protected({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth()
  if (loading) {
    return <div className="grid min-h-screen place-items-center"><Loading label="Restoring session" /></div>
  }
  return user ? <>{children}</> : <Navigate to="/login" replace />
}

export default function App() {
  const restore = useAuth((state) => state.restore)
  useEffect(() => { restore() }, [restore])

  return (
    <QueryClientProvider client={queryClient}>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route
          path="/app"
          element={
            <Protected>
              <Suspense fallback={<div className="p-8"><Loading label="Loading workspace" /></div>}>
                <AppShell />
              </Suspense>
            </Protected>
          }
        >
          <Route index element={<Dashboard />} />
          <Route path="workspace" element={<Workspace />} />
          <Route path="workflow" element={<WorkflowView />} />
          <Route path="agents" element={<AgentMonitor />} />
          <Route path="comparison" element={<Comparison />} />
          <Route path="scores" element={<Scores />} />
          <Route path="master" element={<MasterPrompt />} />
          <Route path="library" element={<LibraryPage />} />
          <Route path="history" element={<HistoryPage />} />
          <Route path="analytics" element={<AnalyticsPage />} />
          <Route path="settings" element={<SettingsPage />} />
        </Route>
        <Route path="*" element={<Navigate to="/app" replace />} />
      </Routes>
    </QueryClientProvider>
  )
}
