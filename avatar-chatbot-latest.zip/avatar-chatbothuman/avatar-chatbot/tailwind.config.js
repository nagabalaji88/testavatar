/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        vision: {
          bg: '#070A12',
          surface: 'rgba(15, 23, 42, 0.55)',
          surfaceHover: 'rgba(30, 41, 59, 0.65)',
          border: 'rgba(255, 255, 255, 0.12)',
          borderHover: 'rgba(255, 255, 255, 0.22)',
          glowCyan: 'rgba(6, 182, 212, 0.25)',
          glowPurple: 'rgba(139, 92, 246, 0.25)',
          glowTeal: 'rgba(20, 184, 166, 0.25)',
          text: '#F8FAFC',
          muted: '#94A3B8',
          subtle: '#64748B',
          cyan: '#06B6D4',
          purple: '#A855F7',
          teal: '#14B8A6',
          rose: '#F43F5E',
          indigo: '#6366F1'
        }
      },
      fontFamily: {
        sans: ['Inter', 'Plus Jakarta Sans', 'sans-serif'],
        display: ['Plus Jakarta Sans', 'Inter', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'monospace']
      },
      boxShadow: {
        glass: '0 8px 32px 0 rgba(0, 0, 0, 0.37)',
        glow: '0 0 25px -5px rgba(6, 182, 212, 0.3)',
        purpleGlow: '0 0 25px -5px rgba(168, 85, 247, 0.3)',
        tealGlow: '0 0 25px -5px rgba(20, 184, 166, 0.3)'
      },
      backgroundImage: {
        'vision-gradient': 'radial-gradient(ellipse at top left, rgba(6,182,212,0.15), transparent 50%), radial-gradient(ellipse at bottom right, rgba(168,85,247,0.15), transparent 50%), radial-gradient(ellipse at center, rgba(20,184,166,0.1), transparent 60%)',
        'glass-gradient': 'linear-gradient(135deg, rgba(255, 255, 255, 0.08) 0%, rgba(255, 255, 255, 0.02) 100%)',
        'border-gradient': 'linear-gradient(135deg, rgba(255, 255, 255, 0.2) 0%, rgba(255, 255, 255, 0.05) 50%, rgba(6, 182, 212, 0.4) 100%)'
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-6px)' }
        },
        pulseGlow: {
          '0%, 100%': { opacity: '0.4', transform: 'scale(1)' },
          '50%': { opacity: '0.8', transform: 'scale(1.03)' }
        },
        shimmer: {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' }
        }
      },
      animation: {
        float: 'float 6s ease-in-out infinite',
        pulseGlow: 'pulseGlow 3s ease-in-out infinite',
        shimmer: 'shimmer 2.5s linear infinite'
      }
    }
  },
  plugins: []
};
