import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Palette, Check, Sparkles, Sun, Zap, Flame, Terminal, Crown } from 'lucide-react';
import { ThemeId, THEMES } from '../../types/theme';

interface ThemeSelectorProps {
  currentTheme: ThemeId;
  onSelectTheme: (themeId: ThemeId) => void;
}

const THEME_ICONS: Record<ThemeId, React.ComponentType<{ className?: string; style?: React.CSSProperties }>> = {
  vision: Sparkles,
  nordic: Sun,
  cyberpunk: Zap,
  sunset: Flame,
  matrix: Terminal,
  luxury: Crown
};

export function ThemeSelector({ currentTheme, onSelectTheme }: ThemeSelectorProps) {
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const activeConfig = THEMES[currentTheme] || THEMES.vision;
  const ActiveIcon = THEME_ICONS[currentTheme] || Sparkles;

  // Close dropdown on outside click
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div ref={containerRef} className="relative z-50">
      {/* Toggle Button */}
      <button
        onClick={() => setIsOpen((prev) => !prev)}
        title="Choose Theme Palette"
        className="flex items-center gap-2 rounded-xl border border-white/20 bg-white/10 px-3 py-1.5 text-xs font-semibold text-white backdrop-blur-md transition-all hover:bg-white/20 active:scale-95 shadow-sm"
      >
        <ActiveIcon className="h-4 w-4" style={{ color: activeConfig.previewColors[1] }} />
        <span className="hidden sm:inline font-medium">{activeConfig.name}</span>
        
        {/* Color preview dots */}
        <div className="flex items-center -space-x-1 pl-1">
          {activeConfig.previewColors.map((color, i) => (
            <span
              key={i}
              className="h-2.5 w-2.5 rounded-full border border-black/30 shadow-xs"
              style={{ backgroundColor: color }}
            />
          ))}
        </div>
      </button>

      {/* Theme Dropdown Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.95 }}
            transition={{ duration: 0.2, ease: 'easeOut' }}
            className="absolute right-0 mt-2 w-80 rounded-2xl border border-white/20 vision-glass p-3 shadow-2xl backdrop-blur-2xl"
          >
            <div className="mb-2 flex items-center justify-between border-b border-white/10 pb-2 px-1">
              <div className="flex items-center gap-2">
                <Palette className="h-4 w-4 text-cyan-400" />
                <p className="text-xs font-bold text-white">Visual Workspace Themes</p>
              </div>
              <span className="font-mono text-[10px] text-vision-muted">6 PALETTES</span>
            </div>

            <div className="grid grid-cols-1 gap-1.5 max-h-[380px] overflow-y-auto pr-1">
              {Object.values(THEMES).map((theme) => {
                const Icon = THEME_ICONS[theme.id];
                const isSelected = currentTheme === theme.id;

                return (
                  <button
                    key={theme.id}
                    onClick={() => {
                      onSelectTheme(theme.id);
                      setIsOpen(false);
                    }}
                    className={`flex items-center gap-3 rounded-xl p-2.5 text-left transition-all ${
                      isSelected
                        ? 'bg-white/20 border border-white/30 shadow-md'
                        : 'hover:bg-white/10 hover:border-white/15'
                    }`}
                  >
                    {/* Theme Icon & Color Preview Box */}
                    <div
                      className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-white/20 shadow-xs"
                      style={{ backgroundColor: theme.previewColors[0] }}
                    >
                      <Icon className="h-4 w-4" style={{ color: theme.previewColors[1] }} />
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-white">{theme.name}</span>
                        {isSelected && <Check className="h-4 w-4 text-cyan-400 shrink-0" />}
                      </div>
                      <p className="text-[10px] text-vision-muted truncate">{theme.description}</p>

                      {/* Mini Color Palette Bar */}
                      <div className="mt-1.5 flex h-1.5 w-full overflow-hidden rounded-full border border-white/10">
                        {theme.previewColors.map((color, idx) => (
                          <div key={idx} className="flex-1" style={{ backgroundColor: color }} />
                        ))}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
