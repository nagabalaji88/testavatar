import { useEffect, useRef, useState, type FormEvent } from 'react';
import { Sparkles, Shield, User, Lock, ArrowRight } from 'lucide-react';
import { AvatarScene } from '../avatar/AvatarScene';
import { useSpeechSynthesis } from '../../hooks/useSpeechSynthesis';
import { useTheme } from '../../hooks/useTheme';
import { ThemeSelector } from '../ui/ThemeSelector';
import { GlassCard } from '../ui/GlassCard';
import type { AuthMode } from '../../types/auth';
import type { AvatarState } from '../../types/avatar';

interface LoginScreenProps {
  modelUrl: string;
  onSignIn: (email: string, password: string) => Promise<void>;
  onRegister: (name: string, email: string, password: string) => Promise<void>;
}

const GREETING = "Welcome to Vision Pro AI Companion. Please sign in or register to begin.";

export function LoginScreen({ modelUrl, onSignIn, onRegister }: LoginScreenProps) {
  const { theme, setTheme } = useTheme();
  const [mode, setMode] = useState<AuthMode>('sign-in');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const synthesis = useSpeechSynthesis();
  const hasGreeted = useRef(false);
  const speechStarted = useRef(false);

  useEffect(() => {
    if (synthesis.isSpeaking) {
      speechStarted.current = true;
    }
  }, [synthesis.isSpeaking]);

  useEffect(() => {
    if (hasGreeted.current) return;
    hasGreeted.current = true;

    synthesis.speak(GREETING);

    const handleInteraction = () => {
      if (speechStarted.current) return;
      synthesis.speak(GREETING);
      speechStarted.current = true;
      cleanup();
    };

    const cleanup = () => {
      window.removeEventListener('click', handleInteraction);
      window.removeEventListener('keydown', handleInteraction);
      window.removeEventListener('touchstart', handleInteraction);
    };

    window.addEventListener('click', handleInteraction);
    window.addEventListener('keydown', handleInteraction);
    window.addEventListener('touchstart', handleInteraction);

    return cleanup;
  }, [synthesis]);

  const avatarState: AvatarState = isSubmitting
    ? 'thinking'
    : synthesis.isSpeaking
      ? 'speaking'
      : 'idle';

  const handleSubmit = async (event: FormEvent) => {
    event.preventDefault();
    setError(null);

    if (mode === 'register' && !name.trim()) {
      setError('Please enter your name.');
      return;
    }
    if (!email.trim() || !password.trim()) {
      setError('Please enter your email and password.');
      return;
    }

    setIsSubmitting(true);
    try {
      if (mode === 'register') {
        await onRegister(name.trim(), email.trim(), password);
      } else {
        await onSignIn(email.trim(), password);
      }
    } catch {
      setError('Authentication failed. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="relative flex min-h-screen w-full items-center justify-center bg-vision-bg p-4 overflow-hidden">
      {/* Top right theme switcher */}
      <div className="absolute top-4 right-4 z-50">
        <ThemeSelector currentTheme={theme} onSelectTheme={setTheme} />
      </div>
      {/* Spatial Ambient Radial Glows */}
      <div className="pointer-events-none absolute -top-40 -left-40 h-[500px] w-[500px] rounded-full bg-cyan-500/15 blur-[120px]" />
      <div className="pointer-events-none absolute -bottom-40 -right-40 h-[500px] w-[500px] rounded-full bg-purple-500/15 blur-[120px]" />
      <div className="pointer-events-none absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-[600px] w-[600px] rounded-full bg-teal-500/10 blur-[150px]" />

      <div className="relative z-10 flex flex-col items-center gap-6 lg:flex-row lg:gap-10 max-w-4xl w-full">
        {/* 3D Avatar Floating Glass Card */}
        <GlassCard glowColor="cyan" className="h-[340px] w-full max-w-sm shrink-0 lg:h-[460px] lg:w-[380px]">
          <AvatarScene modelUrl={modelUrl} state={avatarState} visemeIntensity={synthesis.visemeIntensity} />
        </GlassCard>

        {/* Auth Form Glass Panel */}
        <GlassCard glowColor="purple" className="flex-1 w-full max-w-md p-6 sm:p-8">
          <div className="mb-6 flex flex-col items-center text-center">
            <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-2xl border border-purple-500/30 bg-gradient-to-br from-cyan-500/20 to-purple-500/20 text-cyan-300 shadow-purpleGlow">
              <Sparkles className="h-6 w-6" />
            </div>
            <h1 className="text-xl font-bold tracking-tight text-white sm:text-2xl">Vision Pro Companion</h1>
            <p className="mt-1 text-xs text-vision-muted leading-relaxed max-w-xs">{GREETING}</p>
          </div>

          {/* Tab buttons */}
          <div className="mb-6 flex rounded-xl border border-white/10 bg-black/30 p-1">
            <button
              type="button"
              onClick={() => { setMode('sign-in'); setError(null); }}
              className={`flex-1 rounded-lg py-2 text-xs font-medium transition-all ${
                mode === 'sign-in'
                  ? 'bg-gradient-to-r from-cyan-500/30 to-purple-500/30 text-white border border-white/15 shadow-sm'
                  : 'text-vision-muted hover:text-white'
              }`}
            >
              Sign In
            </button>
            <button
              type="button"
              onClick={() => { setMode('register'); setError(null); }}
              className={`flex-1 rounded-lg py-2 text-xs font-medium transition-all ${
                mode === 'register'
                  ? 'bg-gradient-to-r from-cyan-500/30 to-purple-500/30 text-white border border-white/15 shadow-sm'
                  : 'text-vision-muted hover:text-white'
              }`}
            >
              Register
            </button>
          </div>

          {/* Auth Form */}
          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            {mode === 'register' && (
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-medium text-vision-muted">Full Name</label>
                <div className="vision-input flex items-center gap-2.5 rounded-xl px-3 py-2.5">
                  <User className="h-4 w-4 text-cyan-400 shrink-0" />
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="John Doe"
                    className="w-full bg-transparent text-xs text-white placeholder:text-vision-subtle focus:outline-none"
                  />
                </div>
              </div>
            )}

            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-medium text-vision-muted">Email Address</label>
              <div className="vision-input flex items-center gap-2.5 rounded-xl px-3 py-2.5">
                <Shield className="h-4 w-4 text-purple-400 shrink-0" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="user@example.com"
                  className="w-full bg-transparent text-xs text-white placeholder:text-vision-subtle focus:outline-none"
                />
              </div>
            </div>

            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-medium text-vision-muted">Password</label>
              <div className="vision-input flex items-center gap-2.5 rounded-xl px-3 py-2.5">
                <Lock className="h-4 w-4 text-teal-400 shrink-0" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-transparent text-xs text-white placeholder:text-vision-subtle focus:outline-none"
                />
              </div>
            </div>

            {error && (
              <div className="rounded-xl border border-rose-500/30 bg-rose-500/10 px-3 py-2 text-xs text-rose-300">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={isSubmitting}
              className="mt-2 flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-cyan-500 via-purple-600 to-teal-500 py-3 text-xs font-semibold text-white shadow-glow transition-all hover:brightness-110 active:scale-95 disabled:opacity-50"
            >
              <span>{isSubmitting ? 'Authenticating...' : mode === 'register' ? 'Create Account' : 'Sign In'}</span>
              <ArrowRight className="h-4 w-4" />
            </button>
          </form>
        </GlassCard>
      </div>
    </div>
  );
}
