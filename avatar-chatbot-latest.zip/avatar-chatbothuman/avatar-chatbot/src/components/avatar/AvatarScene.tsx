import React, { Suspense, useEffect } from 'react';
import { Canvas, useThree } from '@react-three/fiber';
import * as THREE from 'three';
import { Radio, Brain, Volume2, UserCheck } from 'lucide-react';
import { AvatarModel } from './AvatarModel';
import { PlaceholderAvatar } from './PlaceholderAvatar';
import { AvatarErrorBoundary } from './AvatarErrorBoundary';
import type { AvatarState } from '../../types/avatar';

interface AvatarSceneProps {
  modelUrl: string;
  state: AvatarState;
  visemeIntensity: number;
}

const STATE_LABEL: Record<AvatarState, string> = {
  idle: 'IDLE / READY',
  listening: 'LISTENING...',
  thinking: 'PROCESSING...',
  speaking: 'RESPONDING...'
};

const STATE_RING_CLASS: Record<AvatarState, string> = {
  idle: 'border-white/10 shadow-glass',
  listening: 'border-teal-400/60 shadow-[0_0_30px_rgba(20,184,166,0.4)] animate-pulse',
  thinking: 'border-purple-400/60 shadow-[0_0_30px_rgba(168,85,247,0.4)] animate-pulse',
  speaking: 'border-cyan-400/60 shadow-[0_0_30px_rgba(6,182,212,0.4)] animate-pulse'
};

const STATE_ICON: Record<AvatarState, React.ComponentType<{ className?: string }>> = {
  idle: UserCheck,
  listening: Radio,
  thinking: Brain,
  speaking: Volume2
};

function LoadingPlaceholder() {
  return (
    <mesh position={[0, 0, 0]}>
      <sphereGeometry args={[0.6, 24, 24]} />
      <meshStandardMaterial color="#0F172A" wireframe />
    </mesh>
  );
}

function CameraRig({ hasModel }: { hasModel: boolean }) {
  const { camera } = useThree();

  useEffect(() => {
    if (hasModel) {
      camera.position.set(0, 1.5, 1.9);
      camera.lookAt(new THREE.Vector3(0, 1.5, 0));
    } else {
      camera.position.set(0, 0, 2.3);
      camera.lookAt(new THREE.Vector3(0, 0, 0));
    }
    camera.updateProjectionMatrix();
  }, [camera, hasModel]);

  return null;
}

export function AvatarScene({ modelUrl, state, visemeIntensity }: AvatarSceneProps) {
  const placeholder = <PlaceholderAvatar state={state} visemeIntensity={visemeIntensity} />;
  const hasModel = Boolean(modelUrl);
  const StateIcon = STATE_ICON[state];

  return (
    <div className="relative flex h-full w-full items-center justify-center overflow-hidden">
      {/* Dynamic State Ring */}
      <div
        className={`pointer-events-none absolute h-[82%] w-[82%] max-w-[420px] rounded-full border transition-all duration-500 ${STATE_RING_CLASS[state]}`}
      />

      {/* R3F Canvas */}
      <Canvas camera={{ fov: 28 }} className="relative z-10">
        <CameraRig hasModel={hasModel} />
        <ambientLight intensity={0.9} />
        <directionalLight position={[2, 3, 4]} intensity={1.4} color="#06B6D4" />
        <directionalLight position={[-2, 1, -3]} intensity={0.8} color="#A855F7" />
        <pointLight position={[0, -2, 2]} intensity={0.5} color="#14B8A6" />
        {modelUrl ? (
          <AvatarErrorBoundary fallback={placeholder}>
            <Suspense fallback={<LoadingPlaceholder />}>
              <AvatarModel modelUrl={modelUrl} state={state} visemeIntensity={visemeIntensity} />
            </Suspense>
          </AvatarErrorBoundary>
        ) : (
          placeholder
        )}
      </Canvas>

      {/* Floating State Badge (Vision Pro Glass Pill) */}
      <div className="pointer-events-none absolute bottom-4 left-1/2 z-20 -translate-x-1/2 flex items-center gap-2 rounded-full border border-white/15 bg-black/40 px-3.5 py-1.5 backdrop-blur-xl shadow-glass">
        <StateIcon className="h-3.5 w-3.5 text-cyan-300 animate-pulse" />
        <span className="font-mono text-[10px] font-semibold uppercase tracking-wider text-white">
          {STATE_LABEL[state]}
        </span>
      </div>
    </div>
  );
}
