import { useRef, useState } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';
import type { AvatarState } from '../../types/avatar';

interface PlaceholderAvatarProps {
  state: AvatarState;
  visemeIntensity: number;
}

/**
 * An open-source, highly visible & interactive 3D procedural avatar tuned for Light Theme.
 *
 * Features:
 *  - High Visibility Porcelain & Indigo Aesthetics (bright studio contrast).
 *  - Click Reaction: Click avatar to trigger a cheerful head nod and bounce.
 *  - Hyper-Responsive Mouse Gaze Tracking: Eyes, pupils, and head track cursor.
 *  - Real-Time Speech Viseme Sync: Mouth, jaw drop, and oral cavity deform with speech.
 *  - Reactive Soundwave Halo: Pulsing orbital halo around head during speech.
 */
export function PlaceholderAvatar({ state, visemeIntensity }: PlaceholderAvatarProps) {
  const groupRef = useRef<THREE.Group>(null);
  const headRef = useRef<THREE.Group>(null);
  const leftEyeRef = useRef<THREE.Group>(null);
  const rightEyeRef = useRef<THREE.Group>(null);
  const leftPupilRef = useRef<THREE.Mesh>(null);
  const rightPupilRef = useRef<THREE.Mesh>(null);
  const mouthOuterRef = useRef<THREE.Mesh>(null);
  const mouthInnerRef = useRef<THREE.Mesh>(null);
  const jawRef = useRef<THREE.Group>(null);
  const leftBrowRef = useRef<THREE.Mesh>(null);
  const rightBrowRef = useRef<THREE.Mesh>(null);
  const soundwaveRingRef = useRef<THREE.Mesh>(null);
  const coreGlowRef = useRef<THREE.MeshStandardMaterial>(null);

  const [clickAnim, setClickAnim] = useState(0);

  const blinkTimerRef = useRef(0);
  const nextBlinkAtRef = useRef(2 + Math.random() * 3);
  const blinkProgressRef = useRef(0);

  const mousePos = useRef({ x: 0, y: 0 });
  const { viewport } = useThree();

  const handlePointerDown = () => {
    setClickAnim(1.0);
  };

  useFrame((frameState, delta) => {
    const t = frameState.clock.elapsedTime;

    // Decaying click animation impulse
    let clickImpulse = 0;
    if (clickAnim > 0) {
      clickImpulse = Math.sin(clickAnim * Math.PI) * 0.15;
      setClickAnim((prev) => Math.max(0, prev - delta * 3));
    }

    // ── Mouse & Pointer Tracking ─────────────────────────────────────────────
    const pointer = frameState.pointer;
    mousePos.current.x = THREE.MathUtils.lerp(mousePos.current.x, pointer.x * (viewport.width / 2), 0.08);
    mousePos.current.y = THREE.MathUtils.lerp(mousePos.current.y, pointer.y * (viewport.height / 2), 0.08);

    // ── Head & Body Pose Physics ─────────────────────────────────────────────
    if (headRef.current) {
      const isListening = state === 'listening';
      const isThinking = state === 'thinking';
      const isSpeaking = state === 'speaking';

      // Mouse tracking angle
      const targetRotY = mousePos.current.x * 0.24;
      const targetRotX = -mousePos.current.y * 0.24 + (isThinking ? -0.12 : 0);

      // Micro-sway & speech bounce
      const idleSwayY = Math.sin(t * 0.9) * 0.05;
      const idleSwayX = Math.sin(t * 1.3) * 0.03;
      const speakBounce = isSpeaking ? Math.sin(t * 12) * 0.03 * visemeIntensity : 0;

      headRef.current.rotation.y = THREE.MathUtils.lerp(
        headRef.current.rotation.y,
        targetRotY + idleSwayY,
        0.1
      );
      headRef.current.rotation.x = THREE.MathUtils.lerp(
        headRef.current.rotation.x,
        targetRotX + idleSwayX + speakBounce + clickImpulse,
        0.1
      );
      headRef.current.position.y = Math.sin(t * 1.6) * 0.03 + speakBounce + clickImpulse * 0.5;

      // Attentive tilt when listening
      if (isListening) {
        headRef.current.rotation.z = THREE.MathUtils.lerp(headRef.current.rotation.z, 0.07, 0.1);
      } else {
        headRef.current.rotation.z = THREE.MathUtils.lerp(headRef.current.rotation.z, 0, 0.1);
      }
    }

    // ── Eye Pupil & Gaze Direction ───────────────────────────────────────────
    if (leftPupilRef.current && rightPupilRef.current) {
      const pupilX = mousePos.current.x * 0.035;
      const pupilY = mousePos.current.y * 0.035;
      leftPupilRef.current.position.x = THREE.MathUtils.lerp(leftPupilRef.current.position.x, pupilX, 0.15);
      leftPupilRef.current.position.y = THREE.MathUtils.lerp(leftPupilRef.current.position.y, pupilY, 0.15);
      rightPupilRef.current.position.x = THREE.MathUtils.lerp(rightPupilRef.current.position.x, pupilX, 0.15);
      rightPupilRef.current.position.y = THREE.MathUtils.lerp(rightPupilRef.current.position.y, pupilY, 0.15);
    }

    // ── Eye Blinking ─────────────────────────────────────────────────────────
    blinkTimerRef.current += delta;
    if (blinkProgressRef.current > 0) {
      blinkProgressRef.current = Math.max(0, blinkProgressRef.current - delta * 9);
    } else if (blinkTimerRef.current >= nextBlinkAtRef.current) {
      blinkTimerRef.current = 0;
      nextBlinkAtRef.current = 2 + Math.random() * 3.5;
      blinkProgressRef.current = 1;
    }
    const blinkVal = easeBlink(blinkProgressRef.current);
    const eyeScaleY = 1 - blinkVal * 0.95;

    if (leftEyeRef.current) leftEyeRef.current.scale.y = eyeScaleY;
    if (rightEyeRef.current) rightEyeRef.current.scale.y = eyeScaleY;

    // ── Eyebrow Expressions ──────────────────────────────────────────────────
    if (leftBrowRef.current && rightBrowRef.current) {
      const isThinking = state === 'thinking';
      const isListening = state === 'listening';
      const isSpeaking = state === 'speaking';

      const browY = isThinking ? 0.05 : isListening ? 0.03 : isSpeaking ? Math.sin(t * 8) * 0.02 : 0;
      const browRot = isThinking ? 0.18 : 0;

      leftBrowRef.current.position.y = THREE.MathUtils.lerp(leftBrowRef.current.position.y, 0.58 + browY, 0.12);
      rightBrowRef.current.position.y = THREE.MathUtils.lerp(rightBrowRef.current.position.y, 0.58 + browY, 0.12);

      leftBrowRef.current.rotation.z = THREE.MathUtils.lerp(leftBrowRef.current.rotation.z, -browRot, 0.12);
      rightBrowRef.current.rotation.z = THREE.MathUtils.lerp(rightBrowRef.current.rotation.z, browRot, 0.12);
    }

    // ── Speech Viseme Lip Sync & Jaw Drop ───────────────────────────────────
    const mouthOpen = state === 'speaking' ? visemeIntensity : 0;
    if (mouthOuterRef.current) {
      mouthOuterRef.current.scale.y = THREE.MathUtils.lerp(mouthOuterRef.current.scale.y, 1 + mouthOpen * 3.5, 0.25);
      mouthOuterRef.current.scale.x = THREE.MathUtils.lerp(mouthOuterRef.current.scale.x, 1 + mouthOpen * 0.5, 0.25);
    }
    if (mouthInnerRef.current) {
      mouthInnerRef.current.scale.y = THREE.MathUtils.lerp(mouthInnerRef.current.scale.y, 0.1 + mouthOpen * 3.0, 0.25);
    }
    if (jawRef.current) {
      jawRef.current.rotation.x = THREE.MathUtils.lerp(jawRef.current.rotation.x, mouthOpen * 0.22, 0.25);
    }

    // ── Audio Soundwave Ring Pulsing ────────────────────────────────────────
    if (soundwaveRingRef.current) {
      const ringScale = state === 'speaking' ? 1 + visemeIntensity * 0.6 : 1 + Math.sin(t * 2) * 0.05;
      soundwaveRingRef.current.scale.set(ringScale, ringScale, 1);
    }

    // ── Dynamic State Colors ─────────────────────────────────────────────────
    if (coreGlowRef.current) {
      let targetColor = '#06B6D4'; // idle cyan
      if (state === 'listening') targetColor = '#14B8A6'; // teal
      if (state === 'thinking') targetColor = '#A855F7'; // purple
      if (state === 'speaking') targetColor = '#06B6D4'; // cyan

      coreGlowRef.current.emissive.lerp(new THREE.Color(targetColor), 0.1);
    }
  });

  return (
    <group
      ref={groupRef}
      position={[0, -0.15, 0]}
      scale={0.95}
      onPointerDown={handlePointerDown}
    >
      {/* ── Soundwave Halo Ring ────────────────────────────────────── */}
      <mesh ref={soundwaveRingRef} position={[0, 0.45, -0.1]}>
        <ringGeometry args={[0.62, 0.66, 64]} />
        <meshStandardMaterial
          color={state === 'speaking' ? '#4F46E5' : state === 'listening' ? '#0D9488' : '#818CF8'}
          emissive={state === 'speaking' ? '#4F46E5' : '#818CF8'}
          emissiveIntensity={state === 'speaking' ? 0.9 : 0.4}
          transparent
          opacity={0.6}
        />
      </mesh>

      {/* ── Head Group (High Visibility Porcelain & Indigo Accent) ───── */}
      <group ref={headRef}>
        {/* Main Head Base */}
        <mesh position={[0, 0.45, 0]}>
          <sphereGeometry args={[0.48, 32, 32]} />
          <meshStandardMaterial color="#E2E8F0" roughness={0.15} metalness={0.2} />
        </mesh>

        {/* Glossy Face Plate */}
        <mesh position={[0, 0.42, 0.11]}>
          <sphereGeometry args={[0.41, 32, 32]} />
          <meshStandardMaterial color="#F8FAFC" roughness={0.1} metalness={0.1} />
        </mesh>

        {/* Left Eye */}
        <group ref={leftEyeRef} position={[-0.17, 0.5, 0.42]}>
          <mesh>
            <sphereGeometry args={[0.08, 16, 16]} />
            <meshStandardMaterial color="#0F172A" roughness={0.1} />
          </mesh>
          <mesh ref={leftPupilRef} position={[0, 0, 0.04]}>
            <sphereGeometry args={[0.045, 16, 16]} />
            <meshStandardMaterial color="#0D9488" emissive="#0D9488" emissiveIntensity={1.2} />
          </mesh>
        </group>

        {/* Right Eye */}
        <group ref={rightEyeRef} position={[0.17, 0.5, 0.42]}>
          <mesh>
            <sphereGeometry args={[0.08, 16, 16]} />
            <meshStandardMaterial color="#0F172A" roughness={0.1} />
          </mesh>
          <mesh ref={rightPupilRef} position={[0, 0, 0.04]}>
            <sphereGeometry args={[0.045, 16, 16]} />
            <meshStandardMaterial color="#0D9488" emissive="#0D9488" emissiveIntensity={1.2} />
          </mesh>
        </group>

        {/* Eyebrows */}
        <mesh ref={leftBrowRef} position={[-0.17, 0.58, 0.44]}>
          <boxGeometry args={[0.11, 0.02, 0.02]} />
          <meshStandardMaterial color="#4F46E5" emissive="#4F46E5" emissiveIntensity={0.8} />
        </mesh>
        <mesh ref={rightBrowRef} position={[0.17, 0.58, 0.44]}>
          <boxGeometry args={[0.11, 0.02, 0.02]} />
          <meshStandardMaterial color="#4F46E5" emissive="#4F46E5" emissiveIntensity={0.8} />
        </mesh>

        {/* Jaw & Mouth (Lip Sync) */}
        <group ref={jawRef} position={[0, 0.31, 0.43]}>
          {/* Lips Outer Frame */}
          <mesh ref={mouthOuterRef} position={[0, 0, 0]}>
            <capsuleGeometry args={[0.018, 0.15, 8, 16]} />
            <meshStandardMaterial color="#4F46E5" emissive="#4F46E5" emissiveIntensity={0.8} />
          </mesh>
          {/* Inner Mouth Cavity */}
          <mesh ref={mouthInnerRef} position={[0, 0, -0.01]}>
            <boxGeometry args={[0.13, 0.035, 0.03]} />
            <meshStandardMaterial color="#0F172A" />
          </mesh>
        </group>

        {/* Headset Ear Accents */}
        <mesh position={[-0.49, 0.46, 0]}>
          <cylinderGeometry args={[0.06, 0.06, 0.09, 16]} />
          <meshStandardMaterial color="#CBD5E1" metalness={0.8} roughness={0.2} />
        </mesh>
        <mesh position={[0.49, 0.46, 0]}>
          <cylinderGeometry args={[0.06, 0.06, 0.09, 16]} />
          <meshStandardMaterial color="#CBD5E1" metalness={0.8} roughness={0.2} />
        </mesh>
      </group>

      {/* ── Body Base ────────────────────────────────────────────── */}
      <group position={[0, -0.28, 0]}>
        {/* Neck */}
        <mesh position={[0, 0.1, 0]}>
          <cylinderGeometry args={[0.15, 0.2, 0.26, 16]} />
          <meshStandardMaterial color="#94A3B8" roughness={0.3} />
        </mesh>

        {/* Core Crest Glow */}
        <mesh position={[0, -0.04, 0.3]}>
          <sphereGeometry args={[0.075, 16, 16]} />
          <meshStandardMaterial ref={coreGlowRef} color="#4F46E5" emissive="#4F46E5" emissiveIntensity={1.0} />
        </mesh>

        {/* Shoulders */}
        <mesh position={[0, -0.28, 0]}>
          <capsuleGeometry args={[0.38, 0.72, 8, 16]} />
          <meshStandardMaterial color="#334155" roughness={0.3} metalness={0.4} />
        </mesh>
      </group>

      {/* Ambient Floating Particles */}
      <ParticlesCount />
    </group>
  );
}

function ParticlesCount() {
  const pointsRef = useRef<THREE.Points>(null);

  const particlesCount = 35;
  const positions = new Float32Array(particlesCount * 3);
  for (let i = 0; i < particlesCount; i++) {
    positions[i * 3] = (Math.random() - 0.5) * 2.2;
    positions[i * 3 + 1] = (Math.random() - 0.5) * 2.2;
    positions[i * 3 + 2] = (Math.random() - 0.5) * 1.8;
  }

  useFrame((frameState) => {
    if (pointsRef.current) {
      pointsRef.current.rotation.y = frameState.clock.elapsedTime * 0.06;
      pointsRef.current.rotation.x = Math.sin(frameState.clock.elapsedTime * 0.04) * 0.04;
    }
  });

  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          args={[positions, 3]}
        />
      </bufferGeometry>
      <pointsMaterial
        size={0.03}
        color="#4F46E5"
        transparent
        opacity={0.6}
        blending={THREE.AdditiveBlending}
      />
    </points>
  );
}

function easeBlink(progress: number): number {
  return progress < 0.5 ? progress * 2 : (1 - progress) * 2;
}
