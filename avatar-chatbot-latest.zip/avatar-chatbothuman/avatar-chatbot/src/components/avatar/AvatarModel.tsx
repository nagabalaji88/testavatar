import { useEffect, useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { useGLTF } from '@react-three/drei';
import * as THREE from 'three';
import type { AvatarState } from '../../types/avatar';

interface AvatarModelProps {
  modelUrl: string;
  state: AvatarState;
  visemeIntensity: number;
}

/** Ready Player Me / ARKit-style morph target names, tried in order until one exists. */
const BLINK_MORPHS = ['eyeBlinkLeft', 'eyeBlinkRight', 'eyesClosed'];
const MOUTH_MORPHS = ['mouthOpen', 'jawOpen', 'viseme_aa'];

function setMorph(mesh: THREE.SkinnedMesh | null, names: string[], value: number) {
  if (!mesh?.morphTargetDictionary || !mesh.morphTargetInfluences) return;
  for (const name of names) {
    const index = mesh.morphTargetDictionary[name];
    if (index !== undefined) {
      mesh.morphTargetInfluences[index] = value;
      return;
    }
  }
}

export function AvatarModel({ modelUrl, state, visemeIntensity }: AvatarModelProps) {
  const { scene } = useGLTF(modelUrl);
  const headBoneRef = useRef<THREE.Object3D | null>(null);
  const blinkTimerRef = useRef(0);
  const nextBlinkAtRef = useRef(2 + Math.random() * 3);
  const blinkProgressRef = useRef(0);

  const clonedScene = useMemo(() => scene.clone(true), [scene]);

  // Morph meshes must come from the CLONED scene — that's what's actually
  // rendered via <primitive object={clonedScene} />. Driving morphs on the
  // original `scene` (from the cached useGLTF result) has no visible effect.
  const morphMeshes = useMemo(() => {
    const meshes: THREE.SkinnedMesh[] = [];
    clonedScene.traverse((child) => {
      if ((child as THREE.SkinnedMesh).morphTargetDictionary) {
        meshes.push(child as THREE.SkinnedMesh);
      }
    });
    return meshes;
  }, [clonedScene]);

  useEffect(() => {
    headBoneRef.current =
      clonedScene.getObjectByName('Head') ?? clonedScene.getObjectByName('head') ?? null;
  }, [clonedScene]);

  useFrame((frameState, delta) => {
    const t = frameState.clock.elapsedTime;

    // Idle head sway, subtler while actively listening so the avatar reads as attentive.
    if (headBoneRef.current) {
      const swayScale = state === 'listening' ? 0.4 : 1;
      headBoneRef.current.rotation.y = Math.sin(t * 0.6) * 0.05 * swayScale;
      headBoneRef.current.rotation.x = Math.sin(t * 0.9) * 0.02 * swayScale + (state === 'thinking' ? 0.05 : 0);
    }

    // Natural blinking: closed-eye pulse on a randomized interval.
    blinkTimerRef.current += delta;
    if (blinkProgressRef.current > 0) {
      blinkProgressRef.current = Math.max(0, blinkProgressRef.current - delta * 6);
      const blinkVal = easeBlink(blinkProgressRef.current);
      for (const mesh of morphMeshes) setMorph(mesh, BLINK_MORPHS, blinkVal);
    } else if (blinkTimerRef.current >= nextBlinkAtRef.current) {
      blinkTimerRef.current = 0;
      nextBlinkAtRef.current = 2 + Math.random() * 3;
      blinkProgressRef.current = 1;
    }

    // Mouth movement: driven by viseme intensity while speaking, otherwise closed.
    const targetMouth = state === 'speaking' ? visemeIntensity : 0;
    for (const mesh of morphMeshes) setMorph(mesh, MOUTH_MORPHS, targetMouth);
  });

  return <primitive object={clonedScene} scale={1.4} />;
}

function easeBlink(progress: number): number {
  return progress < 0.5 ? progress * 2 : (1 - progress) * 2;
}
