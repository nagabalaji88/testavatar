import { motion } from 'framer-motion';
import { Sparkles, User } from 'lucide-react';
import type { ChatMessage } from '../../types/chat';

interface MessageBubbleProps {
  message: ChatMessage;
}

export function MessageBubble({ message }: MessageBubbleProps) {
  const isUser = message.role === 'user';
  const time = new Date(message.timestamp).toLocaleTimeString([], {
    hour: 'numeric',
    minute: '2-digit'
  });

  return (
    <motion.div
      initial={{ opacity: 0, y: 12, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.25, ease: 'easeOut' }}
      className={`flex w-full ${isUser ? 'justify-end' : 'justify-start'}`}
    >
      <div className={`flex max-w-[85%] sm:max-w-[75%] items-start gap-3 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}>
        {/* Avatar badge */}
        <div
          className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-xl border shadow-sm ${
            isUser
              ? 'border-purple-500/30 bg-purple-500/20 text-purple-300'
              : 'border-cyan-500/30 bg-cyan-500/20 text-cyan-300'
          }`}
        >
          {isUser ? <User className="h-4 w-4" /> : <Sparkles className="h-4 w-4" />}
        </div>

        {/* Message bubble */}
        <div className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}>
          <div
            className={`relative overflow-hidden rounded-2xl px-4 py-3 text-sm leading-relaxed ${
              isUser
                ? 'rounded-tr-xs bg-gradient-to-br from-purple-600/90 via-indigo-600/90 to-purple-800/90 text-white shadow-lg shadow-purple-900/30 border border-purple-400/30'
                : 'rounded-tl-xs vision-glass text-slate-100 shadow-lg border border-white/15'
            }`}
          >
            {/* Ambient specular highlight */}
            <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/25 to-transparent" />
            <p className="whitespace-pre-wrap">{message.content}</p>
          </div>

          <span className="mt-1 px-1 font-mono text-[10px] text-vision-subtle">{time}</span>
        </div>
      </div>
    </motion.div>
  );
}
