import { Bot, Sparkles, SlidersHorizontal } from 'lucide-react';
import type { ChatMessage } from '../../types/chat';
import { MessageList } from './MessageList';
import { ChatInput } from './ChatInput';
import { GlassCard } from '../ui/GlassCard';

interface ChatPanelProps {
  messages: ChatMessage[];
  isProcessing: boolean;
  inputValue: string;
  onInputChange: (value: string) => void;
  onSubmit: (text: string) => void;
  isListening: boolean;
  isMicSupported: boolean;
  onToggleMic: () => void;
  isSpeaking?: boolean;
  onStopSpeaking?: () => void;
  isAvatarVisible: boolean;
  onShowAvatar: () => void;
}

export function ChatPanel({
  messages,
  isProcessing,
  inputValue,
  onInputChange,
  onSubmit,
  isListening,
  isMicSupported,
  onToggleMic,
  isSpeaking = false,
  onStopSpeaking,
  isAvatarVisible,
  onShowAvatar,
}: ChatPanelProps) {
  return (
    <GlassCard className="flex h-full flex-col overflow-hidden" glowColor="cyan">
      {/* AI Copilot Header */}
      <div className="flex items-center justify-between border-b border-white/10 px-5 py-3.5 bg-black/20">
        <div className="flex items-center gap-3">
          <div className="relative flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-cyan-500/20 to-purple-500/20 border border-cyan-500/30 text-cyan-300">
            <Bot className="h-4 w-4" />
            <span className="absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full border-2 border-slate-900 bg-teal-400" />
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-semibold tracking-wide text-white">AI Copilot</h2>
              <span className="inline-flex items-center gap-1 rounded-full border border-cyan-500/30 bg-cyan-500/10 px-2 py-0.5 text-[10px] font-medium text-cyan-300">
                <Sparkles className="h-2.5 w-2.5" /> Vision Engine
              </span>
            </div>
            <p className="text-[11px] text-vision-muted">Ready for queries & schedule management</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            title="Copilot settings"
            className="flex h-8 w-8 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-vision-muted transition-all hover:border-white/20 hover:text-white"
          >
            <SlidersHorizontal className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      {/* Message List */}
      <div className="flex-1 overflow-hidden p-4">
        <MessageList
          messages={messages}
          isProcessing={isProcessing}
          onQuickPrompt={(promptText) => onSubmit(promptText)}
        />
      </div>

      {/* Chat Input */}
      <ChatInput
        value={inputValue}
        onChange={onInputChange}
        onSubmit={onSubmit}
        disabled={isProcessing}
        isListening={isListening}
        isMicSupported={isMicSupported}
        onToggleMic={onToggleMic}
        isSpeaking={isSpeaking}
        onStopSpeaking={onStopSpeaking}
        isAvatarVisible={isAvatarVisible}
        onShowAvatar={onShowAvatar}
      />
    </GlassCard>
  );
}
