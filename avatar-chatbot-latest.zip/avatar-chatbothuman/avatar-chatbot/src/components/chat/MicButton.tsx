import { Mic, MicOff } from 'lucide-react';
import { motion } from 'framer-motion';

interface MicButtonProps {
  isListening: boolean;
  isSupported: boolean;
  onToggle: () => void;
}

export function MicButton({ isListening, isSupported, onToggle }: MicButtonProps) {
  return (
    <div className="relative">
      {isListening && (
        <motion.span
          animate={{ scale: [1, 1.3, 1], opacity: [0.6, 0.2, 0.6] }}
          transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' }}
          className="absolute -inset-1.5 rounded-full bg-cyan-500/40 blur-sm pointer-events-none"
        />
      )}

      <button
        type="button"
        onClick={onToggle}
        disabled={!isSupported}
        aria-pressed={isListening}
        aria-label={isListening ? 'Stop listening' : 'Start listening'}
        title={isSupported ? (isListening ? 'Stop voice input' : 'Start voice input') : 'Voice input not supported'}
        className={`relative flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl border transition-all ${
          isListening
            ? 'border-cyan-400 bg-cyan-500/20 text-cyan-300 shadow-[0_0_20px_rgba(6,182,212,0.4)]'
            : 'border-white/10 bg-white/5 text-vision-muted hover:border-white/20 hover:bg-white/10 hover:text-white'
        } disabled:cursor-not-allowed disabled:opacity-40`}
      >
        {isSupported ? (
          isListening ? (
            <Mic className="h-5 w-5 animate-pulse text-cyan-300" />
          ) : (
            <Mic className="h-5 w-5" />
          )
        ) : (
          <MicOff className="h-5 w-5 opacity-50" />
        )}
      </button>
    </div>
  );
}
