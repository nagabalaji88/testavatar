import { FormEvent } from 'react';
import { Send, Square, Sparkles } from 'lucide-react';
import { MicButton } from './MicButton';
import { ShowAvatarButton } from '../avatar/ShowAvatarButton';

interface ChatInputProps {
  value: string;
  onChange: (value: string) => void;
  onSubmit: (text: string) => void;
  disabled: boolean;
  isListening: boolean;
  isMicSupported: boolean;
  onToggleMic: () => void;
  isSpeaking?: boolean;
  onStopSpeaking?: () => void;
  isAvatarVisible: boolean;
  onShowAvatar: () => void;
}

export function ChatInput({
  value,
  onChange,
  onSubmit,
  disabled,
  isListening,
  isMicSupported,
  onToggleMic,
  isSpeaking = false,
  onStopSpeaking,
  isAvatarVisible,
  onShowAvatar,
}: ChatInputProps) {
  const handleSubmit = (event: FormEvent) => {
    event.preventDefault();
    const text = value.trim();
    if (!text || disabled) return;
    onSubmit(text);
    onChange('');
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="relative flex items-center gap-2.5 border-t border-white/10 p-4 bg-black/20"
    >
      {/* Mic or Avatar Restore Button */}
      {isAvatarVisible ? (
        <MicButton isListening={isListening} isSupported={isMicSupported} onToggle={onToggleMic} />
      ) : (
        <ShowAvatarButton onShow={onShowAvatar} />
      )}

      {/* Input container */}
      <div className="relative flex-1 vision-input flex items-center rounded-2xl px-4 py-1.5 transition-all">
        <input
          type="text"
          value={value}
          onChange={(event) => onChange(event.target.value)}
          placeholder={isListening ? 'Listening to your voice...' : 'Ask Copilot anything or schedule an event...'}
          disabled={disabled}
          className="w-full bg-transparent py-2 text-sm text-white placeholder:text-vision-subtle focus:outline-none disabled:opacity-50"
        />

        {/* Ambient hint */}
        <Sparkles className="h-4 w-4 text-cyan-400/50 pointer-events-none ml-2" />
      </div>

      {/* Stop Speaking Button */}
      {isSpeaking && (
        <button
          id="stop-avatar-speaking-btn"
          type="button"
          onClick={onStopSpeaking}
          aria-label="Stop avatar speaking"
          title="Stop Avatar Speech"
          className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-rose-500/80 border border-rose-400/40 text-white transition-all hover:bg-rose-600 hover:shadow-[0_0_15px_rgba(244,63,94,0.4)]"
        >
          <Square className="h-4 w-4 fill-white" />
        </button>
      )}

      {/* Send Button */}
      <button
        type="submit"
        disabled={disabled || !value.trim()}
        className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-cyan-500 to-purple-600 text-white shadow-lg transition-all hover:from-cyan-400 hover:to-purple-500 hover:shadow-cyan-500/25 active:scale-95 disabled:cursor-not-allowed disabled:opacity-30 disabled:hover:shadow-none"
        aria-label="Send message"
      >
        <Send className="h-4 w-4" />
      </button>
    </form>
  );
}
