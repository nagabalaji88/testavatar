import { useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, Calendar, MessageSquare, Bot } from 'lucide-react';
import type { ChatMessage } from '../../types/chat';
import { MessageBubble } from './MessageBubble';

interface MessageListProps {
  messages: ChatMessage[];
  isProcessing: boolean;
  onQuickPrompt?: (text: string) => void;
}

export function MessageList({ messages, isProcessing, onQuickPrompt }: MessageListProps) {
  const bottomRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
  }, [messages, isProcessing]);

  const quickPrompts = [
    {
      icon: Calendar,
      title: 'Schedule a Meeting',
      prompt: 'Schedule a team sync meeting tomorrow at 2 PM for 45 minutes.'
    },
    {
      icon: MessageSquare,
      title: 'Daily Summary',
      prompt: 'What are my top priorities and scheduled events for today?'
    },
    {
      icon: Sparkles,
      title: 'Avatar Assistant',
      prompt: 'Introduce yourself and show me what commands you support.'
    }
  ];

  if (messages.length === 0 && !isProcessing) {
    return (
      <div className="flex h-full flex-col items-center justify-center p-6 text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.4 }}
          className="flex flex-col items-center max-w-md"
        >
          <div className="relative mb-4 flex h-16 w-16 items-center justify-center rounded-3xl border border-cyan-500/30 bg-gradient-to-br from-cyan-500/20 via-purple-500/20 to-teal-500/20 shadow-glow">
            <Sparkles className="h-8 w-8 text-cyan-300 animate-pulse" />
          </div>

          <h2 className="text-xl font-semibold tracking-tight text-white mb-2">
            Spatial AI Copilot
          </h2>
          <p className="text-sm text-vision-muted mb-6 leading-relaxed">
            Speak or type to converse with your 3D avatar companion and manage your daily agenda.
          </p>

          <div className="grid w-full grid-cols-1 gap-2.5 sm:grid-cols-3">
            {quickPrompts.map((item, idx) => {
              const IconComponent = item.icon;
              return (
                <button
                  key={idx}
                  onClick={() => onQuickPrompt && onQuickPrompt(item.prompt)}
                  className="flex flex-col items-start gap-1.5 rounded-2xl border border-white/10 bg-white/5 p-3 text-left transition-all hover:border-cyan-500/40 hover:bg-cyan-500/10 group"
                >
                  <IconComponent className="h-4 w-4 text-cyan-400 group-hover:scale-110 transition-transform" />
                  <span className="text-xs font-medium text-white">{item.title}</span>
                  <span className="text-[10px] text-vision-subtle line-clamp-2">{item.prompt}</span>
                </button>
              );
            })}
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="flex h-full flex-col gap-4 overflow-y-auto pr-2">
      <AnimatePresence initial={false}>
        {messages.map((message) => (
          <MessageBubble key={message.id} message={message} />
        ))}
      </AnimatePresence>

      {isProcessing && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-3 justify-start"
        >
          <div className="flex h-8 w-8 items-center justify-center rounded-xl border border-cyan-500/30 bg-cyan-500/20 text-cyan-300 shadow-glow">
            <Bot className="h-4 w-4 animate-spin" />
          </div>
          <div className="flex items-center gap-2 rounded-2xl rounded-tl-xs border border-white/15 vision-glass px-4 py-3 text-xs text-cyan-300">
            <Sparkles className="h-3.5 w-3.5 animate-pulse text-cyan-400" />
            <span>AI Copilot is thinking...</span>
            <div className="ml-1 flex items-center gap-1">
              <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-cyan-400 [animation-delay:-0.3s]" />
              <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-cyan-400 [animation-delay:-0.15s]" />
              <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-cyan-400" />
            </div>
          </div>
        </motion.div>
      )}

      <div ref={bottomRef} />
    </div>
  );
}
