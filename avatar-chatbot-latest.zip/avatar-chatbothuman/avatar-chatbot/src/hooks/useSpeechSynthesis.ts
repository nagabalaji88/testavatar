import { useCallback, useEffect, useRef, useState } from 'react';

export interface UseSpeechSynthesisResult {
  isSupported: boolean;
  isSpeaking: boolean;
  /** 0-1 mouth-openness target, updated on each word boundary while speaking. */
  visemeIntensity: number;
  speak: (text: string, onDone?: () => void) => void;
  cancel: () => void;
}

/**
 * Wraps the browser SpeechSynthesis API. The Web Speech API does not expose
 * audio amplitude, so lip-sync is approximated: each word-boundary event
 * pulses the mouth open, then eases back toward closed until the next word.
 */
export function useSpeechSynthesis(): UseSpeechSynthesisResult {
  const isSupported = typeof window !== 'undefined' && 'speechSynthesis' in window;
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [visemeIntensity, setVisemeIntensity] = useState(0);
  const decayRef = useRef<number | null>(null);

  const clearDecay = useCallback(() => {
    if (decayRef.current !== null) {
      window.clearInterval(decayRef.current);
      decayRef.current = null;
    }
  }, []);

  useEffect(() => clearDecay, [clearDecay]);

  /** Pick the best male English voice available in the browser. */
  const pickMaleVoice = useCallback((): SpeechSynthesisVoice | null => {
    const voices = window.speechSynthesis.getVoices();
    const enVoices = voices.filter((v) => v.lang.startsWith('en'));
    // Prefer voices explicitly tagged or named as male
    const male = enVoices.find(
      (v) =>
        /male/i.test(v.name) ||
        /\b(David|Mark|James|Daniel|George|Guy)\b/i.test(v.name)
    );
    if (male) return male;
    // Fallback: pick second English voice (often male) or first available
    return enVoices[1] ?? enVoices[0] ?? voices[0] ?? null;
  }, []);

  const speak = useCallback(
    (text: string, onDone?: () => void) => {
      if (!isSupported) {
        onDone?.();
        return;
      }

      window.speechSynthesis.cancel();

      const doSpeak = () => {
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.rate = 1;
        utterance.pitch = 0.85; // Slightly lower pitch for male voice

        const voice = pickMaleVoice();
        if (voice) utterance.voice = voice;

        utterance.onstart = () => {
          setIsSpeaking(true);
        };

        utterance.onboundary = (event) => {
          if (event.name !== 'word') return;
          setVisemeIntensity(0.6 + Math.random() * 0.4);

          clearDecay();
          decayRef.current = window.setInterval(() => {
            setVisemeIntensity((current) => {
              const next = current - 0.15;
              if (next <= 0) {
                clearDecay();
                return 0;
              }
              return next;
            });
          }, 40);
        };

        utterance.onend = () => {
          clearDecay();
          setVisemeIntensity(0);
          setIsSpeaking(false);
          onDone?.();
        };

        utterance.onerror = () => {
          clearDecay();
          setVisemeIntensity(0);
          setIsSpeaking(false);
          onDone?.();
        };

        window.speechSynthesis.speak(utterance);
      };

      // Chrome loads voices asynchronously; wait if none available yet
      if (window.speechSynthesis.getVoices().length === 0) {
        window.speechSynthesis.addEventListener('voiceschanged', doSpeak, { once: true });
      } else {
        doSpeak();
      }
    },
    [clearDecay, isSupported, pickMaleVoice]
  );

  const cancel = useCallback(() => {
    if (!isSupported) return;
    window.speechSynthesis.cancel();
    clearDecay();
    setVisemeIntensity(0);
    setIsSpeaking(false);
  }, [clearDecay, isSupported]);

  return { isSupported, isSpeaking, visemeIntensity, speak, cancel };
}
