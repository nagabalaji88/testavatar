import { useCallback, useState } from 'react';
import type { ChatMessage } from '../types/chat';
import type { CalendarService } from '../types/calendar';
import type { AiService } from '../services/aiService';
import { extractCalendarIntent } from '../services/intentParser';

const SYSTEM_PROMPT = `You are a helpful, concise voice assistant embedded in an avatar chatbot.
Keep replies short and conversational, since they will be spoken aloud.
You can create calendar events; when you do, a separate system already
extracted the details, so simply acknowledge naturally.`;

function createMessage(role: ChatMessage['role'], content: string): ChatMessage {
  return {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`,
    role,
    content,
    timestamp: Date.now()
  };
}

function formatTime(time: string): string {
  const [hourStr, minute] = time.split(':');
  const hour = Number(hourStr);
  const period = hour >= 12 ? 'PM' : 'AM';
  const twelveHour = hour % 12 === 0 ? 12 : hour % 12;
  return `${twelveHour}:${minute} ${period}`;
}

export interface UseChatResult {
  messages: ChatMessage[];
  isProcessing: boolean;
  sendMessage: (text: string) => Promise<void>;
}

export function useChat(
  aiService: AiService,
  calendarService: CalendarService,
  onAssistantReply: (text: string) => void
): UseChatResult {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);

  const sendMessage = useCallback(
    async (text: string) => {
      const trimmed = text.trim();
      if (!trimmed || isProcessing) return;

      const userMessage = createMessage('user', trimmed);
      setMessages((prev) => [...prev, userMessage]);
      setIsProcessing(true);

      try {
        const intent = await extractCalendarIntent(aiService, trimmed);

        let replyText: string;

        if (intent.isCalendarRequest && intent.draft) {
          try {
            const created = await calendarService.createEvent(intent.draft);
            const start = new Date(created.start);
            const end = new Date(created.end);
            replyText = `Done. I've created "${created.title}" on ${start.toLocaleDateString(undefined, {
              weekday: 'long',
              month: 'long',
              day: 'numeric'
            })} from ${formatTime(intent.draft.startTime)} to ${formatTime(end.toTimeString().slice(0, 5))}.`;
          } catch (error) {
            console.error('Calendar event creation failed:', error);
            replyText = "I've got the event details, but I wasn't able to add it to your calendar just now. Please try again in a moment.";
          }
        } else {
          replyText = await aiService.complete([
            { role: 'system', content: SYSTEM_PROMPT },
            ...messages.map((m) => ({ role: m.role, content: m.content })),
            { role: 'user', content: trimmed }
          ]);
        }

        const assistantMessage = createMessage('assistant', replyText);
        setMessages((prev) => [...prev, assistantMessage]);
        onAssistantReply(replyText);
      } catch (error) {
        // Keep the real error in the console for debugging, but never show
        // raw error text (URLs, status codes, stack traces) to the user.
        console.error('Chat request failed:', error);
        const errorText = "Sorry, I couldn't process that request. Please try again in a moment.";
        const assistantMessage = createMessage('assistant', errorText);
        setMessages((prev) => [...prev, assistantMessage]);
        onAssistantReply(errorText);
      } finally {
        setIsProcessing(false);
      }
    },
    [aiService, calendarService, isProcessing, messages, onAssistantReply]
  );

  return { messages, isProcessing, sendMessage };
}