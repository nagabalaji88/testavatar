import { useEffect, useMemo, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Sparkles,
  LogOut,
  User,
  Radio,
  X
} from 'lucide-react';
import { AvatarScene } from './components/avatar/AvatarScene';
import { ChatPanel } from './components/chat/ChatPanel';
import { CalendarPreviewPanel } from './components/calendar/CalendarPreviewPanel';
import { LoginScreen } from './components/auth/LoginScreen';
import { GlassCard } from './components/ui/GlassCard';
import { useAuth } from './hooks/useAuth';
import { useChat } from './hooks/useChat';
import { useSpeechRecognition } from './hooks/useSpeechRecognition';
import { useSpeechSynthesis } from './hooks/useSpeechSynthesis';
import { getAiService } from './services/aiService';
import { getCalendarService } from './services/calendarService';
import { useTheme } from './hooks/useTheme';
import { ThemeSelector } from './components/ui/ThemeSelector';
import type { AvatarState } from './types/avatar';

export default function App() {
  const auth = useAuth();
  const modelUrl = import.meta.env.VITE_AVATAR_MODEL_URL || '/avatar.glb';

  if (!auth.user) {
    return <LoginScreen modelUrl={modelUrl} onSignIn={auth.signIn} onRegister={auth.register} />;
  }

  return (
    <ChatExperience modelUrl={modelUrl} userName={auth.user.name} onSignOut={auth.signOut} />
  );
}

interface ChatExperienceProps {
  modelUrl: string;
  userName: string;
  onSignOut: () => void;
}

function ChatExperience({ modelUrl, userName, onSignOut }: ChatExperienceProps) {
  const { theme, setTheme } = useTheme();
  const [inputValue, setInputValue] = useState('');
  const [isAvatarVisible, setIsAvatarVisible] = useState(true);
  const [isCalendarVisible] = useState(true);

  const aiService = useMemo(() => getAiService(), []);
  const calendarService = useMemo(() => getCalendarService(), []);
  const synthesis = useSpeechSynthesis();

  const hasGreeted = useRef(false);

  const { messages, isProcessing, sendMessage } = useChat(
    aiService,
    calendarService,
    (text) => {
      synthesis.speak(text);
    }
  );

  const recognition = useSpeechRecognition((finalText) => {
    if (finalText) {
      sendMessage(finalText);
    }
    setInputValue('');
  });

  // Greeting on mount
  useEffect(() => {
    if (hasGreeted.current) return;
    hasGreeted.current = true;
    synthesis.speak(`Hello ${userName}, how can I assist you with your schedule today?`);
  }, [synthesis, userName]);

  // Avatar State Sync
  const avatarState: AvatarState = recognition.isListening
    ? 'listening'
    : isProcessing
      ? 'thinking'
      : synthesis.isSpeaking
        ? 'speaking'
        : 'idle';

  // Interaction Handlers
  const handleToggleMic = () => {
    if (recognition.isListening) {
      recognition.stopListening();
    } else {
      synthesis.cancel();
      recognition.startListening();
    }
  };

  const handleSubmit = (text: string) => {
    setInputValue('');
    sendMessage(text);
  };

  const handleStopSpeaking = () => {
    synthesis.cancel();
  };

  return (
    <div className="relative flex h-screen w-screen flex-col bg-vision-bg overflow-hidden text-vision-text font-sans">
      {/* Spatial Ambient Glows */}
      <div className="pointer-events-none absolute -top-40 -left-40 h-[600px] w-[600px] rounded-full bg-cyan-500/10 blur-[140px]" />
      <div className="pointer-events-none absolute top-1/3 -right-40 h-[600px] w-[600px] rounded-full bg-purple-500/10 blur-[140px]" />
      <div className="pointer-events-none absolute -bottom-40 left-1/3 h-[600px] w-[600px] rounded-full bg-teal-500/10 blur-[140px]" />

      {/* Top Header Bar */}
      <header className="relative z-20 flex h-16 shrink-0 items-center justify-between border-b border-white/10 px-6 backdrop-blur-xl bg-black/30">
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-2xl border border-cyan-500/30 bg-gradient-to-br from-cyan-500/20 to-purple-500/20 text-cyan-300 shadow-glow">
            <Sparkles className="h-5 w-5" />
          </div>
          <div>
            <h1 className="text-sm font-bold tracking-wider text-white">VISION PRO AI</h1>
            <p className="text-[10px] font-mono text-cyan-400">SPATIAL COMPANION v2.0</p>
          </div>
        </div>

        {/* Header Status & User Controls */}
        <div className="flex items-center gap-4">
          <ThemeSelector currentTheme={theme} onSelectTheme={setTheme} />

          <div className="hidden sm:flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs">
            <span className="relative flex h-2 w-2">
              <span className={`absolute inline-flex h-full w-full animate-ping rounded-full opacity-75 ${recognition.isListening ? 'bg-cyan-400' : 'bg-teal-400'}`} />
              <span className={`relative inline-flex h-2 w-2 rounded-full ${recognition.isListening ? 'bg-cyan-500' : 'bg-teal-500'}`} />
            </span>
            <span className="text-vision-muted">
              {recognition.isListening ? 'Listening...' : 'Voice Engine Ready'}
            </span>
          </div>

          <div className="flex items-center gap-2 border-l border-white/10 pl-4">
            <div className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-3 py-1.5 text-xs text-white">
              <User className="h-3.5 w-3.5 text-purple-400" />
              <span className="font-medium">{userName}</span>
            </div>

            <button
              onClick={onSignOut}
              title="Sign Out"
              className="flex h-8 w-8 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-vision-muted transition-all hover:border-rose-500/40 hover:bg-rose-500/10 hover:text-rose-300"
            >
              <LogOut className="h-4 w-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Bento Grid Layout */}
      <main className="relative z-10 flex flex-1 min-h-0 p-4 lg:p-6 gap-4 lg:gap-6 overflow-hidden">
        {/* Left Column - Floating 3D Avatar Card */}
        <AnimatePresence mode="popLayout">
          {isAvatarVisible && (
            <motion.section
              key="avatar-panel"
              initial={{ opacity: 0, x: -30, scale: 0.95 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              exit={{ opacity: 0, x: -30, scale: 0.95 }}
              transition={{ duration: 0.35, ease: 'easeOut' }}
              className="relative flex h-full w-full lg:w-[340px] xl:w-[380px] shrink-0 flex-col"
            >
              <GlassCard glowColor="cyan" className="relative flex h-full flex-col overflow-hidden">
                {/* Panel Header */}
                <div className="absolute top-4 left-4 right-4 z-30 flex items-center justify-between">
                  <div className="flex items-center gap-2 rounded-full border border-white/15 bg-black/40 px-3 py-1 text-[11px] backdrop-blur-md">
                    <Radio className="h-3 w-3 text-cyan-400 animate-pulse" />
                    <span className="font-semibold text-white">Avatar Companion</span>
                  </div>

                  <button
                    onClick={() => setIsAvatarVisible(false)}
                    title="Hide Avatar Card"
                    className="flex h-7 w-7 items-center justify-center rounded-full border border-white/15 bg-black/40 text-vision-muted backdrop-blur-md transition-all hover:border-rose-500/40 hover:bg-rose-500/20 hover:text-white"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                </div>

                {/* 3D Canvas Scene */}
                <div className="flex-1 w-full h-full">
                  <AvatarScene modelUrl={modelUrl} state={avatarState} visemeIntensity={synthesis.visemeIntensity} />
                </div>
              </GlassCard>
            </motion.section>
          )}
        </AnimatePresence>

        {/* Center Column - AI Copilot Chat Experience */}
        <section className="relative flex min-h-0 flex-1 flex-col">
          <ChatPanel
            messages={messages}
            isProcessing={isProcessing}
            inputValue={recognition.isListening ? recognition.transcript : inputValue}
            onInputChange={setInputValue}
            onSubmit={handleSubmit}
            isListening={recognition.isListening}
            isMicSupported={recognition.isSupported}
            onToggleMic={handleToggleMic}
            isSpeaking={synthesis.isSpeaking}
            onStopSpeaking={handleStopSpeaking}
            isAvatarVisible={isAvatarVisible}
            onShowAvatar={() => setIsAvatarVisible(true)}
          />
        </section>

        {/* Right Column - Calendar Preview Panel */}
        <AnimatePresence mode="popLayout">
          {isCalendarVisible && (
            <motion.section
              key="calendar-panel"
              initial={{ opacity: 0, x: 30, scale: 0.95 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              exit={{ opacity: 0, x: 30, scale: 0.95 }}
              transition={{ duration: 0.35, ease: 'easeOut' }}
              className="hidden xl:flex h-full w-[320px] shrink-0 flex-col"
            >
              <CalendarPreviewPanel onQuickSchedule={handleSubmit} />
            </motion.section>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}
