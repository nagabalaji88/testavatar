export type ThemeId =
  | 'vision'
  | 'nordic'
  | 'cyberpunk'
  | 'sunset'
  | 'matrix'
  | 'luxury';

export interface ThemeConfig {
  id: ThemeId;
  name: string;
  category: 'Dark' | 'Light' | 'Vibrant' | 'Warm';
  description: string;
  previewColors: [string, string, string];
}

export const THEMES: Record<ThemeId, ThemeConfig> = {
  vision: {
    id: 'vision',
    name: 'Vision Pro Glass',
    category: 'Dark',
    description: 'Spatial navy with cyan & purple glass highlights',
    previewColors: ['#070A12', '#06B6D4', '#A855F7']
  },
  nordic: {
    id: 'nordic',
    name: 'Nordic Snow (Light)',
    category: 'Light',
    description: 'Crisp bright white canvas with arctic blue & slate text',
    previewColors: ['#F8FAFC', '#0284C7', '#0F172A']
  },
  cyberpunk: {
    id: 'cyberpunk',
    name: 'Cyberpunk Neon',
    category: 'Vibrant',
    description: 'Obsidian dark with hot pink, electric blue & gold',
    previewColors: ['#0B0813', '#F43F5E', '#3B82F6']
  },
  sunset: {
    id: 'sunset',
    name: 'Sunset Horizon',
    category: 'Warm',
    description: 'Deep purple twilight with warm coral pink & amber glow',
    previewColors: ['#1A0B2E', '#FF6B6B', '#F59E0B']
  },
  matrix: {
    id: 'matrix',
    name: 'Emerald Matrix',
    category: 'Vibrant',
    description: 'Biotech dark canvas with electric emerald & neon mint',
    previewColors: ['#03100D', '#10B981', '#34D399']
  },
  luxury: {
    id: 'luxury',
    name: 'Royal Gold & Slate',
    category: 'Dark',
    description: 'Graphite slate with warm metallic gold & platinum',
    previewColors: ['#121620', '#EAB308', '#E2E8F0']
  }
};
