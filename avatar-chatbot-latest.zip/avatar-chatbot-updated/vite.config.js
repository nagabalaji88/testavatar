var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import https from 'node:https';
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
var customHttpsAgent = new https.Agent({
    rejectUnauthorized: false,
});
function liveAvatarProxyPlugin() {
    return {
        name: 'liveavatar-proxy',
        configureServer: function (server) {
            // Return a function so our custom proxy middleware runs FIRST before Vite's default handlers
            return function () {
                server.middlewares.use('/api/heygen', function (req, res) {
                    var targetPath = req.url || '';
                    var targetUrl = "https://api.liveavatar.com".concat(targetPath);
                    var reqHeaders = {};
                    for (var _i = 0, _a = Object.entries(req.headers); _i < _a.length; _i++) {
                        var _b = _a[_i], key = _b[0], value = _b[1];
                        if (value && key !== 'host') {
                            reqHeaders[key] = Array.isArray(value) ? value.join(', ') : value;
                        }
                    }
                    var proxyReq = https.request(targetUrl, {
                        method: req.method,
                        headers: __assign(__assign({}, reqHeaders), { host: 'api.liveavatar.com' }),
                        agent: customHttpsAgent,
                        rejectUnauthorized: false,
                    }, function (proxyRes) {
                        res.statusCode = proxyRes.statusCode || 500;
                        for (var _i = 0, _a = Object.entries(proxyRes.headers); _i < _a.length; _i++) {
                            var _b = _a[_i], key = _b[0], value = _b[1];
                            if (value) {
                                res.setHeader(key, value);
                            }
                        }
                        proxyRes.pipe(res);
                    });
                    proxyReq.on('error', function (err) {
                        console.error('[LiveAvatar Proxy Error]:', err.message);
                        res.statusCode = 500;
                        res.setHeader('content-type', 'application/json');
                        res.end(JSON.stringify({ error: err.message }));
                    });
                    req.pipe(proxyReq);
                });
            };
        },
    };
}
export default defineConfig({
    plugins: [react(), liveAvatarProxyPlugin()],
    server: {
        port: 5173,
    },
});
