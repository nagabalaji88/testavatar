/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        signal: {
          bg: '#F8FAFC',
          panel: '#FFFFFF',
          line: '#E2E8F0',
          text: '#0F172A',
          muted: '#64748B',
          indigo: '#4F46E5',
          teal: '#0D9488',
          amber: '#D97706',
          rose: '#E11D48'
        }
      },
      fontFamily: {
        display: ['"Space Grotesk"', 'sans-serif'],
        body: ['"Inter"', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'monospace']
      },
      boxShadow: {
        ring: '0 0 0 1px rgba(79,70,229,0.25), 0 10px 30px -5px rgba(79,70,229,0.15)'
      },
      keyframes: {
        pulseRing: {
          '0%, 100%': { transform: 'scale(1)', opacity: '0.6' },
          '50%': { transform: 'scale(1.05)', opacity: '1' }
        }
      },
      animation: {
        pulseRing: 'pulseRing 2.2s ease-in-out infinite'
      }
    }
  },
  plugins: []
};
