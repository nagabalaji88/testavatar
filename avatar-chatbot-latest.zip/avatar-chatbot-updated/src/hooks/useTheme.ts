import { useState, useEffect } from 'react';
import { ThemeId, THEMES } from '../types/theme';

const STORAGE_KEY = 'avatar-chatbot-theme';

export function useTheme() {
  const [theme, setTheme] = useState<ThemeId>(() => {
    const saved = localStorage.getItem(STORAGE_KEY) as ThemeId;
    return saved && THEMES[saved] ? saved : 'vision';
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, theme);
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  return {
    theme,
    setTheme,
    themeConfig: THEMES[theme],
    allThemes: Object.values(THEMES)
  };
}
