import { useCallback, useState } from 'react';
import type { AuthUser } from '../types/auth';

export interface UseAuthResult {
  user: AuthUser | null;
  isAuthenticated: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string) => Promise<void>;
  signOut: () => void;
}

function mockDelay(ms = 500): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Client-only mock authentication for this proof of concept. There is no
 * backend, database, or credential verification: any well-formed submission
 * succeeds. Swap this out for a real auth provider when integrating with a
 * backend; the LoginScreen component only depends on this hook's shape.
 */
export function useAuth(): UseAuthResult {
  const [user, setUser] = useState<AuthUser | null>(null);

  const signIn = useCallback(async (email: string, _password: string) => {
    await mockDelay();
    setUser({ name: email.split('@')[0], email });
  }, []);

  const register = useCallback(async (name: string, email: string, _password: string) => {
    await mockDelay();
    setUser({ name, email });
  }, []);

  const signOut = useCallback(() => setUser(null), []);

  return { user, isAuthenticated: user !== null, signIn, register, signOut };
}
