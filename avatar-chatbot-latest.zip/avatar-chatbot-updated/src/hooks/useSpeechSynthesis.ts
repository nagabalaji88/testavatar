import { useCallback, useEffect, useRef, useState } from 'react';

export interface UseSpeechSynthesisResult {
  isSupported: boolean;
  isSpeaking: boolean;
  /** 0-1 mouth-openness target, updated on each word boundary while speaking. */
  visemeIntensity: number;
  speak: (text: string, onDone?: () => void) => void;
  cancel: () => void;
}

/**
 * Wraps the browser SpeechSynthesis API. The Web Speech API does not expose
 * audio amplitude, so lip-sync is approximated: each word-boundary event
 * pulses the mouth open, then eases back toward closed until the next word.
 */
export function useSpeechSynthesis(): UseSpeechSynthesisResult {
  const isSupported = typeof window !== 'undefined' && 'speechSynthesis' in window;
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [visemeIntensity, setVisemeIntensity] = useState(0);
  const decayRef = useRef<number | null>(null);

  const clearDecay = useCallback(() => {
    if (decayRef.current !== null) {
      window.clearInterval(decayRef.current);
      decayRef.current = null;
    }
  }, []);

  useEffect(() => clearDecay, [clearDecay]);

  const speak = useCallback(
    (text: string, onDone?: () => void) => {
      if (!isSupported) {
        onDone?.();
        return;
      }

      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1;
      utterance.pitch = 1;

      utterance.onstart = () => {
        setIsSpeaking(true);
      };

      utterance.onboundary = (event) => {
        if (event.name !== 'word') return;
        setVisemeIntensity(0.6 + Math.random() * 0.4);

        clearDecay();
        decayRef.current = window.setInterval(() => {
          setVisemeIntensity((current) => {
            const next = current - 0.15;
            if (next <= 0) {
              clearDecay();
              return 0;
            }
            return next;
          });
        }, 40);
      };

      utterance.onend = () => {
        clearDecay();
        setVisemeIntensity(0);
        setIsSpeaking(false);
        onDone?.();
      };

      utterance.onerror = () => {
        clearDecay();
        setVisemeIntensity(0);
        setIsSpeaking(false);
        onDone?.();
      };

      window.speechSynthesis.speak(utterance);
    },
    [clearDecay, isSupported]
  );

  const cancel = useCallback(() => {
    if (!isSupported) return;
    window.speechSynthesis.cancel();
    clearDecay();
    setVisemeIntensity(0);
    setIsSpeaking(false);
  }, [clearDecay, isSupported]);

  return { isSupported, isSpeaking, visemeIntensity, speak, cancel };
}
