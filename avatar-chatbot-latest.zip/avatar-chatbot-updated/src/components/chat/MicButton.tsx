interface MicButtonProps {
  isListening: boolean;
  isSupported: boolean;
  onToggle: () => void;
}

export function MicButton({ isListening, isSupported, onToggle }: MicButtonProps) {
  return (
    <button
      type="button"
      onClick={onToggle}
      disabled={!isSupported}
      aria-pressed={isListening}
      aria-label={isListening ? 'Stop listening' : 'Start listening'}
      title={isSupported ? 'Toggle voice input' : 'Voice input is not supported in this browser'}
      className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-full border transition-colors ${
        isListening
          ? 'border-signal-teal bg-signal-teal/15 text-signal-teal'
          : 'border-signal-line bg-signal-panel text-signal-muted hover:text-signal-text'
      } disabled:cursor-not-allowed disabled:opacity-40`}
    >
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z" />
        <path d="M19 10v2a7 7 0 0 1-14 0v-2" strokeLinecap="round" />
        <line x1="12" y1="19" x2="12" y2="23" strokeLinecap="round" />
        <line x1="8" y1="23" x2="16" y2="23" strokeLinecap="round" />
      </svg>
    </button>
  );
}
