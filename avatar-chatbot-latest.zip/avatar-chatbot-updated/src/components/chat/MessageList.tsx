import { useEffect, useRef } from 'react';
import type { ChatMessage } from '../../types/chat';
import { MessageBubble } from './MessageBubble';

interface MessageListProps {
  messages: ChatMessage[];
  isProcessing: boolean;
}

export function MessageList({ messages, isProcessing }: MessageListProps) {
  const bottomRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
  }, [messages, isProcessing]);

  if (messages.length === 0 && !isProcessing) {
    return (
      <div className="flex h-full flex-col items-center justify-center gap-2 text-center">
        <p className="font-display text-lg text-signal-text">Say or type something to begin</p>
        <p className="max-w-xs text-sm text-signal-muted">
          Try: "Schedule a meeting with John tomorrow at 3 PM for one hour."
        </p>
      </div>
    );
  }

  return (
    <div className="flex h-full flex-col gap-4 overflow-y-auto pr-1">
      {messages.map((message) => (
        <MessageBubble key={message.id} message={message} />
      ))}
      {isProcessing && (
        <div className="flex justify-start">
          <div className="flex items-center gap-1.5 rounded-2xl rounded-bl-sm border border-signal-line bg-signal-panel px-4 py-3">
            <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-signal-muted [animation-delay:-0.2s]" />
            <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-signal-muted [animation-delay:-0.1s]" />
            <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-signal-muted" />
          </div>
        </div>
      )}
      <div ref={bottomRef} />
    </div>
  );
}
