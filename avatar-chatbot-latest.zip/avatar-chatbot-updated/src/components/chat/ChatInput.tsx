import type { FormEvent } from 'react';
import { MicButton } from './MicButton';

interface ChatInputProps {
  value: string;
  onChange: (value: string) => void;
  onSubmit: (text: string) => void;
  disabled: boolean;
  isListening: boolean;
  isMicSupported: boolean;
  onToggleMic: () => void;
  /** Whether the avatar is currently speaking. Shows the stop button when true. */
  isSpeaking?: boolean;
  /** Called when the user clicks the stop-speaking button. */
  onStopSpeaking?: () => void;
}

export function ChatInput({
  value,
  onChange,
  onSubmit,
  disabled,
  isListening,
  isMicSupported,
  onToggleMic,
  isSpeaking = false,
  onStopSpeaking,
}: ChatInputProps) {
  const handleSubmit = (event: FormEvent) => {
    event.preventDefault();
    const text = value.trim();
    if (!text || disabled) return;
    onSubmit(text);
    onChange('');
  };

  return (
    <form onSubmit={handleSubmit} className="flex items-center gap-2 border-t border-signal-line p-4">
      <MicButton isListening={isListening} isSupported={isMicSupported} onToggle={onToggleMic} />

      <input
        type="text"
        value={value}
        onChange={(event) => onChange(event.target.value)}
        placeholder={isListening ? 'Listening…' : 'Type a message'}
        disabled={disabled}
        className="flex-1 rounded-full border border-signal-line bg-signal-panel px-4 py-2.5 text-sm text-signal-text placeholder:text-signal-muted focus:border-signal-indigo focus:outline-none disabled:opacity-50"
      />

      {/* ── Stop speaking button — only visible while avatar is speaking ── */}
      <button
        id="stop-avatar-speaking-btn"
        type="button"
        onClick={onStopSpeaking}
        aria-label="Stop avatar speaking"
        style={{
          // Animate in/out with width + opacity to avoid layout jump
          width: isSpeaking ? '2.75rem' : '0',
          opacity: isSpeaking ? 1 : 0,
          marginLeft: isSpeaking ? undefined : '0',
          pointerEvents: isSpeaking ? 'auto' : 'none',
          overflow: 'hidden',
          transition: 'width 0.25s ease, opacity 0.2s ease',
        }}
        className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-signal-rose/90 text-white hover:bg-signal-rose"
        tabIndex={isSpeaking ? 0 : -1}
      >
        {/* Square stop icon */}
        <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
          <rect x="4" y="4" width="16" height="16" rx="2" />
        </svg>
      </button>

      {/* ── Send button ────────────────────────────────────────────────── */}
      <button
        type="submit"
        disabled={disabled || !value.trim()}
        className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-signal-indigo text-white transition-opacity hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-30"
        aria-label="Send message"
      >
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <line x1="22" y1="2" x2="11" y2="13" strokeLinecap="round" strokeLinejoin="round" />
          <polygon points="22 2 15 22 11 13 2 9 22 2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </button>
    </form>
  );
}
