import type { ChatMessage } from '../../types/chat';
import { MessageList } from './MessageList';
import { ChatInput } from './ChatInput';

interface ChatPanelProps {
  messages: ChatMessage[];
  isProcessing: boolean;
  inputValue: string;
  onInputChange: (value: string) => void;
  onSubmit: (text: string) => void;
  isListening: boolean;
  isMicSupported: boolean;
  onToggleMic: () => void;
  /** Whether the avatar is currently speaking — surfaces the stop button. */
  isSpeaking?: boolean;
  /** Called when the user clicks the stop-speaking button. */
  onStopSpeaking?: () => void;
}

export function ChatPanel({
  messages,
  isProcessing,
  inputValue,
  onInputChange,
  onSubmit,
  isListening,
  isMicSupported,
  onToggleMic,
  isSpeaking = false,
  onStopSpeaking,
}: ChatPanelProps) {
  return (
    <div className="flex h-full flex-col rounded-2xl border border-signal-line bg-signal-bg/60">
      <div className="flex-1 overflow-hidden p-4">
        <MessageList messages={messages} isProcessing={isProcessing} />
      </div>
      <ChatInput
        value={inputValue}
        onChange={onInputChange}
        onSubmit={onSubmit}
        disabled={isProcessing}
        isListening={isListening}
        isMicSupported={isMicSupported}
        onToggleMic={onToggleMic}
        isSpeaking={isSpeaking}
        onStopSpeaking={onStopSpeaking}
      />
    </div>
  );
}
