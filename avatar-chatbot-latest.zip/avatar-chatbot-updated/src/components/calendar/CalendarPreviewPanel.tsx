import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Calendar as CalendarIcon,
  Clock,
  Plus,
  MapPin,
  Sparkles,
  ChevronRight,
  CheckCircle2
} from 'lucide-react';
import { GlassCard } from '../ui/GlassCard';

interface CalendarPreviewPanelProps {
  onQuickSchedule?: (prompt: string) => void;
}

interface EventItem {
  id: string;
  title: string;
  time: string;
  duration: string;
  location?: string;
  category: 'ai' | 'work' | 'personal';
  isCompleted?: boolean;
}

export const CalendarPreviewPanel: React.FC<CalendarPreviewPanelProps> = ({ onQuickSchedule }) => {
  const [events, setEvents] = useState<EventItem[]>([
    {
      id: '1',
      title: 'AI Companion Daily Briefing',
      time: '09:00 AM',
      duration: '30m',
      location: 'Vision Pro Portal',
      category: 'ai'
    },
    {
      id: '2',
      title: 'Product Design Review',
      time: '11:30 AM',
      duration: '45m',
      location: 'Virtual Conference Room A',
      category: 'work'
    },
    {
      id: '3',
      title: 'Avatar Voice Model Fine-tuning',
      time: '02:00 PM',
      duration: '1h',
      location: 'Local Workstation',
      category: 'ai'
    },
    {
      id: '4',
      title: 'Team Sync & Wrap-up',
      time: '05:00 PM',
      duration: '30m',
      category: 'work'
    }
  ]);

  const [filter, setFilter] = useState<'all' | 'ai'>('all');

  const filteredEvents = filter === 'ai' ? events.filter((e) => e.category === 'ai') : events;

  const toggleEventComplete = (id: string) => {
    setEvents((prev) =>
      prev.map((item) => (item.id === id ? { ...item, isCompleted: !item.isCompleted } : item))
    );
  };

  const handleQuickAdd = () => {
    if (onQuickSchedule) {
      onQuickSchedule('Schedule a 30 minute review meeting tomorrow at 10 AM');
    }
  };

  const categoryBadges = {
    ai: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30',
    work: 'bg-purple-500/20 text-purple-300 border-purple-500/30',
    personal: 'bg-teal-500/20 text-teal-300 border-teal-500/30'
  };

  return (
    <GlassCard className="flex h-full flex-col p-5" glowColor="teal">
      {/* Header */}
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-teal-500/20 to-cyan-500/20 border border-teal-500/30 text-teal-400">
            <CalendarIcon className="h-4 w-4" />
          </div>
          <div>
            <h2 className="text-sm font-semibold tracking-wide text-white">Schedule Preview</h2>
            <p className="text-xs text-vision-muted">Today, {new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</p>
          </div>
        </div>

        <button
          onClick={handleQuickAdd}
          title="Quick Schedule via AI"
          className="flex h-8 w-8 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-vision-muted transition-all hover:border-teal-500/40 hover:bg-teal-500/10 hover:text-teal-300"
        >
          <Plus className="h-4 w-4" />
        </button>
      </div>

      {/* Sync Status Badge */}
      <div className="mb-4 flex items-center justify-between rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-xs">
        <div className="flex items-center gap-2 text-vision-muted">
          <span className="relative flex h-2 w-2">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-teal-400 opacity-75" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-teal-500" />
          </span>
          <span>Google Calendar</span>
        </div>
        <span className="font-mono text-[10px] text-teal-400">SYNCED</span>
      </div>

      {/* Filter Tabs */}
      <div className="mb-3 flex items-center gap-1.5 rounded-lg border border-white/10 bg-black/20 p-1 text-xs">
        <button
          onClick={() => setFilter('all')}
          className={`flex-1 rounded-md py-1 font-medium transition-all ${
            filter === 'all'
              ? 'bg-white/10 text-white shadow-sm'
              : 'text-vision-muted hover:text-white'
          }`}
        >
          All Tasks
        </button>
        <button
          onClick={() => setFilter('ai')}
          className={`flex-1 rounded-md py-1 font-medium transition-all ${
            filter === 'ai'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
              : 'text-vision-muted hover:text-white'
          }`}
        >
          AI Sessions
        </button>
      </div>

      {/* Events Timeline List */}
      <div className="flex-1 overflow-y-auto pr-1 space-y-2.5">
        <AnimatePresence mode="popLayout">
          {filteredEvents.map((event) => (
            <motion.div
              key={event.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.2 }}
              onClick={() => toggleEventComplete(event.id)}
              className={`group relative flex flex-col gap-1.5 rounded-2xl border p-3 transition-all cursor-pointer ${
                event.isCompleted
                  ? 'border-white/5 bg-white/2 opacity-50'
                  : 'border-white/10 bg-white/5 hover:border-teal-500/30 hover:bg-white/10'
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2">
                  <div className="mt-0.5 text-vision-muted group-hover:text-teal-400 transition-colors">
                    <CheckCircle2
                      className={`h-4 w-4 ${
                        event.isCompleted ? 'text-teal-400 fill-teal-500/20' : 'text-vision-muted'
                      }`}
                    />
                  </div>
                  <h3
                    className={`text-xs font-medium ${
                      event.isCompleted ? 'line-through text-vision-muted' : 'text-white'
                    }`}
                  >
                    {event.title}
                  </h3>
                </div>

                <span
                  className={`inline-flex items-center rounded-full border px-2 py-0.5 text-[10px] font-medium ${
                    categoryBadges[event.category]
                  }`}
                >
                  {event.category.toUpperCase()}
                </span>
              </div>

              <div className="flex items-center gap-3 pl-6 text-[11px] text-vision-muted">
                <div className="flex items-center gap-1">
                  <Clock className="h-3 w-3 text-cyan-400" />
                  <span>{event.time}</span>
                  <span className="opacity-50">({event.duration})</span>
                </div>

                {event.location && (
                  <div className="flex items-center gap-1 truncate max-w-[120px]">
                    <MapPin className="h-3 w-3 text-purple-400 shrink-0" />
                    <span className="truncate">{event.location}</span>
                  </div>
                )}
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Quick Action Suggestion Footer */}
      <div className="mt-4 pt-3 border-t border-white/10">
        <button
          onClick={() =>
            onQuickSchedule &&
            onQuickSchedule('What is on my calendar for the rest of today?')
          }
          className="flex w-full items-center justify-between rounded-xl border border-cyan-500/20 bg-gradient-to-r from-cyan-500/10 to-purple-500/10 px-3 py-2.5 text-xs text-cyan-300 transition-all hover:border-cyan-500/40 hover:from-cyan-500/20 hover:to-purple-500/20"
        >
          <div className="flex items-center gap-2">
            <Sparkles className="h-3.5 w-3.5 text-cyan-400" />
            <span>Ask Companion about schedule</span>
          </div>
          <ChevronRight className="h-3.5 w-3.5 opacity-70" />
        </button>
      </div>
    </GlassCard>
  );
};
