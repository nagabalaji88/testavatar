import React from 'react';
import { motion, HTMLMotionProps } from 'framer-motion';

interface GlassCardProps extends HTMLMotionProps<'div'> {
  children: React.ReactNode;
  className?: string;
  glowColor?: 'cyan' | 'purple' | 'teal' | 'none';
  interactive?: boolean;
}

export const GlassCard: React.FC<GlassCardProps> = ({
  children,
  className = '',
  glowColor = 'none',
  interactive = false,
  ...props
}) => {
  const glowStyles = {
    cyan: 'hover:shadow-[0_0_30px_-5px_rgba(6,182,212,0.3)] hover:border-cyan-500/40',
    purple: 'hover:shadow-[0_0_30px_-5px_rgba(168,85,247,0.3)] hover:border-purple-500/40',
    teal: 'hover:shadow-[0_0_30px_-5px_rgba(20,184,166,0.3)] hover:border-teal-500/40',
    none: ''
  };

  return (
    <motion.div
      whileHover={interactive ? { y: -2, scale: 1.005 } : undefined}
      whileTap={interactive ? { scale: 0.995 } : undefined}
      transition={{ duration: 0.2, ease: 'easeOut' }}
      className={`vision-glass-card relative overflow-hidden rounded-3xl ${glowStyles[glowColor]} ${className}`}
      {...props}
    >
      {/* Specular glass reflection line at top */}
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/30 to-transparent" />
      {/* Ambient background light highlight */}
      <div className="pointer-events-none absolute -left-20 -top-20 h-40 w-40 rounded-full bg-white/5 blur-3xl" />
      
      {children}
    </motion.div>
  );
};
