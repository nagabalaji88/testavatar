import { useEffect, useRef, useState, type FormEvent } from 'react';
import { AvatarScene } from '../avatar/AvatarScene';
import { useSpeechSynthesis } from '../../hooks/useSpeechSynthesis';
import type { AuthMode } from '../../types/auth';
import type { AvatarState } from '../../types/avatar';

interface LoginScreenProps {
  modelUrl: string;
  onSignIn: (email: string, password: string) => Promise<void>;
  onRegister: (name: string, email: string, password: string) => Promise<void>;
}

const GREETING = "Welcome! Please sign in, or register if you're new here.";

export function LoginScreen({ modelUrl, onSignIn, onRegister }: LoginScreenProps) {
  const [mode, setMode] = useState<AuthMode>('sign-in');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const synthesis = useSpeechSynthesis();
  const hasGreeted = useRef(false);

  // Greet on mount via SpeechSynthesis
  useEffect(() => {
    if (hasGreeted.current) return;
    hasGreeted.current = true;
    synthesis.speak(GREETING);
  }, [synthesis]);

  // Avatar state drives ring colour + label
  const avatarState: AvatarState = isSubmitting
    ? 'thinking'
    : synthesis.isSpeaking
      ? 'speaking'
      : 'idle';

  const handleSubmit = async (event: FormEvent) => {
    event.preventDefault();
    setError(null);

    if (mode === 'register' && !name.trim()) {
      setError('Please enter your name.');
      return;
    }
    if (!email.trim() || !password.trim()) {
      setError('Please enter your email and password.');
      return;
    }

    setIsSubmitting(true);
    try {
      if (mode === 'register') {
        await onRegister(name.trim(), email.trim(), password);
      } else {
        await onSignIn(email.trim(), password);
      }
    } catch {
      setError('Something went wrong. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const switchMode = (nextMode: AuthMode) => {
    setMode(nextMode);
    setError(null);
  };

  return (
    <div className="flex h-screen flex-col items-center justify-center bg-signal-bg p-4 lg:flex-row lg:gap-8 lg:p-8">
      {/* ── Interactive 3D Avatar Companion Card (synced size with App) ───── */}
      <section className="relative h-[180px] w-full shrink-0 overflow-hidden rounded-2xl border border-slate-200 bg-white/80 backdrop-blur-xl shadow-xl sm:h-[200px] sm:max-w-xs lg:h-[360px] lg:w-[280px] xl:w-[300px] lg:rounded-3xl">
        <AvatarScene modelUrl={modelUrl} state={avatarState} visemeIntensity={synthesis.visemeIntensity} />
      </section>

      {/* ── Login / register form (right) ───────────────────────────── */}
      <section className="flex min-h-0 w-full flex-1 items-center justify-center p-2 sm:max-w-sm lg:w-auto lg:p-0">
        <div className="w-full max-w-sm rounded-2xl border border-signal-line bg-signal-panel p-6 shadow-2xl">
          <p className="mb-6 text-center text-sm text-signal-muted">{GREETING}</p>

          <div className="mb-6 flex rounded-full border border-signal-line bg-signal-bg p-1">
            <button
              type="button"
              onClick={() => switchMode('sign-in')}
              className={`flex-1 rounded-full py-1.5 text-sm transition-colors ${
                mode === 'sign-in' ? 'bg-signal-indigo text-white' : 'text-signal-muted hover:text-signal-text'
              }`}
            >
              Sign in
            </button>
            <button
              type="button"
              onClick={() => switchMode('register')}
              className={`flex-1 rounded-full py-1.5 text-sm transition-colors ${
                mode === 'register' ? 'bg-signal-indigo text-white' : 'text-signal-muted hover:text-signal-text'
              }`}
            >
              Register
            </button>
          </div>

          <form onSubmit={handleSubmit} className="flex flex-col gap-3">
            {mode === 'register' && (
              <label className="flex flex-col gap-1 text-xs text-signal-muted">
                Name
                <input
                  type="text"
                  value={name}
                  onChange={(event) => setName(event.target.value)}
                  className="rounded-lg border border-signal-line bg-signal-bg px-3 py-2 text-sm text-signal-text focus:border-signal-indigo focus:outline-none"
                  autoComplete="name"
                />
              </label>
            )}

            <label className="flex flex-col gap-1 text-xs text-signal-muted">
              Email
              <input
                type="email"
                value={email}
                onChange={(event) => setEmail(event.target.value)}
                className="rounded-lg border border-signal-line bg-signal-bg px-3 py-2 text-sm text-signal-text focus:border-signal-indigo focus:outline-none"
                autoComplete="email"
              />
            </label>

            <label className="flex flex-col gap-1 text-xs text-signal-muted">
              Password
              <input
                type="password"
                value={password}
                onChange={(event) => setPassword(event.target.value)}
                className="rounded-lg border border-signal-line bg-signal-bg px-3 py-2 text-sm text-signal-text focus:border-signal-indigo focus:outline-none"
                autoComplete={mode === 'register' ? 'new-password' : 'current-password'}
              />
            </label>

            {error && <p className="text-xs text-signal-rose">{error}</p>}

            <button
              type="submit"
              disabled={isSubmitting}
              className="mt-2 rounded-full bg-signal-indigo py-2.5 text-sm font-medium text-white transition-opacity hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-50"
            >
              {isSubmitting ? 'Please wait…' : mode === 'register' ? 'Create account' : 'Sign in'}
            </button>
          </form>
        </div>
      </section>
    </div>
  );
}
