import { Component, type ReactNode } from 'react';

interface AvatarErrorBoundaryProps {
  fallback: ReactNode;
  children: ReactNode;
}

interface AvatarErrorBoundaryState {
  hasError: boolean;
}

/**
 * Catches avatar GLB load failures (missing file, bad URL, unreachable
 * host, network error) so a broken model URL degrades to a placeholder
 * avatar instead of crashing the app.
 */
export class AvatarErrorBoundary extends Component<AvatarErrorBoundaryProps, AvatarErrorBoundaryState> {
  state: AvatarErrorBoundaryState = { hasError: false };

  static getDerivedStateFromError(): AvatarErrorBoundaryState {
    return { hasError: true };
  }

  componentDidCatch(error: unknown) {
    console.warn('Avatar model failed to load; falling back to the placeholder avatar.', error);
  }

  render() {
    return this.state.hasError ? this.props.fallback : this.props.children;
  }
}
