import { Canvas } from '@react-three/fiber';
import { ChatbotAvatar } from './ChatbotAvatar';
import type { AvatarState } from '../../types/avatar';

interface AvatarSceneProps {
  /** Unused now that the avatar is a procedural chatbot; kept for prop compatibility. */
  modelUrl?: string;
  state: AvatarState;
  visemeIntensity: number;
}

const STATE_LABEL: Record<AvatarState, string> = {
  idle: 'Idle',
  listening: 'Listening',
  thinking: 'Thinking',
  speaking: 'Speaking'
};

export function AvatarScene({ state, visemeIntensity }: AvatarSceneProps) {
  return (
    <div className="relative flex h-full w-full items-center justify-center">
      <Canvas camera={{ position: [0, 0, 2.3], fov: 32 }} className="relative z-10">
        <ambientLight intensity={0.8} />
        <directionalLight position={[2, 3, 4]} intensity={1.2} />
        <directionalLight position={[-2, 1, -3]} intensity={0.5} />
        <ChatbotAvatar state={state} visemeIntensity={visemeIntensity} />
      </Canvas>
      <div className="pointer-events-none absolute bottom-2.5 left-1/2 z-20 -translate-x-1/2 rounded-full border border-slate-200 bg-white/90 px-3 py-1 font-mono text-[10px] font-medium uppercase tracking-[0.15em] text-slate-600 shadow-sm backdrop-blur">
        {STATE_LABEL[state]}
      </div>
    </div>
  );
}
