import { UserCheck } from 'lucide-react';

interface ShowAvatarButtonProps {
  onShow: () => void;
}

export function ShowAvatarButton({ onShow }: ShowAvatarButtonProps) {
  return (
    <button
      id="show-avatar-fab"
      type="button"
      onClick={onShow}
      aria-label="Show avatar"
      title="Show 3D Avatar Card"
      className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl border border-cyan-500/30 bg-cyan-500/10 text-cyan-300 transition-all hover:border-cyan-400 hover:bg-cyan-500/20 hover:shadow-[0_0_15px_rgba(6,182,212,0.3)]"
    >
      <UserCheck className="h-5 w-5" />
    </button>
  );
}
