interface FloatingAvatarButtonProps {
  /** Called when the user clicks to restore the avatar panel. */
  onShow: () => void;
}

/**
 * A floating action button rendered in the chat area when the avatar panel
 * is hidden. Clicking it restores the avatar panel to view.
 */
export function FloatingAvatarButton({ onShow }: FloatingAvatarButtonProps) {
  return (
    <div className="pointer-events-none absolute bottom-20 left-4 z-40 flex items-end lg:bottom-6 lg:left-6">
      <button
        id="show-avatar-fab"
        type="button"
        onClick={onShow}
        aria-label="Show avatar"
        className="pointer-events-auto group flex items-center gap-2.5 rounded-full border border-slate-200 bg-white/90 py-2.5 pl-3 pr-4 shadow-lg backdrop-blur transition-all duration-300 hover:border-signal-indigo hover:bg-white"
      >
        {/* Avatar icon */}
        <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-signal-indigo/20 transition-colors group-hover:bg-signal-indigo/30">
          <svg
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.8"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="text-signal-indigo"
          >
            <circle cx="12" cy="8" r="4" />
            <path d="M4 20c0-4 3.6-7 8-7s8 3 8 7" />
          </svg>
        </span>

        <span className="flex flex-col leading-tight">
          <span className="font-display text-xs font-medium text-signal-text">Show Avatar</span>
          <span className="font-mono text-[10px] text-signal-muted">3D Interactive</span>
        </span>

        {/* Pulse indicator */}
        <span className="relative ml-1 flex h-2 w-2 shrink-0">
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-signal-indigo opacity-50" />
          <span className="relative inline-flex h-2 w-2 rounded-full bg-signal-indigo" />
        </span>
      </button>
    </div>
  );
}
