import { useRef, useState } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { RoundedBox } from '@react-three/drei';
import * as THREE from 'three';
import type { AvatarState } from '../../types/avatar';

interface ChatbotAvatarProps {
  state: AvatarState;
  visemeIntensity: number;
}

const BAR_COUNT = 5;

/**
 * Procedural robot / chatbot-styled avatar (replaces the human GLB avatar).
 *
 * Features:
 *  - Rounded-box "smart display" head with a glowing visor face plate.
 *  - LED ring eyes that blink and track the cursor.
 *  - Equalizer-style mouth bars that react to live speech viseme intensity.
 *  - Top antenna with a pulsing signal light.
 *  - Chest core light that shifts color per conversation state.
 *  - Click reaction: a friendly head bounce/nod.
 */
export function ChatbotAvatar({ state, visemeIntensity }: ChatbotAvatarProps) {
  const groupRef = useRef<THREE.Group>(null);
  const headRef = useRef<THREE.Group>(null);
  const antennaTipRef = useRef<THREE.Mesh>(null);
  const antennaTipMatRef = useRef<THREE.MeshStandardMaterial>(null);
  const leftEyeRef = useRef<THREE.Group>(null);
  const rightEyeRef = useRef<THREE.Group>(null);
  const leftPupilRef = useRef<THREE.Mesh>(null);
  const rightPupilRef = useRef<THREE.Mesh>(null);
  const barRefs = useRef<(THREE.Mesh | null)[]>([]);
  const chestGlowRef = useRef<THREE.MeshStandardMaterial>(null);
  const visorGlowRef = useRef<THREE.MeshStandardMaterial>(null);

  const [clickAnim, setClickAnim] = useState(0);

  const blinkTimerRef = useRef(0);
  const nextBlinkAtRef = useRef(2 + Math.random() * 3);
  const blinkProgressRef = useRef(0);

  const mousePos = useRef({ x: 0, y: 0 });
  const { viewport } = useThree();

  const handlePointerDown = () => setClickAnim(1.0);

  useFrame((frameState, delta) => {
    const t = frameState.clock.elapsedTime;

    let clickImpulse = 0;
    if (clickAnim > 0) {
      clickImpulse = Math.sin(clickAnim * Math.PI) * 0.15;
      setClickAnim((prev) => Math.max(0, prev - delta * 3));
    }

    // ── Pointer tracking ─────────────────────────────────────────────
    const pointer = frameState.pointer;
    mousePos.current.x = THREE.MathUtils.lerp(mousePos.current.x, pointer.x * (viewport.width / 2), 0.08);
    mousePos.current.y = THREE.MathUtils.lerp(mousePos.current.y, pointer.y * (viewport.height / 2), 0.08);

    const isListening = state === 'listening';
    const isThinking = state === 'thinking';
    const isSpeaking = state === 'speaking';

    // ── Head pose ────────────────────────────────────────────────────
    if (headRef.current) {
      const targetRotY = mousePos.current.x * 0.2;
      const targetRotX = -mousePos.current.y * 0.2 + (isThinking ? -0.1 : 0);

      const idleSwayY = Math.sin(t * 0.8) * 0.04;
      const idleSwayX = Math.sin(t * 1.1) * 0.025;
      const speakBounce = isSpeaking ? Math.sin(t * 12) * 0.025 * visemeIntensity : 0;

      headRef.current.rotation.y = THREE.MathUtils.lerp(headRef.current.rotation.y, targetRotY + idleSwayY, 0.1);
      headRef.current.rotation.x = THREE.MathUtils.lerp(
        headRef.current.rotation.x,
        targetRotX + idleSwayX + speakBounce + clickImpulse,
        0.1
      );
      headRef.current.position.y = Math.sin(t * 1.4) * 0.025 + speakBounce + clickImpulse * 0.5;
      headRef.current.rotation.z = THREE.MathUtils.lerp(
        headRef.current.rotation.z,
        isListening ? 0.06 : 0,
        0.1
      );
    }

    // ── Antenna: idle bob + faster pulse while active ───────────────
    if (antennaTipRef.current) {
      const bob = Math.sin(t * 2.2) * 0.02;
      antennaTipRef.current.position.y = 0.98 + bob;
      const pulseSpeed = isThinking ? 10 : isListening ? 6 : isSpeaking ? 8 : 2.5;
      const pulse = 0.6 + Math.abs(Math.sin(t * pulseSpeed)) * 0.5;
      antennaTipRef.current.scale.setScalar(0.8 + pulse * 0.25);
    }
    if (antennaTipMatRef.current) {
      let color = '#4F46E5';
      if (isListening) color = '#0D9488';
      if (isThinking) color = '#D97706';
      if (isSpeaking) color = '#4F46E5';
      antennaTipMatRef.current.emissive.lerp(new THREE.Color(color), 0.15);
    }

    // ── Gaze / pupil tracking ────────────────────────────────────────
    if (leftPupilRef.current && rightPupilRef.current) {
      const pupilX = mousePos.current.x * 0.02;
      const pupilY = mousePos.current.y * 0.02;
      leftPupilRef.current.position.x = THREE.MathUtils.lerp(leftPupilRef.current.position.x, pupilX, 0.15);
      leftPupilRef.current.position.y = THREE.MathUtils.lerp(leftPupilRef.current.position.y, pupilY, 0.15);
      rightPupilRef.current.position.x = THREE.MathUtils.lerp(rightPupilRef.current.position.x, pupilX, 0.15);
      rightPupilRef.current.position.y = THREE.MathUtils.lerp(rightPupilRef.current.position.y, pupilY, 0.15);
    }

    // ── Blinking (LED eyes flatten on blink) ─────────────────────────
    blinkTimerRef.current += delta;
    if (blinkProgressRef.current > 0) {
      blinkProgressRef.current = Math.max(0, blinkProgressRef.current - delta * 9);
    } else if (blinkTimerRef.current >= nextBlinkAtRef.current) {
      blinkTimerRef.current = 0;
      nextBlinkAtRef.current = 2.5 + Math.random() * 3.5;
      blinkProgressRef.current = 1;
    }
    const blinkVal = easeBlink(blinkProgressRef.current);
    const eyeScaleY = 1 - blinkVal * 0.92;
    if (leftEyeRef.current) leftEyeRef.current.scale.y = eyeScaleY;
    if (rightEyeRef.current) rightEyeRef.current.scale.y = eyeScaleY;

    // ── Mouth: equalizer bars driven by viseme intensity ─────────────
    barRefs.current.forEach((bar, i) => {
      if (!bar) return;
      const mid = (BAR_COUNT - 1) / 2;
      const distFromMid = Math.abs(i - mid);
      let target: number;
      if (isSpeaking) {
        const wobble = Math.sin(t * (9 + i * 2.3) + i) * 0.5 + 0.5;
        target = 0.15 + visemeIntensity * (1.1 - distFromMid * 0.18) * wobble;
      } else if (isThinking) {
        target = 0.2 + Math.abs(Math.sin(t * 4 + i * 0.9)) * 0.35;
      } else if (isListening) {
        target = 0.18 + Math.abs(Math.sin(t * 2 + i * 0.6)) * 0.15;
      } else {
        target = 0.12;
      }
      bar.scale.y = THREE.MathUtils.lerp(bar.scale.y, Math.max(0.08, target), 0.25);
    });

    // ── State-driven glow colors (matches the app's signal palette) ──
    let targetColor = '#4F46E5'; // idle indigo
    if (isListening) targetColor = '#0D9488'; // teal
    if (isThinking) targetColor = '#D97706'; // amber
    if (isSpeaking) targetColor = '#4F46E5'; // indigo

    if (chestGlowRef.current) {
      chestGlowRef.current.emissive.lerp(new THREE.Color(targetColor), 0.1);
    }
    if (visorGlowRef.current) {
      visorGlowRef.current.emissive.lerp(new THREE.Color(targetColor), 0.08);
    }
  });

  return (
    <group ref={groupRef} position={[0, -0.15, 0]} scale={0.95} onPointerDown={handlePointerDown}>
      {/* ── Head Group ─────────────────────────────────────────────── */}
      <group ref={headRef}>
        {/* Antenna stalk */}
        <mesh position={[0, 0.82, 0]}>
          <cylinderGeometry args={[0.012, 0.016, 0.22, 8]} />
          <meshStandardMaterial color="#CBD5E1" metalness={0.7} roughness={0.25} />
        </mesh>
        {/* Antenna signal light */}
        <mesh ref={antennaTipRef} position={[0, 0.98, 0]}>
          <sphereGeometry args={[0.05, 16, 16]} />
          <meshStandardMaterial
            ref={antennaTipMatRef}
            color="#4F46E5"
            emissive="#4F46E5"
            emissiveIntensity={1.3}
          />
        </mesh>

        {/* Head shell */}
        <RoundedBox args={[0.78, 0.62, 0.6]} radius={0.14} smoothness={4} position={[0, 0.45, 0]}>
          <meshStandardMaterial color="#E2E8F0" roughness={0.25} metalness={0.35} />
        </RoundedBox>

        {/* Visor / face plate */}
        <RoundedBox args={[0.58, 0.36, 0.06]} radius={0.1} smoothness={4} position={[0, 0.47, 0.31]}>
          <meshStandardMaterial
            ref={visorGlowRef}
            color="#0F172A"
            emissive="#4F46E5"
            emissiveIntensity={0.35}
            roughness={0.2}
            metalness={0.4}
          />
        </RoundedBox>

        {/* Left LED Eye */}
        <group ref={leftEyeRef} position={[-0.15, 0.5, 0.345]}>
          <mesh>
            <ringGeometry args={[0.045, 0.06, 24]} />
            <meshStandardMaterial color="#4F46E5" emissive="#4F46E5" emissiveIntensity={1.4} side={THREE.DoubleSide} />
          </mesh>
          <mesh ref={leftPupilRef} position={[0, 0, 0.005]}>
            <circleGeometry args={[0.028, 16]} />
            <meshStandardMaterial color="#F0F9FF" emissive="#F0F9FF" emissiveIntensity={1.1} side={THREE.DoubleSide} />
          </mesh>
        </group>

        {/* Right LED Eye */}
        <group ref={rightEyeRef} position={[0.15, 0.5, 0.345]}>
          <mesh>
            <ringGeometry args={[0.045, 0.06, 24]} />
            <meshStandardMaterial color="#4F46E5" emissive="#4F46E5" emissiveIntensity={1.4} side={THREE.DoubleSide} />
          </mesh>
          <mesh ref={rightPupilRef} position={[0, 0, 0.005]}>
            <circleGeometry args={[0.028, 16]} />
            <meshStandardMaterial color="#F0F9FF" emissive="#F0F9FF" emissiveIntensity={1.1} side={THREE.DoubleSide} />
          </mesh>
        </group>

        {/* Equalizer mouth (viseme-reactive LED bars) */}
        <group position={[0, 0.35, 0.345]}>
          {Array.from({ length: BAR_COUNT }).map((_, i) => (
            <mesh
              key={i}
              ref={(el) => (barRefs.current[i] = el)}
              position={[(i - (BAR_COUNT - 1) / 2) * 0.06, 0, 0]}
            >
              <boxGeometry args={[0.03, 0.09, 0.01]} />
              <meshStandardMaterial color="#4F46E5" emissive="#4F46E5" emissiveIntensity={1.1} />
            </mesh>
          ))}
        </group>

        {/* Ear / audio-sensor pods */}
        <mesh position={[-0.42, 0.45, 0]}>
          <cylinderGeometry args={[0.05, 0.05, 0.07, 16]} />
          <meshStandardMaterial color="#94A3B8" metalness={0.8} roughness={0.2} />
        </mesh>
        <mesh position={[0.42, 0.45, 0]}>
          <cylinderGeometry args={[0.05, 0.05, 0.07, 16]} />
          <meshStandardMaterial color="#94A3B8" metalness={0.8} roughness={0.2} />
        </mesh>
      </group>

      {/* ── Body / Torso ─────────────────────────────────────────────── */}
      <group position={[0, -0.28, 0]}>
        {/* Neck joint */}
        <mesh position={[0, 0.12, 0]}>
          <cylinderGeometry args={[0.09, 0.11, 0.14, 16]} />
          <meshStandardMaterial color="#94A3B8" metalness={0.6} roughness={0.3} />
        </mesh>

        {/* Shoulders / chassis */}
        <RoundedBox args={[0.72, 0.5, 0.34]} radius={0.1} smoothness={4} position={[0, -0.18, 0]}>
          <meshStandardMaterial color="#334155" roughness={0.35} metalness={0.45} />
        </RoundedBox>

        {/* Chest core light */}
        <mesh position={[0, -0.1, 0.19]}>
          <circleGeometry args={[0.08, 32]} />
          <meshStandardMaterial
            ref={chestGlowRef}
            color="#4F46E5"
            emissive="#4F46E5"
            emissiveIntensity={1.0}
            side={THREE.DoubleSide}
          />
        </mesh>
        <mesh position={[0, -0.1, 0.185]}>
          <ringGeometry args={[0.09, 0.105, 32]} />
          <meshStandardMaterial color="#CBD5E1" metalness={0.7} roughness={0.2} side={THREE.DoubleSide} />
        </mesh>
      </group>

      <SignalParticles />
    </group>
  );
}

function SignalParticles() {
  const pointsRef = useRef<THREE.Points>(null);
  const count = 30;
  const positions = new Float32Array(count * 3);
  for (let i = 0; i < count; i++) {
    positions[i * 3] = (Math.random() - 0.5) * 2.1;
    positions[i * 3 + 1] = (Math.random() - 0.5) * 2.1;
    positions[i * 3 + 2] = (Math.random() - 0.5) * 1.7;
  }

  useFrame((frameState) => {
    if (pointsRef.current) {
      pointsRef.current.rotation.y = frameState.clock.elapsedTime * 0.05;
      pointsRef.current.rotation.x = Math.sin(frameState.clock.elapsedTime * 0.035) * 0.03;
    }
  });

  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
      </bufferGeometry>
      <pointsMaterial size={0.025} color="#4F46E5" transparent opacity={0.55} blending={THREE.AdditiveBlending} />
    </points>
  );
}

function easeBlink(progress: number): number {
  return progress < 0.5 ? progress * 2 : (1 - progress) * 2;
}
