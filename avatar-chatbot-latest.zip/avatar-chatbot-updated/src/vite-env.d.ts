/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_AI_API_BASE_URL: string;
  readonly VITE_AI_API_KEY: string;
  readonly VITE_AI_MODEL: string;
  readonly VITE_AVATAR_MODEL_URL: string;
  readonly VITE_CALENDAR_PROVIDER: string;
  readonly VITE_CALENDAR_ACCESS_TOKEN: string;
  readonly VITE_CALENDAR_ID: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
