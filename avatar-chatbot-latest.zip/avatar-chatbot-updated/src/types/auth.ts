export type AuthMode = 'sign-in' | 'register';

export interface AuthUser {
  name: string;
  email: string;
}
