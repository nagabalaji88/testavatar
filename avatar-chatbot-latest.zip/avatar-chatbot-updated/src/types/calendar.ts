export interface RecurrenceRule {
  frequency: 'daily' | 'weekly';
  /** 0 = Sunday .. 6 = Saturday. Only used when frequency is 'weekly'. */
  daysOfWeek?: number[];
}

/** Structured fields extracted from a natural-language calendar request. */
export interface CalendarEventDraft {
  title: string;
  /** ISO date, e.g. 2026-07-29 */
  date: string;
  /** 24-hour time, e.g. 15:00 */
  startTime: string;
  /** 24-hour time. Derived from durationMinutes if omitted. */
  endTime?: string;
  durationMinutes?: number;
  location?: string;
  notes?: string;
  recurrence?: RecurrenceRule;
}

export interface CreatedCalendarEvent {
  id: string;
  title: string;
  /** ISO 8601 datetime */
  start: string;
  /** ISO 8601 datetime */
  end: string;
  location?: string;
  notes?: string;
  htmlLink?: string;
}

/** Abstraction so the UI and intent layer never depend on a specific provider or auth flow. */
export interface CalendarService {
  createEvent(draft: CalendarEventDraft): Promise<CreatedCalendarEvent>;
}

/** Supplies a valid access token on demand. Full OAuth flows are out of scope for this POC. */
export interface TokenProvider {
  getAccessToken(): Promise<string>;
}
