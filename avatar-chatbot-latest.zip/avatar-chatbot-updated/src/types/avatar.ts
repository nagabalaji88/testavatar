export type AvatarState = 'idle' | 'listening' | 'thinking' | 'speaking';

/** Instantaneous mouth-openness target used to drive the avatar's viseme morph target. */
export type VisemeIntensity = number;
