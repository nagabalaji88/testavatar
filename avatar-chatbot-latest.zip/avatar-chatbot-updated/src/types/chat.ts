export type ChatRole = 'user' | 'assistant';

export interface ChatMessage {
  id: string;
  role: ChatRole;
  content: string;
  timestamp: number;
}

/** High-level state driving the avatar's behavior and UI affordances. */
export type ConversationState = 'idle' | 'listening' | 'thinking' | 'speaking' | 'error';
