import { useEffect, useMemo, useRef, useState } from 'react';
import { AvatarScene } from './components/avatar/AvatarScene';
import { FloatingAvatarButton } from './components/avatar/FloatingAvatarButton';
import { ChatPanel } from './components/chat/ChatPanel';
import { LoginScreen } from './components/auth/LoginScreen';
import { useAuth } from './hooks/useAuth';
import { useChat } from './hooks/useChat';
import { useSpeechRecognition } from './hooks/useSpeechRecognition';
import { useSpeechSynthesis } from './hooks/useSpeechSynthesis';
import { getAiService } from './services/aiService';
import { getCalendarService } from './services/calendarService';
import type { AvatarState } from './types/avatar';

export default function App() {
  const auth = useAuth();
  const modelUrl = import.meta.env.VITE_AVATAR_MODEL_URL ?? '';

  if (!auth.user) {
    return <LoginScreen modelUrl={modelUrl} onSignIn={auth.signIn} onRegister={auth.register} />;
  }

  return (
    <ChatExperience modelUrl={modelUrl} userName={auth.user.name} onSignOut={auth.signOut} />
  );
}

interface ChatExperienceProps {
  modelUrl: string;
  userName: string;
  onSignOut: () => void;
}

function ChatExperience({ modelUrl, userName, onSignOut }: ChatExperienceProps) {
  const [inputValue, setInputValue] = useState('');
  /** Controls whether the 3D avatar panel is visible on screen. */
  const [isAvatarVisible, setIsAvatarVisible] = useState(true);

  const aiService = useMemo(() => getAiService(), []);
  const calendarService = useMemo(() => getCalendarService(), []);
  const synthesis = useSpeechSynthesis();

  const hasGreeted = useRef(false);

  const { messages, isProcessing, sendMessage } = useChat(
    aiService,
    calendarService,
    (text) => {
      synthesis.speak(text);
    },
  );

  const recognition = useSpeechRecognition((finalText) => {
    if (finalText) {
      sendMessage(finalText);
    }
    setInputValue('');
  });

  // Greeting on first mount
  useEffect(() => {
    if (hasGreeted.current) return;
    hasGreeted.current = true;
    synthesis.speak(`Hi ${userName}, what can I help you with?`);
  }, [synthesis, userName]);

  // ── Avatar state (drives ring colour + label) ──────────────────────────
  const avatarState: AvatarState = recognition.isListening
    ? 'listening'
    : isProcessing
      ? 'thinking'
      : synthesis.isSpeaking
        ? 'speaking'
        : 'idle';

  // ── Interaction handlers ───────────────────────────────────────────────
  const handleToggleMic = () => {
    if (recognition.isListening) {
      recognition.stopListening();
    } else {
      synthesis.cancel();
      recognition.startListening();
    }
  };

  const handleSubmit = (text: string) => {
    setInputValue('');
    sendMessage(text);
  };

  const handleStopSpeaking = () => {
    synthesis.cancel();
  };

  // ── Layout ─────────────────────────────────────────────────────────────
  return (
    <div className="flex h-screen flex-col bg-signal-bg lg:flex-row">
      {/* ── Mobile header ────────────────────────────────────────────── */}
      <header className="flex items-center justify-between border-b border-signal-line px-6 py-4 lg:hidden">
        <div className="flex items-center gap-2">
          <span className="h-2 w-2 rounded-full bg-signal-indigo" />
          <h1 className="font-display text-sm tracking-wide text-signal-text">Avatar Chatbot</h1>
        </div>
        <button type="button" onClick={onSignOut} className="text-xs text-signal-muted hover:text-signal-text">
          Sign out
        </button>
      </header>

      {/* ── Interactive 3D Avatar panel (synced size with LoginScreen) ────── */}
      <section
        aria-label="Interactive 3D Avatar"
        style={{
          transition: 'all 0.4s cubic-bezier(0.4,0,0.2,1)',
        }}
        className={`relative shrink-0 overflow-hidden ${
          isAvatarVisible
            ? 'h-[180px] opacity-100 sm:h-[200px] lg:m-6 lg:h-[360px] lg:w-[280px] xl:w-[300px] lg:rounded-3xl lg:border lg:border-slate-200 lg:bg-white/80 lg:backdrop-blur-xl lg:shadow-xl'
            : 'h-0 opacity-0 lg:h-[360px] lg:w-0 lg:m-0'
        }`}
      >
        {/* Desktop brand header */}
        <div className="absolute left-4 top-4 z-40 hidden items-center justify-between gap-1.5 lg:flex lg:w-[calc(100%-5rem)]">
          <div className="flex items-center gap-1.5">
            <span className="h-2 w-2 rounded-full bg-signal-indigo" />
            <h1 className="font-display text-xs font-medium tracking-wide text-signal-text">Companion</h1>
          </div>
        </div>

        {/* Close button to collapse avatar panel */}
        <button
          id="avatar-close-btn"
          type="button"
          onClick={() => setIsAvatarVisible(false)}
          aria-label="Hide avatar"
          className="absolute right-3 top-3 z-50 flex h-7 w-7 items-center justify-center rounded-full border border-slate-200 bg-white/90 text-signal-muted shadow-sm backdrop-blur transition-all duration-200 hover:border-signal-rose hover:bg-white hover:text-signal-rose"
        >
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
            <line x1="18" y1="6" x2="6" y2="18" />
            <line x1="6" y1="6" x2="18" y2="18" />
          </svg>
        </button>

        {/* Interactive 3D Avatar Scene */}
        <AvatarScene modelUrl={modelUrl} state={avatarState} visemeIntensity={synthesis.visemeIntensity} />
      </section>

      {/* ── Chat panel ────────────────────────────────────────────────── */}
      <section className="relative flex min-h-0 flex-1 flex-col p-4 lg:p-6">
        {/* Floating "Show Avatar" button (rendered inside chat section) */}
        {!isAvatarVisible && (
          <FloatingAvatarButton onShow={() => setIsAvatarVisible(true)} />
        )}

        <ChatPanel
          messages={messages}
          isProcessing={isProcessing}
          inputValue={recognition.isListening ? recognition.transcript : inputValue}
          onInputChange={setInputValue}
          onSubmit={handleSubmit}
          isListening={recognition.isListening}
          isMicSupported={recognition.isSupported}
          onToggleMic={handleToggleMic}
          isSpeaking={synthesis.isSpeaking}
          onStopSpeaking={handleStopSpeaking}
        />
      </section>
    </div>
  );
}
