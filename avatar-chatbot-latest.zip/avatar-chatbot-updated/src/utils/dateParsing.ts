const WEEKDAYS = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];

function pad(n: number): string {
  return n.toString().padStart(2, '0');
}

export function toIsoDate(d: Date): string {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

/**
 * Resolves common relative-date phrases ("today", "tomorrow", "next monday",
 * "friday") into an ISO date, relative to `now`. Returns null if the phrase
 * isn't a recognized relative expression, in which case the caller should
 * fall back to whatever explicit date the AI already extracted.
 */
export function resolveRelativeDate(phrase: string, now: Date = new Date()): string | null {
  const normalized = phrase.trim().toLowerCase();

  if (normalized === 'today') return toIsoDate(now);

  if (normalized === 'tomorrow') {
    const d = new Date(now);
    d.setDate(d.getDate() + 1);
    return toIsoDate(d);
  }

  const nextMatch = normalized.match(/^next\s+(\w+)$/);
  const weekdayName = nextMatch ? nextMatch[1] : normalized;
  const weekdayIndex = WEEKDAYS.indexOf(weekdayName);

  if (weekdayIndex !== -1) {
    const d = new Date(now);
    const currentDay = d.getDay();
    let delta = (weekdayIndex - currentDay + 7) % 7;
    // A bare weekday name always means the next upcoming occurrence, not "today".
    if (delta === 0) delta = 7;
    d.setDate(d.getDate() + delta);
    return toIsoDate(d);
  }

  return null;
}

/**
 * Normalizes times like "3 PM", "3:30pm", "15:00" into 24-hour "HH:mm".
 * Returns null if the string can't be parsed.
 */
export function normalizeTime(input: string): string | null {
  const trimmed = input.trim().toLowerCase();

  const twentyFourHour = trimmed.match(/^([01]?\d|2[0-3]):([0-5]\d)$/);
  if (twentyFourHour) {
    return `${pad(Number(twentyFourHour[1]))}:${twentyFourHour[2]}`;
  }

  const twelveHour = trimmed.match(/^(\d{1,2})(?::([0-5]\d))?\s*(am|pm)$/);
  if (twelveHour) {
    let hour = Number(twelveHour[1]) % 12;
    const minute = twelveHour[2] ?? '00';
    if (twelveHour[3] === 'pm') hour += 12;
    return `${pad(hour)}:${minute}`;
  }

  return null;
}

export function addMinutesToTime(time: string, minutes: number): string {
  const [h, m] = time.split(':').map(Number);
  const total = h * 60 + m + minutes;
  const wrapped = ((total % 1440) + 1440) % 1440;
  return `${pad(Math.floor(wrapped / 60))}:${pad(wrapped % 60)}`;
}

export function combineDateAndTime(date: string, time: string): string {
  // Produces a local ISO 8601 datetime string without a timezone suffix,
  // which downstream calendar services interpret in the user's local zone.
  return `${date}T${time}:00`;
}
