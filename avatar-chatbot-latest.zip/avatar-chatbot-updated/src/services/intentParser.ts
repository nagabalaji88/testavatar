import type { AiService } from './aiService';
import type { CalendarEventDraft } from '../types/calendar';
import { normalizeTime, resolveRelativeDate, toIsoDate } from '../utils/dateParsing';

export interface CalendarIntentResult {
  isCalendarRequest: boolean;
  draft?: CalendarEventDraft;
}

interface RawIntentResponse {
  isCalendarRequest: boolean;
  title?: string;
  datePhrase?: string;
  startTime?: string;
  endTime?: string;
  durationMinutes?: number;
  location?: string;
  notes?: string;
  recurrence?: { frequency: 'daily' | 'weekly'; daysOfWeek?: number[] };
}

const SYSTEM_PROMPT = `You extract calendar-event details from a single user message.
Respond with ONLY a JSON object, no prose, matching this shape:
{
  "isCalendarRequest": boolean,
  "title": string,
  "datePhrase": string,   // e.g. "tomorrow", "next monday", "2026-08-03"
  "startTime": string,    // e.g. "3 PM" or "15:00"
  "endTime": string | null,
  "durationMinutes": number | null,
  "location": string | null,
  "notes": string | null,
  "recurrence": { "frequency": "daily" | "weekly", "daysOfWeek": number[] } | null
}
If the message is not a request to create a calendar event, reminder, or appointment,
respond with { "isCalendarRequest": false }.
Days of week are 0 (Sunday) through 6 (Saturday). "Every weekday" means Monday-Friday: [1,2,3,4,5].
If no duration or end time is mentioned, omit both and let the caller default it.`;

/**
 * Uses the AI service to decide whether a message is a calendar request and,
 * if so, extract structured fields. Relative date/time phrases are then
 * resolved locally so the result is unambiguous before it reaches the
 * calendar service.
 */
export async function extractCalendarIntent(
  aiService: AiService,
  message: string,
  now: Date = new Date()
): Promise<CalendarIntentResult> {
  const raw = await aiService.completeJson<RawIntentResponse>([
    { role: 'system', content: SYSTEM_PROMPT },
    { role: 'user', content: message }
  ]);

  if (!raw.isCalendarRequest || !raw.title || !raw.datePhrase || !raw.startTime) {
    return { isCalendarRequest: false };
  }

  const resolvedDate = resolveRelativeDate(raw.datePhrase, now) ?? isoDateOrNull(raw.datePhrase) ?? toIsoDate(now);
  const resolvedStart = normalizeTime(raw.startTime) ?? raw.startTime;
  const resolvedEnd = raw.endTime ? normalizeTime(raw.endTime) ?? raw.endTime : undefined;

  const draft: CalendarEventDraft = {
    title: raw.title,
    date: resolvedDate,
    startTime: resolvedStart,
    endTime: resolvedEnd,
    durationMinutes: raw.durationMinutes ?? undefined,
    location: raw.location ?? undefined,
    notes: raw.notes ?? undefined,
    recurrence: raw.recurrence ?? undefined
  };

  return { isCalendarRequest: true, draft };
}

function isoDateOrNull(value: string): string | null {
  return /^\d{4}-\d{2}-\d{2}$/.test(value) ? value : null;
}
