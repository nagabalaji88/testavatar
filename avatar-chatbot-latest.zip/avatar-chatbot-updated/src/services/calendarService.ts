import type { CalendarEventDraft, CalendarService, CreatedCalendarEvent, TokenProvider } from '../types/calendar';
import { addMinutesToTime, combineDateAndTime } from '../utils/dateParsing';

const DEFAULT_DURATION_MINUTES = 60;

/**
 * Reads a pre-obtained access token from the environment. This POC does not
 * implement an OAuth flow; a host application would swap this out for a
 * TokenProvider backed by its own auth/session layer.
 */
class StaticTokenProvider implements TokenProvider {
  constructor(private readonly token: string) {}

  async getAccessToken(): Promise<string> {
    if (!this.token) {
      throw new Error(
        'No calendar access token configured. Set VITE_CALENDAR_ACCESS_TOKEN or supply a custom TokenProvider.'
      );
    }
    return this.token;
  }
}

function resolveEndTime(draft: CalendarEventDraft): string {
  if (draft.endTime) return draft.endTime;
  return addMinutesToTime(draft.startTime, draft.durationMinutes ?? DEFAULT_DURATION_MINUTES);
}

export class GoogleCalendarService implements CalendarService {
  constructor(
    private readonly tokenProvider: TokenProvider,
    private readonly calendarId: string = 'primary'
  ) {}

  async createEvent(draft: CalendarEventDraft): Promise<CreatedCalendarEvent> {
    const accessToken = await this.tokenProvider.getAccessToken();
    const startIso = combineDateAndTime(draft.date, draft.startTime);
    const endIso = combineDateAndTime(draft.date, resolveEndTime(draft));
    const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;

    const body: Record<string, unknown> = {
      summary: draft.title,
      location: draft.location,
      description: draft.notes,
      start: { dateTime: startIso, timeZone },
      end: { dateTime: endIso, timeZone }
    };

    if (draft.recurrence) {
      body.recurrence = [buildRRule(draft.recurrence)];
    }

    const response = await fetch(
      `https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(this.calendarId)}/events`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${accessToken}`
        },
        body: JSON.stringify(body)
      }
    );

    if (!response.ok) {
      const detail = await response.text();
      throw new Error(`Failed to create calendar event (${response.status}): ${detail}`);
    }

    const created = await response.json();

    return {
      id: created.id,
      title: created.summary ?? draft.title,
      start: created.start?.dateTime ?? startIso,
      end: created.end?.dateTime ?? endIso,
      location: created.location,
      notes: created.description,
      htmlLink: created.htmlLink
    };
  }
}

function buildRRule(recurrence: NonNullable<CalendarEventDraft['recurrence']>): string {
  if (recurrence.frequency === 'daily') {
    return 'RRULE:FREQ=DAILY';
  }

  const byDay = (recurrence.daysOfWeek ?? [])
    .map((day) => ['SU', 'MO', 'TU', 'WE', 'TH', 'FR', 'SA'][day])
    .join(',');

  return byDay ? `RRULE:FREQ=WEEKLY;BYDAY=${byDay}` : 'RRULE:FREQ=WEEKLY';
}

let cachedService: CalendarService | null = null;

/** Lazily creates a singleton calendar service configured from environment variables. */
export function getCalendarService(): CalendarService {
  if (!cachedService) {
    const token = import.meta.env.VITE_CALENDAR_ACCESS_TOKEN ?? '';
    const calendarId = import.meta.env.VITE_CALENDAR_ID ?? 'primary';
    cachedService = new GoogleCalendarService(new StaticTokenProvider(token), calendarId);
  }
  return cachedService;
}
