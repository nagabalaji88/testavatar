export interface AiChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export interface AiService {
  /** Free-form conversational completion. */
  complete(messages: AiChatMessage[]): Promise<string>;
  /** Completion constrained to return raw JSON matching the caller's expected shape. */
  completeJson<T>(messages: AiChatMessage[]): Promise<T>;
}

interface AiServiceConfig {
  baseUrl: string;
  apiKey: string;
  model: string;
}

function readConfig(): AiServiceConfig {
  return {
    baseUrl: import.meta.env.VITE_AI_API_BASE_URL ?? 'https://api.openai.com/v1',
    apiKey: import.meta.env.VITE_AI_API_KEY ?? '',
    model: import.meta.env.VITE_AI_MODEL ?? 'gpt-4o-mini'
  };
}

class OpenAiCompatibleService implements AiService {
  constructor(private readonly config: AiServiceConfig) {}

  private async request(messages: AiChatMessage[], forceJson: boolean): Promise<string> {
    const response = await fetch(`${this.config.baseUrl}/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${this.config.apiKey}`
      },
      body: JSON.stringify({
        model: this.config.model,
        messages,
        temperature: forceJson ? 0 : 0.6,
        ...(forceJson ? { response_format: { type: 'json_object' } } : {})
      })
    });

    if (!response.ok) {
      const detail = await response.text();
      throw new Error(`AI service request failed (${response.status}): ${detail}`);
    }

    const data = await response.json();
    const content: string | undefined = data?.choices?.[0]?.message?.content;

    if (!content) {
      throw new Error('AI service returned an empty response.');
    }

    return content;
  }

  async complete(messages: AiChatMessage[]): Promise<string> {
    return this.request(messages, false);
  }

  async completeJson<T>(messages: AiChatMessage[]): Promise<T> {
    const raw = await this.request(messages, true);
    const cleaned = raw.replace(/^```json\s*|```$/g, '').trim();
    return JSON.parse(cleaned) as T;
  }
}

let cachedService: AiService | null = null;

/** Lazily creates a singleton AI service configured from environment variables. */
export function getAiService(): AiService {
  if (!cachedService) {
    cachedService = new OpenAiCompatibleService(readConfig());
  }
  return cachedService;
}
