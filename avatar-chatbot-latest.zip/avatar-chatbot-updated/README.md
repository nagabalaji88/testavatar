# Avatar Chatbot

A minimal proof-of-concept React + TypeScript app: a 3D AI avatar that listens,
talks, and creates calendar events from natural language.

## Features

- A login/register screen: the avatar greets the user and asks them to sign
  in or create an account before the chat experience loads
- Animated 3D avatar (idle sway, blinking, lip-synced mouth movement while speaking)
- Voice input via the browser Web Speech API, with typing as a fallback
- Spoken responses via the browser Speech Synthesis API
- Natural-language calendar event creation ("Schedule a meeting with John
  tomorrow at 3 PM for one hour")
- Conversation history
- Responsive two-pane layout (avatar / chat)

## Stack

- React 18 + TypeScript + Vite + Tailwind CSS
- React Three Fiber + Three.js for the avatar (Ready Player Me GLB by default)
- An OpenAI-compatible chat endpoint for conversation and intent extraction
- Google Calendar API for event creation (OAuth abstracted behind a simple
  `TokenProvider` interface — see below)

## Getting started

```bash
npm install
cp .env.example .env
# fill in the values described below
npm run dev
```

Open the printed local URL in a browser that supports the Web Speech API
(Chrome or Edge give the most complete support).

## Configuration

All configuration lives in environment variables (see `.env.example`):

| Variable | Purpose |
| --- | --- |
| `VITE_AI_API_BASE_URL` | Base URL of an OpenAI-compatible `/chat/completions` endpoint |
| `VITE_AI_API_KEY` | API key for that endpoint |
| `VITE_AI_MODEL` | Model name to request |
| `VITE_AVATAR_MODEL_URL` | Optional URL of a `.glb` avatar (Ready Player Me or any rigged GLB with ARKit-style blend shapes). If unset, or if the URL fails to load, a built-in procedural placeholder avatar is used instead |
| `VITE_CALENDAR_PROVIDER` | `google` (Microsoft Graph can be added behind the same `CalendarService` interface) |
| `VITE_CALENDAR_ACCESS_TOKEN` | A valid Google Calendar access token |
| `VITE_CALENDAR_ID` | Calendar to write events to (defaults to `primary`) |

### About calendar authentication

This is a proof of concept, so it does **not** implement a full OAuth flow.
`src/services/calendarService.ts` exposes a `TokenProvider` interface with a
single `getAccessToken()` method. The default implementation reads a
pre-obtained token from `VITE_CALENDAR_ACCESS_TOKEN`. To integrate with a real
OAuth flow, implement `TokenProvider` against your own auth/session layer and
pass it into `GoogleCalendarService` instead.

### About the login screen

`src/hooks/useAuth.ts` is a client-only mock: any well-formed sign-in or
registration submission succeeds, and nothing is persisted or sent to a
server. It exists to demonstrate the avatar-driven login flow, not as a real
authentication system. Swap it for a real provider (e.g. your backend's
session API, Auth0, Firebase Auth) by matching the same `signIn` / `register`
/ `signOut` shape — `LoginScreen` and `App` only depend on that interface.

## Project structure

```
src/
  components/
    auth/       login / register screen
    avatar/     3D scene, GLB model, animation
    chat/       chat panel, message list, input, mic button
  hooks/        auth, speech recognition, speech synthesis, chat orchestration
  services/     AI chat service, calendar service, intent extraction
  types/        shared TypeScript types
  utils/        date/time parsing helpers
```

## Notes

- The avatar's lip-sync is approximate: the Web Speech API does not expose
  audio amplitude, so mouth movement is pulsed on each word boundary and eased
  back toward closed between words.
- Voice recognition uses the browser's built-in `SpeechRecognition` /
  `webkitSpeechRecognition`. If unavailable, the mic button is disabled and
  typed input still works.
- Some browsers restrict audio, including speech synthesis, before any user
  interaction with the page. If the avatar's opening greeting isn't audible,
  the greeting text is also shown on screen, and speech will play normally
  once the user interacts with the page (e.g. clicking a field).
- No database or backend is included by design — sign-in/registration and
  chat history are in-memory for the current browser session only.
- Out of the box (no `VITE_AVATAR_MODEL_URL` set) the app renders a simple
  procedural placeholder avatar built from primitives, so it runs with zero
  external asset dependencies. If a configured GLB URL is invalid or
  unreachable, the app also falls back to this placeholder rather than
  crashing. To use a real face, create a free avatar at
  https://readyplayer.me, copy its `.glb` URL into `VITE_AVATAR_MODEL_URL`,
  and restart the dev server.
