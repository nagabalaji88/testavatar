# Deployment guide

## Local with Docker Compose

```bash
cp backend/.env.example backend/.env      # set FORGE_SECRET_KEY at minimum
docker compose up --build
```

Frontend on 5173, backend on 8000, PostgreSQL on 5432. Compose points the backend at
Postgres, so the SQLite default is only used when you run uvicorn directly.

## Production checklist

**Before anything else**

- [ ] Set `FORGE_SECRET_KEY` to a random 32+ byte value. It signs tokens *and* derives the
      key that seals stored provider keys — rotating it invalidates both, so rotate
      deliberately and re-enter provider keys afterwards.
- [ ] Set `FORGE_DATABASE_URL` to PostgreSQL. SQLite will not survive concurrent workers.
- [ ] Set `FORGE_CORS_ORIGINS` to your real frontend origin, not a wildcard.
- [ ] Terminate TLS in front of the app. Tokens are bearer tokens; over plain HTTP they are
      readable in transit.

**Then**

- [ ] Replace the in-process rate limiter with Redis. The current one is per-process, so with
      four workers the effective limit is four times what you configured.
- [ ] Run migrations with Alembic rather than `create_all`. `init_db()` is fine for a first
      boot and wrong for a schema change on live data.
- [ ] Point the structured logger at your collector, and add an OpenTelemetry exporter in the
      `trace_requests` middleware.
- [ ] Set provider keys as environment variables or a secret manager, not through the UI, so
      they are not in the database at all.

## Backend image

```bash
docker build -t promptforge-api ./backend
docker run -p 8000:8000 \
  -e FORGE_SECRET_KEY=... \
  -e FORGE_DATABASE_URL=postgresql+psycopg://user:pass@host/forge \
  promptforge-api
```

Serve with multiple workers behind the proxy:

```bash
uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 4
```

Stage 4 uses a thread pool per request, so size workers for CPU count and expect each
in-flight run to hold up to four concurrent outbound connections.

## Frontend

```bash
cd frontend
VITE_API_BASE=https://api.example.com/api npm run build
```

`dist/` is static. Serve it from any CDN or static host. The app is a single-page router, so
configure a catch-all rewrite to `index.html` or deep links will 404.

## Health and readiness

- `GET /api/health` → liveness, no dependencies touched.
- `GET /api/status` → readiness plus which providers are live vs simulated.

A provider being simulated is not an outage — the app degrades to local drafting rather than
failing the request, which is why status distinguishes the two.

## Backups

Everything worth keeping is in the database: prompts, versions, scores and audit trail. Back
up on the usual Postgres schedule. `version_history` is append-only, so a restore recovers
every revision, not just the current one.
