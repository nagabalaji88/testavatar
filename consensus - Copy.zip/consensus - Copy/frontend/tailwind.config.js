/** @type {import('tailwindcss').Config} */
export default {
  darkMode: 'class',
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#0A0B0F',
        panel: '#12141A',
        raised: '#1A1D26',
        line: 'rgba(255,255,255,0.10)',
        // The only hues in the product belong to the four model specialists.
        gpt: '#10B981',
        claude: '#F59E0B',
        gemini: '#3B82F6',
        kimi: '#A855F7',
        signal: '#E4E4E7',
      },
      fontFamily: {
        display: ['"Bricolage Grotesque"', 'system-ui', 'sans-serif'],
        body: ['"IBM Plex Sans"', 'system-ui', 'sans-serif'],
        mono: ['"IBM Plex Mono"', 'ui-monospace', 'monospace'],
      },
      keyframes: {
        shimmer: { '0%': { backgroundPosition: '-200% 0' }, '100%': { backgroundPosition: '200% 0' } },
        rise: { from: { opacity: '0', transform: 'translateY(8px)' }, to: { opacity: '1', transform: 'translateY(0)' } },
      },
      animation: { shimmer: 'shimmer 2.4s linear infinite', rise: 'rise 0.4s ease-out' },
    },
  },
  plugins: [],
}
