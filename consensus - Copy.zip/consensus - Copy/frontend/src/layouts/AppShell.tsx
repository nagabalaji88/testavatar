import { AnimatePresence, motion } from 'framer-motion'
import {
  Activity, BarChart3, ChevronLeft, Cpu, FileText, GitCompare, History, Library,
  LayoutDashboard, LogOut, Settings, Sparkles, Workflow,
} from 'lucide-react'
import { useEffect, useState } from 'react'
import { NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom'
import { status } from '../services/api'
import { useAuth } from '../store/useAuth'
import { useRun } from '../store/useRun'

const NAV = [
  { to: '/app', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/app/workspace', label: 'Workspace', icon: Sparkles },
  { to: '/app/workflow', label: 'Workflow', icon: Workflow },
  { to: '/app/agents', label: 'Agent monitor', icon: Cpu },
  { to: '/app/comparison', label: 'Comparison', icon: GitCompare },
  { to: '/app/scores', label: 'Scores', icon: BarChart3 },
  { to: '/app/master', label: 'Master prompt', icon: FileText },
  { to: '/app/library', label: 'Library', icon: Library },
  { to: '/app/history', label: 'History', icon: History },
  { to: '/app/analytics', label: 'Analytics', icon: Activity },
  { to: '/app/settings', label: 'Settings', icon: Settings },
]

export function AppShell() {
  const [expanded, setExpanded] = useState(true)
  const [providers, setProviders] = useState<Record<string, { label: string; mode: string }>>({})
  const { user, signOut } = useAuth()
  const run = useRun((s) => s.run)
  const running = useRun((s) => s.running)
  const navigate = useNavigate()
  const location = useLocation()

  useEffect(() => {
    status().then((body) => setProviders(body.providers)).catch(() => undefined)
  }, [])

  const simulated = Object.values(providers).filter((p) => p.mode === 'simulated').length

  return (
    <div className="flex min-h-screen">
      <motion.aside
        animate={{ width: expanded ? 224 : 72 }}
        transition={{ type: 'spring', stiffness: 220, damping: 26 }}
        className="glass-solid sticky top-0 z-30 hidden h-screen shrink-0 flex-col p-3 md:flex"
      >
        <div className="mb-6 flex items-center gap-2 px-1">
          <span className="grid h-7 w-7 shrink-0 place-items-center rounded-md bg-signal font-display text-sm font-bold text-ink">
            F
          </span>
          {expanded && <span className="font-display text-base font-bold text-zinc-50">PromptForge</span>}
          <button
            onClick={() => setExpanded((v) => !v)}
            aria-label={expanded ? 'Collapse sidebar' : 'Expand sidebar'}
            className="focus-ring ml-auto rounded-md p-1 text-zinc-500 hover:text-zinc-100"
          >
            <ChevronLeft className={`h-4 w-4 transition-transform ${expanded ? '' : 'rotate-180'}`} />
          </button>
        </div>

        <nav className="flex flex-1 flex-col gap-0.5 overflow-y-auto">
          {NAV.map(({ to, label, icon: Icon, end }) => (
            <NavLink
              key={to}
              to={to}
              end={end}
              className={({ isActive }) =>
                `focus-ring flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors ${
                  isActive ? 'bg-white/[0.08] text-zinc-50' : 'text-zinc-500 hover:bg-white/[0.04] hover:text-zinc-200'
                }`
              }
            >
              <Icon className="h-4 w-4 shrink-0" />
              {expanded && <span className="truncate">{label}</span>}
            </NavLink>
          ))}
        </nav>

        <button
          onClick={() => { signOut(); navigate('/login') }}
          className="focus-ring flex items-center gap-3 rounded-lg px-3 py-2 text-sm text-zinc-500 hover:text-zinc-200"
        >
          <LogOut className="h-4 w-4 shrink-0" />
          {expanded && 'Sign out'}
        </button>
      </motion.aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="glass-solid sticky top-0 z-20 flex items-center gap-3 border-b border-line px-4 py-3">
          <span className="font-display text-sm text-zinc-100 md:hidden">PromptForge</span>
          {run && (
            <span className="hidden font-mono text-[11px] text-zinc-500 sm:block">
              last run · {run.master.score.toFixed(1)}/100 · {run.totals.tokens.toLocaleString()} tokens
            </span>
          )}
          {running && <span className="font-mono text-[11px] text-zinc-300">running…</span>}
          <div className="ml-auto flex items-center gap-2 rounded-lg border border-line bg-white/[0.04] px-3 py-1.5">
            <span className="grid h-6 w-6 place-items-center rounded-full bg-zinc-700 text-[10px] font-bold text-zinc-100">
              {user?.full_name?.[0] ?? 'U'}
            </span>
            <div className="hidden leading-tight sm:block">
              <p className="text-xs text-zinc-200">{user?.full_name}</p>
              <p className="font-mono text-[10px] uppercase text-zinc-600">{user?.role}</p>
            </div>
          </div>
        </header>

        <main className="min-w-0 flex-1 px-4 py-6 lg:px-8">
          <AnimatePresence mode="wait">
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.28 }}
            >
              <Outlet />
            </motion.div>
          </AnimatePresence>
        </main>

        <footer className="glass-solid sticky bottom-0 z-20 flex flex-wrap items-center gap-x-5 gap-y-1 border-t border-line px-4 py-2 font-mono text-[10px] uppercase tracking-wider text-zinc-600">
          {Object.entries(providers).map(([id, provider]) => (
            <span key={id} className="flex items-center gap-1.5">
              <span className={`h-1.5 w-1.5 rounded-full ${provider.mode === 'live' ? 'bg-emerald-400' : 'bg-zinc-600'}`} />
              {provider.label} {provider.mode}
            </span>
          ))}
          {simulated > 0 && (
            <span className="text-zinc-500">
              {simulated} provider{simulated === 1 ? '' : 's'} simulated — add keys in Settings
            </span>
          )}
        </footer>
      </div>
    </div>
  )
}
