export type ProviderId = 'openai' | 'anthropic' | 'google' | 'moonshot'

export interface User { id: string; email: string; full_name: string; role: string }

export interface Provider {
  id: ProviderId
  label: string
  model: string
  color: string
  strengths: string[]
  mode: 'live' | 'simulated'
}

export interface ScoreBundle {
  metrics: Record<string, number>
  weighted?: Record<string, number>
  total: number
  rank?: number
  notes: string[]
}

export interface DraftBundle {
  sections: Record<string, string>
  content: string
  meta: { tokens: number; cost_usd: number; duration_ms: number; simulated: boolean; agent: string }
  score: ScoreBundle
}

export interface AgentLog {
  agent: string
  stage: string
  status: string
  summary: string
  input_digest?: string
  output_digest?: string
  tokens: number
  cost_usd: number
  duration_ms: number
  confidence: number
  warnings: string[]
  recommendations: string[]
  created_at?: string
}

export interface ConsensusBundle {
  agreement: number
  pairs: Record<string, number>
  common_strengths: { metric: string; floor: number }[]
  shared_gaps: { metric: string; ceiling: number }[]
  contradictions: { section: string; between: string[]; overlap: number; detail: string }[]
  unique_contributions: Record<string, string[]>
}

export interface QaReport {
  passed: boolean
  problems: { kind: string; detail: string }[]
  score: number
  metrics: Record<string, number>
  weights: Record<string, number>
  placeholders: string[]
}

export interface GenerateResponse {
  session_id: string
  stage: string
  intent: {
    objective: string
    task_type: string
    constraints: string[]
    expected_output: string
    ambiguities: string[]
    risks: string[]
    clarifications: string[]
  }
  plan: { sections: string[]; target_label: string; must_include: string[]; open_questions: string[] }
  drafts: Record<string, DraftBundle>
  ranking: ProviderId[]
  consensus: ConsensusBundle
  master: {
    id: string
    title: string
    content: string
    sections: Record<string, string>
    provenance: Record<string, string>
    score: number
  }
  qa_report: QaReport
  logs: AgentLog[]
  totals: { tokens: number; cost_usd: number; duration_ms: number }
}

export interface LibraryEntry {
  id: string
  session_id: string
  title: string
  score: number
  version: number
  starred: boolean
  created_at: string
  passed_qa: boolean
  providers: string[]
  preview: string
}

export interface Analytics {
  total_sessions: number
  total_prompts: number
  average_score: number
  best_model: string
  consensus_score: number
  average_duration_ms: number
  total_tokens: number
  total_cost_usd: number
  prompt_versions: number
  success_rate: number
  top_prompt: { id: string; title: string; score: number } | null
  by_provider: { provider: string; average: number; runs: number; best: number }[]
  recent: { id: string; title: string; score: number; created_at: string; duration_ms: number }[]
}

export interface SessionSummary {
  id: string
  title: string
  stage: string
  total_tokens: number
  total_cost_usd: number
  duration_ms: number
  created_at: string
}
