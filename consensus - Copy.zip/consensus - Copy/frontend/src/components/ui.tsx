import { motion } from 'framer-motion'
import type { ReactNode } from 'react'

export const PROVIDER_META: Record<string, { label: string; color: string }> = {
  openai: { label: 'GPT', color: '#10B981' },
  anthropic: { label: 'Claude', color: '#F59E0B' },
  google: { label: 'Gemini', color: '#3B82F6' },
  moonshot: { label: 'Kimi', color: '#A855F7' },
  weaver: { label: 'Weaver', color: '#E4E4E7' },
}

export function Panel({
  children, className = '', delay = 0, solid = false,
}: { children: ReactNode; className?: string; delay?: number; solid?: boolean }) {
  return (
    <motion.section
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, delay, ease: [0.22, 1, 0.36, 1] }}
      className={`${solid ? 'glass-solid' : 'glass'} rounded-xl p-5 ${className}`}
    >
      {children}
    </motion.section>
  )
}

export function Button({
  children, onClick, variant = 'primary', disabled, className = '', type = 'button',
}: {
  children: ReactNode
  onClick?: () => void
  variant?: 'primary' | 'ghost' | 'quiet'
  disabled?: boolean
  className?: string
  type?: 'button' | 'submit'
}) {
  const styles = {
    primary: 'bg-signal text-ink font-semibold hover:bg-white',
    ghost: 'border border-line bg-white/[0.04] text-zinc-200 hover:border-zinc-500',
    quiet: 'text-zinc-400 hover:text-zinc-100',
  }[variant]
  return (
    <motion.button
      type={type}
      onClick={onClick}
      disabled={disabled}
      whileTap={{ scale: 0.98 }}
      className={`focus-ring rounded-lg px-4 py-2 text-sm transition-colors disabled:opacity-40 ${styles} ${className}`}
    >
      {children}
    </motion.button>
  )
}

export function Stat({
  label, value, hint, delay = 0,
}: { label: string; value: string | number; hint?: string; delay?: number }) {
  return (
    <Panel delay={delay}>
      <p className="eyebrow">{label}</p>
      <p className="mt-1.5 font-display text-3xl font-bold text-zinc-50">{value}</p>
      {hint && <p className="mt-1 text-xs text-zinc-500">{hint}</p>}
    </Panel>
  )
}

export function ProviderChip({ provider, muted = false }: { provider: string; muted?: boolean }) {
  const meta = PROVIDER_META[provider] ?? { label: provider, color: '#71717A' }
  return (
    <span
      className="inline-flex items-center gap-1.5 rounded-md border px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider"
      style={{
        borderColor: `${meta.color}55`,
        color: muted ? '#a1a1aa' : meta.color,
        background: `${meta.color}12`,
      }}
    >
      <span className="h-1.5 w-1.5 rounded-full" style={{ background: meta.color }} />
      {meta.label}
    </span>
  )
}

export function ScoreDial({ value, size = 56 }: { value: number; size?: number }) {
  const radius = size / 2 - 4
  const circumference = 2 * Math.PI * radius
  const pct = Math.max(0, Math.min(value / 100, 1))
  return (
    <svg width={size} height={size} className="shrink-0">
      <circle cx={size / 2} cy={size / 2} r={radius} fill="none"
        stroke="rgba(255,255,255,0.08)" strokeWidth="4" />
      <motion.circle
        cx={size / 2} cy={size / 2} r={radius} fill="none" stroke="#E4E4E7" strokeWidth="4"
        strokeLinecap="round" transform={`rotate(-90 ${size / 2} ${size / 2})`}
        strokeDasharray={circumference}
        initial={{ strokeDashoffset: circumference }}
        animate={{ strokeDashoffset: circumference * (1 - pct) }}
        transition={{ duration: 0.9, ease: 'easeOut' }}
      />
      <text x="50%" y="54%" textAnchor="middle"
        className="fill-zinc-100 font-mono text-[11px]">{value.toFixed(0)}</text>
    </svg>
  )
}

export function Loading({ label = 'Working' }: { label?: string }) {
  return (
    <div className="flex items-center gap-2 text-sm text-zinc-400">
      <span className="h-3 w-3 animate-pulse rounded-full bg-signal/70" />
      {label}
    </div>
  )
}

export function Empty({ title, action }: { title: string; action?: string }) {
  return (
    <div className="glass rounded-xl p-8 text-center">
      <p className="font-display text-lg text-zinc-100">{title}</p>
      {action && <p className="mt-1 text-sm text-zinc-500">{action}</p>}
    </div>
  )
}

export function PageHeading({ eyebrow, title, description }: {
  eyebrow: string; title: string; description?: string
}) {
  return (
    <header className="mb-6">
      <p className="eyebrow">{eyebrow}</p>
      <h1 className="mt-1 font-display text-3xl font-bold text-zinc-50">{title}</h1>
      {description && <p className="mt-2 max-w-2xl text-sm text-zinc-500">{description}</p>}
    </header>
  )
}
