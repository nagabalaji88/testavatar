import { useEffect, useState } from 'react'
import {
  Bar, BarChart, CartesianGrid, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from 'recharts'
import { Loading, PageHeading, Panel, PROVIDER_META, Stat } from '../components/ui'
import { library, settingsApi } from '../services/api'
import type { Analytics } from '../types'

const tooltipStyle = {
  background: 'rgba(18,20,26,0.95)', border: '1px solid rgba(255,255,255,0.12)',
  borderRadius: 10, fontSize: 12,
}

interface AuditRow { id: string; actor: string; action: string; target: string; created_at: string }

export function AnalyticsPage() {
  const [data, setData] = useState<Analytics | null>(null)
  const [audit, setAudit] = useState<AuditRow[]>([])

  useEffect(() => {
    library.analytics().then(setData).catch(() => undefined)
    settingsApi.audit().then(setAudit).catch(() => undefined)
  }, [])

  if (!data) return <Loading label="Loading analytics" />

  return (
    <>
      <PageHeading
        eyebrow="Analytics"
        title="Cost, latency and which specialist earns its keep"
        description="Costs are estimated from token counts and published per-million-token pricing, so they hold whether a run was live or simulated."
      />

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <Stat label="Total runs" value={data.total_sessions} />
        <Stat label="Total tokens" value={data.total_tokens.toLocaleString()} delay={0.05} />
        <Stat label="Estimated spend" value={`$${data.total_cost_usd.toFixed(4)}`} delay={0.1} />
        <Stat
          label="Cost per prompt"
          value={data.total_prompts ? `$${(data.total_cost_usd / data.total_prompts).toFixed(4)}` : '$0'}
          delay={0.15}
        />
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Panel>
          <p className="eyebrow">Average draft score by specialist</p>
          <div className="mt-4 h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data.by_provider.map((r) => ({
                ...r, label: PROVIDER_META[r.provider]?.label ?? r.provider,
              }))}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                <XAxis dataKey="label" tick={{ fill: '#71717a', fontSize: 11 }} />
                <YAxis domain={[0, 100]} tick={{ fill: '#71717a', fontSize: 11 }} />
                <Tooltip contentStyle={tooltipStyle} cursor={{ fill: 'rgba(255,255,255,0.04)' }} />
                <Bar dataKey="average" radius={[6, 6, 0, 0]} animationDuration={800}>
                  {data.by_provider.map((row) => (
                    <Cell key={row.provider} fill={PROVIDER_META[row.provider]?.color ?? '#71717A'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Panel>

        <Panel delay={0.05}>
          <p className="eyebrow">Recent runs</p>
          <ul className="mt-3 space-y-2">
            {data.recent.map((entry) => (
              <li key={entry.id} className="flex items-center gap-3 border-b border-line/60 pb-2 last:border-0">
                <span className="min-w-0 flex-1 truncate text-sm text-zinc-300">{entry.title}</span>
                <span className="font-mono text-[11px] text-zinc-500">{entry.score.toFixed(1)}</span>
                <span className="font-mono text-[10px] text-zinc-600">{entry.duration_ms}ms</span>
              </li>
            ))}
          </ul>
        </Panel>
      </div>

      <Panel className="mt-4" delay={0.1}>
        <p className="eyebrow">Audit trail</p>
        <ul className="mt-3 max-h-72 space-y-1.5 overflow-y-auto pr-1">
          {audit.map((row) => (
            <li key={row.id} className="font-mono text-[11px] text-zinc-500">
              <span className="text-zinc-300">{row.action}</span> · {row.actor}
              <span className="ml-2 text-zinc-700">{new Date(row.created_at).toLocaleString()}</span>
            </li>
          ))}
        </ul>
      </Panel>
    </>
  )
}
