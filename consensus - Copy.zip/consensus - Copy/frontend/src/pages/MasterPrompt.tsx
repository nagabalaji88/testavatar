import Editor from '@monaco-editor/react'
import { AlertTriangle, Check, Copy, Download, Save } from 'lucide-react'
import { useEffect, useState } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { ConsensusBar } from '../components/ConsensusBar'
import { Button, Empty, PageHeading, Panel, ScoreDial } from '../components/ui'
import { exporter, library } from '../services/api'
import { useRun } from '../store/useRun'
import type { QaReport } from '../types'

const FORMATS = ['markdown', 'json', 'yaml', 'xml', 'txt', 'template', 'html']

export function MasterPrompt() {
  const run = useRun((s) => s.run)
  const [params] = useSearchParams()
  const navigate = useNavigate()
  const requestedId = params.get('id')

  const [masterId, setMasterId] = useState<string | null>(null)
  const [title, setTitle] = useState('')
  const [content, setContent] = useState('')
  const [provenance, setProvenance] = useState<Record<string, string>>({})
  const [score, setScore] = useState(0)
  const [qa, setQa] = useState<QaReport | null>(null)
  const [version, setVersion] = useState(1)
  const [dirty, setDirty] = useState(false)
  const [copied, setCopied] = useState(false)
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    const id = requestedId ?? run?.master.id
    if (!id) return
    library.detail(id).then((data) => {
      if (data.error) return
      setMasterId(data.master.id)
      setTitle(data.master.title)
      setContent(data.master.content)
      setProvenance(data.master.provenance)
      setScore(data.master.score)
      setQa(data.master.qa_report)
      setVersion(data.master.version)
      setDirty(false)
    }).catch(() => undefined)
  }, [requestedId, run])

  const copy = async () => {
    await navigator.clipboard.writeText(content)
    setCopied(true)
    setTimeout(() => setCopied(false), 1800)
  }

  const save = async () => {
    if (!masterId) return
    setSaving(true)
    try {
      const result = await library.revise(masterId, content, 'Edited in the viewer')
      setVersion(result.version)
      setDirty(false)
    } finally {
      setSaving(false)
    }
  }

  if (!masterId) {
    return (
      <>
        <PageHeading eyebrow="Master prompt" title="No prompt selected" />
        <Empty title="Generate one, or open a saved prompt from the library." />
        <div className="mt-4 flex gap-2">
          <Button onClick={() => navigate('/app/workspace')}>Open Workspace</Button>
          <Button variant="ghost" onClick={() => navigate('/app/library')}>Browse library</Button>
        </div>
      </>
    )
  }

  return (
    <>
      <PageHeading eyebrow={`Master prompt · v${version}`} title={title} />

      <div className="grid gap-4 lg:grid-cols-[1fr_320px]">
        <Panel className="p-0">
          <div className="flex flex-wrap items-center gap-2 border-b border-line px-4 py-2.5">
            <Button variant="ghost" onClick={copy} className="flex items-center gap-1.5">
              {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
              {copied ? 'Copied' : 'Copy'}
            </Button>
            <Button onClick={save} disabled={!dirty || saving} className="flex items-center gap-1.5">
              <Save className="h-3.5 w-3.5" /> {saving ? 'Saving…' : dirty ? 'Save as new version' : 'Saved'}
            </Button>
            <div className="ml-auto flex items-center gap-1.5">
              <Download className="h-3.5 w-3.5 text-zinc-500" />
              <select
                onChange={(e) => { if (e.target.value) { exporter.download(masterId, e.target.value); e.target.value = '' } }}
                defaultValue=""
                className="focus-ring rounded-md border border-line bg-white/[0.04] px-2 py-1 text-xs text-zinc-300"
                aria-label="Export format"
              >
                <option value="" className="bg-panel">Export as…</option>
                {FORMATS.map((format) => (
                  <option key={format} value={format} className="bg-panel">{format}</option>
                ))}
              </select>
            </div>
          </div>
          <div className="h-[560px]">
            <Editor
              height="100%"
              defaultLanguage="markdown"
              theme="vs-dark"
              value={content}
              onChange={(value) => { setContent(value ?? ''); setDirty(true) }}
              options={{
                minimap: { enabled: false },
                fontSize: 13,
                wordWrap: 'on',
                lineNumbers: 'off',
                padding: { top: 16 },
                scrollBeyondLastLine: false,
              }}
            />
          </div>
        </Panel>

        <div className="space-y-4">
          <Panel>
            <div className="flex items-center gap-3">
              <ScoreDial value={score} size={64} />
              <div>
                <p className="eyebrow">Consensus score</p>
                <p className="text-sm text-zinc-300">
                  {qa?.passed ? 'Passed structural validation' : 'Validation found problems'}
                </p>
              </div>
            </div>
            <div className="mt-4">
              <p className="eyebrow mb-2">Section provenance</p>
              <ConsensusBar provenance={provenance} height={36} />
            </div>
          </Panel>

          <Panel delay={0.05}>
            <p className="eyebrow">Quality assurance</p>
            {qa && qa.problems.length === 0 && (
              <p className="mt-2 flex items-center gap-1.5 text-sm text-emerald-400">
                <Check className="h-4 w-4" /> No findings.
              </p>
            )}
            <ul className="mt-2 space-y-2">
              {qa?.problems.map((problem, index) => (
                <li key={index} className="flex gap-2 text-xs text-zinc-400">
                  <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-amber-400" />
                  <span>
                    <span className="font-mono text-[10px] uppercase text-zinc-600">{problem.kind}</span>
                    <br />{problem.detail}
                  </span>
                </li>
              ))}
            </ul>
            {qa && qa.placeholders.length > 0 && (
              <>
                <p className="eyebrow mt-4">Placeholders</p>
                <div className="mt-1.5 flex flex-wrap gap-1">
                  {qa.placeholders.map((name) => (
                    <span key={name} className="rounded border border-line px-1.5 py-0.5 font-mono text-[10px] text-zinc-400">
                      {`{{${name}}}`}
                    </span>
                  ))}
                </div>
              </>
            )}
          </Panel>
        </div>
      </div>
    </>
  )
}
