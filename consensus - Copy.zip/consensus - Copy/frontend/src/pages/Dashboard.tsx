import { useEffect, useState } from 'react'
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { useNavigate } from 'react-router-dom'
import { ConsensusBar } from '../components/ConsensusBar'
import { Button, Loading, PageHeading, Panel, ProviderChip, Stat } from '../components/ui'
import { library } from '../services/api'
import { useRun } from '../store/useRun'
import type { Analytics } from '../types'

const tooltipStyle = {
  background: 'rgba(18,20,26,0.95)', border: '1px solid rgba(255,255,255,0.12)',
  borderRadius: 10, fontSize: 12,
}

export function Dashboard() {
  const [data, setData] = useState<Analytics | null>(null)
  const run = useRun((s) => s.run)
  const navigate = useNavigate()

  useEffect(() => { library.analytics().then(setData).catch(() => undefined) }, [])

  if (!data) return <Loading label="Loading run history" />

  const trend = [...data.recent].reverse().map((entry) => ({
    label: new Date(entry.created_at).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }),
    score: entry.score,
  }))

  return (
    <>
      <PageHeading
        eyebrow="Dashboard"
        title="Consensus at a glance"
        description="How many prompts the platform has produced, how well they score, and what the four specialists cost to run."
      />

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <Stat label="Prompts produced" value={data.total_prompts} hint={`${data.total_sessions} runs`} />
        <Stat label="Average score" value={`${data.average_score}/100`} hint={`${Math.round(data.success_rate * 100)}% passed QA`} delay={0.05} />
        <Stat label="Best model" value={data.best_model} hint="highest average draft score" delay={0.1} />
        <Stat label="Consensus" value={`${Math.round(data.consensus_score * 100)}%`} hint="average agreement between drafts" delay={0.15} />
      </div>

      <div className="mt-3 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <Stat label="Execution time" value={`${data.average_duration_ms}ms`} hint="average per run" delay={0.2} />
        <Stat label="Tokens" value={data.total_tokens.toLocaleString()} delay={0.25} />
        <Stat label="API cost" value={`$${data.total_cost_usd.toFixed(4)}`} hint="estimated, all runs" delay={0.3} />
        <Stat label="Prompt versions" value={data.prompt_versions} delay={0.35} />
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <Panel className="lg:col-span-2" delay={0.2}>
          <p className="eyebrow">Score across recent runs</p>
          <div className="mt-4 h-56">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={trend}>
                <defs>
                  <linearGradient id="scoreFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#E4E4E7" stopOpacity={0.4} />
                    <stop offset="100%" stopColor="#E4E4E7" stopOpacity={0.02} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                <XAxis dataKey="label" tick={{ fill: '#71717a', fontSize: 11 }} />
                <YAxis domain={[0, 100]} tick={{ fill: '#71717a', fontSize: 11 }} />
                <Tooltip contentStyle={tooltipStyle} />
                <Area type="monotone" dataKey="score" stroke="#E4E4E7" fill="url(#scoreFill)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Panel>

        <Panel delay={0.25}>
          <p className="eyebrow">Specialist averages</p>
          <ul className="mt-4 space-y-3">
            {data.by_provider.map((row) => (
              <li key={row.provider}>
                <div className="flex items-center gap-2">
                  <ProviderChip provider={row.provider} />
                  <span className="ml-auto font-mono text-[11px] text-zinc-400">{row.average}</span>
                </div>
                <div className="mt-1.5 h-1 overflow-hidden rounded-full bg-white/10">
                  <div className="h-full rounded-full bg-zinc-400" style={{ width: `${row.average}%` }} />
                </div>
                <p className="mt-1 font-mono text-[10px] text-zinc-600">
                  {row.runs} draft{row.runs === 1 ? '' : 's'} · best {row.best}
                </p>
              </li>
            ))}
          </ul>
        </Panel>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Panel delay={0.3}>
          <p className="eyebrow">Top prompt</p>
          {data.top_prompt ? (
            <>
              <p className="mt-2 font-display text-lg text-zinc-50">{data.top_prompt.title}</p>
              <p className="mt-1 font-mono text-[11px] text-zinc-500">
                {data.top_prompt.score.toFixed(1)}/100
              </p>
              <Button
                variant="ghost"
                className="mt-3"
                onClick={() => navigate(`/app/master?id=${data.top_prompt!.id}`)}
              >
                Open it
              </Button>
            </>
          ) : (
            <p className="mt-2 text-sm text-zinc-500">Nothing generated yet.</p>
          )}
        </Panel>

        <Panel delay={0.35}>
          <p className="eyebrow">Last run in this session</p>
          {run ? (
            <>
              <p className="mt-2 truncate text-sm text-zinc-300">{run.master.title}</p>
              <div className="mt-3"><ConsensusBar provenance={run.master.provenance} height={32} /></div>
            </>
          ) : (
            <>
              <p className="mt-2 text-sm text-zinc-500">You have not run the workflow yet in this session.</p>
              <Button className="mt-3" onClick={() => navigate('/app/workspace')}>Open Workspace</Button>
            </>
          )}
        </Panel>
      </div>
    </>
  )
}
