import { Star } from 'lucide-react'
import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Button, Empty, PageHeading, Panel, ProviderChip } from '../components/ui'
import { library } from '../services/api'
import type { LibraryEntry } from '../types'

export function LibraryPage() {
  const [entries, setEntries] = useState<LibraryEntry[]>([])
  const [starredOnly, setStarredOnly] = useState(false)
  const [query, setQuery] = useState('')
  const navigate = useNavigate()

  const load = () => library.list(starredOnly).then(setEntries).catch(() => undefined)
  useEffect(() => { load() }, [starredOnly])

  const toggleStar = async (id: string) => {
    await library.star(id)
    load()
  }

  const visible = entries.filter((entry) =>
    entry.title.toLowerCase().includes(query.toLowerCase()))

  return (
    <>
      <PageHeading
        eyebrow="Library"
        title="Every prompt this platform has produced"
        description="Ranked by consensus score. Star the ones your team has adopted."
      />

      <div className="mb-4 flex flex-wrap gap-2">
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search by title"
          className="field focus-ring w-56"
        />
        <Button variant={starredOnly ? 'primary' : 'ghost'} onClick={() => setStarredOnly((v) => !v)}>
          Starred only
        </Button>
      </div>

      {visible.length === 0 ? (
        <Empty title="Nothing here yet." action="Generate a prompt in the Workspace." />
      ) : (
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
          {visible.map((entry, index) => (
            <Panel key={entry.id} delay={index * 0.04}>
              <div className="flex items-start gap-2">
                <h2 className="min-w-0 flex-1 font-display text-sm text-zinc-50">{entry.title}</h2>
                <button
                  onClick={() => toggleStar(entry.id)}
                  aria-label={entry.starred ? 'Unstar' : 'Star'}
                  className="focus-ring rounded p-0.5"
                >
                  <Star className={`h-4 w-4 ${entry.starred ? 'fill-amber-400 text-amber-400' : 'text-zinc-600'}`} />
                </button>
              </div>
              <p className="mt-2 line-clamp-3 font-mono text-[10px] leading-relaxed text-zinc-600">
                {entry.preview}
              </p>
              <div className="mt-3 flex flex-wrap items-center gap-1.5">
                {entry.providers.map((provider) => (
                  <ProviderChip key={provider} provider={provider} />
                ))}
              </div>
              <div className="mt-3 flex items-center gap-3 border-t border-line pt-3">
                <span className="font-mono text-[11px] text-zinc-400">{entry.score.toFixed(1)}/100</span>
                <span className="font-mono text-[10px] text-zinc-600">v{entry.version}</span>
                <span className={`font-mono text-[10px] ${entry.passed_qa ? 'text-emerald-400' : 'text-amber-400'}`}>
                  {entry.passed_qa ? 'QA passed' : 'QA findings'}
                </span>
                <Button
                  variant="quiet"
                  className="ml-auto"
                  onClick={() => navigate(`/app/master?id=${entry.id}`)}
                >
                  Open
                </Button>
              </div>
            </Panel>
          ))}
        </div>
      )}
    </>
  )
}
