import { motion } from 'framer-motion'
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Button } from '../components/ui'
import { useAuth } from '../store/useAuth'

const DEMO = [
  ['aarti.desai@forge.dev', 'Engineer'],
  ['admin@forge.dev', 'Admin'],
  ['viewer@forge.dev', 'Viewer'],
]

export function Login() {
  const [email, setEmail] = useState('aarti.desai@forge.dev')
  const [password, setPassword] = useState('forge1234')
  const [busy, setBusy] = useState(false)
  const { signIn, error } = useAuth()
  const navigate = useNavigate()

  const submit = async () => {
    setBusy(true)
    const ok = await signIn(email, password)
    setBusy(false)
    if (ok) navigate('/app')
  }

  return (
    <div className="grid min-h-screen place-items-center px-5">
      <motion.div
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass w-full max-w-sm rounded-2xl p-8"
      >
        <div className="mb-6 flex items-center gap-2">
          <span className="grid h-8 w-8 place-items-center rounded-md bg-signal font-display font-bold text-ink">F</span>
          <span className="font-display text-lg font-bold text-zinc-50">PromptForge</span>
        </div>
        <h1 className="font-display text-xl font-bold text-zinc-50">Sign in</h1>
        <p className="mt-1 text-sm text-zinc-500">Demo password: forge1234</p>

        <div className="mt-6 space-y-3">
          <input value={email} onChange={(e) => setEmail(e.target.value)} className="field focus-ring" placeholder="Work email" />
          <input
            type="password" value={password} onChange={(e) => setPassword(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && submit()}
            className="field focus-ring" placeholder="Password"
          />
          {error && <p className="text-xs text-rose-400">{error}</p>}
          <Button onClick={submit} disabled={busy} className="w-full">
            {busy ? 'Signing in…' : 'Sign in'}
          </Button>
        </div>

        <div className="mt-6 space-y-1.5 border-t border-line pt-4">
          <p className="eyebrow mb-2">Demo accounts</p>
          {DEMO.map(([demoEmail, role]) => (
            <button
              key={demoEmail}
              onClick={() => setEmail(demoEmail)}
              className="focus-ring flex w-full items-center justify-between rounded-md border border-line px-2.5 py-1.5 text-left text-[11px] hover:border-zinc-500"
            >
              <span className="text-zinc-300">{role}</span>
              <span className="font-mono text-[10px] text-zinc-600">{demoEmail}</span>
            </button>
          ))}
        </div>
      </motion.div>
    </div>
  )
}
