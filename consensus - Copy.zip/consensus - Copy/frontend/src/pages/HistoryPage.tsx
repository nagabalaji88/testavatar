import { useEffect, useState } from 'react'
import { Empty, PageHeading, Panel } from '../components/ui'
import { library } from '../services/api'
import type { SessionSummary } from '../types'

export function HistoryPage() {
  const [sessions, setSessions] = useState<SessionSummary[]>([])

  useEffect(() => { library.history().then(setSessions).catch(() => undefined) }, [])

  return (
    <>
      <PageHeading
        eyebrow="History"
        title="Every run, with what it cost"
        description="Each row is one full pass through the ten stages."
      />

      {sessions.length === 0 ? (
        <Empty title="No runs recorded yet." />
      ) : (
        <Panel className="overflow-x-auto p-0">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-line text-zinc-500">
                <th className="px-4 py-3 font-mono text-[10px] uppercase tracking-wider">Title</th>
                <th className="px-4 py-3 font-mono text-[10px] uppercase tracking-wider">Stage</th>
                <th className="px-4 py-3 text-right font-mono text-[10px] uppercase tracking-wider">Tokens</th>
                <th className="px-4 py-3 text-right font-mono text-[10px] uppercase tracking-wider">Cost</th>
                <th className="px-4 py-3 text-right font-mono text-[10px] uppercase tracking-wider">Duration</th>
                <th className="px-4 py-3 text-right font-mono text-[10px] uppercase tracking-wider">When</th>
              </tr>
            </thead>
            <tbody>
              {sessions.map((session) => (
                <tr key={session.id} className="border-b border-line/60 last:border-0">
                  <td className="max-w-xs truncate px-4 py-3 text-zinc-200">{session.title}</td>
                  <td className="px-4 py-3">
                    <span className="rounded border border-line px-1.5 py-0.5 font-mono text-[10px] uppercase text-zinc-500">
                      {session.stage}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right font-mono text-xs text-zinc-400">
                    {session.total_tokens.toLocaleString()}
                  </td>
                  <td className="px-4 py-3 text-right font-mono text-xs text-zinc-400">
                    ${session.total_cost_usd.toFixed(4)}
                  </td>
                  <td className="px-4 py-3 text-right font-mono text-xs text-zinc-400">
                    {session.duration_ms}ms
                  </td>
                  <td className="px-4 py-3 text-right font-mono text-[10px] text-zinc-600">
                    {new Date(session.created_at).toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Panel>
      )}
    </>
  )
}
