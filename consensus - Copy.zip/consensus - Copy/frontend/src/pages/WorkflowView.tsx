import { Background, Controls, ReactFlow, type Edge, type Node } from '@xyflow/react'
import '@xyflow/react/dist/style.css'
import { useMemo } from 'react'
import { useNavigate } from 'react-router-dom'
import { Button, Empty, PageHeading, Panel, PROVIDER_META } from '../components/ui'
import { useRun } from '../store/useRun'

const LANES: Record<string, { x: number; y: number }> = {
  'Intent Analyzer': { x: 40, y: 200 },
  'Prompt Planner': { x: 240, y: 200 },
  'GPT Specialist': { x: 450, y: 40 },
  'Claude Specialist': { x: 450, y: 140 },
  'Gemini Specialist': { x: 450, y: 240 },
  'Kimi Specialist': { x: 450, y: 340 },
  'Prompt Evaluator': { x: 690, y: 200 },
  'Consensus Builder': { x: 890, y: 200 },
  'Master Weaver': { x: 1090, y: 200 },
  'Quality Assurance': { x: 1290, y: 140 },
  Optimizer: { x: 1290, y: 260 },
}

const PROVIDER_FOR_AGENT: Record<string, string> = {
  'GPT Specialist': 'openai',
  'Claude Specialist': 'anthropic',
  'Gemini Specialist': 'google',
  'Kimi Specialist': 'moonshot',
}

const FLOW: [string, string][] = [
  ['Intent Analyzer', 'Prompt Planner'],
  ['Prompt Planner', 'GPT Specialist'],
  ['Prompt Planner', 'Claude Specialist'],
  ['Prompt Planner', 'Gemini Specialist'],
  ['Prompt Planner', 'Kimi Specialist'],
  ['GPT Specialist', 'Prompt Evaluator'],
  ['Claude Specialist', 'Prompt Evaluator'],
  ['Gemini Specialist', 'Prompt Evaluator'],
  ['Kimi Specialist', 'Prompt Evaluator'],
  ['Prompt Evaluator', 'Consensus Builder'],
  ['Consensus Builder', 'Master Weaver'],
  ['Master Weaver', 'Quality Assurance'],
  ['Master Weaver', 'Optimizer'],
]

export function WorkflowView() {
  const run = useRun((s) => s.run)
  const navigate = useNavigate()

  const { nodes, edges } = useMemo(() => {
    if (!run) return { nodes: [] as Node[], edges: [] as Edge[] }
    const logByAgent = Object.fromEntries(run.logs.map((log) => [log.agent, log]))

    const flowNodes: Node[] = Object.entries(LANES)
      .filter(([agent]) => logByAgent[agent])
      .map(([agent, position]) => {
        const log = logByAgent[agent]
        const provider = PROVIDER_FOR_AGENT[agent]
        const score = provider ? run.drafts[provider]?.score.total : undefined
        const color = provider ? PROVIDER_META[provider].color : '#E4E4E7'
        return {
          id: agent,
          position,
          data: {
            label: (
              <div className="text-left">
                <p className="text-[11px] font-semibold text-zinc-100">{agent}</p>
                <p className="font-mono text-[9px] text-zinc-500">
                  {log.status} · {log.duration_ms}ms · {log.tokens.toLocaleString()} tok
                </p>
                {score !== undefined && (
                  <p className="font-mono text-[9px]" style={{ color }}>score {score.toFixed(1)}</p>
                )}
              </div>
            ),
          },
          style: {
            background: 'rgba(18,20,26,0.9)',
            backdropFilter: 'blur(12px)',
            border: `1px solid ${log.status === 'complete' ? `${color}66` : '#f43f5e'}`,
            borderRadius: 10,
            padding: 9,
            width: 178,
          },
        }
      })

    const flowEdges: Edge[] = FLOW
      .filter(([source, target]) => logByAgent[source] && logByAgent[target])
      .map(([source, target]) => ({
        id: `${source}->${target}`,
        source,
        target,
        animated: true,
        style: {
          stroke: PROVIDER_FOR_AGENT[source]
            ? `${PROVIDER_META[PROVIDER_FOR_AGENT[source]].color}88`
            : 'rgba(161,161,170,0.35)',
        },
      }))

    return { nodes: flowNodes, edges: flowEdges }
  }, [run])

  if (!run) {
    return (
      <>
        <PageHeading eyebrow="Workflow" title="Nothing has run yet" />
        <Empty title="Run the workflow to see the graph." action="Start in the Workspace." />
        <div className="mt-4"><Button onClick={() => navigate('/app/workspace')}>Open Workspace</Button></div>
      </>
    )
  }

  return (
    <>
      <PageHeading
        eyebrow="Workflow"
        title="How the last run moved"
        description="Stage 4 fans out across every selected specialist and runs them concurrently; everything after it is sequential."
      />
      <Panel className="h-[540px] p-0">
        <ReactFlow nodes={nodes} edges={edges} fitView proOptions={{ hideAttribution: true }}>
          <Background color="rgba(161,161,170,0.2)" gap={22} />
          <Controls className="!bg-white/10" />
        </ReactFlow>
      </Panel>
      <div className="mt-4 grid gap-3 sm:grid-cols-3">
        <Panel><p className="eyebrow">Total duration</p><p className="mt-1 font-display text-2xl text-zinc-50">{run.totals.duration_ms}ms</p></Panel>
        <Panel delay={0.05}><p className="eyebrow">Tokens</p><p className="mt-1 font-display text-2xl text-zinc-50">{run.totals.tokens.toLocaleString()}</p></Panel>
        <Panel delay={0.1}><p className="eyebrow">Estimated cost</p><p className="mt-1 font-display text-2xl text-zinc-50">${run.totals.cost_usd.toFixed(4)}</p></Panel>
      </div>
    </>
  )
}
