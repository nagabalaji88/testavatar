import { useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Button, Empty, PageHeading, Panel, ProviderChip, PROVIDER_META } from '../components/ui'
import { useRun } from '../store/useRun'

const SECTION_LABELS: Record<string, string> = {
  role: 'Role', objective: 'Objective', context: 'Context', business_goal: 'Business goal',
  inputs: 'Inputs', variables: 'Variables', execution_plan: 'Execution plan',
  instructions: 'Instructions', reasoning_strategy: 'Reasoning strategy',
  constraints: 'Constraints', negative_constraints: 'Negative constraints',
  validation_rules: 'Validation rules', output_schema: 'Output schema', examples: 'Examples',
  edge_cases: 'Edge cases', quality_checklist: 'Quality checklist',
  failure_recovery: 'Failure recovery', notes: 'Final notes',
}

export function Comparison() {
  const run = useRun((s) => s.run)
  const navigate = useNavigate()
  const [section, setSection] = useState<string>('constraints')

  const providers = useMemo(() => (run ? Object.keys(run.drafts) : []), [run])

  if (!run) {
    return (
      <>
        <PageHeading eyebrow="Comparison" title="No drafts to compare" />
        <Empty title="Run the workflow first." action="Four drafts appear side by side once it finishes." />
        <div className="mt-4"><Button onClick={() => navigate('/app/workspace')}>Open Workspace</Button></div>
      </>
    )
  }

  const winner = run.master.provenance[section]
  const sections = Object.keys(SECTION_LABELS)

  return (
    <>
      <PageHeading
        eyebrow="Comparison"
        title="Where the specialists diverged"
        description="Pick a section to see all four drafts of it. The one the weaver chose is outlined; a missing panel means that specialist skipped the section entirely."
      />

      <div className="mb-4 flex flex-wrap gap-1.5">
        {sections.map((key) => {
          const source = run.master.provenance[key]
          const color = PROVIDER_META[source]?.color ?? '#52525B'
          return (
            <button
              key={key}
              onClick={() => setSection(key)}
              className={`focus-ring rounded-md border px-2.5 py-1 text-[11px] transition-colors ${
                section === key ? 'border-zinc-400 text-zinc-100' : 'border-line text-zinc-500 hover:text-zinc-300'
              }`}
            >
              <span className="mr-1.5 inline-block h-1.5 w-1.5 rounded-full align-middle" style={{ background: color }} />
              {SECTION_LABELS[key]}
            </button>
          )
        })}
      </div>

      <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
        {providers.map((provider, index) => {
          const draft = run.drafts[provider]
          const body = draft.sections[section]
          const isWinner = winner === provider
          const color = PROVIDER_META[provider].color
          return (
            <Panel
              key={provider}
              delay={index * 0.05}
              className={isWinner ? 'ring-1' : ''}
            >
              <div
                className="-m-5 mb-3 rounded-t-xl px-5 py-3"
                style={{ borderBottom: `1px solid ${color}33`, background: `${color}0d` }}
              >
                <div className="flex items-center gap-2">
                  <ProviderChip provider={provider} />
                  {isWinner && (
                    <span className="rounded border border-zinc-500 px-1.5 py-0.5 font-mono text-[9px] uppercase text-zinc-300">
                      chosen
                    </span>
                  )}
                  <span className="ml-auto font-mono text-[10px] text-zinc-500">
                    {draft.score.total.toFixed(1)}
                  </span>
                </div>
              </div>

              {body ? (
                <pre className="max-h-64 overflow-auto whitespace-pre-wrap font-mono text-[11px] leading-relaxed text-zinc-400">
                  {body}
                </pre>
              ) : (
                <p className="text-[11px] text-zinc-600">
                  Not written — {PROVIDER_META[provider].label} skipped this section.
                </p>
              )}

              <div className="mt-3 border-t border-line pt-3">
                <p className="eyebrow mb-1.5">Unique wording in this draft</p>
                <p className="font-mono text-[10px] leading-relaxed text-zinc-600">
                  {run.consensus.unique_contributions[provider]?.slice(0, 8).join(' · ') || 'nothing exclusive'}
                </p>
              </div>
            </Panel>
          )
        })}
      </div>

      <div className="mt-4 grid gap-3 lg:grid-cols-3">
        <Panel>
          <p className="eyebrow">Agreement</p>
          <p className="mt-1 font-display text-3xl text-zinc-50">
            {Math.round(run.consensus.agreement * 100)}%
          </p>
          <p className="mt-1 text-xs text-zinc-500">
            Average pairwise vocabulary overlap. Low is not bad — it means the drafts brought
            different material to merge.
          </p>
          <ul className="mt-3 space-y-1">
            {Object.entries(run.consensus.pairs).map(([pair, value]) => {
              const [left, right] = pair.split('|')
              return (
                <li key={pair} className="flex items-center gap-2 font-mono text-[10px] text-zinc-500">
                  <span className="w-32">{PROVIDER_META[left]?.label} ↔ {PROVIDER_META[right]?.label}</span>
                  <span className="h-1 flex-1 overflow-hidden rounded-full bg-white/10">
                    <span className="block h-full bg-zinc-400" style={{ width: `${value * 100}%` }} />
                  </span>
                  {Math.round(value * 100)}%
                </li>
              )
            })}
          </ul>
        </Panel>

        <Panel delay={0.05}>
          <p className="eyebrow">Shared gaps</p>
          {run.consensus.shared_gaps.length === 0 ? (
            <p className="mt-2 text-sm text-zinc-500">Nothing every draft missed.</p>
          ) : (
            <ul className="mt-2 space-y-1.5">
              {run.consensus.shared_gaps.map((gap) => (
                <li key={gap.metric} className="text-xs text-amber-300/80">
                  {gap.metric.replace('section:', 'section ').replace(/_/g, ' ')}
                  <span className="ml-1.5 font-mono text-[10px] text-zinc-600">
                    best {gap.ceiling.toFixed(0)}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </Panel>

        <Panel delay={0.1}>
          <p className="eyebrow">Contradictions</p>
          {run.consensus.contradictions.length === 0 ? (
            <p className="mt-2 text-sm text-zinc-500">No section was described in incompatible terms.</p>
          ) : (
            <ul className="mt-2 space-y-2">
              {run.consensus.contradictions.slice(0, 6).map((item, index) => (
                <li key={index} className="text-xs text-zinc-400">
                  <span className="text-zinc-200">{SECTION_LABELS[item.section] ?? item.section}</span>
                  {' — '}
                  {PROVIDER_META[item.between[0]]?.label} vs {PROVIDER_META[item.between[1]]?.label}
                  <span className="ml-1.5 font-mono text-[10px] text-zinc-600">
                    {Math.round(item.overlap * 100)}% overlap
                  </span>
                </li>
              ))}
            </ul>
          )}
        </Panel>
      </div>
    </>
  )
}
