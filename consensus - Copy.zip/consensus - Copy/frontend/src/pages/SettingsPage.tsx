import { Check, KeyRound, ShieldAlert } from 'lucide-react'
import { useEffect, useState } from 'react'
import { Button, PageHeading, Panel, ProviderChip } from '../components/ui'
import { settingsApi } from '../services/api'
import { useAuth } from '../store/useAuth'

interface ProviderRow {
  id: string
  label: string
  model: string
  mode: 'live' | 'simulated'
  circuit_open: boolean
  input_cost_per_mtok: number
  output_cost_per_mtok: number
}

interface StoredSetting { key: string; value: string; encrypted: boolean }

const KEY_FIELDS = [
  ['openai_api_key', 'OpenAI'],
  ['anthropic_api_key', 'Anthropic'],
  ['google_api_key', 'Google'],
  ['moonshot_api_key', 'Moonshot'],
]

export function SettingsPage() {
  const [providers, setProviders] = useState<ProviderRow[]>([])
  const [runtime, setRuntime] = useState<Record<string, string | number>>({})
  const [stored, setStored] = useState<StoredSetting[]>([])
  const [drafts, setDrafts] = useState<Record<string, string>>({})
  const [saved, setSaved] = useState<string>('')
  const [error, setError] = useState('')
  const role = useAuth((s) => s.user?.role)
  const isAdmin = role === 'admin'

  const load = () => settingsApi.read().then((data) => {
    setProviders(data.providers)
    setRuntime(data.runtime)
    setStored(data.settings)
  }).catch(() => undefined)

  useEffect(() => { load() }, [])

  const save = async (key: string) => {
    setError('')
    try {
      await settingsApi.write(key, drafts[key] ?? '', true)
      setDrafts((current) => ({ ...current, [key]: '' }))
      setSaved(key)
      setTimeout(() => setSaved(''), 2000)
      load()
    } catch {
      setError('Only an admin can change provider keys.')
    }
  }

  return (
    <>
      <PageHeading
        eyebrow="Settings"
        title="Providers, keys and runtime limits"
        description="Keys are encrypted before they reach the database and only ever returned masked. A provider with no key runs against the local simulator instead."
      />

      <div className="grid gap-4 lg:grid-cols-2">
        <Panel>
          <p className="eyebrow">Providers</p>
          <ul className="mt-3 space-y-2">
            {providers.map((provider) => (
              <li key={provider.id} className="rounded-lg border border-line bg-white/[0.03] p-3">
                <div className="flex flex-wrap items-center gap-2">
                  <ProviderChip provider={provider.id} />
                  <span className="font-mono text-[10px] text-zinc-500">{provider.model}</span>
                  <span className={`ml-auto font-mono text-[10px] uppercase ${
                    provider.mode === 'live' ? 'text-emerald-400' : 'text-zinc-500'}`}>
                    {provider.mode}
                  </span>
                </div>
                <p className="mt-1.5 font-mono text-[10px] text-zinc-600">
                  ${provider.input_cost_per_mtok}/M in · ${provider.output_cost_per_mtok}/M out
                </p>
                {provider.circuit_open && (
                  <p className="mt-1.5 flex items-center gap-1.5 text-[11px] text-amber-400">
                    <ShieldAlert className="h-3 w-3" /> Circuit open — repeated failures, using the simulator.
                  </p>
                )}
              </li>
            ))}
          </ul>
        </Panel>

        <Panel delay={0.05}>
          <p className="eyebrow">API keys</p>
          {!isAdmin && (
            <p className="mt-2 text-[11px] text-amber-400">
              Your role can read this page but not change keys.
            </p>
          )}
          <div className="mt-3 space-y-3">
            {KEY_FIELDS.map(([key, label]) => {
              const existing = stored.find((s) => s.key === key)
              return (
                <div key={key}>
                  <label className="eyebrow flex items-center gap-1.5" htmlFor={key}>
                    <KeyRound className="h-3 w-3" /> {label}
                  </label>
                  {existing && (
                    <p className="mt-1 font-mono text-[10px] text-zinc-600">stored: {existing.value}</p>
                  )}
                  <div className="mt-1.5 flex gap-2">
                    <input
                      id={key}
                      type="password"
                      value={drafts[key] ?? ''}
                      onChange={(e) => setDrafts((c) => ({ ...c, [key]: e.target.value }))}
                      placeholder="Paste a key to replace"
                      className="field focus-ring"
                      disabled={!isAdmin}
                    />
                    <Button variant="ghost" onClick={() => save(key)} disabled={!isAdmin || !drafts[key]}>
                      {saved === key ? <Check className="h-4 w-4" /> : 'Save'}
                    </Button>
                  </div>
                </div>
              )
            })}
          </div>
          {error && <p className="mt-3 text-xs text-rose-400">{error}</p>}
        </Panel>
      </div>

      <Panel className="mt-4" delay={0.1}>
        <p className="eyebrow">Runtime</p>
        <dl className="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {Object.entries(runtime).map(([key, value]) => (
            <div key={key} className="flex items-center justify-between rounded-lg border border-line px-3 py-2">
              <dt className="text-xs text-zinc-500">{key.replace(/_/g, ' ')}</dt>
              <dd className="font-mono text-xs text-zinc-300">{String(value)}</dd>
            </div>
          ))}
        </dl>
        <p className="mt-3 text-[11px] text-zinc-600">
          These come from environment variables on the backend. Change them in the deployment
          config rather than here, so a restart cannot silently revert them.
        </p>
      </Panel>
    </>
  )
}
