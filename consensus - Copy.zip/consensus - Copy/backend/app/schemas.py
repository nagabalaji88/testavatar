"""API contracts. Services below this layer speak plain dicts."""
from __future__ import annotations

from datetime import datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field


class LoginRequest(BaseModel):
    email: str
    password: str


class UserOut(BaseModel):
    id: str
    email: str
    full_name: str
    role: str

    model_config = ConfigDict(from_attributes=True)


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut


class GenerateRequest(BaseModel):
    problem_statement: str = Field(min_length=15)
    expected_output: str = ""
    constraints: list[str] = []
    target_models: list[str] = []
    context: str = ""
    business_goal: str = ""
    providers: list[str] = []
    title: str = ""
    project_id: Optional[str] = None


class AnalyzeRequest(BaseModel):
    problem_statement: str = Field(min_length=15)
    expected_output: str = ""
    constraints: list[str] = []


class EvaluateRequest(BaseModel):
    sections: dict[str, str]


class ExportRequest(BaseModel):
    master_prompt_id: str
    format: str = "markdown"


class ReviseRequest(BaseModel):
    content: str
    change_note: str = ""


class ProjectCreate(BaseModel):
    name: str
    description: str = ""


class SettingUpdate(BaseModel):
    key: str
    value: str
    encrypted: bool = False


class SessionSummary(BaseModel):
    id: str
    title: str
    stage: str
    total_tokens: int
    total_cost_usd: float
    duration_ms: int
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)
