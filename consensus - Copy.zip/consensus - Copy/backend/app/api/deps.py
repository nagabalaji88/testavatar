"""Auth, RBAC and a small in-process rate limiter."""
from __future__ import annotations

import time
from collections import defaultdict, deque

from fastapi import Depends, Header, HTTPException, Request, status
from sqlalchemy.orm import Session

from .. import models
from ..core.config import settings
from ..core.database import get_db
from ..core.security import decode_token

_hits: dict[str, deque] = defaultdict(deque)


def rate_limit(request: Request) -> None:
    """Fixed-window limiter keyed on client host. Swap for Redis in a multi-worker deploy."""
    key = request.client.host if request.client else "anonymous"
    now = time.time()
    window = _hits[key]
    while window and now - window[0] > 60:
        window.popleft()
    if len(window) >= settings.rate_limit_per_minute:
        raise HTTPException(
            status.HTTP_429_TOO_MANY_REQUESTS,
            f"Rate limit of {settings.rate_limit_per_minute} requests per minute reached.",
        )
    window.append(now)


def current_user(
    authorization: str = Header(default=""),
    db: Session = Depends(get_db),
) -> models.User:
    if not authorization.lower().startswith("bearer "):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Sign in to continue.")
    payload = decode_token(authorization.split(" ", 1)[1])
    if not payload:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Session expired. Sign in again.")
    user = db.get(models.User, payload.get("sub", ""))
    if not user or not user.is_active:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Account is not active.")
    return user


def require_roles(*roles: str):
    def guard(user: models.User = Depends(current_user)) -> models.User:
        if roles and user.role not in roles and user.role != "admin":
            raise HTTPException(
                status.HTTP_403_FORBIDDEN, f"This action needs one of: {', '.join(roles)}."
            )
        return user

    return guard
