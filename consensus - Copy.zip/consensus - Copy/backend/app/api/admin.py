"""Projects, settings, provider keys and the audit trail."""
from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import models, schemas
from ..core.config import settings as app_settings
from ..core.database import get_db
from ..core.security import mask, seal, unseal
from ..services.providers import CATALOG, PROVIDERS, breaker, is_live
from .deps import current_user, require_roles

router = APIRouter(tags=["admin"])


@router.get("/projects")
def projects(db: Session = Depends(get_db), user: models.User = Depends(current_user)):
    rows = db.scalars(select(models.Project)).all()
    return [
        {"id": p.id, "name": p.name, "description": p.description,
         "sessions": len(p.sessions), "created_at": p.created_at}
        for p in rows
    ]


@router.post("/projects")
def create_project(payload: schemas.ProjectCreate, db: Session = Depends(get_db),
                   user: models.User = Depends(require_roles("engineer"))):
    project = models.Project(name=payload.name, description=payload.description, owner_id=user.id)
    db.add(project)
    db.commit()
    db.refresh(project)
    return {"id": project.id, "name": project.name}


@router.get("/settings")
def get_settings(db: Session = Depends(get_db), user: models.User = Depends(current_user)):
    rows = db.scalars(select(models.Setting)).all()
    stored = [
        {
            "key": s.key,
            "value": mask(unseal(s.value) or "") if s.encrypted else s.value,
            "encrypted": s.encrypted,
            "updated_at": s.updated_at,
        }
        for s in rows
    ]
    return {
        "settings": stored,
        "runtime": {
            "rate_limit_per_minute": app_settings.rate_limit_per_minute,
            "max_retries": app_settings.max_retries,
            "circuit_breaker_failures": app_settings.circuit_breaker_failures,
            "request_timeout_seconds": app_settings.request_timeout_seconds,
            "database": app_settings.database_url.split(":")[0],
        },
        "providers": [
            {
                "id": provider,
                "label": CATALOG[provider]["label"],
                "model": CATALOG[provider]["model"],
                "color": CATALOG[provider]["color"],
                "mode": "live" if is_live(provider) else "simulated",
                "circuit_open": breaker.is_open(provider),
                "input_cost_per_mtok": CATALOG[provider]["in_cost"],
                "output_cost_per_mtok": CATALOG[provider]["out_cost"],
            }
            for provider in PROVIDERS
        ],
    }


@router.put("/settings")
def upsert_setting(payload: schemas.SettingUpdate, db: Session = Depends(get_db),
                   user: models.User = Depends(require_roles("admin"))):
    """Secrets are sealed before they touch the database and masked on the way out."""
    row = db.scalar(select(models.Setting).where(models.Setting.key == payload.key))
    value = seal(payload.value) if payload.encrypted else payload.value
    if row:
        row.value, row.encrypted = value, payload.encrypted
    else:
        db.add(models.Setting(key=payload.key, value=value, encrypted=payload.encrypted))
    db.add(models.AuditEvent(actor=user.full_name, action="settings.update", target=payload.key))
    db.commit()
    return {"key": payload.key, "stored": True, "encrypted": payload.encrypted}


@router.get("/audit")
def audit(limit: int = 100, db: Session = Depends(get_db),
          user: models.User = Depends(current_user)):
    rows = db.scalars(
        select(models.AuditEvent).order_by(models.AuditEvent.created_at.desc()).limit(limit)
    ).all()
    return [
        {"id": e.id, "actor": e.actor, "action": e.action, "target": e.target,
         "detail": e.detail, "created_at": e.created_at}
        for e in rows
    ]


@router.get("/agent-logs")
def agent_logs(limit: int = 200, db: Session = Depends(get_db),
               user: models.User = Depends(current_user)):
    rows = db.scalars(
        select(models.AgentLog).order_by(models.AgentLog.created_at.desc()).limit(limit)
    ).all()
    return [
        {
            "id": log.id, "session_id": log.session_id, "agent": log.agent, "stage": log.stage,
            "status": log.status, "summary": log.summary, "tokens": log.tokens,
            "cost_usd": log.cost_usd, "duration_ms": log.duration_ms,
            "confidence": log.confidence, "warnings": log.warnings,
            "recommendations": log.recommendations, "created_at": log.created_at,
        }
        for log in rows
    ]
