"""The generation pipeline and its individual stages."""
from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import models, schemas
from ..agents.analysis import IntentAnalyzer, PromptPlanner
from ..agents.orchestrator import STAGES, agent_registry, run_workflow
from ..agents.specialists import run_specialists
from ..agents.synthesis import ConsensusBuilder, MasterWeaver, PromptEvaluator
from ..core.database import get_db
from ..services.evaluation import WEIGHTS, evaluate
from ..services.persistence import persist_run
from ..services.providers import CATALOG, PROVIDERS, is_live
from ..services.sections import SECTIONS
from .deps import current_user, rate_limit

router = APIRouter(tags=["workflow"])


@router.post("/generate", dependencies=[Depends(rate_limit)])
def generate(
    payload: schemas.GenerateRequest,
    db: Session = Depends(get_db),
    user: models.User = Depends(current_user),
):
    """Stages 1-10. Returns the session id plus everything the UI needs to render the run."""
    data = payload.model_dump()
    state = run_workflow(data, data.get("providers") or None)
    session = persist_run(db, state, data, user)
    master = session.master
    return {
        "session_id": session.id,
        "stage": state["stage"],
        "intent": state["intent"],
        "plan": state["plan"],
        "drafts": {
            provider: {
                "sections": sections,
                "content": state["draft_meta"][provider]["content"],
                "meta": state["draft_meta"][provider],
                "score": state["scores"][provider],
            }
            for provider, sections in state["drafts"].items()
        },
        "ranking": state["ranking"],
        "consensus": state["consensus"],
        "master": {
            "id": master.id if master else None,
            "title": session.title,
            "content": state["master_content"],
            "sections": state["master_sections"],
            "provenance": state["provenance"],
            "score": state["final_score"],
        },
        "qa_report": state["qa_report"],
        "logs": state["logs"],
        "totals": {
            "tokens": state["total_tokens"],
            "cost_usd": state["total_cost_usd"],
            "duration_ms": state["duration_ms"],
        },
    }


@router.post("/analyze")
def analyze(payload: schemas.AnalyzeRequest, user: models.User = Depends(current_user)):
    state = PromptPlanner().run(IntentAnalyzer().run({**payload.model_dump(), "logs": []}))
    return {"intent": state["intent"], "plan": state["plan"], "logs": state["logs"]}


@router.post("/draft")
def draft(payload: schemas.GenerateRequest, user: models.User = Depends(current_user)):
    state = PromptPlanner().run(IntentAnalyzer().run({**payload.model_dump(), "logs": []}))
    state = run_specialists(state, payload.providers or PROVIDERS)
    return {"drafts": state["drafts"], "meta": state["draft_meta"], "logs": state["logs"]}


@router.post("/evaluate")
def evaluate_sections(payload: schemas.EvaluateRequest, user: models.User = Depends(current_user)):
    return {"evaluation": evaluate(payload.sections), "weights": WEIGHTS}


@router.post("/consensus")
def consensus(payload: schemas.GenerateRequest, user: models.User = Depends(current_user)):
    state = PromptPlanner().run(IntentAnalyzer().run({**payload.model_dump(), "logs": []}))
    state = run_specialists(state, payload.providers or PROVIDERS)
    state = ConsensusBuilder().run(PromptEvaluator().run(state))
    return {"consensus": state["consensus"], "scores": state["scores"], "logs": state["logs"]}


@router.post("/weave")
def weave(payload: schemas.GenerateRequest, user: models.User = Depends(current_user)):
    state = PromptPlanner().run(IntentAnalyzer().run({**payload.model_dump(), "logs": []}))
    state = run_specialists(state, payload.providers or PROVIDERS)
    state = MasterWeaver().run(ConsensusBuilder().run(PromptEvaluator().run(state)))
    return {"sections": state["master_sections"], "provenance": state["provenance"]}


@router.get("/workflow/meta")
def workflow_meta(user: models.User = Depends(current_user)):
    return {
        "stages": STAGES,
        "agents": agent_registry(),
        "sections": SECTIONS,
        "weights": WEIGHTS,
        "providers": [
            {
                "id": provider,
                "label": CATALOG[provider]["label"],
                "model": CATALOG[provider]["model"],
                "color": CATALOG[provider]["color"],
                "strengths": CATALOG[provider]["strengths"],
                "mode": "live" if is_live(provider) else "simulated",
            }
            for provider in PROVIDERS
        ],
    }


@router.get("/sessions/{session_id}")
def get_session(session_id: str, db: Session = Depends(get_db),
                user: models.User = Depends(current_user)):
    session = db.get(models.PromptSession, session_id)
    if not session:
        return {"error": "not_found"}
    consensus_row = db.scalar(
        select(models.ConsensusResult).where(models.ConsensusResult.session_id == session_id)
    )
    drafts = []
    for draft in session.drafts:
        drafts.append({
            "provider": draft.provider, "agent": draft.agent, "content": draft.content,
            "sections": draft.sections, "tokens": draft.tokens, "cost_usd": draft.cost_usd,
            "duration_ms": draft.duration_ms, "simulated": draft.simulated,
            "score": {
                "total": draft.score.total, "rank": draft.score.rank,
                "metrics": draft.score.metrics, "notes": draft.score.notes,
            } if draft.score else None,
        })
    return {
        "session": {
            "id": session.id, "title": session.title, "stage": session.stage,
            "problem_statement": session.problem_statement,
            "expected_output": session.expected_output, "constraints": session.constraints,
            "intent": session.intent, "total_tokens": session.total_tokens,
            "total_cost_usd": session.total_cost_usd, "duration_ms": session.duration_ms,
            "created_at": session.created_at,
        },
        "drafts": drafts,
        "consensus": {
            "agreement": consensus_row.agreement,
            "common_strengths": consensus_row.common_strengths,
            "shared_gaps": consensus_row.shared_gaps,
            "contradictions": consensus_row.contradictions,
            "unique_contributions": consensus_row.unique_contributions,
            "section_winners": consensus_row.section_winners,
        } if consensus_row else None,
        "master": {
            "id": session.master.id, "title": session.master.title,
            "content": session.master.content, "sections": session.master.sections,
            "provenance": session.master.provenance, "score": session.master.score,
            "qa_report": session.master.qa_report, "version": session.master.version,
            "starred": session.master.starred,
        } if session.master else None,
        "logs": [
            {
                "agent": log.agent, "stage": log.stage, "status": log.status,
                "summary": log.summary, "input_digest": log.input_digest,
                "output_digest": log.output_digest, "tokens": log.tokens,
                "cost_usd": log.cost_usd, "duration_ms": log.duration_ms,
                "confidence": log.confidence, "warnings": log.warnings,
                "recommendations": log.recommendations,
            }
            for log in session.logs
        ],
    }
