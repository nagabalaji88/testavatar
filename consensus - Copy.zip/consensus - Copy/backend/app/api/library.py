"""History, prompt library, versioning and export."""
from fastapi import APIRouter, Depends, Response
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import models, schemas
from ..core.database import get_db
from ..services.export import FORMATS, MEDIA_TYPES, filename, render_export
from ..services.persistence import analytics_snapshot, revise_master
from .deps import current_user

router = APIRouter(tags=["library"])


@router.get("/history", response_model=list[schemas.SessionSummary])
def history(limit: int = 50, db: Session = Depends(get_db),
            user: models.User = Depends(current_user)):
    return db.scalars(
        select(models.PromptSession)
        .order_by(models.PromptSession.created_at.desc())
        .limit(limit)
    ).all()


@router.get("/library")
def library(starred_only: bool = False, db: Session = Depends(get_db),
            user: models.User = Depends(current_user)):
    query = select(models.MasterPrompt).order_by(models.MasterPrompt.score.desc())
    if starred_only:
        query = query.where(models.MasterPrompt.starred.is_(True))
    return [
        {
            "id": m.id, "session_id": m.session_id, "title": m.title, "score": m.score,
            "version": m.version, "starred": m.starred, "created_at": m.created_at,
            "passed_qa": m.qa_report.get("passed", False),
            "providers": sorted(set(m.provenance.values())),
            "preview": m.content[:220],
        }
        for m in db.scalars(query).all()
    ]


@router.get("/library/{master_id}")
def get_master(master_id: str, db: Session = Depends(get_db),
               user: models.User = Depends(current_user)):
    master = db.get(models.MasterPrompt, master_id)
    if not master:
        return {"error": "not_found"}
    versions = db.scalars(
        select(models.VersionHistory)
        .where(models.VersionHistory.master_prompt_id == master_id)
        .order_by(models.VersionHistory.version.desc())
    ).all()
    return {
        "master": {
            "id": master.id, "session_id": master.session_id, "title": master.title,
            "content": master.content, "sections": master.sections,
            "provenance": master.provenance, "score": master.score,
            "qa_report": master.qa_report, "version": master.version,
            "starred": master.starred,
        },
        "versions": [
            {"version": v.version, "change_note": v.change_note, "author": v.author,
             "created_at": v.created_at}
            for v in versions
        ],
    }


@router.post("/library/{master_id}/revise")
def revise(master_id: str, payload: schemas.ReviseRequest, db: Session = Depends(get_db),
           user: models.User = Depends(current_user)):
    master = revise_master(db, master_id, payload.content, payload.change_note, user.full_name)
    if not master:
        return {"error": "not_found"}
    return {"id": master.id, "version": master.version}


@router.post("/library/{master_id}/star")
def toggle_star(master_id: str, db: Session = Depends(get_db),
                user: models.User = Depends(current_user)):
    master = db.get(models.MasterPrompt, master_id)
    if not master:
        return {"error": "not_found"}
    master.starred = not master.starred
    db.commit()
    return {"id": master.id, "starred": master.starred}


@router.get("/export/formats")
def export_formats(user: models.User = Depends(current_user)):
    return {"formats": FORMATS}


@router.post("/export")
def export(payload: schemas.ExportRequest, db: Session = Depends(get_db),
           user: models.User = Depends(current_user)):
    master = db.get(models.MasterPrompt, payload.master_prompt_id)
    if not master:
        return {"error": "not_found"}
    body = render_export(
        payload.format, master.title, master.sections,
        {"score": master.score, "version": master.version,
         "providers": sorted(set(master.provenance.values()))},
    )
    return Response(
        content=body,
        media_type=MEDIA_TYPES[payload.format],
        headers={
            "Content-Disposition": f'attachment; filename="{filename(master.title, payload.format)}"'
        },
    )


@router.get("/analytics")
def analytics(db: Session = Depends(get_db), user: models.User = Depends(current_user)):
    return analytics_snapshot(db)
