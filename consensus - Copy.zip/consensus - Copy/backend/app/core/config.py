"""Settings. Every value is overridable through AEGIS-style env vars (prefix FORGE_)."""
from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_name: str = "PromptForge"
    api_prefix: str = "/api"
    database_url: str = "sqlite:///./forge.db"
    secret_key: str = "forge-dev-secret-change-me"
    token_ttl_seconds: int = 60 * 60 * 12

    # Provider credentials. Any that are absent fall back to the local simulator,
    # so the full consensus workflow runs with no keys at all.
    openai_api_key: str = ""
    anthropic_api_key: str = ""
    google_api_key: str = ""
    moonshot_api_key: str = ""

    openai_model: str = "gpt-4o-mini"
    anthropic_model: str = "claude-sonnet-4-5"
    google_model: str = "gemini-2.0-flash"
    moonshot_model: str = "moonshot-v1-32k"

    request_timeout_seconds: int = 90
    max_retries: int = 2
    circuit_breaker_failures: int = 3
    rate_limit_per_minute: int = 60

    cors_origins: str = "http://localhost:5173,http://127.0.0.1:5173"

    model_config = SettingsConfigDict(env_file=".env", env_prefix="FORGE_", extra="ignore")

    @property
    def cors_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
