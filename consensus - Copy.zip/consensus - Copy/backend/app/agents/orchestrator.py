"""LangGraph-shaped workflow: ten stages, one of which fans out across providers."""
from __future__ import annotations

import time
from typing import Optional

from ..services.providers import PROVIDERS
from .analysis import IntentAnalyzer, PromptPlanner
from .base import State
from .specialists import Specialist, run_specialists
from .synthesis import ConsensusBuilder, MasterWeaver, Optimizer, PromptEvaluator, QualityAssurance

STAGES = [
    "input_analysis", "intent", "planning", "drafting", "evaluation",
    "consensus", "weaving", "validation", "optimization", "export",
]


def agent_registry() -> list[dict]:
    """Used by the Agent Monitor screen and the /agents endpoint."""
    agents = [IntentAnalyzer(), PromptPlanner(), *[Specialist(p) for p in PROVIDERS],
              PromptEvaluator(), ConsensusBuilder(), MasterWeaver(), QualityAssurance()]
    return [
        {"index": index, "name": a.name, "stage": a.stage, "description": a.description}
        for index, a in enumerate(agents, start=1)
    ]


def run_workflow(payload: dict, providers: Optional[list[str]] = None) -> State:
    started = time.perf_counter()
    providers = [p for p in (providers or PROVIDERS) if p in PROVIDERS] or PROVIDERS

    state: State = {
        "problem_statement": payload["problem_statement"],
        "expected_output": payload.get("expected_output", ""),
        "constraints": payload.get("constraints", []),
        "target_models": payload.get("target_models", []),
        "context": payload.get("context", ""),
        "business_goal": payload.get("business_goal", ""),
        "logs": [],
    }

    state = IntentAnalyzer().run(state)
    state = PromptPlanner().run(state)
    state = run_specialists(state, providers)
    state = PromptEvaluator().run(state)
    state = ConsensusBuilder().run(state)
    state = MasterWeaver().run(state)
    state = QualityAssurance().run(state)
    state = Optimizer().run(state)

    meta = state.get("draft_meta", {})
    state["total_tokens"] = sum(m["tokens"] for m in meta.values())
    state["total_cost_usd"] = round(sum(m["cost_usd"] for m in meta.values()), 6)
    state["duration_ms"] = int((time.perf_counter() - started) * 1000)
    state["stage"] = "complete"
    return state
