"""Agents 1 and 2 — intent extraction and prompt planning."""
from __future__ import annotations

import re

from ..services.sections import SECTIONS
from .base import Agent, State

TASK_SIGNALS = {
    "extraction": ["extract", "parse", "pull out", "identify fields", "scrape"],
    "classification": ["classify", "categorise", "categorize", "label", "triage", "route"],
    "generation": ["write", "draft", "generate", "compose", "create"],
    "summarisation": ["summarise", "summarize", "condense", "tl;dr", "digest"],
    "transformation": ["convert", "translate", "rewrite", "reformat", "migrate"],
    "analysis": ["analyse", "analyze", "evaluate", "assess", "compare", "review"],
    "agentic": ["tool", "function call", "agent", "workflow", "orchestrate"],
}

AMBIGUITY_MARKERS = [
    "etc", "and so on", "something like", "appropriate", "as needed", "reasonable",
    "good", "nice", "better", "handle it", "figure out",
]


def classify(text: str) -> str:
    lowered = text.lower()
    best, hits = "generation", 0
    for task, markers in TASK_SIGNALS.items():
        count = sum(1 for marker in markers if marker in lowered)
        if count > hits:
            best, hits = task, count
    return best


def find_ambiguity(text: str) -> list[str]:
    lowered = text.lower()
    return [marker for marker in AMBIGUITY_MARKERS if marker in lowered]


class IntentAnalyzer(Agent):
    name = "Intent Analyzer"
    stage = "intent"
    description = "Extracts objective, constraints, risks and the questions worth asking."

    def handle(self, state: State):
        problem = state["problem_statement"]
        constraints = list(state.get("constraints") or [])
        task_type = classify(problem)
        vague = find_ambiguity(problem)

        clarifications: list[str] = []
        if not state.get("expected_output"):
            clarifications.append("What exact output format should the caller receive?")
        if not constraints:
            clarifications.append("What must the answer never do?")
        if vague:
            clarifications.append(
                f"These terms are open to interpretation: {', '.join(vague[:4])}."
            )
        if not re.search(r"\b(user|customer|team|analyst|engineer|caller)\b", problem, re.I):
            clarifications.append("Who consumes the output, and what do they do with it?")

        risks = []
        if task_type in {"extraction", "analysis"}:
            risks.append("Fabricated values when the source lacks the requested field.")
        if len(problem.split()) < 25:
            risks.append("The statement is short; the model will fill gaps with assumptions.")
        if not state.get("expected_output"):
            risks.append("Undefined output shape makes downstream parsing unreliable.")

        intent = {
            "objective": problem.strip().split("\n")[0][:220],
            "task_type": task_type,
            "constraints": constraints,
            "expected_output": state.get("expected_output", ""),
            "context": state.get("context", ""),
            "business_goal": state.get("business_goal", ""),
            "ambiguities": vague,
            "risks": risks,
            "clarifications": clarifications,
        }
        state["intent"] = intent
        confidence = round(max(0.35, 0.95 - 0.1 * len(clarifications) - 0.04 * len(vague)), 2)
        return state, {
            "summary": f"Classified as a {task_type} task with {len(constraints)} explicit "
                       f"constraints and {len(clarifications)} open questions.",
            "input_digest": problem[:280],
            "output_digest": f"task={task_type} risks={len(risks)}",
            "confidence": confidence,
            "warnings": [f"ambiguous wording: {v}" for v in vague[:3]],
            "recommendations": clarifications[:3],
        }


class PromptPlanner(Agent):
    name = "Prompt Planner"
    stage = "planning"
    description = "Turns intent into the modular section brief every specialist writes against."

    def handle(self, state: State):
        intent = state["intent"]
        targets = state.get("target_models") or []
        plan = {
            "sections": SECTIONS,
            "persona": f"a specialist in {intent['task_type']} work",
            "target_models": targets,
            "target_label": ", ".join(targets) if targets else "provider-neutral",
            "must_include": ["output_schema", "negative_constraints", "edge_cases"],
            "open_questions": intent["clarifications"],
        }
        state["plan"] = plan
        return state, {
            "summary": f"Planned {len(SECTIONS)} sections for {plan['target_label']} targets.",
            "output_digest": ", ".join(plan["must_include"]),
            "confidence": 0.88,
            "recommendations": ["Resolve open questions before shipping the prompt."]
            if plan["open_questions"] else [],
        }
