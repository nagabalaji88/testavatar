"""Agents 3-6 — the four provider specialists, run in parallel."""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor

from ..services.drafting import PROFILES, draft_sections
from ..services.providers import CATALOG, complete
from ..services.sections import parse, render
from .base import Agent, State

SYSTEM = (
    "You are a prompt engineering specialist. Write a reusable master prompt using exactly "
    "these markdown section headings, in order, and nothing else outside them."
)


class Specialist(Agent):
    """One vendor's draft. Live when a key is configured, simulated otherwise."""

    provider: str = "openai"
    stage = "drafting"

    def __init__(self, provider: str) -> None:
        self.provider = provider
        spec = CATALOG[provider]
        self.name = f"{spec['label']} Specialist"
        self.description = f"Optimises for {', '.join(spec['strengths'])}."

    def handle(self, state: State):
        intent, plan = state["intent"], state["plan"]
        baseline = draft_sections(self.provider, intent, plan)

        user = (
            f"Task type: {intent['task_type']}\n"
            f"Objective: {intent['objective']}\n"
            f"Expected output: {intent['expected_output'] or 'unspecified'}\n"
            f"Constraints: {'; '.join(intent['constraints']) or 'none stated'}\n"
            f"Emphasise: {', '.join(PROFILES[self.provider]['deep'])}\n\n"
            f"Sections: {', '.join(plan['sections'])}"
        )
        result = complete(self.provider, SYSTEM, user, simulator=lambda: render(baseline))
        sections = parse(result.text) if not result.simulated else baseline
        if not sections:
            sections = baseline

        state.setdefault("drafts", {})[self.provider] = sections
        state.setdefault("draft_meta", {})[self.provider] = {
            "tokens": result.tokens,
            "cost_usd": result.cost_usd,
            "duration_ms": result.duration_ms,
            "simulated": result.simulated,
            "agent": self.name,
            "content": render(sections),
        }
        return state, {
            "summary": f"Drafted {len(sections)} sections "
                       f"({'simulated' if result.simulated else 'live'} inference).",
            "output_digest": ", ".join(list(sections)[:6]),
            "tokens": result.tokens,
            "cost_usd": result.cost_usd,
            "confidence": 0.7 if result.simulated else 0.9,
            "warnings": result.warnings,
        }


def run_specialists(state: State, providers: list[str]) -> State:
    """Stage 4 runs the four vendors concurrently — they do not depend on each other."""
    agents = [Specialist(provider) for provider in providers]
    # Each specialist gets its own slice of state so the threads never share a
    # mutable list; only its own draft and log entry are merged back.
    def _isolated(agent: Specialist) -> State:
        return agent.run({"intent": state["intent"], "plan": state["plan"], "logs": []})

    with ThreadPoolExecutor(max_workers=len(agents) or 1) as pool:
        results = list(pool.map(_isolated, agents))

    for partial in results:
        state.setdefault("drafts", {}).update(partial.get("drafts", {}))
        state.setdefault("draft_meta", {}).update(partial.get("draft_meta", {}))
        state.setdefault("logs", []).extend(partial.get("logs", []))
    return state
