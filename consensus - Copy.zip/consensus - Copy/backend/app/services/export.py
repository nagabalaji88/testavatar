"""Export engine: one prompt, seven formats."""
from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from xml.sax.saxutils import escape

import yaml

from .sections import HEADINGS, SECTIONS

FORMATS = ["markdown", "json", "yaml", "xml", "txt", "template", "html"]
MEDIA_TYPES = {
    "markdown": "text/markdown", "json": "application/json", "yaml": "application/x-yaml",
    "xml": "application/xml", "txt": "text/plain", "template": "text/plain",
    "html": "text/html",
}
EXTENSIONS = {
    "markdown": "md", "json": "json", "yaml": "yaml", "xml": "xml",
    "txt": "txt", "template": "tmpl", "html": "html",
}


def _ordered(sections: dict[str, str]) -> list[tuple[str, str]]:
    return [(key, sections[key]) for key in SECTIONS if sections.get(key)]


def render_export(fmt: str, title: str, sections: dict[str, str], meta: dict) -> str:
    if fmt not in FORMATS:
        raise ValueError(f"unsupported format: {fmt}")
    generated = datetime.now(timezone.utc).isoformat(timespec="seconds")

    if fmt == "markdown":
        head = [f"# {title}", "", f"> Generated {generated} · consensus score "
                                 f"{meta.get('score', 0)}/100", ""]
        body = [f"## {HEADINGS[key]}\n{value}" for key, value in _ordered(sections)]
        return "\n".join(head + body) + "\n"

    if fmt == "json":
        return json.dumps(
            {"title": title, "generated_at": generated, "meta": meta,
             "sections": dict(_ordered(sections))},
            indent=2,
        )

    if fmt == "yaml":
        return yaml.safe_dump(
            {"title": title, "generated_at": generated, "meta": meta,
             "sections": dict(_ordered(sections))},
            sort_keys=False, allow_unicode=True, default_flow_style=False,
        )

    if fmt == "xml":
        parts = [
            '<?xml version="1.0" encoding="UTF-8"?>',
            f'<master_prompt title="{escape(title)}" generated="{generated}" '
            f'score="{meta.get("score", 0)}">',
        ]
        for key, value in _ordered(sections):
            parts.append(f"  <{key}>{escape(value)}</{key}>")
        parts.append("</master_prompt>")
        return "\n".join(parts)

    if fmt == "txt":
        blocks = [f"{HEADINGS[key].upper()}\n{'-' * len(HEADINGS[key])}\n{value}"
                  for key, value in _ordered(sections)]
        return f"{title}\n{'=' * len(title)}\n\n" + "\n\n".join(blocks) + "\n"

    if fmt == "template":
        # A reusable template: placeholders left intact, with a declared variable header.
        body = "\n\n".join(f"## {HEADINGS[k]}\n{v}" for k, v in _ordered(sections))
        variables = sorted(set(re.findall(r"\{\{\s*([a-zA-Z_][\w]*)\s*\}\}", body)))
        header = "\n".join(f"# @var {name}" for name in variables)
        return f"# @template {title}\n{header}\n\n{body}\n"

    escaped = [
        f"<section><h2>{escape(HEADINGS[key])}</h2><pre>{escape(value)}</pre></section>"
        for key, value in _ordered(sections)
    ]
    return (
        "<!doctype html><html><head><meta charset='utf-8'>"
        f"<title>{escape(title)}</title></head><body>"
        f"<h1>{escape(title)}</h1><p>Generated {generated}</p>"
        + "".join(escaped)
        + "</body></html>"
    )


def filename(title: str, fmt: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", title.lower()).strip("-")[:60] or "master-prompt"
    return f"{slug}.{EXTENSIONS[fmt]}"
