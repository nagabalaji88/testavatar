"""Consensus analysis and master weaving."""
from __future__ import annotations

import re

from .evaluation import METRICS, WEIGHTS, evaluate, validate_payloads
from .sections import SECTIONS

STOPWORDS = {
    "the", "and", "for", "with", "that", "this", "from", "your", "you", "not", "are", "its",
    "into", "each", "every", "when", "than", "then", "there", "which", "will", "must", "never",
    "always", "output", "input", "use", "using", "based",
}


def _tokens(text: str) -> set[str]:
    return {
        word for word in re.findall(r"[a-zA-Z][a-zA-Z0-9_\-]{2,}", text.lower())
        if word not in STOPWORDS
    }


def jaccard(a: set[str], b: set[str]) -> float:
    if not a and not b:
        return 1.0
    return round(len(a & b) / len(a | b), 4) if (a | b) else 0.0


def agreement_matrix(drafts: dict[str, dict[str, str]]) -> dict:
    """Pairwise similarity between every pair of drafts, plus the overall agreement."""
    token_sets = {
        provider: _tokens("\n".join(sections.values())) for provider, sections in drafts.items()
    }
    providers = list(drafts)
    pairs: dict[str, float] = {}
    scores: list[float] = []
    for index, left in enumerate(providers):
        for right in providers[index + 1:]:
            value = jaccard(token_sets[left], token_sets[right])
            pairs[f"{left}|{right}"] = value
            scores.append(value)
    overall = round(sum(scores) / len(scores), 4) if scores else 0.0
    return {"pairs": pairs, "agreement": overall}


def analyse(drafts: dict[str, dict[str, str]], scores: dict[str, dict]) -> dict:
    """Common strengths, shared gaps, contradictions, unique contributions, winners."""
    providers = list(drafts)
    matrix = agreement_matrix(drafts)

    common_strengths, shared_gaps = [], []
    for metric in METRICS:
        values = [scores[p]["metrics"][metric] for p in providers]
        if min(values) >= 70:
            common_strengths.append({"metric": metric, "floor": min(values)})
        if max(values) < 55:
            shared_gaps.append({"metric": metric, "ceiling": max(values)})

    # A section every draft omits is a gap the weaver has to fill itself.
    for section in SECTIONS:
        if all(not drafts[p].get(section) for p in providers):
            shared_gaps.append({"metric": f"section:{section}", "ceiling": 0})

    contradictions = []
    for section in SECTIONS:
        present = [p for p in providers if drafts[p].get(section)]
        if len(present) < 2:
            continue
        token_sets = {p: _tokens(drafts[p][section]) for p in present}
        for index, left in enumerate(present):
            for right in present[index + 1:]:
                overlap = jaccard(token_sets[left], token_sets[right])
                if overlap < 0.12:
                    contradictions.append({
                        "section": section, "between": [left, right], "overlap": overlap,
                        "detail": "the two drafts describe this section in incompatible terms",
                    })

    unique: dict[str, list[str]] = {}
    for provider in providers:
        others: set[str] = set()
        for other in providers:
            if other != provider:
                others |= _tokens("\n".join(drafts[other].values()))
        own = _tokens("\n".join(drafts[provider].values()))
        unique[provider] = sorted(own - others)[:12]

    return {
        "agreement": matrix["agreement"],
        "pairs": matrix["pairs"],
        "common_strengths": common_strengths,
        "shared_gaps": shared_gaps,
        "contradictions": contradictions[:12],
        "unique_contributions": unique,
    }


# Which evaluation metrics a given section actually moves. Used to pick a winner
# per section instead of handing the whole prompt to the best overall draft.
SECTION_METRICS: dict[str, list[str]] = {
    "role": ["clarity", "portability"],
    "objective": ["clarity", "completeness"],
    "context": ["completeness", "hallucination_resistance"],
    "business_goal": ["completeness"],
    "inputs": ["structure", "completeness"],
    "variables": ["structure", "portability"],
    "execution_plan": ["reasoning", "clarity"],
    "instructions": ["clarity", "reasoning"],
    "reasoning_strategy": ["reasoning"],
    "constraints": ["constraints"],
    "negative_constraints": ["constraints", "hallucination_resistance"],
    "validation_rules": ["structure", "constraints"],
    "output_schema": ["structure"],
    "examples": ["few_shot"],
    "edge_cases": ["edge_cases"],
    "quality_checklist": ["completeness", "structure"],
    "failure_recovery": ["edge_cases"],
    "notes": ["token_efficiency"],
}


def _section_strength(provider: str, section: str, drafts, scores) -> float:
    body = drafts[provider].get(section)
    if not body:
        return -1.0
    metrics = SECTION_METRICS.get(section, ["clarity"])
    metric_score = sum(scores[provider]["metrics"][m] for m in metrics) / len(metrics)
    # Reward substance, but not padding: detail helps up to about four lines.
    detail = min(len([l for l in body.splitlines() if l.strip()]), 4) * 5
    return round(metric_score + detail, 3)


def weave(drafts: dict[str, dict[str, str]], scores: dict[str, dict], intent: dict) -> dict:
    """Pick the strongest version of every section, then guarantee a real hybrid.

    If one provider would win every section, the runner-up takes the sections
    where its margin of loss was smallest — the output is never a copy of a
    single draft, which is the whole point of running four of them.
    """
    providers = list(drafts)
    strengths = {
        section: {p: _section_strength(p, section, drafts, scores) for p in providers}
        for section in SECTIONS
    }

    provenance: dict[str, str] = {}
    for section in SECTIONS:
        ranked = sorted(strengths[section].items(), key=lambda kv: kv[1], reverse=True)
        if ranked and ranked[0][1] >= 0:
            provenance[section] = ranked[0][0]

    winners = set(provenance.values())
    if len(winners) == 1 and len(providers) > 1:
        dominant = winners.pop()
        margins = []
        for section, source in provenance.items():
            alternatives = [
                (p, strengths[section][p]) for p in providers
                if p != dominant and strengths[section][p] >= 0
            ]
            if alternatives:
                best_other = max(alternatives, key=lambda kv: kv[1])
                margins.append((strengths[section][source] - best_other[1], section, best_other[0]))
        for _, section, challenger in sorted(margins)[: max(1, len(margins) // 3)]:
            provenance[section] = challenger

    sections = {section: drafts[source][section] for section, source in provenance.items()}

    # Fill sections nobody wrote, so the master prompt is always complete.
    filled: list[str] = []
    for section in SECTIONS:
        if section not in sections:
            sections[section] = _fallback(section, intent)
            provenance[section] = "weaver"
            filled.append(section)

    return {"sections": sections, "provenance": provenance, "filled": filled}


def _fallback(section: str, intent: dict) -> str:
    defaults = {
        "business_goal": "Reduce the manual effort this task currently costs, without lowering "
                         "the quality bar the reviewer applies today.",
        "failure_recovery": "If the output cannot satisfy the schema, return the schema with the "
                            "`warnings` array populated and the reason named precisely. "
                            "Never fail silently.",
        "quality_checklist": "- [ ] Output parses in the declared format.\n"
                             "- [ ] Every constraint is satisfied.\n"
                             "- [ ] No unsupported claim appears in the answer.",
        "notes": f"Generated by consensus across four model specialists for a "
                 f"{intent.get('task_type', 'general')} task.",
    }
    return defaults.get(section, f"_(synthesised by the weaver — no draft supplied {section})_")


def quality_report(sections: dict[str, str]) -> dict:
    """Agent 10: structural validation of the woven prompt."""
    problems = validate_payloads(sections)
    body = "\n".join(sections.values())

    declared = set(re.findall(r"\{\{\s*([a-zA-Z_][\w]*)\s*\}\}", body))
    referenced_in_inputs = set(
        re.findall(r"\{\{\s*([a-zA-Z_][\w]*)\s*\}\}",
                   sections.get("inputs", "") + sections.get("variables", ""))
    )
    orphans = sorted(declared - referenced_in_inputs)
    if orphans:
        problems.append({
            "kind": "placeholder",
            "detail": f"used but never declared in Inputs or Variables: {', '.join(orphans)}",
        })

    missing = [s for s in SECTIONS if not sections.get(s)]
    if missing:
        problems.append({"kind": "completeness", "detail": f"missing: {', '.join(missing)}"})

    risky = re.findall(
        r"(?i)\b(latest|current|today|recent|as of now|up to date)\b", body
    )
    if risky:
        problems.append({
            "kind": "hallucination_risk",
            "detail": f"{len(risky)} time-relative phrase(s) that will silently go stale",
        })

    evaluation = evaluate(sections)
    return {
        "passed": not [p for p in problems if p["kind"] in {"json", "xml", "markdown"}],
        "problems": problems,
        "score": evaluation["total"],
        "metrics": evaluation["metrics"],
        "weights": WEIGHTS,
        "placeholders": sorted(declared),
    }
