"""The canonical section list every draft and the master prompt are built from."""
from __future__ import annotations

from typing import Optional

SECTIONS: list[str] = [
    "role", "objective", "context", "business_goal", "inputs", "variables",
    "execution_plan", "instructions", "reasoning_strategy", "constraints",
    "negative_constraints", "validation_rules", "output_schema", "examples",
    "edge_cases", "quality_checklist", "failure_recovery", "notes",
]

HEADINGS: dict[str, str] = {
    "role": "Role",
    "objective": "Objective",
    "context": "Context",
    "business_goal": "Business goal",
    "inputs": "Inputs",
    "variables": "Variables",
    "execution_plan": "Execution plan",
    "instructions": "Step-by-step instructions",
    "reasoning_strategy": "Reasoning strategy",
    "constraints": "Constraints",
    "negative_constraints": "Negative constraints",
    "validation_rules": "Validation rules",
    "output_schema": "Output schema",
    "examples": "Examples",
    "edge_cases": "Edge cases",
    "quality_checklist": "Quality checklist",
    "failure_recovery": "Failure recovery",
    "notes": "Final notes",
}


def render(sections: dict[str, str]) -> str:
    """Turn a section map into the markdown prompt users copy out."""
    blocks = []
    for key in SECTIONS:
        body = (sections.get(key) or "").strip()
        if not body:
            continue
        blocks.append(f"## {HEADINGS[key]}\n{body}")
    return "\n\n".join(blocks)


def parse(text: str) -> dict[str, str]:
    """Best-effort inverse of `render`, used when a live provider returns markdown."""
    reverse = {v.lower(): k for k, v in HEADINGS.items()}
    found: dict[str, str] = {}
    current: Optional[str] = None
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith("#"):
            heading = stripped.lstrip("#").strip().lower()
            current = reverse.get(heading)
            if current:
                found[current] = ""
            continue
        if current:
            found[current] += line + "\n"
    return {key: value.strip() for key, value in found.items() if value.strip()}
