"""LiteLLM-style provider gateway.

One `complete()` signature for every vendor, with retries, a circuit breaker and
token/cost accounting. When a provider has no API key configured, the call is
served by the local simulator instead, so the whole ten-agent workflow runs
offline with provider-distinct output rather than four identical drafts.
"""
from __future__ import annotations

import re
import time
from dataclasses import dataclass, field

import httpx

from ..core.config import settings

# Per-million-token prices used for the cost estimate shown in the UI.
CATALOG: dict[str, dict] = {
    "openai": {
        "label": "GPT", "model": settings.openai_model, "key": settings.openai_api_key,
        "url": "https://api.openai.com/v1/chat/completions",
        "in_cost": 0.15, "out_cost": 0.60, "color": "#10B981",
        "strengths": ["structure", "output_schema", "function calling"],
    },
    "anthropic": {
        "label": "Claude", "model": settings.anthropic_model, "key": settings.anthropic_api_key,
        "url": "https://api.anthropic.com/v1/messages",
        "in_cost": 3.00, "out_cost": 15.00, "color": "#F59E0B",
        "strengths": ["reasoning", "edge cases", "safety"],
    },
    "google": {
        "label": "Gemini", "model": settings.google_model, "key": settings.google_api_key,
        "url": "https://generativelanguage.googleapis.com/v1beta/models",
        "in_cost": 0.10, "out_cost": 0.40, "color": "#3B82F6",
        "strengths": ["long context", "grounding", "multimodal"],
    },
    "moonshot": {
        "label": "Kimi", "model": settings.moonshot_model, "key": settings.moonshot_api_key,
        "url": "https://api.moonshot.cn/v1/chat/completions",
        "in_cost": 0.60, "out_cost": 0.60, "color": "#A855F7",
        "strengths": ["conciseness", "cross-language", "long context"],
    },
}

PROVIDERS = list(CATALOG)


@dataclass
class Completion:
    provider: str
    text: str
    tokens: int
    cost_usd: float
    duration_ms: int
    simulated: bool
    warnings: list[str] = field(default_factory=list)


class CircuitBreaker:
    """Stops hammering a provider that keeps failing; falls back to the simulator."""

    def __init__(self, threshold: int) -> None:
        self.threshold = threshold
        self.failures: dict[str, int] = {}

    def is_open(self, provider: str) -> bool:
        return self.failures.get(provider, 0) >= self.threshold

    def record_failure(self, provider: str) -> None:
        self.failures[provider] = self.failures.get(provider, 0) + 1

    def record_success(self, provider: str) -> None:
        self.failures[provider] = 0


breaker = CircuitBreaker(settings.circuit_breaker_failures)


def estimate_tokens(text: str) -> int:
    """Cheap approximation — good enough for budgeting, no tokenizer dependency."""
    return max(1, int(len(text) / 4) + len(re.findall(r"\s+", text)) // 8)


def estimate_cost(provider: str, prompt_tokens: int, output_tokens: int) -> float:
    spec = CATALOG[provider]
    return round(
        (prompt_tokens * spec["in_cost"] + output_tokens * spec["out_cost"]) / 1_000_000, 6
    )


def is_live(provider: str) -> bool:
    return bool(CATALOG[provider]["key"]) and not breaker.is_open(provider)


def _payload(provider: str, system: str, user: str) -> tuple[str, dict, dict]:
    spec = CATALOG[provider]
    if provider == "anthropic":
        return (
            spec["url"],
            {"x-api-key": spec["key"], "anthropic-version": "2023-06-01"},
            {"model": spec["model"], "max_tokens": 4000, "system": system,
             "messages": [{"role": "user", "content": user}]},
        )
    if provider == "google":
        return (
            f"{spec['url']}/{spec['model']}:generateContent?key={spec['key']}",
            {},
            {"contents": [{"parts": [{"text": f"{system}\n\n{user}"}]}]},
        )
    return (
        spec["url"],
        {"Authorization": f"Bearer {spec['key']}"},
        {"model": spec["model"], "messages": [
            {"role": "system", "content": system}, {"role": "user", "content": user}]},
    )


def _extract(provider: str, body: dict) -> str:
    if provider == "anthropic":
        return "".join(block.get("text", "") for block in body.get("content", []))
    if provider == "google":
        parts = body["candidates"][0]["content"]["parts"]
        return "".join(part.get("text", "") for part in parts)
    return body["choices"][0]["message"]["content"]


def complete(provider: str, system: str, user: str, simulator=None) -> Completion:
    """Call the provider, or fall back to `simulator()` when live inference is unavailable."""
    started = time.perf_counter()
    warnings: list[str] = []

    if is_live(provider):
        url, headers, body = _payload(provider, system, user)
        for attempt in range(settings.max_retries + 1):
            try:
                with httpx.Client(timeout=settings.request_timeout_seconds) as client:
                    response = client.post(url, json=body, headers=headers)
                    response.raise_for_status()
                    text = _extract(provider, response.json())
                breaker.record_success(provider)
                prompt_tokens = estimate_tokens(system + user)
                output_tokens = estimate_tokens(text)
                return Completion(
                    provider=provider, text=text,
                    tokens=prompt_tokens + output_tokens,
                    cost_usd=estimate_cost(provider, prompt_tokens, output_tokens),
                    duration_ms=int((time.perf_counter() - started) * 1000),
                    simulated=False, warnings=warnings,
                )
            except Exception as exc:  # noqa: BLE001
                warnings.append(f"attempt {attempt + 1} failed: {type(exc).__name__}")
                breaker.record_failure(provider)
                time.sleep(0.2 * (attempt + 1))
        warnings.append("fell back to the local simulator")

    text = simulator() if simulator else ""
    prompt_tokens = estimate_tokens(system + user)
    output_tokens = estimate_tokens(text)
    return Completion(
        provider=provider, text=text,
        tokens=prompt_tokens + output_tokens,
        cost_usd=estimate_cost(provider, prompt_tokens, output_tokens),
        duration_ms=int((time.perf_counter() - started) * 1000),
        simulated=True, warnings=warnings,
    )
