"""Deterministic prompt evaluation against the weighted matrix.

Every metric is a pure function from the section map to 0-100, so scores are
reproducible and testable — no model is asked to grade its own homework.
"""
from __future__ import annotations

import json
import re

from .sections import SECTIONS

WEIGHTS: dict[str, int] = {
    "clarity": 15,
    "reasoning": 15,
    "constraints": 10,
    "completeness": 15,
    "portability": 10,
    "token_efficiency": 5,
    "structure": 10,
    "few_shot": 5,
    "edge_cases": 10,
    "hallucination_resistance": 5,
}

VENDOR_TOKENS = re.compile(
    r"\b(gpt|openai|claude|anthropic|gemini|google|kimi|moonshot|chatgpt)\b", re.I
)
HEDGES = re.compile(r"\b(maybe|probably|might|possibly|as far as i know|i think)\b", re.I)
GROUNDING = re.compile(
    r"\b(do not fabricate|never fabricate|only use|supplied context|cite|ground|evidence|"
    r"assume nothing|state assumptions)\b", re.I
)


def _text(sections: dict[str, str]) -> str:
    return "\n".join(sections.values())


def _scale(value: float, low: float, high: float) -> float:
    """Map a raw measurement onto 0-100, clamped."""
    if high == low:
        return 50.0
    return round(max(0.0, min((value - low) / (high - low), 1.0)) * 100, 1)


def clarity(sections: dict[str, str]) -> float:
    body = _text(sections)
    sentences = [s for s in re.split(r"[.\n]", body) if len(s.strip()) > 4]
    if not sentences:
        return 0.0
    average_words = sum(len(s.split()) for s in sentences) / len(sentences)
    # 8-18 words per sentence is the readable band; penalise both extremes.
    penalty = abs(average_words - 13) / 13
    imperatives = len(re.findall(r"(?m)^\s*(?:\d+\.|-|\u2022)?\s*[A-Z][a-z]+\b", body))
    return round(max(0.0, min((1 - penalty) * 85 + min(imperatives, 15), 100)), 1)


def reasoning(sections: dict[str, str]) -> float:
    present = sum(
        1 for key in ("reasoning_strategy", "execution_plan", "instructions") if sections.get(key)
    )
    depth = len(sections.get("reasoning_strategy", "").splitlines())
    return round(min(present / 3 * 60 + depth * 13, 100), 1)


def constraints(sections: dict[str, str]) -> float:
    positive = len(sections.get("constraints", "").splitlines())
    negative = len(sections.get("negative_constraints", "").splitlines())
    return round(min(positive * 12 + negative * 16, 100), 1)


def completeness(sections: dict[str, str]) -> float:
    return round(len([s for s in SECTIONS if sections.get(s)]) / len(SECTIONS) * 100, 1)


def portability(sections: dict[str, str]) -> float:
    body = _text(sections)
    vendor_mentions = len(VENDOR_TOKENS.findall(body))
    return round(max(0.0, 100 - vendor_mentions * 18), 1)


def token_efficiency(sections: dict[str, str]) -> float:
    words = len(_text(sections).split())
    # 250-700 words is the sweet spot for a reusable master prompt.
    if words < 250:
        return _scale(words, 0, 250)
    if words > 700:
        return round(max(0.0, 100 - (words - 700) / 12), 1)
    return 100.0


def structure(sections: dict[str, str]) -> float:
    body = _text(sections)
    has_schema = bool(sections.get("output_schema"))
    fenced = body.count("```") >= 2
    bulleted = len(re.findall(r"(?m)^\s*[-*\d]", body))
    return round(min(has_schema * 40 + fenced * 25 + min(bulleted, 7) * 5, 100), 1)


def few_shot(sections: dict[str, str]) -> float:
    examples = sections.get("examples", "")
    return round(min(len([l for l in examples.splitlines() if l.strip()]) * 34, 100), 1)


def edge_cases(sections: dict[str, str]) -> float:
    lines = len([l for l in sections.get("edge_cases", "").splitlines() if l.strip()])
    recovery = 25 if sections.get("failure_recovery") else 0
    return round(min(lines * 25 + recovery, 100), 1)


def hallucination_resistance(sections: dict[str, str]) -> float:
    body = _text(sections)
    guards = len(GROUNDING.findall(body))
    hedges = len(HEDGES.findall(body))
    return round(max(0.0, min(guards * 22 - hedges * 10, 100)), 1)


METRICS = {
    "clarity": clarity,
    "reasoning": reasoning,
    "constraints": constraints,
    "completeness": completeness,
    "portability": portability,
    "token_efficiency": token_efficiency,
    "structure": structure,
    "few_shot": few_shot,
    "edge_cases": edge_cases,
    "hallucination_resistance": hallucination_resistance,
}


def evaluate(sections: dict[str, str]) -> dict:
    raw = {name: fn(sections) for name, fn in METRICS.items()}
    weighted = {
        name: round(value * WEIGHTS[name] / 100, 2) for name, value in raw.items()
    }
    total = round(sum(weighted.values()), 1)
    notes: list[str] = []
    for name, value in sorted(raw.items(), key=lambda kv: kv[1])[:3]:
        if value < 60:
            notes.append(f"{name.replace('_', ' ')} is weak at {value:.0f}/100")
    missing = [s for s in SECTIONS if not sections.get(s)]
    if missing:
        notes.append(f"missing sections: {', '.join(missing)}")
    return {"metrics": raw, "weighted": weighted, "total": total, "notes": notes}


def validate_payloads(sections: dict[str, str]) -> list[dict]:
    """QA support: check that every fenced JSON block actually parses."""
    problems: list[dict] = []
    body = "\n".join(sections.values())
    for block in re.findall(r"```json\s*(.*?)```", body, re.S):
        try:
            json.loads(block.strip())
        except json.JSONDecodeError as exc:
            problems.append({"kind": "json", "detail": str(exc)})
    if body.count("```") % 2 != 0:
        problems.append({"kind": "markdown", "detail": "unbalanced code fence"})
    opened = re.findall(r"<([a-zA-Z_][\w\-]*)>", body)
    closed = re.findall(r"</([a-zA-Z_][\w\-]*)>", body)
    for tag in set(opened) - set(closed):
        problems.append({"kind": "xml", "detail": f"<{tag}> is never closed"})
    return problems
