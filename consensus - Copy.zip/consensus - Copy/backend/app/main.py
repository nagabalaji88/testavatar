"""PromptForge — multi-LLM consensus prompt engineering platform."""
import logging
import time
import uuid
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware

from .api import admin, auth, library, workflow
from .core.config import settings
from .core.database import Base, SessionLocal, engine
from .seed import seed_if_empty

logging.basicConfig(
    level=logging.INFO,
    format='{"ts":"%(asctime)s","level":"%(levelname)s","logger":"%(name)s","msg":"%(message)s"}',
)
logger = logging.getLogger("forge")


def init_db() -> None:
    """Create tables and load demo data. Safe to call repeatedly."""
    Base.metadata.create_all(bind=engine)
    with SessionLocal() as db:
        seed_if_empty(db)


@asynccontextmanager
async def lifespan(_: FastAPI):
    init_db()
    yield


app = FastAPI(
    lifespan=lifespan,
    title=settings.app_name,
    version="1.0.0",
    description="Generate a master prompt by consensus across four model specialists.",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_list or ["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def trace_requests(request: Request, call_next):
    """Structured access log with a correlation id — the seam for OpenTelemetry."""
    trace_id = request.headers.get("x-trace-id") or uuid.uuid4().hex[:16]
    started = time.perf_counter()
    response = await call_next(request)
    elapsed = int((time.perf_counter() - started) * 1000)
    response.headers["x-trace-id"] = trace_id
    logger.info(
        "%s %s -> %s in %sms [%s]",
        request.method, request.url.path, response.status_code, elapsed, trace_id,
    )
    return response


for router in (auth.router, workflow.router, library.router, admin.router):
    app.include_router(router, prefix=settings.api_prefix)


@app.get("/api/status")
def status() -> dict:
    from .services.providers import CATALOG, PROVIDERS, is_live

    return {
        "status": "online",
        "app": settings.app_name,
        "providers": {
            provider: {
                "label": CATALOG[provider]["label"],
                "mode": "live" if is_live(provider) else "simulated",
            }
            for provider in PROVIDERS
        },
    }


@app.get("/api/health")
def health() -> dict:
    return {"status": "ok"}
