import os
import tempfile

os.environ["FORGE_DATABASE_URL"] = f"sqlite:///{tempfile.mkdtemp()}/test.db"

from fastapi.testclient import TestClient  # noqa: E402

from app.main import app, init_db  # noqa: E402

init_db()
client = TestClient(app)


def _headers(email="aarti.desai@forge.dev"):
    response = client.post("/api/auth/login", json={"email": email, "password": "forge1234"})
    assert response.status_code == 200, response.text
    return {"Authorization": f"Bearer {response.json()['access_token']}"}


def test_status_is_open_and_reports_provider_modes():
    body = client.get("/api/status").json()
    assert body["status"] == "online"
    assert set(body["providers"]) == {"openai", "anthropic", "google", "moonshot"}


def test_login_rejects_bad_password():
    assert client.post(
        "/api/auth/login", json={"email": "aarti.desai@forge.dev", "password": "wrong"}
    ).status_code == 401


def test_protected_routes_require_a_token():
    assert client.get("/api/history").status_code == 401


def test_trace_id_header_is_returned():
    assert client.get("/api/health").headers.get("x-trace-id")


def test_generate_returns_full_run():
    body = client.post(
        "/api/generate",
        headers=_headers(),
        json={
            "problem_statement": "Convert customer emails into structured CRM records and "
                                 "flag the ones that need a human reply.",
            "expected_output": "JSON record per email",
            "constraints": ["never store credit card numbers"],
        },
    ).json()
    assert len(body["drafts"]) == 4
    assert body["ranking"]
    assert len(set(body["master"]["provenance"].values())) > 1
    assert len(body["logs"]) == 11
    assert body["totals"]["tokens"] > 0


def test_stage_endpoints_work_independently():
    headers = _headers()
    payload = {"problem_statement": "Summarise long legal contracts into a one page brief."}
    assert client.post("/api/analyze", headers=headers, json=payload).json()["intent"]
    assert client.post("/api/draft", headers=headers, json=payload).json()["drafts"]
    assert "agreement" in client.post("/api/consensus", headers=headers, json=payload).json()["consensus"]
    assert client.post("/api/weave", headers=headers, json=payload).json()["sections"]


def test_history_library_and_export_round_trip():
    headers = _headers()
    library = client.get("/api/library", headers=headers).json()
    assert library
    master_id = library[0]["id"]

    detail = client.get(f"/api/library/{master_id}", headers=headers).json()
    assert detail["master"]["sections"]
    assert detail["versions"][0]["version"] == 1

    export = client.post(
        "/api/export", headers=headers, json={"master_prompt_id": master_id, "format": "yaml"}
    )
    assert export.status_code == 200
    assert "attachment" in export.headers["content-disposition"]

    revised = client.post(
        f"/api/library/{master_id}/revise", headers=headers,
        json={"content": "## Role\nRevised.", "change_note": "tightened"},
    ).json()
    assert revised["version"] == 2


def test_analytics_and_workflow_meta():
    headers = _headers()
    analytics = client.get("/api/analytics", headers=headers).json()
    assert analytics["total_prompts"] >= 1
    assert analytics["by_provider"]

    meta = client.get("/api/workflow/meta", headers=headers).json()
    assert len(meta["agents"]) == 10
    assert len(meta["stages"]) == 10
    assert sum(meta["weights"].values()) == 100


def test_viewer_cannot_create_projects():
    response = client.post(
        "/api/projects", headers=_headers("viewer@forge.dev"),
        json={"name": "nope", "description": ""},
    )
    assert response.status_code == 403


def test_secrets_are_masked_on_read():
    admin = _headers("admin@forge.dev")
    client.put("/api/settings", headers=admin,
               json={"key": "openai_api_key", "value": "sk-secret-value-123", "encrypted": True})
    body = client.get("/api/settings", headers=admin).json()
    stored = next(s for s in body["settings"] if s["key"] == "openai_api_key")
    assert "secret-value" not in stored["value"]
    assert stored["encrypted"] is True
