import { Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { AvatarModel } from './AvatarModel';
import { PlaceholderAvatar } from './PlaceholderAvatar';
import { AvatarErrorBoundary } from './AvatarErrorBoundary';
import type { AvatarState } from '../../types/avatar';

interface AvatarSceneProps {
  /** URL of a rigged GLB avatar. If empty, or if loading fails, a procedural placeholder is used instead. */
  modelUrl: string;
  state: AvatarState;
  visemeIntensity: number;
}

const STATE_LABEL: Record<AvatarState, string> = {
  idle: 'Idle',
  listening: 'Listening',
  thinking: 'Thinking',
  speaking: 'Speaking'
};

const STATE_RING_CLASS: Record<AvatarState, string> = {
  idle: 'border-signal-line',
  listening: 'border-signal-teal shadow-ring animate-pulseRing',
  thinking: 'border-signal-amber shadow-ring animate-pulseRing',
  speaking: 'border-signal-indigo shadow-ring animate-pulseRing'
};

function LoadingPlaceholder() {
  return (
    <mesh position={[0, 0, 0]}>
      <sphereGeometry args={[0.6, 24, 24]} />
      <meshStandardMaterial color="#1E222C" wireframe />
    </mesh>
  );
}

export function AvatarScene({ modelUrl, state, visemeIntensity }: AvatarSceneProps) {
  const placeholder = <PlaceholderAvatar state={state} visemeIntensity={visemeIntensity} />;

  return (
    <div className="relative flex h-full w-full items-center justify-center">
      <Canvas camera={{ position: [0, 0, 2.3], fov: 32 }} className="relative z-10">
        <ambientLight intensity={0.8} />
        <directionalLight position={[2, 3, 4]} intensity={1.2} />
        <directionalLight position={[-2, 1, -3]} intensity={0.5} />
        {modelUrl ? (
          <AvatarErrorBoundary fallback={placeholder}>
            <Suspense fallback={<LoadingPlaceholder />}>
              <AvatarModel modelUrl={modelUrl} state={state} visemeIntensity={visemeIntensity} />
            </Suspense>
          </AvatarErrorBoundary>
        ) : (
          placeholder
        )}
      </Canvas>
      <div className="pointer-events-none absolute bottom-2.5 left-1/2 z-20 -translate-x-1/2 rounded-full border border-slate-200 bg-white/90 px-3 py-1 font-mono text-[10px] font-medium uppercase tracking-[0.15em] text-slate-600 shadow-sm backdrop-blur">
        {STATE_LABEL[state]}
      </div>
    </div>
  );
}
