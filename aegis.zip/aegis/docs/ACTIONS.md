# Actions checklist

## Complete

### Backend
- [x] Environment-driven configuration with typed settings
- [x] SQLAlchemy models: users, sessions, items, reviews, graph, simulations, audit, notifications, prompts
- [x] PBKDF2 password hashing and HMAC-signed bearer tokens
- [x] Role-based access control as a reusable FastAPI dependency
- [x] Agent base class with timing, failure isolation and trace capture
- [x] Agents 1–8 implemented, with the privacy gate running first
- [x] Capture orchestrator that halts when consent is absent
- [x] Hash-based embeddings and cosine retrieval
- [x] Exponential decay scoring and portfolio health
- [x] RAG copilot with source attribution and follow-up suggestions
- [x] Scenario generation, scoring and badges
- [x] Ten API routers covering every screen
- [x] Audit events on capture, review, copilot and refresh
- [x] Demo seed data with realistic transcripts and aged records
- [x] 17 tests: agents, scoring, retrieval, API flows, RBAC

### Frontend
- [x] Glass design system: GlassCard, AnimatedButton, MetricCard, badges, meters, loaders
- [x] AI orb signature element with pointer tracking and reduced-motion support
- [x] App shell: collapsible sidebar, global search, notifications, assistant rail, status bar
- [x] Landing and authentication screens
- [x] Dashboard with animated area, radar and bar charts
- [x] Capture screen with drag/drop, consent gate and live agent trace
- [x] Validation portal with confidence slider, visibility control and review history
- [x] Knowledge graph on React Flow with type filters and legend
- [x] Copilot chat with markdown, sources and follow-ups
- [x] Scenario simulator with branching choices, scoring and badges
- [x] Knowledge health gauge and recall queue
- [x] Governance centre and admin console
- [x] Route-level code splitting, typed API client, toast system
- [x] Keyboard focus rings, reduced-motion support, responsive layouts

### Documentation and tooling
- [x] README, ARCHITECTURE, API_DOCUMENTATION, DATABASE_SCHEMA, PROJECT_PLAN, ACTIONS
- [x] Docker Compose for backend and frontend
- [x] Offline inference engine so the demo runs with no API key

## Pending

- [ ] Server-sent events for streaming agent trace and copilot tokens
- [ ] Swap the in-process vector store for Chroma or pgvector
- [ ] Persist the graph in Neo4j and expose Cypher-backed relationship queries
- [ ] Whisper transcription for voice capture
- [ ] Scheduled refresh job that pushes the recall queue to experts
- [ ] Vitest coverage for the capture and validation flows
- [ ] SSO and per-department data isolation
