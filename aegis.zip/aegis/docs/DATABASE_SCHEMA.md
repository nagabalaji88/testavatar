# Database schema

SQLAlchemy 2.0 declarative models in `backend/app/models.py`. IDs are 16-character hex
strings. Default engine is SQLite; set `AEGIS_DATABASE_URL` for PostgreSQL.

## Tables

### users
| Column | Type | Notes |
|---|---|---|
| id | str(32) | PK |
| email | str(160) | unique, indexed |
| full_name | str(160) | |
| password_hash | str(255) | PBKDF2-SHA256, per-user salt |
| role | str(32) | `expert` · `reviewer` · `learner` · `admin` |
| department | str(80) | |
| is_active | bool | deactivation without deletion |
| created_at | datetime | |

### capture_sessions
One ingested artifact. Keeps both the raw and redacted text so an auditor can verify what
was removed, while everything downstream reads only the redacted copy.

| Column | Type | Notes |
|---|---|---|
| id | str(32) | PK |
| title, source_type | str | `meeting_transcript`, `pull_request`, `incident_report`, … |
| raw_content, redacted_content | text | |
| status | str(32) | `processing` · `awaiting_validation` · `blocked` |
| consent_granted | bool | false halts the pipeline at the gate |
| pii_findings | JSON | `[{type, start, end, preview, severity}]` |
| agent_trace | JSON | the full run, replayed by the UI |
| author_id | FK → users.id | |
| created_at | datetime | |

### knowledge_items
| Column | Type | Notes |
|---|---|---|
| id | str(32) | PK |
| session_id | FK → capture_sessions.id | cascade delete |
| title, summary, body | str/text | body is the ADR |
| kind | str(32) | `decision` · `risk` · `best_practice` · `heuristic` · `incident` |
| domain | str(80) | |
| tags | JSON | string array |
| confidence | float | calibrated, not raw model output |
| status | str(24) | **indexed** — `pending` · `approved` · `rejected` |
| visibility | str(24) | `internal` · `department` · `enterprise` |
| version | int | increments on each edit |
| usage_count | int | feeds the health score |
| embedding | JSON | 256-dim float array |
| expert_name | str(160) | attribution shown with every copilot answer |
| created_at, updated_at, last_reviewed_at | datetime | `last_reviewed_at` drives decay |

### reviews
Append-only decision history: `id`, `item_id` (FK), `reviewer_id` (FK), `reviewer_name`,
`decision`, `comment`, `confidence`, `created_at`. Rows are never updated, so the full
review conversation stays visible on the card.

### graph_nodes / graph_edges
`graph_nodes`: `id`, `label`, `node_type` (**indexed**), `item_id`, `meta` JSON, `created_at`.
`graph_edges`: `id`, `source_id` (**indexed**), `target_id` (**indexed**), `relation`, `weight`.

Nodes are deduplicated on `(label, node_type)` at write time, so the same technology
mentioned in ten captures becomes one hub with ten edges.

### simulations / simulation_attempts
`simulations`: `id`, `scenario`, `title`, `tree` JSON, `source_item_id`, `created_at`.
`simulation_attempts`: `id`, `simulation_id` (**indexed**), `user_id`, `path` JSON,
`score`, `badge`, `created_at`.

### audit_events
`id`, `actor`, `action`, `target`, `detail` JSON, `created_at`. Written on capture, every
review decision, every copilot query and every refresh request.

### notifications
`id`, `title`, `body`, `level`, `read`, `created_at`.

### prompt_templates
`id`, `key` (unique), `description`, `template`, `updated_at`. Editable from Admin so
extraction behaviour can be tuned without a redeploy.

## Relationships

```
users ──1:N──▶ capture_sessions ──1:N──▶ knowledge_items ──1:N──▶ reviews
                                              │
                                              └──▶ graph_nodes ──N:N──▶ graph_nodes (via graph_edges)

knowledge_items ──1:N──▶ simulations ──1:N──▶ simulation_attempts ◀──N:1── users
```

## Indexing

Indexed today: `users.email`, `knowledge_items.status`, `graph_nodes.node_type`,
`graph_edges.source_id`/`target_id`, `simulation_attempts.simulation_id`.

For a PostgreSQL deployment, add a composite index on
`knowledge_items(status, domain)` for filtered lists, and move `embedding` to `pgvector`
with an IVFFlat index once the corpus outgrows in-process cosine search.
