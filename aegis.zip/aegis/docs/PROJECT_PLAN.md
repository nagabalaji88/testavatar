# Project plan

## Approach

Five sprints, each ending with an application you can actually run. Nothing was scaffolded
ahead of the sprint that needed it, so there is no dead code waiting for a feature.

## Sprint 1 — Foundation ✅

Config via environment variables, SQLAlchemy models, PBKDF2 hashing and HMAC-signed tokens
(stdlib only — no crypto dependency to pin), session management, role guard dependency.

*Runnable at the end:* `/api/status` and `/api/auth/login` against a seeded database.

## Sprint 2 — Agent pipeline ✅

The `Agent` base class with timing, failure isolation and trace capture. Privacy, Capture,
Structuring, Validation and Embedding agents plus the orchestrator. Recommendation,
Learning and Refresh agents for on-demand work. Vector store and decay scoring as pure
functions with unit tests.

*Runnable at the end:* `POST /api/capture` runs end to end and returns a full trace.

## Sprint 3 — API surface ✅

Ten routers covering capture, knowledge, validation, search, graph, copilot, simulation,
health, analytics, governance and admin. RBAC enforced at the dependency layer and covered
by an integration test that asserts a learner gets 403 on validation.

*Runnable at the end:* complete API with `/docs`, 17 tests passing.

## Sprint 4 — Interface ✅

Design system first (glass surfaces, gradient display type, the orb), then the eleven
screens on top of it. Route-level code splitting so the graph canvas and chart library only
load when opened.

*Runnable at the end:* full product, `npm run build` clean.

## Sprint 5 — Hardening and documentation ✅

Documentation set, Docker Compose, offline/live inference parity, accessibility pass
(keyboard focus rings, reduced-motion support, responsive down to mobile).

## What a next sprint would take on

- **Streaming responses.** The copilot renders complete answers today; SSE would let the
  Capture screen stream agent trace entries as they finish rather than on completion.
- **Real vector and graph backends.** Chroma or pgvector behind `vector_store.py`, Neo4j
  behind the graph persistence. Both are already isolated behind function boundaries.
- **Whisper ingestion.** The voice source type currently expects a transcript; wiring
  Whisper would close the loop on genuinely tacit hallway knowledge.
- **Scheduled refresh.** The Refresh Agent runs on request; a nightly job would push the
  recall queue to experts instead of waiting for someone to open the health screen.
- **Frontend test suite.** Vitest plus Testing Library on the validation and capture flows.
- **SSO and per-department data isolation** for a real enterprise rollout.
