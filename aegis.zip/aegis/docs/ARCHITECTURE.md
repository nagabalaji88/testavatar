# Architecture

## System shape

```
React 19 + Vite (TypeScript)          FastAPI (Python 3.12)
┌──────────────────────────┐          ┌────────────────────────────────────┐
│ Pages / Glass components │  HTTPS   │ API routers  → services → agents   │
│ Zustand stores           │ ───────► │ Auth guard   → RBAC dependency     │
│ Axios client (+ JWT)     │          │ SQLAlchemy   → SQLite / PostgreSQL │
└──────────────────────────┘          └────────────────────────────────────┘
                                                  │
                                   vector index · knowledge graph · audit log
```

## The capture pipeline

Order is a safety property, not a preference. The privacy gate runs **first**, so no
downstream agent — and no LLM call — ever receives unredacted text.

```
raw artifact
   │
   ├─▶ 1. Privacy Agent          consent check → PII scan → redaction
   │        (blocks the run entirely if consent was not granted)
   ├─▶ 2. Knowledge Capture      decisions, risks, best practices, incidents
   ├─▶ 3. Structuring Agent      ADR format: context / decision / rationale / consequences
   ├─▶ 4. Validation Agent       calibrated confidence → reviewer cards (status: pending)
   └─▶ 5. Embedding Agent        vectors + graph nodes and edges
              │
       human expert approves ──▶ approved corpus ──▶ Copilot · Simulator · Search
```

Three further agents run on demand rather than in the pipeline:

- **Recommendation Agent** — ranks the approved corpus against a learner's question.
- **Learning Agent** — turns an approved record into a branching scenario with scoring.
- **Refresh Agent** — scores decay across the corpus and builds the recall queue.

Every agent subclasses `Agent` and returns `(state, detail, output)`. The base class times
the call, catches failures so one bad agent cannot kill a run, and appends a trace entry —
which is exactly what the Capture screen streams back to the user. The state-in/state-out
shape matches LangGraph nodes, so porting the orchestrator is mechanical.

## Design decisions worth knowing

**Privacy before extraction.** Redaction could have run at storage time. It runs at ingress
instead, because the moment raw text reaches a model provider, the guarantee is already gone.

**Services speak plain dicts.** Pydantic models exist only at the API boundary
(`schemas.py`). Business logic in `services/` and `agents/` takes and returns dicts, which
keeps the pure functions trivially unit-testable without constructing models.

**Deterministic fallbacks everywhere.** `complete_json` and `complete_text` both take a
fallback that the offline engine produces. The app is fully demonstrable with no API key,
and a provider outage degrades quality instead of throwing.

**Decay is computed, not stored.** Freshness is an exponential decay on
`last_reviewed_at` with a configurable half-life, so health is always current and there is
no scheduled job to fall behind.

**Confidence is calibrated, not copied.** The Validation Agent adjusts model-reported
confidence with evidence-length penalties and a standing penalty on risk claims, so
"the model was sure" never substitutes for expert sign-off.

## Layout

```
backend/app/
  api/          routers + auth dependencies (deps.py holds the RBAC guard)
  agents/       the eight agents and the pipeline orchestrator
  services/     llm gateway, vector store, health scoring, persistence, copilot
  core/         config, database session, password hashing and token signing
  models.py     SQLAlchemy tables
  schemas.py    Pydantic request/response contracts
  seed.py       demo users, transcripts and knowledge
backend/tests/  agent/scoring unit tests + API and RBAC integration tests

frontend/src/
  components/   GlassCard, AnimatedButton, MetricCard, AIOrb, AgentTrace, toasts
  layouts/      AppShell: sidebar, top bar, assistant rail, status bar
  pages/        the eleven screens (lazily loaded)
  services/     typed Axios client
  store/        Zustand auth and toast stores
  types/        shared API types
```

## Security model

- Passwords are PBKDF2-SHA256 with a per-user salt, 120k iterations.
- Bearer tokens are HMAC-SHA256 signed with an expiry claim; a tampered token fails
  constant-time comparison.
- `require_roles()` guards mutations — a learner receives 403 on the validation endpoint,
  which is covered by an integration test.
- Every capture, review, copilot query and refresh request writes an audit event.

## Production notes

Swap SQLite for PostgreSQL via `AEGIS_DATABASE_URL`; the models are portable. For scale,
replace `services/vector_store.py` with Chroma/FAISS and `graph_service` persistence with
Neo4j — both are isolated behind function boundaries specifically so those swaps are local.
