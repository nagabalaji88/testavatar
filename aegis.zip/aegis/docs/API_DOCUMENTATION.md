# API reference

Base URL: `http://localhost:8000/api` · Interactive docs: `/docs`

All endpoints except `/status` and `/auth/login` require `Authorization: Bearer <token>`.

## Auth

| Method | Path | Body | Returns |
|---|---|---|---|
| POST | `/auth/login` | `{email, password}` | `{access_token, token_type, user}` |
| GET | `/auth/me` | — | current user |

401 is returned for a bad credential, expired token or deactivated account. The frontend
interceptor clears the token and redirects to `/login` on any 401.

## Capture

| Method | Path | Notes |
|---|---|---|
| POST | `/capture` | Runs the five-agent pipeline. Body: `{title, source_type, content, consent_granted, domain}` |
| POST | `/capture/upload` | Multipart file upload, same pipeline |
| GET | `/capture/sessions` | Recent sessions with PII and item counts |
| GET | `/capture/sessions/{id}` | Redacted text, PII findings, full agent trace, drafted items |

`POST /capture` response:

```json
{
  "session_id": "8f2c…",
  "status": "awaiting_validation",
  "pii_findings": [{"type": "EMAIL", "severity": "medium", "preview": "pri…"}],
  "redacted_content": "…[EMAIL_REDACTED]…",
  "trace": [{"agent": "Privacy Agent", "status": "complete", "detail": "…", "duration_ms": 3}],
  "items": [{"id": "…", "title": "…", "kind": "decision", "confidence": 0.78, "status": "pending"}]
}
```

If `consent_granted` is false the pipeline halts at the privacy gate: status is `blocked`,
the trace has a single entry and no items are created.

## Knowledge and validation

| Method | Path | Notes |
|---|---|---|
| GET | `/knowledge` | Filter by `status`, `domain`, `limit` |
| GET | `/knowledge/{id}` | Item plus its full review history |
| GET | `/validation/queue` | Pending cards, lowest confidence first |
| POST | `/validation/{id}` | `{decision: approve\|reject\|edit, comment, confidence, visibility, title?, body?}` — **requires expert, reviewer or admin** (403 otherwise) |
| POST | `/search` | `{query, top_k, domain?}` — cosine search over approved records; bumps usage counts |

## Copilot

| Method | Path | Notes |
|---|---|---|
| POST | `/copilot` | `{question, history, top_k}` → `{answer, sources[], confidence, followups[]}` |

Answers are grounded in approved records only. With no relevant match the copilot says so
rather than generating an unsourced answer.

## Knowledge graph

| Method | Path | Notes |
|---|---|---|
| GET | `/graph` | Optional `node_type` and `q` filters → `{nodes[], edges[]}` |

Node types: `decision`, `expert`, `technology`, `incident`, `architecture`, `dependency`.

## Simulation

| Method | Path | Notes |
|---|---|---|
| GET | `/simulation/scenarios` | Available scenario types |
| POST | `/simulation/start` | `{scenario}` → session with the decision tree |
| POST | `/simulation/answer` | `{simulation_id, node_id, choice_id, path}` → feedback, running score, next node, badge on completion |
| GET | `/simulation/progress` | Attempts, average score, badges earned |

## Knowledge health

| Method | Path | Notes |
|---|---|---|
| GET | `/knowledge-health` | Portfolio health, freshness, decay, recall queue |
| POST | `/knowledge-health/refresh/{id}` | Notifies the owning expert; writes an audit event |

## Analytics, governance, admin

| Method | Path | Notes |
|---|---|---|
| GET | `/analytics/dashboard` | Metrics, 14-day timeline, domain/kind breakdowns, most-reused |
| GET | `/notifications` | Recent notifications |
| POST | `/notifications/{id}/read` | Mark read |
| GET | `/governance/pii` | Redaction counts by type |
| GET | `/governance/audit` | Audit trail, newest first |
| GET | `/governance/consent` | Consent register per artifact |
| GET | `/governance/access` | Visibility distribution and the role/permission matrix |
| GET/POST/PATCH | `/admin/users` | List, create, update — **admin only** |
| GET/PUT | `/admin/prompts` | Prompt templates — **admin only** |
| GET | `/admin/system` | Runtime configuration and inference mode |
| GET | `/admin/agents` | Agent registry with descriptions |

## Status

`GET /api/status` → `{status, app, llm, vector_index}`. No auth; used by the status bar.
