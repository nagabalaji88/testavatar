# Project AEGIS

**Ethical Tacit Knowledge Capture & Dynamic Transfer System**

AEGIS captures how experts actually reason — from meeting transcripts, pull requests and
incident reports — strips personal data before anything is analysed, has a human expert
validate every extracted card, and then teaches that knowledge back to junior engineers
through a grounded copilot and branching scenario simulations.

The design constraint that shapes everything: **no knowledge is ever published on a model's
say-so, and no model ever sees raw PII.**

---

## Quick start

### Backend

```bash
cd backend
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

The API is at http://localhost:8000 with interactive docs at `/docs`.
On first run it creates `aegis.db` (SQLite) and seeds demo users, transcripts and knowledge.

### Frontend

```bash
cd frontend
npm install
npm run dev
```

Open http://localhost:5173. Vite proxies `/api` to the backend, so no CORS setup is needed
in development.

### Demo accounts

| Email | Role | Can do |
|---|---|---|
| `priya.raman@aegis.dev` | expert | capture, validate, publish |
| `marcus.hale@aegis.dev` | reviewer | validate, comment |
| `dana.oyelaran@aegis.dev` | learner | search, copilot, simulate |
| `admin@aegis.dev` | admin | everything, plus configuration |

Password for all: `aegis1234`

### Tests

```bash
cd backend && python -m pytest tests -q       # 17 tests: agents, scoring, API, RBAC
cd frontend && npm run typecheck && npm run build
```

---

## Running with a real LLM

AEGIS ships with a deterministic offline engine so the full pipeline runs with no API key —
useful for demos and CI. Point it at any OpenAI-compatible endpoint to switch to live inference:

```bash
export AEGIS_OPENAI_API_KEY=sk-...
export AEGIS_OPENAI_MODEL=gpt-4o-mini
export AEGIS_OPENAI_BASE_URL=https://api.openai.com/v1
```

Every agent calls through `app/services/llm.py`, and each LLM call passes a deterministic
fallback, so a provider outage degrades the output rather than breaking the run.

## Configuration

All settings are environment variables prefixed `AEGIS_` (see `app/core/config.py`):

| Variable | Default | Purpose |
|---|---|---|
| `AEGIS_DATABASE_URL` | `sqlite:///./aegis.db` | Any SQLAlchemy URL, e.g. PostgreSQL |
| `AEGIS_SECRET_KEY` | dev value | Token signing key — **change in production** |
| `AEGIS_DECAY_HALF_LIFE_DAYS` | `120` | How fast knowledge freshness decays |
| `AEGIS_STALE_THRESHOLD` | `0.45` | Health score below which a record is recalled |
| `AEGIS_CORS_ORIGINS` | localhost:5173 | Comma-separated allowed origins |

## What is in the box

| Screen | What it does |
|---|---|
| Landing | The thesis: reasoning leaves with the people who made it |
| Dashboard | Capture volume, review backlog, health, domain coverage |
| Capture | Drag/drop or paste an artifact; watch all five agents run |
| Validation | Approve, edit or reject each card; set visibility and confidence |
| Knowledge graph | Decisions linked to experts, technologies and incidents |
| Copilot | RAG chat that names its sources and admits when it has nothing |
| Simulator | Branching scenarios scored against expert judgement |
| Knowledge health | Decay gauge and the recall queue |
| Governance | PII analytics, consent register, audit trail, access model |
| Admin | Roles, prompt templates, agent registry, system config |

Further reading: [`ARCHITECTURE.md`](docs/ARCHITECTURE.md) ·
[`API_DOCUMENTATION.md`](docs/API_DOCUMENTATION.md) ·
[`DATABASE_SCHEMA.md`](docs/DATABASE_SCHEMA.md) ·
[`PROJECT_PLAN.md`](docs/PROJECT_PLAN.md) ·
[`ACTIONS.md`](docs/ACTIONS.md)
