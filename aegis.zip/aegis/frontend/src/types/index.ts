export type Role = 'expert' | 'reviewer' | 'learner' | 'admin'

export interface User {
  id: string
  email: string
  full_name: string
  role: Role
  department: string
}

export interface AgentStep {
  agent: string
  status: string
  detail: string
  duration_ms: number
  output: Record<string, unknown>
}

export interface KnowledgeItem {
  id: string
  title: string
  summary: string
  body: string
  kind: string
  domain: string
  tags: string[]
  confidence: number
  status: 'pending' | 'approved' | 'rejected'
  visibility: string
  version: number
  usage_count: number
  expert_name: string
  created_at: string
  updated_at: string
  last_reviewed_at: string
}

export interface PiiFinding {
  type: string
  start: number
  end: number
  preview: string
  severity: 'high' | 'medium'
}

export interface CaptureResult {
  session_id: string
  status: string
  pii_findings: PiiFinding[]
  redacted_content: string
  trace: AgentStep[]
  items: KnowledgeItem[]
}

export interface CopilotSource {
  id: string
  title: string
  expert_name: string
  domain: string
  confidence: number
  score: number
}

export interface CopilotReply {
  answer: string
  sources: CopilotSource[]
  confidence: number
  followups: string[]
}

export interface DashboardData {
  metrics: {
    knowledge_captured: number
    approved: number
    pending_reviews: number
    experts: number
    active_learners: number
    knowledge_health: number
    decay_score: number
    daily_ai_usage: number
  }
  timeline: { date: string; captured: number }[]
  by_domain: { name: string; value: number }[]
  by_kind: { name: string; value: number }[]
  top_used: { title: string; usage: number }[]
}

export interface HealthReport {
  health: number
  freshness: number
  decay: number
  total: number
  recall_queue: {
    id: string
    title: string
    freshness: number
    decay: number
    health: number
    age_days: number
    confidence: number
  }[]
}

export interface SimulationChoice {
  id: string
  label: string
  score: number
  next: string | null
  feedback: string
}

export interface SimulationNode {
  id: string
  prompt: string
  choices: SimulationChoice[]
}

export interface SimulationSession {
  id: string
  scenario: string
  title: string
  tree: { root: string; nodes: Record<string, SimulationNode> }
}
