import { motion, useMotionValue, useSpring } from 'framer-motion'
import { useEffect } from 'react'

/**
 * The signature element: a knowledge core that leans toward the pointer.
 * Rings represent the capture → validate → transfer loop.
 */
export function AIOrb({ size = 220, follow = true }: { size?: number; follow?: boolean }) {
  const x = useMotionValue(0)
  const y = useMotionValue(0)
  const sx = useSpring(x, { stiffness: 60, damping: 18 })
  const sy = useSpring(y, { stiffness: 60, damping: 18 })

  useEffect(() => {
    if (!follow) return
    const move = (event: MouseEvent) => {
      x.set(((event.clientX / window.innerWidth) - 0.5) * 26)
      y.set(((event.clientY / window.innerHeight) - 0.5) * 26)
    }
    window.addEventListener('mousemove', move)
    return () => window.removeEventListener('mousemove', move)
  }, [follow, x, y])

  return (
    <motion.div style={{ x: sx, y: sy, width: size, height: size }} className="relative">
      <motion.div
        animate={{ rotate: 360 }}
        transition={{ duration: 26, repeat: Infinity, ease: 'linear' }}
        className="absolute inset-0 rounded-full border border-cyanide/30"
      />
      <motion.div
        animate={{ rotate: -360 }}
        transition={{ duration: 18, repeat: Infinity, ease: 'linear' }}
        className="absolute inset-5 rounded-full border border-violetGlow/40 border-dashed"
      />
      <motion.div
        animate={{ scale: [1, 1.06, 1], opacity: [0.75, 1, 0.75] }}
        transition={{ duration: 4.5, repeat: Infinity }}
        className="absolute inset-10 rounded-full bg-[radial-gradient(circle_at_35%_30%,#67e8f9,#4f46e5_45%,#7c3aed_75%)] blur-[1px]"
      />
      <div className="absolute inset-10 rounded-full shadow-[0_0_90px_18px_rgba(79,70,229,0.35)]" />
    </motion.div>
  )
}
