import { motion } from 'framer-motion'
import { CheckCircle2, CircleAlert } from 'lucide-react'
import type { AgentStep } from '../types'

export function AgentTrace({ steps }: { steps: AgentStep[] }) {
  return (
    <ol className="space-y-3">
      {steps.map((step, index) => (
        <motion.li
          key={`${step.agent}-${index}`}
          initial={{ opacity: 0, x: -12 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: index * 0.12 }}
          className="glass rounded-xl p-3"
        >
          <div className="flex items-start gap-3">
            {step.status === 'complete'
              ? <CheckCircle2 className="mt-0.5 h-4 w-4 text-tealGlow" />
              : <CircleAlert className="mt-0.5 h-4 w-4 text-amber-400" />}
            <div className="min-w-0">
              <p className="font-display text-sm text-slate-900 dark:text-white">{step.agent}</p>
              <p className="text-xs text-slate-500 dark:text-slate-400">{step.detail}</p>
            </div>
            <span className="ml-auto shrink-0 font-mono text-[10px] text-slate-400 dark:text-slate-500">
              {step.duration_ms}ms
            </span>
          </div>
        </motion.li>
      ))}
    </ol>
  )
}
