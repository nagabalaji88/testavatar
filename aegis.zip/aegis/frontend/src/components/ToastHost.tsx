import { AnimatePresence, motion } from 'framer-motion'
import { useToast } from '../store/useToast'

const tones: Record<string, string> = {
  info: 'border-cyanide/40',
  success: 'border-tealGlow/50',
  warning: 'border-amber-400/50',
  error: 'border-rose-400/50',
}

export function ToastHost() {
  const { toasts, dismiss } = useToast()
  return (
    <div className="pointer-events-none fixed bottom-16 right-5 z-50 flex w-80 flex-col gap-2">
      <AnimatePresence>
        {toasts.map((toast) => (
          <motion.button
            key={toast.id}
            layout
            initial={{ opacity: 0, x: 60, scale: 0.95 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={{ opacity: 0, x: 60 }}
            transition={{ type: 'spring', stiffness: 320, damping: 26 }}
            onClick={() => dismiss(toast.id)}
            className={`glass-strong pointer-events-auto rounded-xl border p-3 text-left ${tones[toast.level]}`}
          >
            <p className="font-display text-sm text-white">{toast.title}</p>
            {toast.body && <p className="mt-0.5 text-xs text-slate-400">{toast.body}</p>}
          </motion.button>
        ))}
      </AnimatePresence>
    </div>
  )
}
