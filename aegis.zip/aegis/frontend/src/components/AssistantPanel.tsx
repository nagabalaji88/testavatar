import { AnimatePresence, motion } from 'framer-motion'
import { PanelRightClose, PanelRightOpen, Send } from 'lucide-react'
import { useState } from 'react'
import { stagger } from '../lib/motion'
import { copilot } from '../services/api'
import type { CopilotReply } from '../types'
import { AIOrb } from './AIOrb'
import { ThinkingLoader } from './ui'

/** Right-hand assistant rail. Answers only from validated knowledge. */
export function AssistantPanel() {
  const [open, setOpen] = useState(true)
  const [question, setQuestion] = useState('')
  const [reply, setReply] = useState<CopilotReply | null>(null)
  const [busy, setBusy] = useState(false)

  const ask = async (text: string) => {
    if (!text.trim()) return
    setBusy(true)
    try {
      setReply(await copilot.ask(text))
    } finally {
      setBusy(false)
      setQuestion('')
    }
  }

  return (
    <motion.aside
      animate={{ width: open ? 320 : 56 }}
      transition={{ type: 'spring', stiffness: 220, damping: 26 }}
      className="glass-strong sticky top-[57px] hidden h-[calc(100vh-57px)] shrink-0 flex-col border-l border-slate-900/10 p-3 dark:border-white/10 xl:flex"
    >
      <button
        onClick={() => setOpen((v) => !v)}
        aria-label={open ? 'Hide assistant' : 'Show assistant'}
        className="focus-ring mb-3 self-end rounded-lg p-1 text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white"
      >
        {open ? <PanelRightClose className="h-4 w-4" /> : <PanelRightOpen className="h-4 w-4" />}
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="flex min-h-0 flex-1 flex-col"
          >
            <div className="mb-2 grid place-items-center">
              <AIOrb size={112} follow={false} />
            </div>
            <p className="eyebrow">Assistant</p>
            <p className="mb-3 text-xs text-slate-500 dark:text-slate-400">
              Grounded in approved knowledge only. Every answer carries its sources.
            </p>

            <div className="min-h-0 flex-1 overflow-y-auto pr-1">
              {busy && <ThinkingLoader label="Retrieving validated knowledge" />}
              <AnimatePresence mode="wait">
                {!busy && reply && (
                  <motion.div
                    key={reply.answer}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    className="space-y-3"
                  >
                    <p className="whitespace-pre-wrap text-sm text-slate-700 dark:text-slate-200">{reply.answer}</p>
                    {reply.sources.map((source, index) => (
                      <motion.div
                        key={source.id}
                        initial={{ opacity: 0, y: 6 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={stagger(index)}
                        className="rounded-lg border border-slate-900/10 bg-slate-900/5 p-2 dark:border-white/10 dark:bg-white/5"
                      >
                        <p className="text-xs text-slate-900 dark:text-white">{source.title}</p>
                        <p className="font-mono text-[10px] text-slate-400 dark:text-slate-500">
                          {source.expert_name} · relevance {Math.round(source.score * 100)}%
                        </p>
                      </motion.div>
                    ))}
                    {reply.followups.map((followup, index) => (
                      <motion.button
                        key={followup}
                        initial={{ opacity: 0, y: 6 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={stagger(index + reply.sources.length)}
                        onClick={() => ask(followup)}
                        className="focus-ring w-full rounded-lg border border-cyanide/25 px-2 py-1.5 text-left text-[11px] text-cyan-700 hover:bg-cyanide/10 dark:text-cyanide"
                      >
                        {followup}
                      </motion.button>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
              {!busy && !reply && (
                <p className="text-xs text-slate-400 dark:text-slate-500">
                  Ask something like “how do we handle retries on payment writes?”
                </p>
              )}
            </div>

            <div className="mt-3 flex items-center gap-2">
              <input
                value={question}
                onChange={(event) => setQuestion(event.target.value)}
                onKeyDown={(event) => event.key === 'Enter' && ask(question)}
                placeholder="Ask the knowledge base"
                className="focus-ring w-full rounded-xl border border-slate-900/10 bg-slate-900/5 px-3 py-2 text-xs placeholder:text-slate-400 dark:border-white/10 dark:bg-white/5 dark:placeholder:text-slate-500"
              />
              <button
                onClick={() => ask(question)}
                aria-label="Send question"
                className="focus-ring rounded-xl bg-gradient-to-r from-cyanide to-indigoGlow p-2 text-slate-900"
              >
                <Send className="h-3.5 w-3.5" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.aside>
  )
}
