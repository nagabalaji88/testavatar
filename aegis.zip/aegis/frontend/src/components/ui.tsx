import { motion } from 'framer-motion'
import type { ReactNode } from 'react'

export function GlassCard({
  children, className = '', delay = 0, interactive = true,
}: { children: ReactNode; className?: string; delay?: number; interactive?: boolean }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16, filter: 'blur(6px)' }}
      animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
      transition={{ duration: 0.5, delay, ease: [0.22, 1, 0.36, 1] }}
      whileHover={interactive ? { y: -4, boxShadow: '0 26px 70px -28px rgba(34,211,238,0.45)' } : undefined}
      className={`glass rounded-2xl p-5 ${className}`}
    >
      {children}
    </motion.div>
  )
}

export function AnimatedButton({
  children, onClick, variant = 'primary', type = 'button', disabled, className = '',
}: {
  children: ReactNode
  onClick?: () => void
  variant?: 'primary' | 'ghost' | 'danger'
  type?: 'button' | 'submit'
  disabled?: boolean
  className?: string
}) {
  const styles = {
    primary:
      'bg-[linear-gradient(100deg,#22d3ee,#6366f1_50%,#8b5cf6)] bg-[length:200%_100%] text-slate-950 font-semibold hover:bg-right',
    ghost: 'glass text-slate-700 dark:text-slate-200 hover:border-cyanide/50',
    danger: 'bg-rose-500/10 border border-rose-400/40 text-rose-700 dark:bg-rose-500/15 dark:text-rose-200 hover:bg-rose-500/20 dark:hover:bg-rose-500/25',
  }[variant]
  return (
    <motion.button
      type={type}
      onClick={onClick}
      disabled={disabled}
      whileTap={{ scale: 0.97 }}
      className={`focus-ring rounded-xl px-4 py-2 text-sm transition-all duration-500 disabled:opacity-40 ${styles} ${className}`}
    >
      {children}
    </motion.button>
  )
}

export function MetricCard({
  label, value, hint, accent = 'from-cyanide to-indigoGlow', delay = 0,
}: { label: string; value: string | number; hint?: string; accent?: string; delay?: number }) {
  return (
    <GlassCard delay={delay} className="relative overflow-hidden">
      <div className={`absolute inset-x-0 top-0 h-px bg-gradient-to-r ${accent}`} />
      <p className="eyebrow">{label}</p>
      <p className="mt-2 font-display text-3xl font-bold text-slate-900 dark:text-white">{value}</p>
      {hint && <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">{hint}</p>}
    </GlassCard>
  )
}

export function ConfidenceMeter({ value }: { value: number }) {
  const pct = Math.round(value * 100)
  const tone = pct >= 75 ? 'from-tealGlow to-cyanide' : pct >= 50 ? 'from-cyanide to-indigoGlow' : 'from-amber-400 to-rose-400'
  return (
    <div className="flex items-center gap-2">
      <div className="h-1.5 w-24 overflow-hidden rounded-full bg-slate-900/10 dark:bg-white/10">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${pct}%` }}
          transition={{ duration: 0.8, ease: 'easeOut' }}
          className={`h-full rounded-full bg-gradient-to-r ${tone}`}
        />
      </div>
      <span className="font-mono text-[11px] text-slate-500 dark:text-slate-400">{pct}%</span>
    </div>
  )
}

export function Badge({ children, tone = 'cyan' }: { children: ReactNode; tone?: string }) {
  const tones: Record<string, string> = {
    cyan: 'border-cyanide/40 text-cyanide bg-cyanide/10',
    violet: 'border-violetGlow/40 text-violet-300 bg-violetGlow/10',
    amber: 'border-amber-400/40 text-amber-300 bg-amber-400/10',
    rose: 'border-rose-400/40 text-rose-300 bg-rose-400/10',
    slate: 'border-slate-900/15 text-slate-600 bg-slate-900/5 dark:border-white/15 dark:text-slate-300 dark:bg-white/5',
  }
  return (
    <span className={`rounded-full border px-2.5 py-0.5 font-mono text-[10px] uppercase tracking-wider ${tones[tone] ?? tones.slate}`}>
      {children}
    </span>
  )
}

export function ThinkingLoader({ label = 'Agents are working' }: { label?: string }) {
  return (
    <div className="flex items-center gap-3 text-sm text-slate-600 dark:text-slate-300">
      <span className="relative flex h-3 w-3">
        <span className="absolute inline-flex h-full w-full rounded-full bg-cyanide/60 animate-pulseRing" />
        <span className="relative inline-flex h-3 w-3 rounded-full bg-cyanide" />
      </span>
      {label}
      <span className="flex gap-1">
        {[0, 1, 2].map((i) => (
          <motion.span
            key={i}
            animate={{ opacity: [0.2, 1, 0.2] }}
            transition={{ duration: 1.2, repeat: Infinity, delay: i * 0.2 }}
            className="h-1 w-1 rounded-full bg-slate-500 dark:bg-slate-300"
          />
        ))}
      </span>
    </div>
  )
}

export function EmptyState({ title, action }: { title: string; action?: string }) {
  return (
    <div className="glass rounded-2xl p-8 text-center">
      <p className="font-display text-lg text-slate-900 dark:text-white">{title}</p>
      {action && <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">{action}</p>}
    </div>
  )
}

export function SectionHeading({ eyebrow, title, description }: {
  eyebrow: string; title: string; description?: string
}) {
  return (
    <div className="mb-6">
      <p className="eyebrow">{eyebrow}</p>
      <h1 className="mt-1 font-display text-3xl font-bold text-slate-900 dark:text-white">{title}</h1>
      {description && <p className="mt-2 max-w-2xl text-sm text-slate-500 dark:text-slate-400">{description}</p>}
    </div>
  )
}
