import axios from 'axios'
import type {
  CaptureResult, CopilotReply, DashboardData, HealthReport, KnowledgeItem, SimulationSession, User,
} from '../types'

export const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE ?? '/api',
})

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('aegis_token')
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error?.response?.status === 401 && !location.pathname.startsWith('/login')) {
      localStorage.removeItem('aegis_token')
      location.assign('/login')
    }
    return Promise.reject(error)
  },
)

export const auth = {
  login: (email: string, password: string) =>
    api.post<{ access_token: string; user: User }>('/auth/login', { email, password })
      .then((r) => r.data),
  me: () => api.get<User>('/auth/me').then((r) => r.data),
}

export const capture = {
  submit: (payload: {
    title: string; source_type: string; content: string
    consent_granted: boolean; domain: string
  }) => api.post<CaptureResult>('/capture', payload).then((r) => r.data),
  sessions: () => api.get('/capture/sessions').then((r) => r.data),
}

export const knowledge = {
  list: (params?: { status?: string; domain?: string }) =>
    api.get<KnowledgeItem[]>('/knowledge', { params }).then((r) => r.data),
  queue: () => api.get<KnowledgeItem[]>('/validation/queue').then((r) => r.data),
  detail: (id: string) => api.get(`/knowledge/${id}`).then((r) => r.data),
  review: (id: string, payload: Record<string, unknown>) =>
    api.post<KnowledgeItem>(`/validation/${id}`, payload).then((r) => r.data),
  search: (query: string, top_k = 5) =>
    api.post('/search', { query, top_k }).then((r) => r.data),
}

export const graph = {
  fetch: (params?: { node_type?: string; q?: string }) =>
    api.get('/graph', { params }).then((r) => r.data),
}

export const copilot = {
  ask: (question: string, history: { role: string; content: string }[] = []) =>
    api.post<CopilotReply>('/copilot', { question, history }).then((r) => r.data),
}

export const simulation = {
  scenarios: () => api.get('/simulation/scenarios').then((r) => r.data),
  start: (scenario: string) =>
    api.post<SimulationSession>('/simulation/start', { scenario }).then((r) => r.data),
  answer: (payload: Record<string, unknown>) =>
    api.post('/simulation/answer', payload).then((r) => r.data),
  progress: () => api.get('/simulation/progress').then((r) => r.data),
}

export const health = {
  report: () => api.get<HealthReport>('/knowledge-health').then((r) => r.data),
  requestRefresh: (id: string) =>
    api.post(`/knowledge-health/refresh/${id}`).then((r) => r.data),
}

export const analytics = {
  dashboard: () => api.get<DashboardData>('/analytics/dashboard').then((r) => r.data),
  notifications: () => api.get('/notifications').then((r) => r.data),
}

export const governance = {
  pii: () => api.get('/governance/pii').then((r) => r.data),
  audit: () => api.get('/governance/audit').then((r) => r.data),
  consent: () => api.get('/governance/consent').then((r) => r.data),
  access: () => api.get('/governance/access').then((r) => r.data),
}

export const admin = {
  users: () => api.get<User[]>('/admin/users').then((r) => r.data),
  updateUser: (id: string, payload: Record<string, unknown>) =>
    api.patch(`/admin/users/${id}`, payload).then((r) => r.data),
  prompts: () => api.get('/admin/prompts').then((r) => r.data),
  savePrompt: (key: string, template: string) =>
    api.put(`/admin/prompts/${key}`, { template }).then((r) => r.data),
  system: () => api.get('/admin/system').then((r) => r.data),
  agents: () => api.get('/admin/agents').then((r) => r.data),
}

export const status = () => api.get('/status').then((r) => r.data)
