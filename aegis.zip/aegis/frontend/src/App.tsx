import { Suspense, lazy, useEffect } from 'react'
import { Navigate, Route, Routes } from 'react-router-dom'
import { AppShell } from './layouts/AppShell'
import { Landing } from './pages/Landing'
import { Login } from './pages/Login'
import { useAuth } from './store/useAuth'
import { ThinkingLoader } from './components/ui'

// Route-level code splitting: charts and the graph canvas are heavy and only
// load when someone actually opens those screens.
const Dashboard = lazy(() => import('./pages/Dashboard').then((m) => ({ default: m.Dashboard })))
const Capture = lazy(() => import('./pages/Capture').then((m) => ({ default: m.Capture })))
const Validation = lazy(() => import('./pages/Validation').then((m) => ({ default: m.Validation })))
const KnowledgeGraph = lazy(() => import('./pages/KnowledgeGraph').then((m) => ({ default: m.KnowledgeGraph })))
const Copilot = lazy(() => import('./pages/Copilot').then((m) => ({ default: m.Copilot })))
const Simulator = lazy(() => import('./pages/Simulator').then((m) => ({ default: m.Simulator })))
const Health = lazy(() => import('./pages/Health').then((m) => ({ default: m.Health })))
const Governance = lazy(() => import('./pages/Governance').then((m) => ({ default: m.Governance })))
const Admin = lazy(() => import('./pages/Admin').then((m) => ({ default: m.Admin })))

function Protected({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth()
  if (loading) {
    return <div className="grid min-h-screen place-items-center"><ThinkingLoader label="Restoring session" /></div>
  }
  return user ? <>{children}</> : <Navigate to="/login" replace />
}

export default function App() {
  const restore = useAuth((state) => state.restore)
  useEffect(() => { restore() }, [restore])

  return (
    <Routes>
      <Route path="/" element={<Landing />} />
      <Route path="/login" element={<Login />} />
      <Route
        path="/app"
        element={
          <Protected>
            <Suspense fallback={<div className="p-8"><ThinkingLoader label="Loading workspace" /></div>}>
              <AppShell />
            </Suspense>
          </Protected>
        }
      >
        <Route index element={<Dashboard />} />
        <Route path="capture" element={<Capture />} />
        <Route path="validation" element={<Validation />} />
        <Route path="graph" element={<KnowledgeGraph />} />
        <Route path="copilot" element={<Copilot />} />
        <Route path="simulator" element={<Simulator />} />
        <Route path="health" element={<Health />} />
        <Route path="governance" element={<Governance />} />
        <Route path="admin" element={<Admin />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}
