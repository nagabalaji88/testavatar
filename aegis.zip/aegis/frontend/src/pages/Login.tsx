import { motion } from 'framer-motion'
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { AIOrb } from '../components/AIOrb'
import { AnimatedButton } from '../components/ui'
import { useAuth } from '../store/useAuth'

const DEMO = [
  ['priya.raman@aegis.dev', 'Expert'],
  ['marcus.hale@aegis.dev', 'Reviewer'],
  ['dana.oyelaran@aegis.dev', 'Learner'],
  ['admin@aegis.dev', 'Admin'],
]

export function Login() {
  const [email, setEmail] = useState('priya.raman@aegis.dev')
  const [password, setPassword] = useState('aegis1234')
  const [busy, setBusy] = useState(false)
  const { signIn, error } = useAuth()
  const navigate = useNavigate()

  const submit = async () => {
    setBusy(true)
    const ok = await signIn(email, password)
    setBusy(false)
    if (ok) navigate('/app')
  }

  return (
    <div className="grid min-h-screen place-items-center px-5">
      <motion.div
        initial={{ opacity: 0, scale: 0.96, filter: 'blur(10px)' }}
        animate={{ opacity: 1, scale: 1, filter: 'blur(0px)' }}
        transition={{ duration: 0.6 }}
        className="glass w-full max-w-md rounded-3xl p-8"
      >
        <div className="mb-6 grid place-items-center">
          <AIOrb size={150} />
        </div>
        <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-white">Sign in to AEGIS</h1>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">Use a demo account below. Password: aegis1234</p>

        <div className="mt-6 space-y-3">
          <input
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            placeholder="Work email"
            className="focus-ring w-full rounded-xl border border-slate-900/10 bg-slate-900/5 px-3 py-2.5 text-sm dark:border-white/10 dark:bg-white/5"
          />
          <input
            type="password"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            onKeyDown={(event) => event.key === 'Enter' && submit()}
            placeholder="Password"
            className="focus-ring w-full rounded-xl border border-slate-900/10 bg-slate-900/5 px-3 py-2.5 text-sm dark:border-white/10 dark:bg-white/5"
          />
          {error && <p className="text-xs text-rose-600 dark:text-rose-300">{error}</p>}
          <AnimatedButton onClick={submit} disabled={busy} className="w-full">
            {busy ? 'Signing in…' : 'Sign in'}
          </AnimatedButton>
        </div>

        <div className="mt-6 border-t border-slate-900/10 pt-4 dark:border-white/10">
          <p className="eyebrow mb-2">Demo accounts</p>
          <div className="grid grid-cols-2 gap-2">
            {DEMO.map(([demoEmail, role], index) => (
              <motion.button
                key={demoEmail}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 + index * 0.05 }}
                whileHover={{ y: -2 }}
                onClick={() => setEmail(demoEmail)}
                className="focus-ring rounded-lg border border-slate-900/10 bg-slate-900/5 px-2 py-1.5 text-left text-[11px] text-slate-600 hover:border-cyanide/40 dark:border-white/10 dark:bg-white/5 dark:text-slate-300"
              >
                <span className="block text-slate-900 dark:text-white">{role}</span>
                <span className="font-mono text-[10px] text-slate-400 dark:text-slate-500">{demoEmail}</span>
              </motion.button>
            ))}
          </div>
        </div>
      </motion.div>
    </div>
  )
}
