import { AnimatePresence, motion } from 'framer-motion'
import { Award, RotateCcw } from 'lucide-react'
import { useEffect, useState } from 'react'
import { AnimatedButton, Badge, GlassCard, SectionHeading } from '../components/ui'
import { stagger } from '../lib/motion'
import { simulation } from '../services/api'
import { useToast } from '../store/useToast'
import type { SimulationNode, SimulationSession } from '../types'

const SCENARIOS = [
  { id: 'incident', label: 'Incident response' },
  { id: 'architecture', label: 'Architecture choice' },
  { id: 'production', label: 'Production issue' },
  { id: 'hr', label: 'Team process' },
  { id: 'security', label: 'Security advisory' },
]

interface Step { node: string; choice: string; score: number }

export function Simulator() {
  const [session, setSession] = useState<SimulationSession | null>(null)
  const [node, setNode] = useState<SimulationNode | null>(null)
  const [path, setPath] = useState<Step[]>([])
  const [feedback, setFeedback] = useState<{ text: string; score: number }[]>([])
  const [total, setTotal] = useState(0)
  const [badge, setBadge] = useState('')
  const [progress, setProgress] = useState<{ attempts: number; average_score: number; badges: string[] } | null>(null)
  const push = useToast((s) => s.push)

  const loadProgress = () => simulation.progress().then(setProgress).catch(() => undefined)
  useEffect(() => { loadProgress() }, [])

  const start = async (scenario: string) => {
    const data = await simulation.start(scenario)
    setSession(data)
    setNode(data.tree.nodes[data.tree.root])
    setPath([])
    setFeedback([])
    setTotal(0)
    setBadge('')
  }

  const choose = async (choiceId: string) => {
    if (!session || !node) return
    const result = await simulation.answer({
      simulation_id: session.id, node_id: node.id, choice_id: choiceId, path,
    })
    setPath(result.path)
    setTotal(result.total)
    setFeedback((current) => [...current, { text: result.feedback, score: result.score }])
    if (result.finished) {
      setBadge(result.badge)
      setNode(null)
      push({ title: `Scenario complete — ${result.badge}`, body: `${result.total} of ${result.max_score} points.`, level: 'success' })
      loadProgress()
    } else {
      setNode(result.next_node)
    }
  }

  return (
    <>
      <SectionHeading
        eyebrow="Scenario simulator"
        title="Practise the decision before you have to make it"
        description="Scenarios are generated from approved knowledge, so the right answer is the one your experts would actually choose."
      />

      <div className="grid gap-4 lg:grid-cols-[1fr_320px]">
        <div className="space-y-4">
          <div className="flex flex-wrap gap-2">
            {SCENARIOS.map((scenario, index) => (
              <motion.div
                key={scenario.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={stagger(index)}
              >
                <AnimatedButton
                  variant={session?.scenario === scenario.id ? 'primary' : 'ghost'}
                  onClick={() => start(scenario.id)}
                >
                  {scenario.label}
                </AnimatedButton>
              </motion.div>
            ))}
          </div>

          {!session && (
            <GlassCard interactive={false}>
              <p className="text-sm text-slate-500 dark:text-slate-400">Pick a scenario to begin.</p>
            </GlassCard>
          )}

          <AnimatePresence mode="wait">
            {node && (
              <motion.div
                key={node.id}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.25 }}
              >
                <GlassCard interactive={false}>
                  <Badge tone="cyan">{session?.scenario}</Badge>
                  <p className="mt-3 font-display text-lg text-slate-900 dark:text-white">{node.prompt}</p>
                  <div className="mt-4 space-y-2">
                    {node.choices.map((choice, index) => (
                      <motion.button
                        key={choice.id}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={stagger(index)}
                        onClick={() => choose(choice.id)}
                        className="focus-ring w-full rounded-xl border border-slate-900/10 bg-slate-900/5 px-4 py-3 text-left text-sm text-slate-700 transition-colors hover:border-cyanide/50 hover:bg-cyanide/5 dark:border-white/10 dark:bg-white/5 dark:text-slate-200"
                      >
                        {choice.label}
                      </motion.button>
                    ))}
                  </div>
                </GlassCard>
              </motion.div>
            )}
          </AnimatePresence>

          {feedback.map((entry, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -12 }}
              animate={{ opacity: 1, x: 0 }}
              className="glass rounded-xl p-3 text-sm"
            >
              <span className={entry.score >= 10 ? 'text-tealGlow' : entry.score >= 5 ? 'text-amber-500 dark:text-amber-300' : 'text-rose-500 dark:text-rose-300'}>
                +{entry.score}
              </span>{' '}
              <span className="text-slate-600 dark:text-slate-300">{entry.text}</span>
            </motion.div>
          ))}

          <AnimatePresence>
            {badge && (
              <motion.div
                initial={{ opacity: 0, y: 12, scale: 0.98 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -8 }}
              >
                <GlassCard interactive={false}>
                  <div className="flex items-center gap-3">
                    <Award className="h-6 w-6 text-cyanide" />
                    <div>
                      <p className="font-display text-lg text-slate-900 dark:text-white">{badge}</p>
                      <p className="text-sm text-slate-500 dark:text-slate-400">You scored {total} points on this run.</p>
                    </div>
                    <AnimatedButton
                      variant="ghost"
                      className="ml-auto flex items-center gap-2"
                      onClick={() => session && start(session.scenario)}
                    >
                      <RotateCcw className="h-3.5 w-3.5" /> Run it again
                    </AnimatedButton>
                  </div>
                </GlassCard>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <GlassCard interactive={false}>
          <p className="eyebrow">Your progress</p>
          <p className="mt-3 font-display text-3xl font-bold text-slate-900 dark:text-white">{progress?.attempts ?? 0}</p>
          <p className="text-xs text-slate-400 dark:text-slate-500">scenarios completed</p>
          <p className="mt-4 text-sm text-slate-600 dark:text-slate-300">Average score {progress?.average_score ?? 0}</p>
          <div className="mt-4 flex flex-wrap gap-1.5">
            {(progress?.badges ?? []).map((earned, index) => (
              <motion.div
                key={earned}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={stagger(index)}
              >
                <Badge tone="violet">{earned}</Badge>
              </motion.div>
            ))}
            {(progress?.badges?.length ?? 0) === 0 && (
              <p className="text-xs text-slate-400 dark:text-slate-500">Badges appear once you finish a scenario.</p>
            )}
          </div>
        </GlassCard>
      </div>
    </>
  )
}
