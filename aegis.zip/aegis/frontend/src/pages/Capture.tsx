import { AnimatePresence, motion } from 'framer-motion'
import { FileText, ShieldAlert, Upload } from 'lucide-react'
import { useRef, useState } from 'react'
import { AgentTrace } from '../components/AgentTrace'
import { AnimatedButton, Badge, GlassCard, SectionHeading, ThinkingLoader } from '../components/ui'
import { stagger } from '../lib/motion'
import { capture } from '../services/api'
import { useToast } from '../store/useToast'
import type { CaptureResult } from '../types'

const SOURCES = [
  'meeting_transcript', 'slack_thread', 'teams_export', 'code_review',
  'pull_request', 'incident_report', 'voice_note',
]
const DOMAINS = ['Architecture', 'Platform Engineering', 'Reliability', 'Security', 'Data']

export function Capture() {
  const [title, setTitle] = useState('')
  const [sourceType, setSourceType] = useState(SOURCES[0])
  const [domain, setDomain] = useState(DOMAINS[0])
  const [content, setContent] = useState('')
  const [consent, setConsent] = useState(true)
  const [busy, setBusy] = useState(false)
  const [result, setResult] = useState<CaptureResult | null>(null)
  const [dragging, setDragging] = useState(false)
  const fileInput = useRef<HTMLInputElement>(null)
  const push = useToast((s) => s.push)

  const readFile = (file: File) => {
    const reader = new FileReader()
    reader.onload = () => {
      setContent(String(reader.result))
      if (!title) setTitle(file.name.replace(/\.[^.]+$/, ''))
    }
    reader.readAsText(file)
  }

  const run = async () => {
    if (title.trim().length < 3 || content.trim().length < 20) {
      push({ title: 'Add a title and some content', body: 'At least 20 characters of source text.', level: 'warning' })
      return
    }
    setBusy(true)
    setResult(null)
    try {
      const data = await capture.submit({
        title, source_type: sourceType, content, consent_granted: consent, domain,
      })
      setResult(data)
      push({
        title: consent ? `${data.items.length} cards drafted` : 'Capture blocked at the privacy gate',
        body: consent ? 'Send them to the validation queue when you are ready.' : 'Consent was not granted.',
        level: consent ? 'success' : 'warning',
      })
    } catch {
      push({ title: 'Capture failed', body: 'The pipeline did not complete. Try again.', level: 'error' })
    } finally {
      setBusy(false)
    }
  }

  return (
    <>
      <SectionHeading
        eyebrow="Ethical capture engine"
        title="Turn an artifact into reviewable knowledge"
        description="Drop in a transcript, pull request or postmortem. PII is removed before any extraction happens, and nothing is published without an expert’s approval."
      />

      <div className="grid gap-4 lg:grid-cols-[1.1fr_0.9fr]">
        <GlassCard>
          <div className="grid gap-3 sm:grid-cols-2">
            <input
              value={title}
              onChange={(event) => setTitle(event.target.value)}
              placeholder="What is this artifact?"
              className="focus-ring rounded-xl border border-slate-900/10 bg-slate-900/5 px-3 py-2 text-sm dark:border-white/10 dark:bg-white/5 sm:col-span-2"
            />
            <select
              value={sourceType}
              onChange={(event) => setSourceType(event.target.value)}
              className="focus-ring rounded-xl border border-slate-900/10 bg-slate-900/5 px-3 py-2 text-sm dark:border-white/10 dark:bg-white/5"
            >
              {SOURCES.map((source) => (
                <option key={source} value={source} className="bg-white dark:bg-deep">
                  {source.replace(/_/g, ' ')}
                </option>
              ))}
            </select>
            <select
              value={domain}
              onChange={(event) => setDomain(event.target.value)}
              className="focus-ring rounded-xl border border-slate-900/10 bg-slate-900/5 px-3 py-2 text-sm dark:border-white/10 dark:bg-white/5"
            >
              {DOMAINS.map((option) => (
                <option key={option} value={option} className="bg-white dark:bg-deep">{option}</option>
              ))}
            </select>
          </div>

          <div
            onDragOver={(event) => { event.preventDefault(); setDragging(true) }}
            onDragLeave={() => setDragging(false)}
            onDrop={(event) => {
              event.preventDefault()
              setDragging(false)
              const file = event.dataTransfer.files?.[0]
              if (file) readFile(file)
            }}
            onClick={() => fileInput.current?.click()}
            className={`mt-3 cursor-pointer rounded-xl border border-dashed p-6 text-center transition-colors ${
              dragging ? 'border-cyanide bg-cyanide/10' : 'border-slate-900/15 hover:border-cyanide/40 dark:border-white/15'
            }`}
          >
            <Upload className="mx-auto h-5 w-5 text-cyanide" />
            <p className="mt-2 text-sm text-slate-600 dark:text-slate-300">Drop a text file, or click to choose one</p>
            <p className="text-xs text-slate-400 dark:text-slate-500">Transcripts, diffs, postmortems, exported threads</p>
            <input
              ref={fileInput}
              type="file"
              accept=".txt,.md,.log,.json,.diff"
              className="hidden"
              onChange={(event) => event.target.files?.[0] && readFile(event.target.files[0])}
            />
          </div>

          <textarea
            value={content}
            onChange={(event) => setContent(event.target.value)}
            rows={10}
            placeholder="Or paste the conversation here…"
            className="focus-ring mt-3 w-full rounded-xl border border-slate-900/10 bg-slate-900/5 p-3 font-mono text-xs leading-relaxed dark:border-white/10 dark:bg-white/5"
          />

          <label className="mt-3 flex items-center gap-2 text-sm text-slate-600 dark:text-slate-300">
            <input
              type="checkbox"
              checked={consent}
              onChange={(event) => setConsent(event.target.checked)}
              className="h-4 w-4 accent-cyanide"
            />
            Everyone in this artifact consented to knowledge capture
          </label>

          <div className="mt-4 flex items-center gap-3">
            <AnimatedButton onClick={run} disabled={busy}>
              {busy ? 'Running pipeline…' : 'Run capture pipeline'}
            </AnimatedButton>
            {busy && <ThinkingLoader />}
          </div>
        </GlassCard>

        <div className="space-y-4">
          <GlassCard>
            <p className="eyebrow">Agent pipeline</p>
            {!result && !busy && (
              <p className="mt-3 text-sm text-slate-400 dark:text-slate-500">
                The five capture agents will report here as they run.
              </p>
            )}
            {busy && <div className="mt-3"><ThinkingLoader label="Privacy gate first" /></div>}
            {result && <div className="mt-3"><AgentTrace steps={result.trace} /></div>}
          </GlassCard>

          <AnimatePresence>
            {result && (
              <motion.div
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
              >
                <GlassCard>
                  <div className="flex items-center gap-2">
                    <ShieldAlert className="h-4 w-4 text-amber-300" />
                    <p className="eyebrow">Privacy findings</p>
                    <span className="ml-auto"><Badge tone={result.pii_findings.length ? 'amber' : 'cyan'}>
                      {result.pii_findings.length} redacted
                    </Badge></span>
                  </div>
                  <div className="mt-3 flex flex-wrap gap-1.5">
                    {result.pii_findings.map((finding, index) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={stagger(index)}
                      >
                        <Badge tone={finding.severity === 'high' ? 'rose' : 'amber'}>
                          {finding.type}
                        </Badge>
                      </motion.div>
                    ))}
                    {result.pii_findings.length === 0 && (
                      <p className="text-sm text-slate-400 dark:text-slate-500">No personal data detected in this artifact.</p>
                    )}
                  </div>
                  <pre className="mt-3 max-h-40 overflow-auto rounded-lg border border-slate-900/10 bg-slate-900/5 p-3 font-mono text-[11px] text-slate-500 dark:border-white/10 dark:bg-black/30 dark:text-slate-400">
                    {result.redacted_content.slice(0, 900)}
                  </pre>
                </GlassCard>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      <AnimatePresence>
        {result && result.items.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="mt-6"
          >
            <p className="eyebrow mb-3">Drafted cards · pending expert review</p>
            <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
              {result.items.map((item, index) => (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, y: 14 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.06 }}
                  className="glass rounded-2xl p-4"
                >
                  <div className="flex items-center gap-2">
                    <FileText className="h-4 w-4 text-cyanide" />
                    <Badge tone="violet">{item.kind.replace('_', ' ')}</Badge>
                  </div>
                  <p className="mt-2 text-sm text-slate-900 dark:text-white">{item.title}</p>
                  <div className="mt-3 flex flex-wrap gap-1">
                    {item.tags.slice(0, 4).map((tag, tagIndex) => (
                      <motion.div
                        key={tag}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={stagger(tagIndex)}
                      >
                        <Badge tone="slate">{tag}</Badge>
                      </motion.div>
                    ))}
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
