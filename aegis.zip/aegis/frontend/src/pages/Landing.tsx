import { motion } from 'framer-motion'
import { ArrowRight, BrainCircuit, GraduationCap, Network, ShieldCheck } from 'lucide-react'
import { Link } from 'react-router-dom'
import { AIOrb } from '../components/AIOrb'
import { AnimatedButton, GlassCard } from '../components/ui'

const PILLARS = [
  { icon: ShieldCheck, title: 'Consent first', body: 'Nothing is captured without consent, and PII is stripped before any model sees the text.' },
  { icon: BrainCircuit, title: 'Human validated', body: 'Agents draft; experts approve. No knowledge is published on a model’s say-so.' },
  { icon: Network, title: 'Connected, not filed', body: 'Decisions link to the experts, technologies and incidents that shaped them.' },
  { icon: GraduationCap, title: 'Taught, not stored', body: 'Juniors meet knowledge as scenarios they have to reason through.' },
]

const STAGES = [
  ['Capture', 'A transcript, PR or incident report goes in.'],
  ['Redact', 'The privacy agent removes PII before extraction.'],
  ['Structure', 'Candidates become decision records with consequences.'],
  ['Validate', 'An expert approves, edits or rejects each card.'],
  ['Transfer', 'Copilot answers and simulations draw on approved records only.'],
]

export function Landing() {
  return (
    <div className="mx-auto max-w-6xl px-5 py-10">
      <nav className="mb-16 flex items-center justify-between">
        <span className="font-display text-xl font-bold gradient-text">AEGIS</span>
        <Link to="/login">
          <AnimatedButton>Sign in</AnimatedButton>
        </Link>
      </nav>

      <section className="grid items-center gap-10 lg:grid-cols-[1.15fr_0.85fr]">
        <div>
          <p className="eyebrow">Tacit knowledge operating system</p>
          <h1 className="mt-3 font-display text-5xl font-bold leading-[1.05] text-slate-900 dark:text-white sm:text-6xl">
            The reasoning behind your best decisions{' '}
            <span className="gradient-text">leaves with the people who made them.</span>
          </h1>
          <p className="mt-5 max-w-xl text-slate-500 dark:text-slate-400">
            AEGIS captures how your experts actually think — from meetings, pull requests and
            postmortems — validates it with those same experts, and teaches it to everyone else.
          </p>
          <div className="mt-7 flex flex-wrap gap-3">
            <Link to="/login">
              <AnimatedButton className="flex items-center gap-2">
                Open the workspace <ArrowRight className="h-4 w-4" />
              </AnimatedButton>
            </Link>
            <Link to="/login">
              <AnimatedButton variant="ghost">See the demo data</AnimatedButton>
            </Link>
          </div>
          <dl className="mt-10 grid grid-cols-3 gap-4 border-t border-slate-900/10 pt-6 dark:border-white/10">
            {[['8', 'specialist agents'], ['5', 'stage capture pipeline'], ['0', 'records published unreviewed']].map(
              ([value, label], index) => (
                <motion.div
                  key={label}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 + index * 0.08 }}
                >
                  <dt className="font-display text-3xl font-bold text-slate-900 dark:text-white">{value}</dt>
                  <dd className="mt-1 text-xs text-slate-400 dark:text-slate-500">{label}</dd>
                </motion.div>
              ),
            )}
          </dl>
        </div>
        <div className="grid place-items-center">
          <AIOrb size={320} />
        </div>
      </section>

      <section className="mt-24 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {PILLARS.map(({ icon: Icon, title, body }, index) => (
          <GlassCard key={title} delay={index * 0.08}>
            <Icon className="h-5 w-5 text-cyanide" />
            <h3 className="mt-3 font-display text-base text-slate-900 dark:text-white">{title}</h3>
            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">{body}</p>
          </GlassCard>
        ))}
      </section>

      <section className="mt-24">
        <p className="eyebrow">How a capture moves through the system</p>
        <div className="mt-6 space-y-3">
          {STAGES.map(([title, body], index) => (
            <motion.div
              key={title}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.07 }}
              className="glass flex items-center gap-4 rounded-xl p-4"
            >
              <span className="font-mono text-xs text-cyanide">{String(index + 1).padStart(2, '0')}</span>
              <span className="font-display text-slate-900 dark:text-white">{title}</span>
              <span className="text-sm text-slate-500 dark:text-slate-400">{body}</span>
            </motion.div>
          ))}
        </div>
      </section>

      <footer className="mt-24 border-t border-slate-900/10 py-8 text-xs text-slate-400 dark:border-white/10 dark:text-slate-500">
        AEGIS — ethical tacit knowledge capture and dynamic transfer.
      </footer>
    </div>
  )
}
