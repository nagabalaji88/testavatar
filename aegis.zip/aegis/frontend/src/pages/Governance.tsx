import { motion } from 'framer-motion'
import { useEffect, useState } from 'react'
import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from 'recharts'
import { Badge, GlassCard, MetricCard, SectionHeading, ThinkingLoader } from '../components/ui'
import { rechartsTheme } from '../lib/chartTheme'
import { stagger } from '../lib/motion'
import { governance } from '../services/api'
import { useTheme } from '../store/useTheme'

const COLORS = ['#22d3ee', '#8b5cf6', '#2dd4bf', '#6366f1', '#f59e0b', '#f43f5e']

interface Pii { total_findings: number; sessions_scanned: number; by_type: { name: string; value: number }[] }
interface AuditRow { id: string; actor: string; action: string; target: string; created_at: string }
interface ConsentRow { session_id: string; title: string; source_type: string; consent_granted: boolean; author: string }
interface Access { visibility: { name: string; value: number }[]; roles: Record<string, string[]> }

export function Governance() {
  const [pii, setPii] = useState<Pii | null>(null)
  const [audit, setAudit] = useState<AuditRow[]>([])
  const [consent, setConsent] = useState<ConsentRow[]>([])
  const [access, setAccess] = useState<Access | null>(null)
  const { theme } = useTheme()
  const chart = rechartsTheme(theme === 'dark')

  useEffect(() => {
    governance.pii().then(setPii).catch(() => undefined)
    governance.audit().then(setAudit).catch(() => undefined)
    governance.consent().then(setConsent).catch(() => undefined)
    governance.access().then(setAccess).catch(() => undefined)
  }, [])

  if (!pii) return <ThinkingLoader label="Loading governance records" />

  return (
    <>
      <SectionHeading
        eyebrow="Governance center"
        title="Prove what was captured, and what was never stored"
        description="Consent, redaction and access are recorded per artifact, so an auditor can reconstruct any decision."
      />

      <div className="grid gap-4 sm:grid-cols-3">
        <MetricCard label="PII spans redacted" value={pii.total_findings} hint={`${pii.sessions_scanned} artifacts scanned`} />
        <MetricCard label="Consent on file" value={`${consent.filter((c) => c.consent_granted).length}/${consent.length}`} accent="from-tealGlow to-cyanide" delay={0.06} />
        <MetricCard label="Audit events" value={audit.length} accent="from-violetGlow to-indigoGlow" delay={0.12} />
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <GlassCard>
          <p className="eyebrow">Redactions by type</p>
          <div className="mt-2 h-56">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={pii.by_type} dataKey="value" nameKey="name" innerRadius={48} outerRadius={80} paddingAngle={3}>
                  {pii.by_type.map((entry, index) => (
                    <Cell key={entry.name} fill={COLORS[index % COLORS.length]} stroke="none" />
                  ))}
                </Pie>
                <Tooltip contentStyle={chart.tooltipStyle} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {pii.by_type.map((entry, index) => (
              <motion.div
                key={entry.name}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={stagger(index)}
              >
                <Badge tone="slate">{entry.name} · {entry.value}</Badge>
              </motion.div>
            ))}
          </div>
        </GlassCard>

        <GlassCard>
          <p className="eyebrow">Access model</p>
          <div className="mt-3 space-y-2">
            {Object.entries(access?.roles ?? {}).map(([role, permissions], index) => (
              <motion.div
                key={role}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={stagger(index)}
                className="rounded-xl border border-slate-900/10 bg-slate-900/5 p-3 dark:border-white/10 dark:bg-white/5"
              >
                <p className="text-sm text-slate-900 dark:text-white">{role}</p>
                <div className="mt-1.5 flex flex-wrap gap-1">
                  {permissions.map((permission) => (
                    <Badge key={permission} tone="cyan">{permission}</Badge>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </GlassCard>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <GlassCard>
          <p className="eyebrow">Consent register</p>
          <ul className="mt-3 space-y-2">
            {consent.slice(0, 8).map((row, index) => (
              <motion.li
                key={row.session_id}
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                transition={stagger(index)}
                className="flex items-center gap-2 text-sm"
              >
                <span className="min-w-0 flex-1 truncate text-slate-600 dark:text-slate-300">{row.title}</span>
                <Badge tone={row.consent_granted ? 'cyan' : 'rose'}>
                  {row.consent_granted ? 'granted' : 'missing'}
                </Badge>
              </motion.li>
            ))}
          </ul>
        </GlassCard>

        <GlassCard>
          <p className="eyebrow">Audit trail</p>
          <ul className="mt-3 max-h-64 space-y-2 overflow-y-auto pr-1">
            {audit.slice(0, 20).map((row, index) => (
              <motion.li
                key={row.id}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                transition={stagger(index, 0.03)}
                className="font-mono text-[11px] text-slate-500 dark:text-slate-400"
              >
                <span className="text-cyan-700 dark:text-cyanide">{row.action}</span> · {row.actor}
                <span className="ml-2 text-slate-400 dark:text-slate-600">{new Date(row.created_at).toLocaleString()}</span>
              </motion.li>
            ))}
          </ul>
        </GlassCard>
      </div>
    </>
  )
}
