import { motion } from 'framer-motion'
import { useEffect, useState } from 'react'
import {
  Area, AreaChart, Bar, BarChart, CartesianGrid, PolarAngleAxis, PolarGrid, Radar, RadarChart,
  ResponsiveContainer, Tooltip, XAxis, YAxis,
} from 'recharts'
import { rechartsTheme } from '../lib/chartTheme'
import { stagger } from '../lib/motion'
import { analytics } from '../services/api'
import { useTheme } from '../store/useTheme'
import type { DashboardData } from '../types'
import { GlassCard, MetricCard, SectionHeading, ThinkingLoader } from '../components/ui'

export function Dashboard() {
  const [data, setData] = useState<DashboardData | null>(null)
  const { theme } = useTheme()
  const chart = rechartsTheme(theme === 'dark')

  useEffect(() => {
    analytics.dashboard().then(setData).catch(() => undefined)
  }, [])

  if (!data) return <ThinkingLoader label="Loading knowledge metrics" />
  const m = data.metrics

  return (
    <>
      <SectionHeading
        eyebrow="Overview"
        title="Knowledge at a glance"
        description="What has been captured, what is waiting on a human, and how well it is holding up over time."
      />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <MetricCard label="Knowledge captured" value={m.knowledge_captured} hint={`${m.approved} approved`} delay={0} />
        <MetricCard label="Pending reviews" value={m.pending_reviews} hint="Waiting on an expert" accent="from-amber-400 to-rose-400" delay={0.06} />
        <MetricCard label="Knowledge health" value={`${Math.round(m.knowledge_health * 100)}%`} hint={`Decay ${Math.round(m.decay_score * 100)}%`} accent="from-tealGlow to-cyanide" delay={0.12} />
        <MetricCard label="Retrievals" value={m.daily_ai_usage} hint={`${m.active_learners} active learners`} accent="from-violetGlow to-indigoGlow" delay={0.18} />
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <GlassCard className="lg:col-span-2" delay={0.2}>
          <p className="eyebrow">Capture timeline · 14 days</p>
          <div className="mt-4 h-56">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data.timeline}>
                <defs>
                  <linearGradient id="capture" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#22d3ee" stopOpacity={0.55} />
                    <stop offset="100%" stopColor="#6366f1" stopOpacity={0.05} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke={chart.grid} />
                <XAxis dataKey="date" tick={chart.axis} tickFormatter={(v: string) => v.slice(5)} />
                <YAxis tick={chart.axis} allowDecimals={false} />
                <Tooltip contentStyle={chart.tooltipStyle} />
                <Area type="monotone" dataKey="captured" stroke="#22d3ee" fill="url(#capture)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </GlassCard>

        <GlassCard delay={0.26}>
          <p className="eyebrow">Coverage by domain</p>
          <div className="mt-4 h-56">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart data={data.by_domain}>
                <PolarGrid stroke={chart.polarGrid} />
                <PolarAngleAxis dataKey="name" tick={chart.angleAxisTick} />
                <Radar dataKey="value" stroke="#8b5cf6" fill="#8b5cf6" fillOpacity={0.35} />
                <Tooltip contentStyle={chart.tooltipStyle} />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </GlassCard>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <GlassCard delay={0.3}>
          <p className="eyebrow">Knowledge types</p>
          <div className="mt-4 h-52">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data.by_kind}>
                <CartesianGrid strokeDasharray="3 3" stroke={chart.grid} />
                <XAxis dataKey="name" tick={chart.axis} />
                <YAxis tick={chart.axis} allowDecimals={false} />
                <Tooltip contentStyle={chart.tooltipStyle} cursor={{ fill: chart.cursorFill }} />
                <Bar dataKey="value" fill="#22d3ee" radius={[6, 6, 0, 0]} animationDuration={900} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </GlassCard>

        <GlassCard delay={0.34}>
          <p className="eyebrow">Most reused records</p>
          <ul className="mt-4 space-y-2">
            {data.top_used.map((row, index) => (
              <motion.li
                key={row.title}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={stagger(index)}
                className="flex items-center gap-3"
              >
                <span className="min-w-0 flex-1 truncate text-sm text-slate-600 dark:text-slate-300">{row.title}</span>
                <div className="h-1.5 w-24 overflow-hidden rounded-full bg-slate-900/10 dark:bg-white/10">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${Math.min(row.usage * 5, 100)}%` }}
                    transition={{ duration: 0.6, ease: 'easeOut', delay: index * 0.04 }}
                    className="h-full rounded-full bg-gradient-to-r from-cyanide to-violetGlow"
                  />
                </div>
                <span className="w-6 text-right font-mono text-[11px] text-slate-400 dark:text-slate-500">{row.usage}</span>
              </motion.li>
            ))}
          </ul>
        </GlassCard>
      </div>
    </>
  )
}
