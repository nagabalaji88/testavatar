import { motion } from 'framer-motion'
import { useEffect, useState } from 'react'
import { AnimatedButton, GlassCard, MetricCard, SectionHeading, ThinkingLoader } from '../components/ui'
import { stagger } from '../lib/motion'
import { health } from '../services/api'
import { useTheme } from '../store/useTheme'
import { useToast } from '../store/useToast'
import type { HealthReport } from '../types'

function Gauge({ value, isDark }: { value: number; isDark: boolean }) {
  const pct = Math.max(0, Math.min(value, 1))
  const circumference = 2 * Math.PI * 70
  return (
    <svg viewBox="0 0 180 180" className="h-48 w-48">
      <circle cx="90" cy="90" r="70" fill="none" stroke={isDark ? 'rgba(255,255,255,0.08)' : 'rgba(15,23,42,0.08)'} strokeWidth="12" />
      <motion.circle
        cx="90" cy="90" r="70" fill="none" stroke="url(#gaugeGradient)" strokeWidth="12"
        strokeLinecap="round" transform="rotate(-90 90 90)"
        strokeDasharray={circumference}
        initial={{ strokeDashoffset: circumference }}
        animate={{ strokeDashoffset: circumference * (1 - pct) }}
        transition={{ duration: 1.2, ease: 'easeOut' }}
      />
      <defs>
        <linearGradient id="gaugeGradient" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#22d3ee" />
          <stop offset="100%" stopColor="#8b5cf6" />
        </linearGradient>
      </defs>
      <text x="90" y="86" textAnchor="middle" className="fill-slate-900 dark:fill-white font-display text-3xl font-bold">
        {Math.round(pct * 100)}%
      </text>
      <text x="90" y="108" textAnchor="middle" className="fill-slate-500 dark:fill-slate-400 text-[10px] uppercase tracking-widest">
        health
      </text>
    </svg>
  )
}

export function Health() {
  const [report, setReport] = useState<HealthReport | null>(null)
  const push = useToast((s) => s.push)
  const { theme } = useTheme()

  const load = () => health.report().then(setReport).catch(() => undefined)
  useEffect(() => { load() }, [])

  const requestRefresh = async (id: string, title: string) => {
    const result = await health.requestRefresh(id)
    push({ title: 'Refresh requested', body: `${result.expert} will confirm “${title.slice(0, 40)}”.`, level: 'success' })
  }

  if (!report) return <ThinkingLoader label="Scoring knowledge decay" />

  return (
    <>
      <SectionHeading
        eyebrow="Knowledge health"
        title="Knowledge rots quietly"
        description="Freshness decays on a 120-day half-life. Records that fall below the threshold go back to their author before anyone learns something outdated."
      />

      <div className="grid gap-4 lg:grid-cols-[auto_1fr]">
        <GlassCard interactive={false} className="grid place-items-center">
          <Gauge value={report.health} isDark={theme === 'dark'} />
        </GlassCard>
        <div className="grid gap-4 sm:grid-cols-3">
          <MetricCard label="Freshness" value={`${Math.round(report.freshness * 100)}%`} hint="Average across approved records" />
          <MetricCard label="Decay" value={`${Math.round(report.decay * 100)}%`} accent="from-amber-400 to-rose-400" delay={0.06} />
          <MetricCard label="Approved records" value={report.total} accent="from-tealGlow to-cyanide" delay={0.12} />
        </div>
      </div>

      <div className="mt-6">
        <p className="eyebrow mb-3">Recall queue · lowest health first</p>
        {report.recall_queue.length === 0 ? (
          <GlassCard interactive={false}>
            <p className="text-sm text-slate-500 dark:text-slate-400">Everything is within the freshness threshold.</p>
          </GlassCard>
        ) : (
          <div className="space-y-2">
            {report.recall_queue.map((item, index) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={stagger(index, 0.05)}
                className="glass flex flex-wrap items-center gap-3 rounded-xl p-3"
              >
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm text-slate-700 dark:text-slate-200">{item.title}</p>
                  <p className="font-mono text-[10px] text-slate-400 dark:text-slate-500">
                    {item.age_days} days since review · health {Math.round(item.health * 100)}%
                  </p>
                </div>
                <div className="h-1.5 w-28 overflow-hidden rounded-full bg-slate-900/10 dark:bg-white/10">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${Math.round(item.decay * 100)}%` }}
                    transition={{ duration: 0.6, ease: 'easeOut', delay: index * 0.05 }}
                    className="h-full rounded-full bg-gradient-to-r from-rose-400 to-amber-400"
                  />
                </div>
                <AnimatedButton variant="ghost" onClick={() => requestRefresh(item.id, item.title)}>
                  Ask the author
                </AnimatedButton>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </>
  )
}
