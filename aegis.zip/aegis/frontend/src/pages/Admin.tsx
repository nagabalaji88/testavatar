import { motion } from 'framer-motion'
import { useEffect, useState } from 'react'
import { AnimatedButton, Badge, GlassCard, SectionHeading, ThinkingLoader } from '../components/ui'
import { stagger } from '../lib/motion'
import { admin } from '../services/api'
import { useToast } from '../store/useToast'
import type { User } from '../types'

const ROLES = ['expert', 'reviewer', 'learner', 'admin']

interface Prompt { id: string; key: string; description: string; template: string }
interface SystemInfo { model: string; llm_mode: string; vector_dimensions: number; decay_half_life_days: number; database: string }
interface AgentInfo { name: string; description: string }

export function Admin() {
  const [users, setUsers] = useState<User[]>([])
  const [prompts, setPrompts] = useState<Prompt[]>([])
  const [system, setSystem] = useState<SystemInfo | null>(null)
  const [agents, setAgents] = useState<AgentInfo[]>([])
  const [denied, setDenied] = useState(false)
  const [draft, setDraft] = useState<Record<string, string>>({})
  const push = useToast((s) => s.push)

  useEffect(() => {
    admin.users().then(setUsers).catch(() => setDenied(true))
    admin.prompts().then(setPrompts).catch(() => undefined)
    admin.system().then(setSystem).catch(() => undefined)
    admin.agents().then(setAgents).catch(() => undefined)
  }, [])

  const changeRole = async (id: string, role: string) => {
    await admin.updateUser(id, { role })
    setUsers((current) => current.map((u) => (u.id === id ? { ...u, role: role as User['role'] } : u)))
    push({ title: 'Role updated', level: 'success' })
  }

  const savePrompt = async (key: string) => {
    await admin.savePrompt(key, draft[key] ?? '')
    push({ title: 'Prompt saved', body: key, level: 'success' })
  }

  if (denied) {
    return (
      <GlassCard interactive={false}>
        <p className="font-display text-lg text-slate-900 dark:text-white">Admin access required</p>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">Sign in as admin@aegis.dev to configure the system.</p>
      </GlassCard>
    )
  }

  if (!system) return <ThinkingLoader label="Loading configuration" />

  return (
    <>
      <SectionHeading
        eyebrow="Admin"
        title="People, prompts and pipeline configuration"
        description="Everything the agents rely on is editable here, so the system can be tuned without a redeploy."
      />

      <div className="grid gap-4 lg:grid-cols-2">
        <GlassCard>
          <p className="eyebrow">People and roles</p>
          <ul className="mt-3 space-y-2">
            {users.map((user, index) => (
              <motion.li
                key={user.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={stagger(index)}
                className="flex flex-wrap items-center gap-2 rounded-xl border border-slate-900/10 bg-slate-900/5 p-2.5 dark:border-white/10 dark:bg-white/5"
              >
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm text-slate-900 dark:text-white">{user.full_name}</p>
                  <p className="font-mono text-[10px] text-slate-400 dark:text-slate-500">{user.email}</p>
                </div>
                <select
                  value={user.role}
                  onChange={(event) => changeRole(user.id, event.target.value)}
                  className="focus-ring rounded-lg border border-slate-900/10 bg-slate-900/5 px-2 py-1 text-xs dark:border-white/10 dark:bg-white/5"
                >
                  {ROLES.map((role) => (
                    <option key={role} value={role} className="bg-white dark:bg-deep">{role}</option>
                  ))}
                </select>
              </motion.li>
            ))}
          </ul>
        </GlassCard>

        <GlassCard>
          <p className="eyebrow">System configuration</p>
          <dl className="mt-3 space-y-2 text-sm">
            {[
              ['Model', system.model],
              ['Inference mode', system.llm_mode],
              ['Vector dimensions', String(system.vector_dimensions)],
              ['Decay half-life', `${system.decay_half_life_days} days`],
              ['Database', system.database],
            ].map(([label, value], index) => (
              <motion.div
                key={label}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={stagger(index)}
                className="flex items-center justify-between border-b border-slate-900/5 pb-1.5 dark:border-white/5"
              >
                <dt className="text-slate-500 dark:text-slate-400">{label}</dt>
                <dd className="font-mono text-xs text-slate-700 dark:text-slate-200">{value}</dd>
              </motion.div>
            ))}
          </dl>
        </GlassCard>
      </div>

      <GlassCard className="mt-4">
        <p className="eyebrow">Agent registry</p>
        <div className="mt-3 grid gap-2 md:grid-cols-2">
          {agents.map((agent, index) => (
            <motion.div
              key={agent.name}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={stagger(index)}
              className="rounded-xl border border-slate-900/10 bg-slate-900/5 p-3 dark:border-white/10 dark:bg-white/5"
            >
              <div className="flex items-center gap-2">
                <span className="font-mono text-[10px] text-cyanide">{String(index + 1).padStart(2, '0')}</span>
                <p className="text-sm text-slate-900 dark:text-white">{agent.name}</p>
              </div>
              <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">{agent.description}</p>
            </motion.div>
          ))}
        </div>
      </GlassCard>

      <GlassCard className="mt-4">
        <p className="eyebrow">Prompt templates</p>
        {prompts.length === 0 && <p className="mt-3 text-sm text-slate-400 dark:text-slate-500">No templates stored yet.</p>}
        <div className="mt-3 space-y-3">
          {prompts.map((prompt, index) => (
            <motion.div
              key={prompt.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={stagger(index)}
            >
              <div className="mb-1.5 flex items-center gap-2">
                <Badge tone="violet">{prompt.key}</Badge>
                <span className="text-xs text-slate-400 dark:text-slate-500">{prompt.description}</span>
              </div>
              <textarea
                defaultValue={prompt.template}
                onChange={(event) => setDraft((current) => ({ ...current, [prompt.key]: event.target.value }))}
                rows={3}
                className="focus-ring w-full rounded-xl border border-slate-900/10 bg-slate-900/5 p-3 font-mono text-xs dark:border-white/10 dark:bg-black/25"
              />
              <AnimatedButton variant="ghost" className="mt-2" onClick={() => savePrompt(prompt.key)}>
                Save template
              </AnimatedButton>
            </motion.div>
          ))}
        </div>
      </GlassCard>
    </>
  )
}
