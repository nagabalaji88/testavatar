import { motion } from 'framer-motion'
import { Send } from 'lucide-react'
import { useEffect, useRef, useState } from 'react'
import Markdown from 'react-markdown'
import { useSearchParams } from 'react-router-dom'
import { AnimatedButton, Badge, ConfidenceMeter, GlassCard, SectionHeading, ThinkingLoader } from '../components/ui'
import { stagger } from '../lib/motion'
import { copilot } from '../services/api'
import type { CopilotReply } from '../types'

interface Turn { role: 'user' | 'assistant'; content: string; reply?: CopilotReply }

export function Copilot() {
  const [turns, setTurns] = useState<Turn[]>([])
  const [question, setQuestion] = useState('')
  const [busy, setBusy] = useState(false)
  const [params] = useSearchParams()
  const endRef = useRef<HTMLDivElement>(null)

  const ask = async (text: string) => {
    if (!text.trim() || busy) return
    setTurns((current) => [...current, { role: 'user', content: text }])
    setQuestion('')
    setBusy(true)
    try {
      const reply = await copilot.ask(text, turns.map((t) => ({ role: t.role, content: t.content })))
      setTurns((current) => [...current, { role: 'assistant', content: reply.answer, reply }])
    } finally {
      setBusy(false)
    }
  }

  useEffect(() => {
    const initial = params.get('q')
    if (initial) ask(initial)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [turns, busy])

  return (
    <>
      <SectionHeading
        eyebrow="AI copilot"
        title="Ask the people who already solved it"
        description="Answers come only from knowledge an expert has approved, and always name their source."
      />

      <GlassCard interactive={false} className="flex h-[62vh] flex-col">
        <div className="min-h-0 flex-1 space-y-4 overflow-y-auto pr-2">
          {turns.length === 0 && !busy && (
            <div className="grid gap-2 pt-6">
              <p className="text-sm text-slate-500 dark:text-slate-400">Try one of these:</p>
              {[
                'How should we handle retries on payment writes?',
                'What went wrong in the cache stampede incident?',
                'Why did we pick sidecars over a shared proxy?',
              ].map((suggestion, index) => (
                <motion.button
                  key={suggestion}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={stagger(index)}
                  onClick={() => ask(suggestion)}
                  className="focus-ring w-fit rounded-xl border border-cyanide/25 px-3 py-1.5 text-sm text-cyan-700 hover:bg-cyanide/10 dark:text-cyanide"
                >
                  {suggestion}
                </motion.button>
              ))}
            </div>
          )}

          {turns.map((turn, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={turn.role === 'user' ? 'flex justify-end' : ''}
            >
              {turn.role === 'user' ? (
                <p className="max-w-[80%] rounded-2xl rounded-br-sm bg-gradient-to-r from-cyanide/20 to-indigoGlow/20 px-4 py-2 text-sm text-slate-800 dark:text-slate-100">
                  {turn.content}
                </p>
              ) : (
                <div className="max-w-[92%] rounded-2xl rounded-bl-sm border border-slate-900/10 bg-slate-900/5 p-4 dark:border-white/10 dark:bg-white/5">
                  <div className="prose prose-sm dark:prose-invert max-w-none prose-p:my-1.5 prose-headings:font-display">
                    <Markdown>{turn.content}</Markdown>
                  </div>
                  {turn.reply && turn.reply.sources.length > 0 && (
                    <div className="mt-3 border-t border-slate-900/10 pt-3 dark:border-white/10">
                      <div className="mb-2 flex items-center gap-2">
                        <p className="eyebrow">Sources</p>
                        <span className="ml-auto"><ConfidenceMeter value={turn.reply.confidence} /></span>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {turn.reply.sources.map((source, index) => (
                          <motion.span
                            key={source.id}
                            initial={{ opacity: 0, y: 6 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={stagger(index)}
                            className="rounded-lg border border-slate-900/10 bg-slate-900/5 px-2 py-1 text-[11px] text-slate-600 dark:border-white/10 dark:bg-black/25 dark:text-slate-300"
                          >
                            {source.title.slice(0, 46)}
                            <span className="ml-1 font-mono text-[10px] text-slate-400 dark:text-slate-500">{source.expert_name}</span>
                          </motion.span>
                        ))}
                      </div>
                      <div className="mt-3 flex flex-wrap gap-2">
                        {turn.reply.followups.map((followup, index) => (
                          <motion.button
                            key={followup}
                            initial={{ opacity: 0, y: 6 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={stagger(index)}
                            onClick={() => ask(followup)}
                            className="focus-ring rounded-lg border border-violetGlow/30 px-2 py-1 text-[11px] text-violet-700 hover:bg-violetGlow/10 dark:text-violet-300"
                          >
                            {followup}
                          </motion.button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </motion.div>
          ))}

          {busy && <ThinkingLoader label="Searching validated knowledge" />}
          <div ref={endRef} />
        </div>

        <div className="mt-3 flex items-center gap-2 border-t border-slate-900/10 pt-3 dark:border-white/10">
          <input
            value={question}
            onChange={(event) => setQuestion(event.target.value)}
            onKeyDown={(event) => event.key === 'Enter' && ask(question)}
            placeholder="Ask about a decision, an incident or a trade-off"
            className="focus-ring flex-1 rounded-xl border border-slate-900/10 bg-slate-900/5 px-3 py-2.5 text-sm dark:border-white/10 dark:bg-white/5"
          />
          <AnimatedButton onClick={() => ask(question)} disabled={busy}>
            <Send className="h-4 w-4" />
          </AnimatedButton>
        </div>
      </GlassCard>

      <p className="mt-3 text-xs text-slate-400 dark:text-slate-500">
        <Badge tone="slate">grounded</Badge> If nothing approved covers your question, the copilot says so
        instead of guessing.
      </p>
    </>
  )
}
