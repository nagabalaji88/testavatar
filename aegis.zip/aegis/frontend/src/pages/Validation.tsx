import { AnimatePresence, motion } from 'framer-motion'
import { useEffect, useState } from 'react'
import { AnimatedButton, Badge, ConfidenceMeter, EmptyState, GlassCard, SectionHeading } from '../components/ui'
import { stagger } from '../lib/motion'
import { knowledge } from '../services/api'
import { useAuth } from '../store/useAuth'
import { useToast } from '../store/useToast'
import type { KnowledgeItem } from '../types'

const VISIBILITY = ['internal', 'department', 'enterprise']

export function Validation() {
  const [queue, setQueue] = useState<KnowledgeItem[]>([])
  const [active, setActive] = useState<KnowledgeItem | null>(null)
  const [comment, setComment] = useState('')
  const [confidence, setConfidence] = useState(0.8)
  const [visibility, setVisibility] = useState('department')
  const [history, setHistory] = useState<{ reviewer_name: string; decision: string; comment: string }[]>([])
  const push = useToast((s) => s.push)
  const role = useAuth((s) => s.user?.role)
  const canReview = role === 'expert' || role === 'reviewer' || role === 'admin'

  const load = () => knowledge.queue().then((items) => {
    setQueue(items)
    setActive((current) => items.find((i) => i.id === current?.id) ?? items[0] ?? null)
  })

  useEffect(() => { load() }, [])

  useEffect(() => {
    if (!active) return
    setConfidence(active.confidence)
    setVisibility(active.visibility)
    knowledge.detail(active.id).then((data) => setHistory(data.reviews ?? []))
  }, [active])

  const decide = async (decision: 'approve' | 'reject' | 'edit') => {
    if (!active) return
    await knowledge.review(active.id, { decision, comment, confidence, visibility })
    push({
      title: decision === 'approve' ? 'Card approved' : decision === 'reject' ? 'Card rejected' : 'Card updated',
      body: decision === 'approve' ? 'It is now available to the copilot and simulator.' : undefined,
      level: decision === 'reject' ? 'warning' : 'success',
    })
    setComment('')
    load()
  }

  return (
    <>
      <SectionHeading
        eyebrow="Validation portal"
        title="Every card needs a human decision"
        description="Approve what matches how you actually work, correct what does not, and set who gets to see it."
      />

      {queue.length === 0 ? (
        <EmptyState title="The review queue is clear." action="Run a capture to generate new cards." />
      ) : (
        <div className="grid gap-4 lg:grid-cols-[340px_1fr]">
          <div className="space-y-2">
            {queue.map((item) => (
              <motion.button
                key={item.id}
                layout
                onClick={() => setActive(item)}
                className={`glass w-full rounded-xl p-3 text-left transition-colors ${
                  active?.id === item.id ? 'border-cyanide/50' : ''
                }`}
              >
                <div className="flex items-center gap-2">
                  <Badge tone="violet">{item.kind.replace('_', ' ')}</Badge>
                  <span className="ml-auto"><ConfidenceMeter value={item.confidence} /></span>
                </div>
                <p className="mt-2 line-clamp-2 text-sm text-slate-700 dark:text-slate-200">{item.title}</p>
                <p className="mt-1 font-mono text-[10px] text-slate-400 dark:text-slate-500">
                  {item.expert_name} · {item.domain}
                </p>
              </motion.button>
            ))}
          </div>

          <AnimatePresence mode="wait">
            {active && (
              <motion.div
                key={active.id}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.25 }}
              >
                <GlassCard interactive={false}>
                  <div className="flex flex-wrap items-center gap-2">
                    <Badge tone="cyan">v{active.version}</Badge>
                    <Badge tone="violet">{active.kind.replace('_', ' ')}</Badge>
                    <Badge tone="slate">{active.domain}</Badge>
                    <span className="ml-auto"><ConfidenceMeter value={confidence} /></span>
                  </div>
                  <h2 className="mt-3 font-display text-xl text-slate-900 dark:text-white">{active.title}</h2>
                  <pre className="mt-3 max-h-72 overflow-auto whitespace-pre-wrap rounded-xl border border-slate-900/10 bg-slate-900/5 p-4 text-sm leading-relaxed text-slate-600 dark:border-white/10 dark:bg-black/25 dark:text-slate-300">
                    {active.body || active.summary}
                  </pre>

                  <div className="mt-4 grid gap-3 sm:grid-cols-2">
                    <label className="text-sm">
                      <span className="eyebrow">Confidence</span>
                      <input
                        type="range" min={0} max={1} step={0.05} value={confidence}
                        onChange={(event) => setConfidence(Number(event.target.value))}
                        className="mt-2 w-full accent-cyanide"
                      />
                    </label>
                    <label className="text-sm">
                      <span className="eyebrow">Who can see it</span>
                      <select
                        value={visibility}
                        onChange={(event) => setVisibility(event.target.value)}
                        className="focus-ring mt-2 w-full rounded-xl border border-slate-900/10 bg-slate-900/5 px-3 py-2 text-sm dark:border-white/10 dark:bg-white/5"
                      >
                        {VISIBILITY.map((option) => (
                          <option key={option} value={option} className="bg-white dark:bg-deep">{option}</option>
                        ))}
                      </select>
                    </label>
                  </div>

                  <textarea
                    value={comment}
                    onChange={(event) => setComment(event.target.value)}
                    rows={3}
                    placeholder="Add context for whoever reads this next"
                    className="focus-ring mt-3 w-full rounded-xl border border-slate-900/10 bg-slate-900/5 p-3 text-sm dark:border-white/10 dark:bg-white/5"
                  />

                  {!canReview && (
                    <p className="mt-3 text-xs text-amber-600 dark:text-amber-300">
                      Your role can read the queue but not decide on cards.
                    </p>
                  )}

                  <div className="mt-4 flex flex-wrap gap-2">
                    <AnimatedButton onClick={() => decide('approve')} disabled={!canReview}>Approve</AnimatedButton>
                    <AnimatedButton variant="ghost" onClick={() => decide('edit')} disabled={!canReview}>Save edits</AnimatedButton>
                    <AnimatedButton variant="danger" onClick={() => decide('reject')} disabled={!canReview}>Reject</AnimatedButton>
                  </div>

                  {history.length > 0 && (
                    <div className="mt-5 border-t border-slate-900/10 pt-4 dark:border-white/10">
                      <p className="eyebrow mb-2">Review history</p>
                      <ul className="space-y-2">
                        {history.map((entry, index) => (
                          <motion.li
                            key={index}
                            initial={{ opacity: 0, y: 6 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={stagger(index)}
                            className="text-xs text-slate-500 dark:text-slate-400"
                          >
                            <span className="text-slate-700 dark:text-slate-200">{entry.reviewer_name}</span> · {entry.decision}
                            {entry.comment && ` — ${entry.comment}`}
                          </motion.li>
                        ))}
                      </ul>
                    </div>
                  )}
                </GlassCard>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      )}
    </>
  )
}
