import {
  Background, Controls, MiniMap, ReactFlow, type Edge, type Node,
} from '@xyflow/react'
import '@xyflow/react/dist/style.css'
import { AnimatePresence, motion } from 'framer-motion'
import { useEffect, useMemo, useState } from 'react'
import { GlassCard, SectionHeading, ThinkingLoader } from '../components/ui'
import { graphTheme } from '../lib/chartTheme'
import { stagger } from '../lib/motion'
import { graph } from '../services/api'
import { useTheme } from '../store/useTheme'

const TYPE_COLOR: Record<string, string> = {
  decision: '#22d3ee',
  expert: '#8b5cf6',
  technology: '#2dd4bf',
  incident: '#f43f5e',
  architecture: '#6366f1',
  dependency: '#f59e0b',
}

interface RawNode { id: string; label: string; type: string }
interface RawEdge { id: string; source: string; target: string; relation: string }

export function KnowledgeGraph() {
  const [raw, setRaw] = useState<{ nodes: RawNode[]; edges: RawEdge[] } | null>(null)
  const [query, setQuery] = useState('')
  const [typeFilter, setTypeFilter] = useState('')
  const [selected, setSelected] = useState<RawNode | null>(null)
  const { theme } = useTheme()
  const gt = graphTheme(theme === 'dark')

  useEffect(() => {
    graph.fetch({ q: query || undefined, node_type: typeFilter || undefined }).then(setRaw)
  }, [query, typeFilter])

  const { nodes, edges } = useMemo(() => {
    if (!raw) return { nodes: [] as Node[], edges: [] as Edge[] }
    const radius = 60 + raw.nodes.length * 9
    const flowNodes: Node[] = raw.nodes.map((node, index) => {
      const angle = (index / Math.max(raw.nodes.length, 1)) * Math.PI * 2
      const color = TYPE_COLOR[node.type] ?? '#94a3b8'
      return {
        id: node.id,
        position: { x: Math.cos(angle) * radius + 420, y: Math.sin(angle) * radius + 300 },
        data: { label: node.label.length > 38 ? `${node.label.slice(0, 38)}…` : node.label },
        style: {
          background: gt.nodeBackground,
          backdropFilter: 'blur(12px)',
          border: `1px solid ${color}`,
          color: gt.nodeText,
          borderRadius: 12,
          fontSize: 11,
          padding: 8,
          width: 190,
          boxShadow: `0 0 22px -8px ${color}`,
        },
      }
    })
    const flowEdges: Edge[] = raw.edges.map((edge) => ({
      id: edge.id,
      source: edge.source,
      target: edge.target,
      label: edge.relation,
      animated: true,
      style: { stroke: gt.edgeStroke },
      labelStyle: { fill: gt.edgeLabel, fontSize: 9 },
    }))
    return { nodes: flowNodes, edges: flowEdges }
  }, [raw, gt.nodeBackground, gt.nodeText, gt.edgeStroke, gt.edgeLabel])

  return (
    <>
      <SectionHeading
        eyebrow="Knowledge graph"
        title="How decisions, experts and systems connect"
        description="Each decision keeps its author and the technologies it touches, so you can trace why something is the way it is."
      />

      <div className="mb-4 flex flex-wrap gap-2">
        <input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Search nodes"
          className="focus-ring w-56 rounded-xl border border-slate-900/10 bg-slate-900/5 px-3 py-2 text-sm dark:border-white/10 dark:bg-white/5"
        />
        <select
          value={typeFilter}
          onChange={(event) => setTypeFilter(event.target.value)}
          className="focus-ring rounded-xl border border-slate-900/10 bg-slate-900/5 px-3 py-2 text-sm dark:border-white/10 dark:bg-white/5"
        >
          <option value="" className="bg-white dark:bg-deep">All node types</option>
          {Object.keys(TYPE_COLOR).map((type) => (
            <option key={type} value={type} className="bg-white dark:bg-deep">{type}</option>
          ))}
        </select>
        <div className="ml-auto flex flex-wrap items-center gap-2">
          {Object.entries(TYPE_COLOR).map(([type, color], index) => (
            <motion.span
              key={type}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              transition={stagger(index)}
              className="flex items-center gap-1.5 font-mono text-[10px] uppercase text-slate-500 dark:text-slate-400"
            >
              <span className="h-2 w-2 rounded-full" style={{ background: color }} /> {type}
            </motion.span>
          ))}
        </div>
      </div>

      <GlassCard interactive={false} className="h-[560px] p-0">
        {!raw ? (
          <div className="grid h-full place-items-center"><ThinkingLoader label="Loading graph" /></div>
        ) : (
          <ReactFlow
            nodes={nodes}
            edges={edges}
            fitView
            onNodeClick={(_, node) => setSelected(raw.nodes.find((n) => n.id === node.id) ?? null)}
            proOptions={{ hideAttribution: true }}
          >
            <Background color={gt.background} gap={22} />
            <Controls className="!bg-slate-900/10 !text-slate-900 dark:!bg-white/10" />
            <MiniMap pannable maskColor={gt.minimapMask} style={{ background: gt.minimapBackground }} />
          </ReactFlow>
        )}
      </GlassCard>

      <AnimatePresence>
        {selected && (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="mt-4"
          >
            <GlassCard interactive={false}>
              <p className="eyebrow">{selected.type}</p>
              <p className="mt-1 text-slate-900 dark:text-white">{selected.label}</p>
              <p className="mt-2 text-xs text-slate-500 dark:text-slate-400">
                {raw?.edges.filter((e) => e.source === selected.id || e.target === selected.id).length ?? 0} connections in the graph.
              </p>
            </GlassCard>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
