import { create } from 'zustand'
import { auth } from '../services/api'
import type { User } from '../types'

interface AuthState {
  user: User | null
  loading: boolean
  error: string
  signIn: (email: string, password: string) => Promise<boolean>
  signOut: () => void
  restore: () => Promise<void>
}

export const useAuth = create<AuthState>((set) => ({
  user: null,
  loading: true,
  error: '',
  signIn: async (email, password) => {
    set({ error: '' })
    try {
      const data = await auth.login(email, password)
      localStorage.setItem('aegis_token', data.access_token)
      set({ user: data.user })
      return true
    } catch {
      set({ error: 'Email or password is incorrect.' })
      return false
    }
  },
  signOut: () => {
    localStorage.removeItem('aegis_token')
    set({ user: null })
  },
  restore: async () => {
    if (!localStorage.getItem('aegis_token')) {
      set({ loading: false })
      return
    }
    try {
      set({ user: await auth.me(), loading: false })
    } catch {
      localStorage.removeItem('aegis_token')
      set({ user: null, loading: false })
    }
  },
}))
