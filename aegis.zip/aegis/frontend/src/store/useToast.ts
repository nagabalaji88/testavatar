import { create } from 'zustand'

export interface Toast {
  id: number
  title: string
  body?: string
  level: 'info' | 'success' | 'warning' | 'error'
}

interface ToastState {
  toasts: Toast[]
  push: (toast: Omit<Toast, 'id'>) => void
  dismiss: (id: number) => void
}

export const useToast = create<ToastState>((set) => ({
  toasts: [],
  push: (toast) => {
    const id = Date.now() + Math.random()
    set((state) => ({ toasts: [...state.toasts, { ...toast, id }] }))
    setTimeout(() => set((state) => ({ toasts: state.toasts.filter((t) => t.id !== id) })), 4200)
  },
  dismiss: (id) => set((state) => ({ toasts: state.toasts.filter((t) => t.id !== id) })),
}))
