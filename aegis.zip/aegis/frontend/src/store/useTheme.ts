import { create } from 'zustand'

type Theme = 'light' | 'dark'

function apply(theme: Theme) {
  document.documentElement.classList.toggle('dark', theme === 'dark')
}

interface ThemeState {
  theme: Theme
  toggle: () => void
  setTheme: (theme: Theme) => void
}

const initial: Theme = (localStorage.getItem('aegis_theme') as Theme | null) ?? 'light'
apply(initial)

export const useTheme = create<ThemeState>((set) => ({
  theme: initial,
  toggle: () =>
    set((state) => {
      const next: Theme = state.theme === 'dark' ? 'light' : 'dark'
      localStorage.setItem('aegis_theme', next)
      apply(next)
      return { theme: next }
    }),
  setTheme: (theme) => {
    localStorage.setItem('aegis_theme', theme)
    apply(theme)
    set({ theme })
  },
}))
