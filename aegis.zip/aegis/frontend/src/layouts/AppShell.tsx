import { AnimatePresence, motion } from 'framer-motion'
import {
  Activity, Bell, BrainCircuit, ChevronLeft, Gauge, GraduationCap, LayoutDashboard,
  LogOut, Moon, Network, Search, Settings, ShieldCheck, Sparkles, Sun, Upload,
} from 'lucide-react'
import { useEffect, useState } from 'react'
import { NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom'
import { AssistantPanel } from '../components/AssistantPanel'
import { ToastHost } from '../components/ToastHost'
import { analytics, status as fetchStatus } from '../services/api'
import { useAuth } from '../store/useAuth'
import { useTheme } from '../store/useTheme'

const NAV = [
  { to: '/app', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/app/capture', label: 'Capture', icon: Upload },
  { to: '/app/validation', label: 'Validation', icon: ShieldCheck },
  { to: '/app/graph', label: 'Knowledge graph', icon: Network },
  { to: '/app/copilot', label: 'Copilot', icon: BrainCircuit },
  { to: '/app/simulator', label: 'Simulator', icon: GraduationCap },
  { to: '/app/health', label: 'Knowledge health', icon: Gauge },
  { to: '/app/governance', label: 'Governance', icon: Activity },
  { to: '/app/admin', label: 'Admin', icon: Settings },
]

export function AppShell() {
  const [expanded, setExpanded] = useState(true)
  const [systemStatus, setSystemStatus] = useState<{ llm: string; vector_index: string } | null>(null)
  const [alerts, setAlerts] = useState<{ id: string; title: string; body: string }[]>([])
  const [showAlerts, setShowAlerts] = useState(false)
  const { user, signOut } = useAuth()
  const { theme, toggle } = useTheme()
  const navigate = useNavigate()
  const location = useLocation()

  useEffect(() => {
    fetchStatus().then(setSystemStatus).catch(() => undefined)
    analytics.notifications().then(setAlerts).catch(() => undefined)
  }, [])

  return (
    <div className="flex min-h-screen">
      <motion.aside
        animate={{ width: expanded ? 232 : 76 }}
        transition={{ type: 'spring', stiffness: 220, damping: 26 }}
        className="glass-strong sticky top-0 z-30 hidden h-screen shrink-0 flex-col p-3 md:flex"
      >
        <div className="mb-6 flex items-center gap-2 px-1">
          <Sparkles className="h-6 w-6 shrink-0 text-cyanide" />
          {expanded && <span className="font-display text-lg font-bold gradient-text">AEGIS</span>}
          <button
            onClick={() => setExpanded((v) => !v)}
            aria-label={expanded ? 'Collapse sidebar' : 'Expand sidebar'}
            className="focus-ring ml-auto rounded-lg p-1 text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white"
          >
            <ChevronLeft className={`h-4 w-4 transition-transform ${expanded ? '' : 'rotate-180'}`} />
          </button>
        </div>
        <nav className="flex flex-1 flex-col gap-1">
          {NAV.map(({ to, label, icon: Icon, end }, index) => (
            <motion.div
              key={to}
              initial={{ opacity: 0, x: -12 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3, delay: index * 0.04, ease: [0.22, 1, 0.36, 1] }}
            >
              <NavLink
                to={to}
                end={end}
                className={({ isActive }) =>
                  `focus-ring group flex items-center gap-3 rounded-xl px-3 py-2 text-sm transition-colors ${
                    isActive
                      ? 'bg-slate-900/10 text-slate-900 dark:bg-white/10 dark:text-white'
                      : 'text-slate-500 hover:bg-slate-900/5 hover:text-slate-800 dark:text-slate-400 dark:hover:bg-white/5 dark:hover:text-slate-100'
                  }`
                }
              >
                <Icon className="h-4 w-4 shrink-0 transition-transform group-hover:scale-110" />
                {expanded && <span className="truncate">{label}</span>}
              </NavLink>
            </motion.div>
          ))}
        </nav>
        <button
          onClick={() => { signOut(); navigate('/login') }}
          className="focus-ring flex items-center gap-3 rounded-xl px-3 py-2 text-sm text-slate-500 hover:text-rose-600 dark:text-slate-400 dark:hover:text-rose-300"
        >
          <LogOut className="h-4 w-4 shrink-0" />
          {expanded && 'Sign out'}
        </button>
      </motion.aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="glass-strong sticky top-0 z-20 flex items-center gap-3 border-b border-slate-900/10 px-4 py-3 dark:border-white/10">
          <div className="relative hidden flex-1 md:block">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400 dark:text-slate-500" />
            <input
              placeholder="Search knowledge, experts, decisions"
              onKeyDown={(event) => {
                if (event.key === 'Enter') {
                  navigate(`/app/copilot?q=${encodeURIComponent(event.currentTarget.value)}`)
                }
              }}
              className="focus-ring w-full rounded-xl border border-slate-900/10 bg-slate-900/5 py-2 pl-9 pr-3 text-sm placeholder:text-slate-400 dark:border-white/10 dark:bg-white/5 dark:placeholder:text-slate-500"
            />
          </div>
          <span className="font-display text-sm text-slate-900 dark:text-white md:hidden">AEGIS</span>
          <button
            onClick={toggle}
            className="focus-ring relative overflow-hidden rounded-xl p-2 text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white"
            aria-label={theme === 'dark' ? 'Switch to light theme' : 'Switch to dark theme'}
          >
            <AnimatePresence mode="wait" initial={false}>
              <motion.span
                key={theme}
                initial={{ opacity: 0, rotate: -90, scale: 0.6 }}
                animate={{ opacity: 1, rotate: 0, scale: 1 }}
                exit={{ opacity: 0, rotate: 90, scale: 0.6 }}
                transition={{ duration: 0.25 }}
                className="block"
              >
                {theme === 'dark' ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
              </motion.span>
            </AnimatePresence>
          </button>
          <button
            onClick={() => setShowAlerts((v) => !v)}
            className="focus-ring relative rounded-xl p-2 text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white"
            aria-label="Notifications"
          >
            <Bell className="h-4 w-4" />
            {alerts.length > 0 && (
              <span className="absolute right-1.5 top-1.5 h-1.5 w-1.5 rounded-full bg-cyanide" />
            )}
          </button>
          <div className="flex items-center gap-2 rounded-xl border border-slate-900/10 bg-slate-900/5 px-3 py-1.5 dark:border-white/10 dark:bg-white/5">
            <div className="grid h-6 w-6 place-items-center rounded-full bg-gradient-to-br from-cyanide to-violetGlow text-[10px] font-bold text-slate-900">
              {user?.full_name?.[0] ?? 'A'}
            </div>
            <div className="hidden leading-tight sm:block">
              <p className="text-xs text-slate-900 dark:text-white">{user?.full_name}</p>
              <p className="font-mono text-[10px] uppercase text-slate-400 dark:text-slate-500">{user?.role}</p>
            </div>
          </div>
        </header>

        <AnimatePresence>
          {showAlerts && (
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              className="glass-strong absolute right-4 top-16 z-30 w-80 rounded-xl p-3"
            >
              <p className="eyebrow mb-2">Notifications</p>
              {alerts.length === 0 && <p className="text-sm text-slate-500 dark:text-slate-400">Nothing new.</p>}
              {alerts.slice(0, 6).map((alert, index) => (
                <motion.div
                  key={alert.id}
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.25, delay: index * 0.04 }}
                  className="border-b border-slate-900/5 py-2 last:border-0 dark:border-white/5"
                >
                  <p className="text-sm text-slate-900 dark:text-white">{alert.title}</p>
                  <p className="text-xs text-slate-500 dark:text-slate-400">{alert.body}</p>
                </motion.div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>

        <div className="flex min-h-0 flex-1">
          <main className="min-w-0 flex-1 px-4 py-6 lg:px-8">
            <AnimatePresence mode="wait">
              <motion.div
                key={location.pathname}
                initial={{ opacity: 0, y: 12, filter: 'blur(8px)' }}
                animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
                exit={{ opacity: 0, y: -8, filter: 'blur(8px)' }}
                transition={{ duration: 0.35 }}
              >
                <Outlet />
              </motion.div>
            </AnimatePresence>
          </main>
          <AssistantPanel />
        </div>

        <footer className="glass-strong sticky bottom-0 z-20 flex flex-wrap items-center gap-x-5 gap-y-1 border-t border-slate-900/10 px-4 py-2 font-mono text-[10px] uppercase tracking-wider text-slate-500 dark:border-white/10 dark:text-slate-400">
          <span className="flex items-center gap-1.5">
            <span className="h-1.5 w-1.5 rounded-full bg-tealGlow" /> AI {systemStatus?.llm ?? '—'}
          </span>
          <span>Embeddings ready</span>
          <span>Vector index {systemStatus?.vector_index ?? '—'}</span>
          <span className="ml-auto hidden sm:block">AEGIS v1.0</span>
        </footer>
      </div>
      <ToastHost />
    </div>
  )
}
