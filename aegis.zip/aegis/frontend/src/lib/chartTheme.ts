export function rechartsTheme(isDark: boolean) {
  return {
    axis: { stroke: isDark ? '#64748b' : '#94a3b8', fontSize: 11 },
    grid: isDark ? 'rgba(255,255,255,0.06)' : 'rgba(15,23,42,0.08)',
    polarGrid: isDark ? 'rgba(255,255,255,0.12)' : 'rgba(15,23,42,0.12)',
    cursorFill: isDark ? 'rgba(255,255,255,0.04)' : 'rgba(15,23,42,0.04)',
    angleAxisTick: { fill: isDark ? '#94a3b8' : '#64748b', fontSize: 10 },
    tooltipStyle: {
      background: isDark ? 'rgba(8,17,31,0.92)' : 'rgba(255,255,255,0.95)',
      border: isDark ? '1px solid rgba(255,255,255,0.15)' : '1px solid rgba(15,23,42,0.1)',
      borderRadius: 12,
      fontSize: 12,
      color: isDark ? '#e2e8f0' : '#1e293b',
    },
  }
}

export function graphTheme(isDark: boolean) {
  return {
    nodeBackground: isDark ? 'rgba(255,255,255,0.06)' : 'rgba(15,23,42,0.04)',
    nodeText: isDark ? '#e2e8f0' : '#1e293b',
    edgeStroke: isDark ? 'rgba(148,163,184,0.35)' : 'rgba(100,116,139,0.4)',
    edgeLabel: isDark ? '#94a3b8' : '#64748b',
    background: isDark ? 'rgba(148,163,184,0.25)' : 'rgba(100,116,139,0.2)',
    minimapMask: isDark ? 'rgba(4,11,29,0.75)' : 'rgba(226,232,240,0.75)',
    minimapBackground: isDark ? 'rgba(8,17,31,0.8)' : 'rgba(255,255,255,0.8)',
  }
}
