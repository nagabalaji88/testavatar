import type { Transition, Variants } from 'framer-motion'

export const listItem: Variants = {
  initial: { opacity: 0, y: 10 },
  animate: { opacity: 1, y: 0 },
  exit: { opacity: 0, y: -6 },
}

export function stagger(index: number, base = 0.04): Transition {
  return { duration: 0.35, delay: index * base, ease: [0.22, 1, 0.36, 1] }
}

export const panelPresence: Variants = {
  initial: { opacity: 0, y: 12, filter: 'blur(6px)' },
  animate: { opacity: 1, y: 0, filter: 'blur(0px)' },
  exit: { opacity: 0, y: -8, filter: 'blur(6px)' },
}
