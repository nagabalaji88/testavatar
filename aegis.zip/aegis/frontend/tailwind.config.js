/** @type {import('tailwindcss').Config} */
export default {
  darkMode: 'class',
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        abyss: '#040B1D',
        deep: '#08111F',
        slate900: '#0E172A',
        electric: '#3B82F6',
        cyanide: '#22D3EE',
        violetGlow: '#8B5CF6',
        indigoGlow: '#6366F1',
        tealGlow: '#2DD4BF',
      },
      fontFamily: {
        display: ['"Space Grotesk"', 'system-ui', 'sans-serif'],
        body: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'ui-monospace', 'monospace'],
      },
      boxShadow: {
        glass: '0 18px 60px -20px rgba(2, 8, 23, 0.9)',
        glow: '0 0 24px -4px rgba(59, 130, 246, 0.55)',
      },
      keyframes: {
        drift: { '0%,100%': { transform: 'translateY(0)' }, '50%': { transform: 'translateY(-12px)' } },
        sweep: { '0%': { backgroundPosition: '0% 50%' }, '100%': { backgroundPosition: '200% 50%' } },
        pulseRing: { '0%': { opacity: '0.6', transform: 'scale(0.9)' }, '100%': { opacity: '0', transform: 'scale(1.6)' } },
      },
      animation: {
        drift: 'drift 7s ease-in-out infinite',
        sweep: 'sweep 6s linear infinite',
        pulseRing: 'pulseRing 2.4s ease-out infinite',
      },
    },
  },
  plugins: [],
}
