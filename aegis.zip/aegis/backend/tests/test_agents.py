from datetime import datetime, timedelta, timezone

from app.agents.capture import extract
from app.agents.learning import badge_for, build_tree
from app.agents.orchestrator import run_capture_pipeline
from app.agents.privacy import redact, scan
from app.agents.validation import calibrate
from app.services.knowledge_health import freshness, portfolio_health
from app.services.vector_store import embed, search

SAMPLE = """We decided to use append-only ledger tables instead of in-place updates.
The risk is unbounded growth, so always partition by month.
Contact priya@aegis.dev or call 555-0143 with questions. api_key: sk-test-123456"""


def test_privacy_finds_and_redacts_pii():
    findings = scan(SAMPLE)
    types = {f["type"] for f in findings}
    assert "EMAIL" in types
    assert "SECRET" in types
    redacted, _ = redact(SAMPLE)
    assert "priya@aegis.dev" not in redacted
    assert "EMAIL_REDACTED" in redacted


def test_capture_extracts_decisions_and_risks():
    items = extract(SAMPLE)
    kinds = {i["kind"] for i in items}
    assert "decision" in kinds
    assert "risk" in kinds
    assert all(0 < i["confidence"] <= 1 for i in items)


def test_validation_penalises_thin_evidence():
    strong = {"confidence": 0.8, "evidence": "word " * 30, "tags": ["a", "b", "c", "d"],
              "kind": "decision"}
    weak = {"confidence": 0.8, "evidence": "short", "tags": [], "kind": "risk"}
    assert calibrate(strong)[0] > calibrate(weak)[0]


def test_pipeline_blocks_without_consent():
    state = run_capture_pipeline({"raw_content": SAMPLE, "consent_granted": False})
    assert state["status"] == "blocked"
    assert state["trace"][0]["agent"] == "Privacy Agent"


def test_pipeline_produces_candidates_and_graph():
    state = run_capture_pipeline(
        {"title": "t", "raw_content": SAMPLE, "consent_granted": True, "expert_name": "Priya"}
    )
    assert state["status"] == "awaiting_validation"
    assert state["candidates"]
    assert state["graph_fragment"]["nodes"]
    assert len(state["trace"]) == 5
    # No agent after the privacy gate should ever see raw PII.
    assert "priya@aegis.dev" not in state["redacted_content"]


def test_vector_search_ranks_relevant_first():
    corpus = [
        {"id": "1", "title": "cache stampede single flight", "embedding": embed("cache stampede single flight lock")},
        {"id": "2", "title": "payments ledger partitioning", "embedding": embed("payments ledger append only partition")},
    ]
    results = search("how do we stop a cache stampede", corpus, 2)
    assert results[0]["id"] == "1"


def test_freshness_decays_over_time():
    now = datetime.now(timezone.utc)
    assert freshness(now) > freshness(now - timedelta(days=120)) > freshness(now - timedelta(days=400))


def test_portfolio_health_flags_stale_items():
    old = datetime.now(timezone.utc) - timedelta(days=500)
    report = portfolio_health(
        [{"id": "1", "title": "old", "last_reviewed_at": old, "confidence": 0.4, "usage_count": 0}]
    )
    assert report["stale"]
    assert 0 <= report["health"] <= 1


def test_simulation_tree_and_badges():
    tree = build_tree({"title": "x", "summary": "y"}, "incident")
    assert tree["root"] in tree["nodes"]
    assert badge_for(20, 20) == "Expert Mirror"
    assert badge_for(0, 20) == "Needs Coaching"
