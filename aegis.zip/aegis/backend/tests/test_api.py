import os
import tempfile

os.environ["AEGIS_DATABASE_URL"] = f"sqlite:///{tempfile.mkdtemp()}/test.db"

from fastapi.testclient import TestClient  # noqa: E402

from app.main import app, init_db  # noqa: E402

init_db()
client = TestClient(app)


def _token(email="priya.raman@aegis.dev"):
    response = client.post("/api/auth/login", json={"email": email, "password": "aegis1234"})
    assert response.status_code == 200, response.text
    return {"Authorization": f"Bearer {response.json()['access_token']}"}


def test_status_open():
    assert client.get("/api/status").json()["status"] == "online"


def test_login_rejects_bad_password():
    assert client.post(
        "/api/auth/login", json={"email": "priya.raman@aegis.dev", "password": "nope"}
    ).status_code == 401


def test_protected_route_requires_token():
    assert client.get("/api/knowledge").status_code == 401


def test_capture_review_and_search_flow():
    headers = _token()
    capture = client.post(
        "/api/capture",
        headers=headers,
        json={
            "title": "Queue backpressure review",
            "source_type": "meeting_transcript",
            "content": "We decided to drop the queue depth alarm to 5k because the risk is "
                       "consumers fall behind silently. Always alert on lag, not depth. "
                       "Reach me at ops@aegis.dev.",
            "domain": "Reliability",
        },
    ).json()
    assert capture["items"]
    assert any(f["type"] == "EMAIL" for f in capture["pii_findings"])
    assert len(capture["trace"]) == 5

    item_id = capture["items"][0]["id"]
    approved = client.post(
        f"/api/validation/{item_id}",
        headers=headers,
        json={"decision": "approve", "comment": "Confirmed", "confidence": 0.9,
              "visibility": "enterprise"},
    ).json()
    assert approved["status"] == "approved"

    results = client.post(
        "/api/search", headers=headers, json={"query": "queue lag alerting", "top_k": 3}
    ).json()
    assert isinstance(results, list)


def test_copilot_answers_with_sources():
    headers = _token()
    payload = client.post(
        "/api/copilot", headers=headers, json={"question": "how should we handle retries"}
    ).json()
    assert "answer" in payload
    assert "followups" in payload


def test_dashboard_graph_and_governance():
    headers = _token()
    assert "metrics" in client.get("/api/analytics/dashboard", headers=headers).json()
    graph = client.get("/api/graph", headers=headers).json()
    assert "nodes" in graph and "edges" in graph
    assert "by_type" in client.get("/api/governance/pii", headers=headers).json()


def test_learner_cannot_validate():
    headers = _token("dana.oyelaran@aegis.dev")
    queue = client.get("/api/validation/queue", headers=headers).json()
    if queue:
        response = client.post(
            f"/api/validation/{queue[0]['id']}", headers=headers, json={"decision": "approve"}
        )
        assert response.status_code == 403


def test_simulation_round_trip():
    headers = _token("dana.oyelaran@aegis.dev")
    sim = client.post("/api/simulation/start", headers=headers, json={"scenario": "incident"}).json()
    node = sim["tree"]["nodes"][sim["tree"]["root"]]
    answer = client.post(
        "/api/simulation/answer",
        headers=headers,
        json={"simulation_id": sim["id"], "node_id": node["id"],
              "choice_id": node["choices"][0]["id"], "path": []},
    ).json()
    assert answer["score"] == 10
