"""Demo seed data so the app is meaningful on first run."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

from sqlalchemy import select
from sqlalchemy.orm import Session

from . import models
from .core.security import hash_password
from .services import knowledge_service

USERS = [
    ("priya.raman@aegis.dev", "Priya Raman", "expert", "Platform Engineering"),
    ("marcus.hale@aegis.dev", "Marcus Hale", "reviewer", "Architecture"),
    ("dana.oyelaran@aegis.dev", "Dana Oyelaran", "learner", "Platform Engineering"),
    ("admin@aegis.dev", "System Admin", "admin", "IT"),
]

TRANSCRIPTS = [
    (
        "Payments cutover retrospective",
        "meeting_transcript",
        "Platform Engineering",
        """Priya: We decided to move the payments ledger to an append-only table instead of
        updating rows in place, because the reconciliation job kept racing with refunds.
        The risk is that the table grows fast, so always partition by month and archive
        anything older than 18 months before the index bloats.
        Marcus: Watch out for the retry path — if the gateway times out we saw duplicate
        charges until we made the idempotency key the client reference, not the request id.
        Priya: Rule of thumb: any write that can be retried by a customer needs an
        idempotency key owned by the caller. Reach me on priya.raman@aegis.dev if unclear.""",
    ),
    (
        "SEV1 postmortem: cache stampede",
        "incident_report",
        "Reliability",
        """Root cause: a cold cache after deploy caused every request to hit Postgres at once,
        and connection pool exhaustion took the checkout API down for 22 minutes.
        We decided to warm the cache during the deploy health check rather than raising the
        pool size, because a larger pool just moves the failure to the database.
        The risk with warming is deploy time grows, so we cap warmup at 45 seconds.
        Best practice: never let a cache miss fan out unbounded — always use a single-flight
        lock per key. On-call phone was 555-0143 during the incident.""",
    ),
    (
        "Service mesh design review",
        "pull_request",
        "Architecture",
        """We chose sidecar-per-pod over a shared node proxy because per-team mTLS rotation
        was impossible to reason about with the shared model.
        The caveat is memory overhead, roughly 60MB per pod, so make sure batch workloads
        opt out of injection with the annotation rather than running the sidecar idle.
        We agreed to keep retries at the mesh layer and remove them from application code,
        since double retries were amplifying every partial outage.""",
    ),
]


def seed_if_empty(db: Session) -> None:
    if db.scalar(select(models.User).limit(1)):
        return

    users = {}
    for email, name, role, department in USERS:
        user = models.User(
            email=email,
            full_name=name,
            password_hash=hash_password("aegis1234"),
            role=role,
            department=department,
        )
        db.add(user)
        users[role] = user
    db.commit()

    expert = users["expert"]
    for title, source_type, domain, content in TRANSCRIPTS:
        knowledge_service.capture(
            db,
            {
                "title": title,
                "source_type": source_type,
                "content": content,
                "consent_granted": True,
                "expert_name": expert.full_name,
                "author_id": expert.id,
                "domain": domain,
            },
            actor=expert.full_name,
        )

    # Approve a realistic subset and age some records so decay is visible.
    items = db.scalars(select(models.KnowledgeItem)).all()
    for index, item in enumerate(items):
        if index % 3 == 2:
            continue  # leave a third pending for the validation queue
        item.status = "approved"
        item.usage_count = (index * 7) % 23
        item.last_reviewed_at = datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(
            days=(index * 37) % 260
        )
    knowledge_service.notify(
        db, "Welcome to AEGIS", "Seed knowledge is loaded. Sign in as any demo user.", "info"
    )
    db.add(
        models.PromptTemplate(
            key="capture.extract",
            description="Extraction prompt for the Knowledge Capture Agent",
            template="You extract tacit engineering knowledge. Return JSON items with "
                     "title, kind, summary, tags, confidence.",
        )
    )
    db.commit()
