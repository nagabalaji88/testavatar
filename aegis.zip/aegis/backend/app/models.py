"""Relational model for AEGIS."""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import JSON, Boolean, DateTime, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .core.database import Base


def _uid() -> str:
    return uuid.uuid4().hex[:16]


def _now() -> datetime:
    return datetime.now(timezone.utc)


class User(Base):
    __tablename__ = "users"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_uid)
    email: Mapped[str] = mapped_column(String(160), unique=True, index=True)
    full_name: Mapped[str] = mapped_column(String(160))
    password_hash: Mapped[str] = mapped_column(String(255))
    # expert | reviewer | learner | admin
    role: Mapped[str] = mapped_column(String(32), default="learner")
    department: Mapped[str] = mapped_column(String(80), default="Engineering")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)

    captures: Mapped[list["CaptureSession"]] = relationship(back_populates="author")


class CaptureSession(Base):
    """One ingested artifact (transcript, PR, incident report, voice note...)."""

    __tablename__ = "capture_sessions"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_uid)
    title: Mapped[str] = mapped_column(String(200))
    source_type: Mapped[str] = mapped_column(String(48))
    raw_content: Mapped[str] = mapped_column(Text)
    redacted_content: Mapped[str] = mapped_column(Text, default="")
    status: Mapped[str] = mapped_column(String(32), default="processing")
    consent_granted: Mapped[bool] = mapped_column(Boolean, default=True)
    pii_findings: Mapped[list] = mapped_column(JSON, default=list)
    agent_trace: Mapped[list] = mapped_column(JSON, default=list)
    author_id: Mapped[Optional[str]] = mapped_column(ForeignKey("users.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)

    author: Mapped[Optional[User]] = relationship(back_populates="captures")
    items: Mapped[list["KnowledgeItem"]] = relationship(
        back_populates="session", cascade="all, delete-orphan"
    )


class KnowledgeItem(Base):
    """A single validated (or pending) unit of tacit knowledge."""

    __tablename__ = "knowledge_items"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_uid)
    session_id: Mapped[Optional[str]] = mapped_column(ForeignKey("capture_sessions.id"))
    title: Mapped[str] = mapped_column(String(240))
    summary: Mapped[str] = mapped_column(Text, default="")
    body: Mapped[str] = mapped_column(Text, default="")
    # decision | risk | best_practice | heuristic | incident
    kind: Mapped[str] = mapped_column(String(32), default="decision")
    domain: Mapped[str] = mapped_column(String(80), default="Architecture")
    tags: Mapped[list] = mapped_column(JSON, default=list)
    confidence: Mapped[float] = mapped_column(Float, default=0.6)
    # pending | approved | rejected
    status: Mapped[str] = mapped_column(String(24), default="pending", index=True)
    visibility: Mapped[str] = mapped_column(String(24), default="department")
    version: Mapped[int] = mapped_column(Integer, default=1)
    usage_count: Mapped[int] = mapped_column(Integer, default=0)
    embedding: Mapped[list] = mapped_column(JSON, default=list)
    expert_name: Mapped[str] = mapped_column(String(160), default="Unattributed")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=_now, onupdate=_now)
    last_reviewed_at: Mapped[datetime] = mapped_column(DateTime, default=_now)

    session: Mapped[Optional[CaptureSession]] = relationship(back_populates="items")
    reviews: Mapped[list["Review"]] = relationship(
        back_populates="item", cascade="all, delete-orphan"
    )


class Review(Base):
    __tablename__ = "reviews"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_uid)
    item_id: Mapped[str] = mapped_column(ForeignKey("knowledge_items.id"))
    reviewer_id: Mapped[Optional[str]] = mapped_column(ForeignKey("users.id"), nullable=True)
    reviewer_name: Mapped[str] = mapped_column(String(160), default="System")
    decision: Mapped[str] = mapped_column(String(24))
    comment: Mapped[str] = mapped_column(Text, default="")
    confidence: Mapped[float] = mapped_column(Float, default=0.7)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)

    item: Mapped[KnowledgeItem] = relationship(back_populates="reviews")


class GraphNode(Base):
    __tablename__ = "graph_nodes"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_uid)
    label: Mapped[str] = mapped_column(String(200))
    # decision | expert | technology | incident | architecture | dependency
    node_type: Mapped[str] = mapped_column(String(40), index=True)
    item_id: Mapped[Optional[str]] = mapped_column(String(32), nullable=True)
    meta: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)


class GraphEdge(Base):
    __tablename__ = "graph_edges"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_uid)
    source_id: Mapped[str] = mapped_column(String(32), index=True)
    target_id: Mapped[str] = mapped_column(String(32), index=True)
    relation: Mapped[str] = mapped_column(String(60), default="relates_to")
    weight: Mapped[float] = mapped_column(Float, default=1.0)


class Simulation(Base):
    __tablename__ = "simulations"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_uid)
    scenario: Mapped[str] = mapped_column(String(60))
    title: Mapped[str] = mapped_column(String(200))
    tree: Mapped[dict] = mapped_column(JSON, default=dict)
    source_item_id: Mapped[Optional[str]] = mapped_column(String(32), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)


class SimulationAttempt(Base):
    __tablename__ = "simulation_attempts"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_uid)
    simulation_id: Mapped[str] = mapped_column(String(32), index=True)
    user_id: Mapped[Optional[str]] = mapped_column(String(32), nullable=True)
    path: Mapped[list] = mapped_column(JSON, default=list)
    score: Mapped[int] = mapped_column(Integer, default=0)
    badge: Mapped[str] = mapped_column(String(60), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)


class AuditEvent(Base):
    __tablename__ = "audit_events"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_uid)
    actor: Mapped[str] = mapped_column(String(160), default="system")
    action: Mapped[str] = mapped_column(String(80))
    target: Mapped[str] = mapped_column(String(200), default="")
    detail: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)


class Notification(Base):
    __tablename__ = "notifications"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_uid)
    title: Mapped[str] = mapped_column(String(200))
    body: Mapped[str] = mapped_column(Text, default="")
    level: Mapped[str] = mapped_column(String(24), default="info")
    read: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)


class PromptTemplate(Base):
    __tablename__ = "prompt_templates"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_uid)
    key: Mapped[str] = mapped_column(String(80), unique=True)
    description: Mapped[str] = mapped_column(String(240), default="")
    template: Mapped[str] = mapped_column(Text)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=_now, onupdate=_now)
