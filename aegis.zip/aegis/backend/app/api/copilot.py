from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from .. import models, schemas
from ..core.database import get_db
from ..services import copilot_service, knowledge_service
from .deps import current_user

router = APIRouter(prefix="/copilot", tags=["copilot"])


@router.post("")
def ask(
    payload: schemas.CopilotRequest,
    db: Session = Depends(get_db),
    user: models.User = Depends(current_user),
):
    corpus = knowledge_service.approved_corpus(db)
    result = copilot_service.answer(payload.question, corpus, payload.history, payload.top_k)
    knowledge_service.bump_usage(db, [s["id"] for s in result["sources"]])
    knowledge_service.record_audit(db, user.full_name, "copilot.ask", "", {"q": payload.question[:120]})
    db.commit()
    return result
