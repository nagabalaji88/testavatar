from collections import Counter

from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import models
from ..core.database import get_db
from .deps import current_user

router = APIRouter(prefix="/governance", tags=["governance"])


@router.get("/pii")
def pii_analytics(db: Session = Depends(get_db), user: models.User = Depends(current_user)):
    sessions = db.scalars(select(models.CaptureSession)).all()
    counter: Counter = Counter()
    for session in sessions:
        for finding in session.pii_findings or []:
            counter[finding["type"]] += 1
    return {
        "total_findings": sum(counter.values()),
        "sessions_scanned": len(sessions),
        "by_type": [{"name": k, "value": v} for k, v in counter.most_common()],
        "redaction_rate": 1.0 if sessions else 0.0,
    }


@router.get("/audit")
def audit(limit: int = 100, db: Session = Depends(get_db),
          user: models.User = Depends(current_user)):
    rows = db.scalars(
        select(models.AuditEvent).order_by(models.AuditEvent.created_at.desc()).limit(limit)
    ).all()
    return [
        {"id": e.id, "actor": e.actor, "action": e.action, "target": e.target,
         "detail": e.detail, "created_at": e.created_at}
        for e in rows
    ]


@router.get("/consent")
def consent(db: Session = Depends(get_db), user: models.User = Depends(current_user)):
    sessions = db.scalars(select(models.CaptureSession)).all()
    return [
        {
            "session_id": s.id,
            "title": s.title,
            "source_type": s.source_type,
            "consent_granted": s.consent_granted,
            "captured_at": s.created_at,
            "author": s.author.full_name if s.author else "Unknown",
        }
        for s in sessions
    ]


@router.get("/access")
def access_matrix(db: Session = Depends(get_db), user: models.User = Depends(current_user)):
    items = db.scalars(select(models.KnowledgeItem)).all()
    counter: Counter = Counter(i.visibility for i in items)
    return {
        "visibility": [{"name": k, "value": v} for k, v in counter.items()],
        "roles": {
            "expert": ["capture", "validate", "publish"],
            "reviewer": ["validate", "comment"],
            "learner": ["search", "copilot", "simulate"],
            "admin": ["everything", "configure", "audit"],
        },
    }
