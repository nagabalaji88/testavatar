import random

from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import models, schemas
from ..agents.learning import LearningAgent, badge_for
from ..core.database import get_db
from .deps import current_user

router = APIRouter(prefix="/simulation", tags=["simulation"])

SCENARIOS = ["incident", "architecture", "production", "hr", "security"]


@router.get("/scenarios")
def scenarios(user: models.User = Depends(current_user)):
    return [{"id": s, "label": s.replace("_", " ").title()} for s in SCENARIOS]


@router.post("/start")
def start(
    payload: schemas.SimulationStartRequest,
    db: Session = Depends(get_db),
    user: models.User = Depends(current_user),
):
    approved = db.scalars(
        select(models.KnowledgeItem).where(models.KnowledgeItem.status == "approved")
    ).all()
    source = random.choice(approved) if approved else None
    item = (
        {"title": source.title, "summary": source.summary, "id": source.id}
        if source
        else {"title": "General incident response", "summary": "No approved knowledge yet."}
    )
    state = LearningAgent().run({"item": item, "scenario": payload.scenario})
    simulation = models.Simulation(
        scenario=payload.scenario,
        title=item["title"],
        tree=state["tree"],
        source_item_id=item.get("id"),
    )
    db.add(simulation)
    db.commit()
    db.refresh(simulation)
    return {
        "id": simulation.id,
        "scenario": simulation.scenario,
        "title": simulation.title,
        "tree": simulation.tree,
        "trace": state.get("trace", []),
    }


@router.post("/answer")
def answer(
    payload: schemas.SimulationAnswerRequest,
    db: Session = Depends(get_db),
    user: models.User = Depends(current_user),
):
    simulation = db.get(models.Simulation, payload.simulation_id)
    if not simulation:
        return {"error": "not_found"}
    node = simulation.tree["nodes"].get(payload.node_id)
    choice = next((c for c in node["choices"] if c["id"] == payload.choice_id), None)
    if not choice:
        return {"error": "invalid_choice"}
    path = payload.path + [{"node": payload.node_id, "choice": choice["id"], "score": choice["score"]}]
    total = sum(step["score"] for step in path)
    finished = choice["next"] is None
    result = {
        "feedback": choice["feedback"],
        "score": choice["score"],
        "total": total,
        "next_node": simulation.tree["nodes"].get(choice["next"]) if choice["next"] else None,
        "path": path,
        "finished": finished,
    }
    if finished:
        maximum = 10 * len(simulation.tree["nodes"])
        badge = badge_for(total, maximum)
        db.add(
            models.SimulationAttempt(
                simulation_id=simulation.id,
                user_id=user.id,
                path=path,
                score=total,
                badge=badge,
            )
        )
        db.commit()
        result["badge"] = badge
        result["max_score"] = maximum
    return result


@router.get("/progress")
def progress(db: Session = Depends(get_db), user: models.User = Depends(current_user)):
    attempts = db.scalars(
        select(models.SimulationAttempt).where(models.SimulationAttempt.user_id == user.id)
    ).all()
    return {
        "attempts": len(attempts),
        "average_score": round(sum(a.score for a in attempts) / len(attempts), 1) if attempts else 0,
        "badges": sorted({a.badge for a in attempts if a.badge}),
        "history": [
            {"score": a.score, "badge": a.badge, "created_at": a.created_at} for a in attempts[-10:]
        ],
    }
