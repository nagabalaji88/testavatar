from typing import Optional

from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import models, schemas
from ..core.database import get_db
from ..services import knowledge_service
from ..services.vector_store import search
from .deps import current_user, require_roles

router = APIRouter(tags=["knowledge"])


@router.get("/knowledge", response_model=list[schemas.KnowledgeItemOut])
def list_items(
    status: Optional[str] = None,
    domain: Optional[str] = None,
    limit: int = 100,
    db: Session = Depends(get_db),
    user: models.User = Depends(current_user),
):
    query = select(models.KnowledgeItem).order_by(models.KnowledgeItem.created_at.desc())
    if status:
        query = query.where(models.KnowledgeItem.status == status)
    if domain:
        query = query.where(models.KnowledgeItem.domain == domain)
    return db.scalars(query.limit(limit)).all()


@router.get("/knowledge/{item_id}")
def get_item(item_id: str, db: Session = Depends(get_db), user: models.User = Depends(current_user)):
    item = db.get(models.KnowledgeItem, item_id)
    if not item:
        return {"error": "not_found"}
    return {
        "item": schemas.KnowledgeItemOut.model_validate(item),
        "reviews": [
            {
                "reviewer_name": r.reviewer_name,
                "decision": r.decision,
                "comment": r.comment,
                "confidence": r.confidence,
                "created_at": r.created_at,
            }
            for r in item.reviews
        ],
    }


@router.post("/validation/{item_id}", response_model=schemas.KnowledgeItemOut)
def review_item(
    item_id: str,
    payload: schemas.ReviewRequest,
    db: Session = Depends(get_db),
    user: models.User = Depends(require_roles("expert", "reviewer")),
):
    return knowledge_service.review(db, item_id, payload.model_dump(), reviewer=user.full_name)


@router.get("/validation/queue")
def review_queue(db: Session = Depends(get_db), user: models.User = Depends(current_user)):
    items = db.scalars(
        select(models.KnowledgeItem)
        .where(models.KnowledgeItem.status == "pending")
        .order_by(models.KnowledgeItem.confidence.asc())
    ).all()
    return [schemas.KnowledgeItemOut.model_validate(i) for i in items]


@router.post("/search")
def search_knowledge(
    payload: schemas.SearchRequest,
    db: Session = Depends(get_db),
    user: models.User = Depends(current_user),
):
    corpus = knowledge_service.approved_corpus(db, payload.domain)
    matches = search(payload.query, corpus, payload.top_k)
    knowledge_service.bump_usage(db, [m["id"] for m in matches])
    return [
        {
            "id": m["id"],
            "title": m["title"],
            "summary": m["summary"],
            "domain": m["domain"],
            "kind": m["kind"],
            "expert_name": m["expert_name"],
            "confidence": m["confidence"],
            "score": m["score"],
        }
        for m in matches
    ]
