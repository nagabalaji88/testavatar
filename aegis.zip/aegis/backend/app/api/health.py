from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import models
from ..agents.refresh import RefreshAgent
from ..core.database import get_db
from ..services import knowledge_service
from .deps import current_user

router = APIRouter(prefix="/knowledge-health", tags=["knowledge health"])


@router.get("")
def health(db: Session = Depends(get_db), user: models.User = Depends(current_user)):
    items = knowledge_service.approved_corpus(db)
    state = RefreshAgent().run({"items": items})
    report = state.get("health", {})
    return {
        "health": report.get("health", 0),
        "freshness": report.get("freshness", 0),
        "decay": report.get("decay", 0),
        "total": report.get("total", 0),
        "recall_queue": report.get("stale", []),
        "trace": state.get("trace", []),
    }


@router.post("/refresh/{item_id}")
def request_refresh(item_id: str, db: Session = Depends(get_db),
                    user: models.User = Depends(current_user)):
    item = db.get(models.KnowledgeItem, item_id)
    if not item:
        return {"error": "not_found"}
    knowledge_service.notify(
        db,
        f"Refresh requested: {item.title[:60]}",
        f"{user.full_name} asked {item.expert_name} to confirm this is still current.",
        "action",
    )
    knowledge_service.record_audit(db, user.full_name, "knowledge.refresh_requested", item.id)
    db.commit()
    return {"status": "requested", "expert": item.expert_name}
