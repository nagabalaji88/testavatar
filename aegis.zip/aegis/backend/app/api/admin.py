from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import models, schemas
from ..core.config import settings
from ..core.database import get_db
from ..core.security import hash_password
from .deps import require_roles

router = APIRouter(prefix="/admin", tags=["admin"])


@router.get("/users", response_model=list[schemas.UserOut])
def users(db: Session = Depends(get_db), _=Depends(require_roles("admin"))):
    return db.scalars(select(models.User)).all()


@router.post("/users", response_model=schemas.UserOut)
def create_user(payload: dict, db: Session = Depends(get_db), _=Depends(require_roles("admin"))):
    user = models.User(
        email=payload["email"].lower(),
        full_name=payload["full_name"],
        password_hash=hash_password(payload.get("password", "aegis1234")),
        role=payload.get("role", "learner"),
        department=payload.get("department", "Engineering"),
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


@router.patch("/users/{user_id}", response_model=schemas.UserOut)
def update_user(user_id: str, payload: dict, db: Session = Depends(get_db),
                _=Depends(require_roles("admin"))):
    user = db.get(models.User, user_id)
    for field in ("role", "department", "is_active", "full_name"):
        if field in payload:
            setattr(user, field, payload[field])
    db.commit()
    db.refresh(user)
    return user


@router.get("/prompts")
def prompts(db: Session = Depends(get_db), _=Depends(require_roles("admin"))):
    rows = db.scalars(select(models.PromptTemplate)).all()
    return [
        {"id": p.id, "key": p.key, "description": p.description,
         "template": p.template, "updated_at": p.updated_at}
        for p in rows
    ]


@router.put("/prompts/{key}")
def update_prompt(key: str, payload: dict, db: Session = Depends(get_db),
                  _=Depends(require_roles("admin"))):
    prompt = db.scalar(select(models.PromptTemplate).where(models.PromptTemplate.key == key))
    if not prompt:
        prompt = models.PromptTemplate(key=key, template=payload.get("template", ""))
        db.add(prompt)
    else:
        prompt.template = payload.get("template", prompt.template)
        prompt.description = payload.get("description", prompt.description)
    db.commit()
    return {"status": "saved", "key": key}


@router.get("/system")
def system(_=Depends(require_roles("admin"))):
    return {
        "app_name": settings.app_name,
        "model": settings.openai_model,
        "llm_mode": "live" if settings.llm_enabled else "offline deterministic engine",
        "vector_dimensions": 256,
        "decay_half_life_days": settings.decay_half_life_days,
        "stale_threshold": settings.stale_threshold,
        "database": settings.database_url.split(":")[0],
    }


@router.get("/agents")
def agents(_=Depends(require_roles("admin"))):
    from ..agents import (
        EmbeddingAgent, KnowledgeCaptureAgent, KnowledgeStructuringAgent, LearningAgent,
        PrivacyAgent, RecommendationAgent, RefreshAgent, ValidationAgent,
    )

    registry = [
        PrivacyAgent(), KnowledgeCaptureAgent(), KnowledgeStructuringAgent(), ValidationAgent(),
        EmbeddingAgent(), RecommendationAgent(), LearningAgent(), RefreshAgent(),
    ]
    return [{"name": a.name, "description": a.description} for a in registry]
