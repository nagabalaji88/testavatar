from fastapi import APIRouter, Depends, File, UploadFile
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import models, schemas
from ..core.database import get_db
from ..services import knowledge_service
from .deps import current_user

router = APIRouter(prefix="/capture", tags=["capture"])


@router.post("", response_model=schemas.CaptureResult)
def create_capture(
    payload: schemas.CaptureRequest,
    db: Session = Depends(get_db),
    user: models.User = Depends(current_user),
):
    data = payload.model_dump()
    data["author_id"] = user.id
    data.setdefault("expert_name", user.full_name)
    if data["expert_name"] == "Unattributed":
        data["expert_name"] = user.full_name
    return knowledge_service.capture(db, data, actor=user.full_name)


@router.post("/upload", response_model=schemas.CaptureResult)
async def upload_capture(
    file: UploadFile = File(...),
    source_type: str = "meeting_transcript",
    db: Session = Depends(get_db),
    user: models.User = Depends(current_user),
):
    raw = (await file.read()).decode("utf-8", errors="ignore")
    return knowledge_service.capture(
        db,
        {
            "title": file.filename or "Uploaded artifact",
            "source_type": source_type,
            "content": raw,
            "consent_granted": True,
            "expert_name": user.full_name,
            "author_id": user.id,
            "domain": "Architecture",
        },
        actor=user.full_name,
    )


@router.get("/sessions")
def list_sessions(db: Session = Depends(get_db), user: models.User = Depends(current_user)):
    sessions = db.scalars(
        select(models.CaptureSession).order_by(models.CaptureSession.created_at.desc()).limit(50)
    ).all()
    return [
        {
            "id": s.id,
            "title": s.title,
            "source_type": s.source_type,
            "status": s.status,
            "pii_count": len(s.pii_findings or []),
            "item_count": len(s.items),
            "created_at": s.created_at,
        }
        for s in sessions
    ]


@router.get("/sessions/{session_id}")
def get_session(session_id: str, db: Session = Depends(get_db),
                user: models.User = Depends(current_user)):
    session = db.get(models.CaptureSession, session_id)
    if not session:
        return {"error": "not_found"}
    return {
        "id": session.id,
        "title": session.title,
        "source_type": session.source_type,
        "status": session.status,
        "redacted_content": session.redacted_content,
        "pii_findings": session.pii_findings,
        "trace": session.agent_trace,
        "items": [schemas.KnowledgeItemOut.model_validate(i) for i in session.items],
    }
