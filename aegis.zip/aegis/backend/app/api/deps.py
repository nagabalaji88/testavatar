"""Shared FastAPI dependencies: current user + role guards."""
from __future__ import annotations

from fastapi import Depends, Header, HTTPException, status
from sqlalchemy.orm import Session

from .. import models
from ..core.database import get_db
from ..core.security import decode_token


def current_user(
    authorization: str = Header(default=""),
    db: Session = Depends(get_db),
) -> models.User:
    if not authorization.lower().startswith("bearer "):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Sign in to continue.")
    payload = decode_token(authorization.split(" ", 1)[1])
    if not payload:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Session expired. Sign in again.")
    user = db.get(models.User, payload.get("sub", ""))
    if not user or not user.is_active:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Account is not active.")
    return user


def require_roles(*roles: str):
    def guard(user: models.User = Depends(current_user)) -> models.User:
        if roles and user.role not in roles and user.role != "admin":
            raise HTTPException(
                status.HTTP_403_FORBIDDEN,
                f"This action needs one of: {', '.join(roles)}.",
            )
        return user

    return guard
