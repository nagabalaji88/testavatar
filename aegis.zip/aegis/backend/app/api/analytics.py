from collections import Counter
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .. import models
from ..core.database import get_db
from ..services import knowledge_service
from ..services.knowledge_health import portfolio_health
from .deps import current_user

router = APIRouter(tags=["analytics"])


@router.get("/analytics/dashboard")
def dashboard(db: Session = Depends(get_db), user: models.User = Depends(current_user)):
    total = db.scalar(select(func.count()).select_from(models.KnowledgeItem)) or 0
    approved = db.scalar(
        select(func.count()).select_from(models.KnowledgeItem).where(
            models.KnowledgeItem.status == "approved")
    ) or 0
    pending = db.scalar(
        select(func.count()).select_from(models.KnowledgeItem).where(
            models.KnowledgeItem.status == "pending")
    ) or 0
    experts = db.scalar(
        select(func.count()).select_from(models.User).where(models.User.role == "expert")
    ) or 0
    learners = db.scalar(
        select(func.count()).select_from(models.User).where(models.User.role == "learner")
    ) or 0
    items = knowledge_service.approved_corpus(db)
    report = portfolio_health(items)

    now = datetime.now(timezone.utc).replace(tzinfo=None)
    timeline = []
    for offset in range(13, -1, -1):
        day = (now - timedelta(days=offset)).date()
        count = db.scalar(
            select(func.count()).select_from(models.KnowledgeItem).where(
                func.date(models.KnowledgeItem.created_at) == day.isoformat()
            )
        ) or 0
        timeline.append({"date": day.isoformat(), "captured": count})

    all_items = db.scalars(select(models.KnowledgeItem)).all()
    by_domain = Counter(i.domain for i in all_items)
    by_kind = Counter(i.kind for i in all_items)
    return {
        "metrics": {
            "knowledge_captured": total,
            "approved": approved,
            "pending_reviews": pending,
            "experts": experts,
            "active_learners": learners,
            "knowledge_health": report.get("health", 0),
            "decay_score": report.get("decay", 0),
            "daily_ai_usage": sum(i.usage_count for i in all_items),
        },
        "timeline": timeline,
        "by_domain": [{"name": k, "value": v} for k, v in by_domain.items()],
        "by_kind": [{"name": k, "value": v} for k, v in by_kind.items()],
        "top_used": sorted(
            [{"title": i.title[:48], "usage": i.usage_count} for i in all_items],
            key=lambda r: r["usage"],
            reverse=True,
        )[:6],
    }


@router.get("/notifications")
def notifications(db: Session = Depends(get_db), user: models.User = Depends(current_user)):
    rows = db.scalars(
        select(models.Notification).order_by(models.Notification.created_at.desc()).limit(20)
    ).all()
    return [
        {"id": n.id, "title": n.title, "body": n.body, "level": n.level,
         "read": n.read, "created_at": n.created_at}
        for n in rows
    ]


@router.post("/notifications/{notification_id}/read")
def mark_read(notification_id: str, db: Session = Depends(get_db),
              user: models.User = Depends(current_user)):
    notification = db.get(models.Notification, notification_id)
    if notification:
        notification.read = True
        db.commit()
    return {"status": "ok"}
