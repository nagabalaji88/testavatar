from typing import Optional

from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import models
from ..core.database import get_db
from .deps import current_user

router = APIRouter(prefix="/graph", tags=["graph"])


@router.get("")
def get_graph(
    node_type: Optional[str] = None,
    q: Optional[str] = None,
    db: Session = Depends(get_db),
    user: models.User = Depends(current_user),
):
    query = select(models.GraphNode)
    if node_type:
        query = query.where(models.GraphNode.node_type == node_type)
    nodes = db.scalars(query).all()
    if q:
        needle = q.lower()
        nodes = [n for n in nodes if needle in n.label.lower()]
    node_ids = {n.id for n in nodes}
    edges = [
        e
        for e in db.scalars(select(models.GraphEdge)).all()
        if e.source_id in node_ids and e.target_id in node_ids
    ]
    return {
        "nodes": [
            {
                "id": n.id,
                "label": n.label,
                "type": n.node_type,
                "meta": n.meta,
                "created_at": n.created_at,
            }
            for n in nodes
        ],
        "edges": [
            {"id": e.id, "source": e.source_id, "target": e.target_id, "relation": e.relation}
            for e in edges
        ],
    }
