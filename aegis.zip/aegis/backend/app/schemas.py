"""Pydantic models. Used only at the API boundary — services speak plain dicts."""
from __future__ import annotations

from datetime import datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field


class LoginRequest(BaseModel):
    email: str
    password: str


class UserOut(BaseModel):
    id: str
    email: str
    full_name: str
    role: str
    department: str

    model_config = ConfigDict(from_attributes=True)


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut


class CaptureRequest(BaseModel):
    title: str = Field(min_length=3, max_length=200)
    source_type: str = "meeting_transcript"
    content: str = Field(min_length=20)
    consent_granted: bool = True
    expert_name: str = "Unattributed"
    domain: str = "Architecture"


class AgentStep(BaseModel):
    agent: str
    status: str
    detail: str
    duration_ms: int
    output: dict = {}


class KnowledgeItemOut(BaseModel):
    id: str
    title: str
    summary: str
    body: str
    kind: str
    domain: str
    tags: list[str]
    confidence: float
    status: str
    visibility: str
    version: int
    usage_count: int
    expert_name: str
    created_at: datetime
    updated_at: datetime
    last_reviewed_at: datetime

    model_config = ConfigDict(from_attributes=True)


class CaptureResult(BaseModel):
    session_id: str
    status: str
    pii_findings: list[dict]
    redacted_content: str
    trace: list[AgentStep]
    items: list[KnowledgeItemOut]


class ReviewRequest(BaseModel):
    decision: str  # approve | reject | edit
    comment: str = ""
    confidence: float = 0.8
    visibility: Optional[str] = None
    title: Optional[str] = None
    body: Optional[str] = None


class SearchRequest(BaseModel):
    query: str
    top_k: int = 5
    domain: Optional[str] = None


class CopilotRequest(BaseModel):
    question: str
    history: list[dict] = []
    top_k: int = 4


class SimulationStartRequest(BaseModel):
    scenario: str = "incident"


class SimulationAnswerRequest(BaseModel):
    simulation_id: str
    node_id: str
    choice_id: str
    path: list[dict] = []
