"""Persistence bridge between the agent pipeline and the database."""
from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import models
from ..agents.orchestrator import run_capture_pipeline


def _now() -> datetime:
    return datetime.now(timezone.utc)


def record_audit(db: Session, actor: str, action: str, target: str = "", detail: dict | None = None):
    db.add(models.AuditEvent(actor=actor, action=action, target=target, detail=detail or {}))


def notify(db: Session, title: str, body: str = "", level: str = "info"):
    db.add(models.Notification(title=title, body=body, level=level))


def persist_graph_fragment(db: Session, fragment: dict, item_ids: dict[str, str]) -> None:
    key_to_id: dict[str, str] = {}
    for node in fragment.get("nodes", []):
        existing = db.scalar(
            select(models.GraphNode).where(
                models.GraphNode.label == node["label"],
                models.GraphNode.node_type == node["node_type"],
            )
        )
        if existing:
            key_to_id[node["key"]] = existing.id
            continue
        created = models.GraphNode(
            label=node["label"],
            node_type=node["node_type"],
            meta=node.get("meta", {}),
            item_id=item_ids.get(node["key"]),
        )
        db.add(created)
        db.flush()
        key_to_id[node["key"]] = created.id
    for edge in fragment.get("edges", []):
        source, target = key_to_id.get(edge["source"]), key_to_id.get(edge["target"])
        if not source or not target:
            continue
        db.add(models.GraphEdge(source_id=source, target_id=target, relation=edge["relation"]))


def capture(db: Session, payload: dict, actor: str = "system") -> dict:
    """Run the pipeline and persist the session, items and graph fragment."""
    state = run_capture_pipeline(
        {
            "title": payload["title"],
            "raw_content": payload["content"],
            "consent_granted": payload.get("consent_granted", True),
            "expert_name": payload.get("expert_name", "Unattributed"),
            "domain": payload.get("domain", "Architecture"),
        }
    )

    session = models.CaptureSession(
        title=payload["title"],
        source_type=payload.get("source_type", "meeting_transcript"),
        raw_content=payload["content"],
        redacted_content=state.get("redacted_content", ""),
        status=state.get("status", "processing"),
        consent_granted=payload.get("consent_granted", True),
        pii_findings=state.get("pii_findings", []),
        agent_trace=state.get("trace", []),
        author_id=payload.get("author_id"),
    )
    db.add(session)
    db.flush()

    items: list[models.KnowledgeItem] = []
    key_to_item: dict[str, str] = {}
    for candidate in state.get("candidates", []):
        item = models.KnowledgeItem(
            session_id=session.id,
            title=candidate["title"],
            summary=candidate.get("summary", ""),
            body=candidate.get("body", ""),
            kind=candidate.get("kind", "decision"),
            domain=candidate.get("domain", "Architecture"),
            tags=candidate.get("tags", []),
            confidence=candidate.get("confidence", 0.6),
            embedding=candidate.get("embedding", []),
            expert_name=payload.get("expert_name", "Unattributed"),
            status="pending",
        )
        db.add(item)
        db.flush()
        items.append(item)
        key_to_item[f"item::{candidate['title'][:60]}"] = item.id

    persist_graph_fragment(db, state.get("graph_fragment", {}), key_to_item)
    record_audit(db, actor, "capture.run", session.id,
                 {"items": len(items), "pii": len(state.get("pii_findings", []))})
    if items:
        notify(db, f"{len(items)} knowledge cards need review",
               f"From “{payload['title']}”.", "action")
    db.commit()

    return {
        "session_id": session.id,
        "status": session.status,
        "pii_findings": session.pii_findings,
        "redacted_content": session.redacted_content,
        "trace": session.agent_trace,
        "items": items,
    }


def review(db: Session, item_id: str, payload: dict, reviewer: str = "Reviewer") -> models.KnowledgeItem | None:
    item = db.get(models.KnowledgeItem, item_id)
    if not item:
        return None
    decision = payload["decision"]
    if decision == "edit":
        if payload.get("title"):
            item.title = payload["title"]
        if payload.get("body"):
            item.body = payload["body"]
        item.version += 1
    elif decision == "approve":
        item.status = "approved"
        item.last_reviewed_at = _now()
    elif decision == "reject":
        item.status = "rejected"
    if payload.get("visibility"):
        item.visibility = payload["visibility"]
    item.confidence = payload.get("confidence", item.confidence)
    db.add(
        models.Review(
            item_id=item.id,
            reviewer_name=reviewer,
            decision=decision,
            comment=payload.get("comment", ""),
            confidence=item.confidence,
        )
    )
    record_audit(db, reviewer, f"review.{decision}", item.id, {"comment": payload.get("comment", "")})
    db.commit()
    db.refresh(item)
    return item


def approved_corpus(db: Session, domain: str | None = None) -> list[dict]:
    query = select(models.KnowledgeItem).where(models.KnowledgeItem.status == "approved")
    if domain:
        query = query.where(models.KnowledgeItem.domain == domain)
    return [
        {
            "id": i.id,
            "title": i.title,
            "summary": i.summary,
            "body": i.body,
            "kind": i.kind,
            "domain": i.domain,
            "tags": i.tags,
            "confidence": i.confidence,
            "expert_name": i.expert_name,
            "embedding": i.embedding,
            "usage_count": i.usage_count,
            "last_reviewed_at": i.last_reviewed_at,
            "updated_at": i.updated_at,
        }
        for i in db.scalars(query).all()
    ]


def bump_usage(db: Session, item_ids: list[str]) -> None:
    for item_id in item_ids:
        item = db.get(models.KnowledgeItem, item_id)
        if item:
            item.usage_count += 1
    db.commit()
