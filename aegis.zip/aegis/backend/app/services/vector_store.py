"""Hash-based embeddings + cosine search.

Pure Python so the demo needs no model download. Swap `embed()` for
sentence-transformers or an OpenAI embedding call and nothing else changes.
"""
from __future__ import annotations

import hashlib
import math

from .llm import STOPWORDS
import re

DIMENSIONS = 256


def _tokens(text: str) -> list[str]:
    return [
        w for w in re.findall(r"[a-zA-Z][a-zA-Z0-9_\-]{1,}", text.lower())
        if w not in STOPWORDS
    ]


def embed(text: str) -> list[float]:
    vector = [0.0] * DIMENSIONS
    tokens = _tokens(text)
    for token in tokens:
        bucket = int(hashlib.md5(token.encode()).hexdigest(), 16) % DIMENSIONS
        vector[bucket] += 1.0
    norm = math.sqrt(sum(v * v for v in vector))
    if norm == 0:
        return vector
    return [round(v / norm, 6) for v in vector]


def cosine(a: list[float], b: list[float]) -> float:
    if not a or not b or len(a) != len(b):
        return 0.0
    return round(sum(x * y for x, y in zip(a, b)), 6)


def search(query: str, records: list[dict], top_k: int = 5) -> list[dict]:
    """`records` are dicts with at least `embedding`; returns them scored + sorted."""
    query_vector = embed(query)
    scored = []
    for record in records:
        score = cosine(query_vector, record.get("embedding") or [])
        if score <= 0:
            continue
        scored.append({**record, "score": score})
    scored.sort(key=lambda r: r["score"], reverse=True)
    return scored[:top_k]
