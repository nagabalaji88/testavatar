"""Knowledge decay + health scoring. Pure functions, easy to unit test."""
from __future__ import annotations

import math
from datetime import datetime, timezone


def _age_days(moment: datetime) -> float:
    if moment.tzinfo is None:
        moment = moment.replace(tzinfo=timezone.utc)
    return max((datetime.now(timezone.utc) - moment).total_seconds() / 86400, 0.0)


def freshness(last_reviewed: datetime, half_life_days: int = 120) -> float:
    """1.0 = reviewed today, decaying exponentially toward 0."""
    return round(math.exp(-_age_days(last_reviewed) * math.log(2) / half_life_days), 4)


def decay_score(last_reviewed: datetime, half_life_days: int = 120) -> float:
    return round(1 - freshness(last_reviewed, half_life_days), 4)


def item_health(item: dict, half_life_days: int = 120) -> dict:
    fresh = freshness(item["last_reviewed_at"], half_life_days)
    usage = min(item.get("usage_count", 0) / 25, 1.0)
    confidence = item.get("confidence", 0.5)
    score = round(0.5 * fresh + 0.2 * usage + 0.3 * confidence, 4)
    return {
        "id": item["id"],
        "title": item["title"],
        "freshness": fresh,
        "decay": round(1 - fresh, 4),
        "usage_factor": round(usage, 4),
        "confidence": confidence,
        "health": score,
        "age_days": round(_age_days(item["last_reviewed_at"]), 1),
    }


def portfolio_health(items: list[dict], half_life_days: int = 120,
                     stale_threshold: float = 0.45) -> dict:
    if not items:
        return {"health": 0.0, "decay": 0.0, "freshness": 0.0, "stale": [], "total": 0}
    scored = [item_health(i, half_life_days) for i in items]
    health = round(sum(s["health"] for s in scored) / len(scored), 4)
    fresh = round(sum(s["freshness"] for s in scored) / len(scored), 4)
    stale = sorted(
        [s for s in scored if s["health"] < stale_threshold],
        key=lambda s: s["health"],
    )
    return {
        "health": health,
        "freshness": fresh,
        "decay": round(1 - fresh, 4),
        "total": len(scored),
        "stale": stale[:12],
        "items": scored,
    }
