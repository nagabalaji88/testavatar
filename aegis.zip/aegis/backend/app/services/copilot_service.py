"""RAG copilot: retrieve → ground → answer, always with attribution."""
from __future__ import annotations

from ..agents.recommendation import RecommendationAgent, suggest_followups
from .llm import complete_text


def _grounded_fallback(question: str, matches: list[dict]) -> str:
    if not matches:
        return (
            "Nothing in the validated knowledge base covers that yet. "
            "Capture a session on this topic, or ask an expert directly and record the answer."
        )
    lines = [f"Here is what the validated knowledge base says about **{question.strip()}**:", ""]
    for index, match in enumerate(matches, start=1):
        lines.append(f"**{index}. {match['title']}**")
        lines.append(match.get("summary") or match.get("body", "")[:280])
        lines.append(
            f"_Source: {match['expert_name']} · {match['domain']} · "
            f"confidence {match['confidence']:.0%} · relevance {match['score']:.0%}_"
        )
        lines.append("")
    return "\n".join(lines)


def answer(question: str, corpus: list[dict], history: list[dict] | None = None,
           top_k: int = 4) -> dict:
    state = RecommendationAgent().run({"query": question, "corpus": corpus, "top_k": top_k})
    matches = state.get("matches", [])
    context = "\n\n".join(
        f"[{m['id']}] {m['title']}\n{m.get('body') or m.get('summary','')}" for m in matches
    )
    reply = complete_text(
        system=(
            "You are the AEGIS Copilot. Answer only from the provided validated knowledge. "
            "Cite sources as [id]. If the context is insufficient, say so plainly."
        ),
        user=f"Question: {question}\n\nValidated knowledge:\n{context}",
        fallback=_grounded_fallback(question, matches),
    )
    return {
        "answer": reply,
        "sources": [
            {
                "id": m["id"],
                "title": m["title"],
                "expert_name": m["expert_name"],
                "domain": m["domain"],
                "confidence": m["confidence"],
                "score": m["score"],
            }
            for m in matches
        ],
        "confidence": round(sum(m["score"] for m in matches) / len(matches), 3) if matches else 0.0,
        "followups": suggest_followups(question, matches),
        "trace": state.get("trace", []),
    }
