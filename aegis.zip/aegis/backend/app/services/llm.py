"""LLM gateway.

If an OpenAI-compatible key is configured we call it; otherwise we fall back to
a deterministic local engine so the entire agent pipeline still runs offline.
Every agent goes through `complete_json` / `complete_text` so swapping the
provider is a one-file change.
"""
from __future__ import annotations

import json
import re

import httpx

from ..core.config import settings

STOPWORDS = {
    "the", "and", "for", "with", "that", "this", "from", "have", "has", "was", "were",
    "are", "our", "you", "your", "but", "not", "all", "any", "can", "will", "into",
    "they", "them", "their", "when", "what", "which", "there", "here", "been", "also",
    "more", "than", "then", "over", "just", "about", "after", "before", "should",
    "would", "could", "because", "while", "using", "used", "very", "each", "into",
}


def _post(messages: list[dict], temperature: float = 0.2) -> str:
    payload = {
        "model": settings.openai_model,
        "messages": messages,
        "temperature": temperature,
    }
    headers = {"Authorization": f"Bearer {settings.openai_api_key}"}
    with httpx.Client(timeout=60) as client:
        response = client.post(
            f"{settings.openai_base_url.rstrip('/')}/chat/completions",
            json=payload,
            headers=headers,
        )
        response.raise_for_status()
        return response.json()["choices"][0]["message"]["content"]


def complete_text(system: str, user: str, fallback: str = "") -> str:
    if not settings.llm_enabled:
        return fallback
    try:
        return _post([{"role": "system", "content": system}, {"role": "user", "content": user}])
    except Exception:  # noqa: BLE001 - degrade gracefully, never break the pipeline
        return fallback


def complete_json(system: str, user: str, fallback: dict) -> dict:
    if not settings.llm_enabled:
        return fallback
    raw = complete_text(system + "\nRespond with JSON only, no markdown fences.", user, "")
    if not raw:
        return fallback
    cleaned = re.sub(r"^```(?:json)?|```$", "", raw.strip(), flags=re.MULTILINE).strip()
    try:
        parsed = json.loads(cleaned)
        return parsed if isinstance(parsed, dict) else fallback
    except json.JSONDecodeError:
        return fallback


def keywords(text: str, limit: int = 8) -> list[str]:
    """Cheap keyword extraction used by the offline engine and for tagging."""
    counts: dict[str, int] = {}
    for word in re.findall(r"[a-zA-Z][a-zA-Z0-9_\-]{2,}", text.lower()):
        if word in STOPWORDS:
            continue
        counts[word] = counts.get(word, 0) + 1
    ranked = sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))
    return [word for word, _ in ranked[:limit]]


def sentences(text: str) -> list[str]:
    parts = re.split(r"(?<=[.!?])\s+|\n+", text)
    return [p.strip() for p in parts if len(p.strip()) > 25]
