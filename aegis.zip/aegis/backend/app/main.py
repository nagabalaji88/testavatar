"""Project AEGIS API."""
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .api import (
    admin, analytics, auth, capture, copilot, governance, graph, health, knowledge, simulation,
)
from .core.config import settings
from .core.database import Base, SessionLocal, engine
from .seed import seed_if_empty

def init_db() -> None:
    """Create tables and load demo data. Safe to call repeatedly."""
    Base.metadata.create_all(bind=engine)
    with SessionLocal() as db:
        seed_if_empty(db)


@asynccontextmanager
async def lifespan(_: FastAPI):
    init_db()
    yield


app = FastAPI(
    lifespan=lifespan,
    title=settings.app_name,
    version="1.0.0",
    description="Ethical tacit knowledge capture and dynamic transfer.",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_list or ["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

for router in (
    auth.router, capture.router, knowledge.router, graph.router, copilot.router,
    simulation.router, health.router, analytics.router, governance.router, admin.router,
):
    app.include_router(router, prefix=settings.api_prefix)


@app.get("/api/status")
def status() -> dict:
    return {
        "status": "online",
        "app": settings.app_name,
        "llm": "live" if settings.llm_enabled else "offline",
        "vector_index": "ready",
    }
