"""Agent 6 — Recommendation. Context-aware retrieval for the Copilot and dashboards."""
from __future__ import annotations

from ..services.vector_store import search
from .base import Agent, AgentState


class RecommendationAgent(Agent):
    name = "Recommendation Agent"
    description = "Ranks approved knowledge against the learner's current context."

    def handle(self, state: AgentState):
        matches = search(state["query"], state.get("corpus", []), state.get("top_k", 5))
        state["matches"] = matches
        top = matches[0]["title"] if matches else "no match"
        return state, f"Retrieved {len(matches)} sources (top: {top}).", {"count": len(matches)}


def suggest_followups(question: str, matches: list[dict]) -> list[str]:
    suggestions = []
    for match in matches[:3]:
        suggestions.append(f"What are the trade-offs behind “{match['title'][:60]}”?")
    suggestions.append(f"Who is the expert I should ask about {question.strip()[:48]}?")
    return suggestions[:4]
