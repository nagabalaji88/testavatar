"""Agent 3 — Knowledge Structuring. Turns raw candidates into ADR-shaped records."""
from __future__ import annotations

from ..services.llm import complete_text
from .base import Agent, AgentState

ADR = """### Context
{context}

### Decision
{decision}

### Rationale
{rationale}

### Consequences
{consequences}

### Applies to
{applies}
"""


def to_adr(candidate: dict, source_title: str) -> str:
    kind = candidate["kind"].replace("_", " ")
    return ADR.format(
        context=f"Captured from *{source_title}* while discussing {candidate['domain']}.",
        decision=candidate["title"],
        rationale=candidate.get("evidence") or candidate.get("summary", ""),
        consequences=(
            "Teams following this guidance inherit the expert's reasoning; "
            f"ignoring it re-opens the {kind} the expert already resolved."
        ),
        applies=", ".join(candidate.get("tags", [])) or candidate["domain"],
    )


class KnowledgeStructuringAgent(Agent):
    name = "Knowledge Structuring Agent"
    description = "Formats candidates as Architecture Decision Records with consequences."

    def handle(self, state: AgentState):
        title = state.get("title", "capture session")
        for candidate in state.get("candidates", []):
            baseline = to_adr(candidate, title)
            candidate["body"] = complete_text(
                system="Rewrite the ADR so it is concise, specific and reusable. Keep the headings.",
                user=baseline,
                fallback=baseline,
            )
            if not candidate.get("summary"):
                candidate["summary"] = candidate["title"]
        count = len(state.get("candidates", []))
        return state, f"Structured {count} records into ADR format.", {"structured": count}
