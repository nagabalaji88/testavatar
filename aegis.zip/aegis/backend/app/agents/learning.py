"""Agent 7 — Learning. Turns approved knowledge into branching simulations and quizzes."""
from __future__ import annotations

from .base import Agent, AgentState

SCENARIO_FRAMES = {
    "incident": "Production is degraded and you are the on-call engineer.",
    "architecture": "You are designing a new service and must choose an approach.",
    "production": "A deploy has just gone out and metrics look wrong.",
    "hr": "A teammate raises a process concern during a review cycle.",
    "security": "A dependency scan has flagged a critical advisory.",
}


def build_tree(item: dict, scenario: str) -> dict:
    frame = SCENARIO_FRAMES.get(scenario, SCENARIO_FRAMES["incident"])
    guidance = item.get("title", "the captured guidance")
    return {
        "root": "n1",
        "nodes": {
            "n1": {
                "id": "n1",
                "prompt": f"{frame} {item.get('summary', guidance)} What is your first move?",
                "choices": [
                    {
                        "id": "c1",
                        "label": "Apply the captured expert guidance directly",
                        "score": 10,
                        "next": "n2",
                        "feedback": f"Matches expert practice: {guidance}",
                    },
                    {
                        "id": "c2",
                        "label": "Escalate immediately without triage",
                        "score": 4,
                        "next": "n2",
                        "feedback": "Escalation is safe but skips cheap triage the expert does first.",
                    },
                    {
                        "id": "c3",
                        "label": "Restart the service and hope it clears",
                        "score": 0,
                        "next": "n2",
                        "feedback": "This destroys the evidence the postmortem needs.",
                    },
                ],
            },
            "n2": {
                "id": "n2",
                "prompt": "The situation is stabilising. How do you close it out?",
                "choices": [
                    {
                        "id": "c4",
                        "label": "Write it up and link the decision record",
                        "score": 10,
                        "next": None,
                        "feedback": "Knowledge stays in the graph instead of in someone's head.",
                    },
                    {
                        "id": "c5",
                        "label": "Mention it in standup tomorrow",
                        "score": 5,
                        "next": None,
                        "feedback": "Better than nothing, but the knowledge is not captured.",
                    },
                    {
                        "id": "c6",
                        "label": "Move on, it is resolved",
                        "score": 0,
                        "next": None,
                        "feedback": "The next person will rediscover this the hard way.",
                    },
                ],
            },
        },
    }


def badge_for(score: int, maximum: int = 20) -> str:
    ratio = score / maximum if maximum else 0
    if ratio >= 0.9:
        return "Expert Mirror"
    if ratio >= 0.7:
        return "Sound Judgement"
    if ratio >= 0.4:
        return "Getting There"
    return "Needs Coaching"


class LearningAgent(Agent):
    name = "Learning Agent"
    description = "Generates scenario simulations, quizzes and progression badges."

    def handle(self, state: AgentState):
        item = state.get("item", {})
        scenario = state.get("scenario", "incident")
        state["tree"] = build_tree(item, scenario)
        return state, f"Built a {scenario} simulation from “{item.get('title','')[:50]}”.", {
            "nodes": len(state["tree"]["nodes"])
        }
