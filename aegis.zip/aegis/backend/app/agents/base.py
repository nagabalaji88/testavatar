"""Agent contract.

Every agent is a pure-ish function over a mutable dict state, wrapped so the
orchestrator can record a trace the UI streams back to the user. This is the
same shape LangGraph nodes use, so porting to LangGraph is mechanical.
"""
from __future__ import annotations

import time
from typing import Any

AgentState = dict[str, Any]


class Agent:
    name: str = "agent"
    description: str = ""

    def handle(self, state: AgentState) -> tuple[AgentState, str, dict]:
        """Return (state, human readable detail, structured output)."""
        raise NotImplementedError

    def run(self, state: AgentState) -> AgentState:
        started = time.perf_counter()
        try:
            state, detail, output = self.handle(state)
            status = "complete"
        except Exception as exc:  # noqa: BLE001 - a failed agent must not kill the run
            detail, output, status = f"{type(exc).__name__}: {exc}", {}, "failed"
        state.setdefault("trace", []).append(
            {
                "agent": self.name,
                "status": status,
                "detail": detail,
                "duration_ms": int((time.perf_counter() - started) * 1000),
                "output": output,
            }
        )
        return state
