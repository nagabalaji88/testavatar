"""Agent 2 — Privacy. Presidio-style PII detection and redaction."""
from __future__ import annotations

import re

from .base import Agent, AgentState

PATTERNS: list[tuple[str, str]] = [
    ("EMAIL", r"[\w\.\-\+]+@[\w\-]+\.[\w\.\-]+"),
    ("PHONE", r"(?:\+?\d{1,3}[\s\-])?(?:\(?\d{3}\)?[\s\-])?\d{3}[\s\-]\d{4}\b"),
    ("CREDIT_CARD", r"\b(?:\d{4}[ \-]?){3}\d{4}\b"),
    ("IP_ADDRESS", r"\b(?:\d{1,3}\.){3}\d{1,3}\b"),
    ("AWS_KEY", r"\bAKIA[0-9A-Z]{16}\b"),
    ("SECRET", r"(?i)\b(?:api[_\- ]?key|secret|password|token)\s*[:=]\s*\S+"),
    ("NATIONAL_ID", r"\b\d{3}-\d{2}-\d{4}\b"),
    ("URL_WITH_CREDS", r"https?://[^\s:@]+:[^\s@]+@\S+"),
]


def scan(text: str) -> list[dict]:
    findings: list[dict] = []
    for label, pattern in PATTERNS:
        for match in re.finditer(pattern, text):
            findings.append(
                {
                    "type": label,
                    "start": match.start(),
                    "end": match.end(),
                    "preview": match.group()[:4] + "…",
                    "severity": "high" if label in {"CREDIT_CARD", "AWS_KEY", "SECRET",
                                                    "NATIONAL_ID", "URL_WITH_CREDS"} else "medium",
                }
            )
    return sorted(findings, key=lambda f: f["start"])


def redact(text: str) -> tuple[str, list[dict]]:
    findings = scan(text)
    redacted = text
    for finding in sorted(findings, key=lambda f: f["start"], reverse=True):
        redacted = redacted[: finding["start"]] + f"[{finding['type']}_REDACTED]" + redacted[finding["end"]:]
    return redacted, findings


class PrivacyAgent(Agent):
    name = "Privacy Agent"
    description = "Detects and redacts PII before anything is persisted or embedded."

    def handle(self, state: AgentState):
        if not state.get("consent_granted", True):
            state["blocked"] = True
            return state, "Consent not granted — capture blocked at the privacy gate.", {}
        redacted, findings = redact(state["raw_content"])
        state["redacted_content"] = redacted
        state["pii_findings"] = findings
        high = [f for f in findings if f["severity"] == "high"]
        detail = (
            f"Redacted {len(findings)} PII spans ({len(high)} high severity). "
            "Downstream agents only ever see the redacted text."
        )
        return state, detail, {"pii_count": len(findings), "high_severity": len(high)}
