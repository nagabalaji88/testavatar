"""Agent 8 — Refresh. Finds stale knowledge and drafts expert nudges."""
from __future__ import annotations

from ..core.config import settings
from ..services.knowledge_health import portfolio_health
from .base import Agent, AgentState


class RefreshAgent(Agent):
    name = "Refresh Agent"
    description = "Flags decaying knowledge and notifies the owning expert."

    def handle(self, state: AgentState):
        report = portfolio_health(
            state.get("items", []), settings.decay_half_life_days, settings.stale_threshold
        )
        state["health"] = report
        state["recall_queue"] = report["stale"]
        return (
            state,
            f"{len(report['stale'])} records fell below the freshness threshold.",
            {"health": report["health"], "stale": len(report["stale"])},
        )
