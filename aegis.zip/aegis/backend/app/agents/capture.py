"""Agent 1 — Knowledge Capture. Pulls decisions, risks and heuristics out of raw text."""
from __future__ import annotations

import re

from ..services.llm import complete_json, keywords, sentences
from .base import Agent, AgentState

SIGNALS = {
    "decision": [
        "we decided", "we chose", "we went with", "decision", "agreed to", "settled on",
        "instead of", "rather than", "we picked", "final call",
    ],
    "risk": [
        "risk", "danger", "careful", "watch out", "fails", "outage", "broke", "caveat",
        "gotcha", "regression", "timeout", "deadlock", "leak", "never ",
    ],
    "best_practice": [
        "always", "make sure", "rule of thumb", "best practice", "prefer", "convention",
        "we usually", "the trick is", "in practice",
    ],
    "incident": [
        "incident", "postmortem", "root cause", "sev1", "sev2", "on-call", "paged",
        "rollback", "downtime",
    ],
}


def _classify(sentence: str) -> str | None:
    lowered = sentence.lower()
    best, hits = None, 0
    for kind, markers in SIGNALS.items():
        count = sum(1 for m in markers if m in lowered)
        if count > hits:
            best, hits = kind, count
    return best


def _title(sentence: str) -> str:
    cleaned = re.sub(r"\s+", " ", sentence).strip().rstrip(".")
    return (cleaned[:95] + "…") if len(cleaned) > 96 else cleaned


def extract(text: str, domain: str = "Architecture") -> list[dict]:
    """Deterministic extraction — the offline baseline the LLM can improve on."""
    found: list[dict] = []
    for sentence in sentences(text):
        kind = _classify(sentence)
        if not kind:
            continue
        found.append(
            {
                "title": _title(sentence),
                "kind": kind,
                "domain": domain,
                "summary": _title(sentence),
                "evidence": sentence,
                "tags": keywords(sentence, 5),
                "confidence": round(min(0.55 + 0.08 * len(keywords(sentence, 6)), 0.93), 2),
            }
        )
    # Deduplicate on title, keep the strongest.
    unique: dict[str, dict] = {}
    for candidate in found:
        existing = unique.get(candidate["title"].lower())
        if not existing or candidate["confidence"] > existing["confidence"]:
            unique[candidate["title"].lower()] = candidate
    return list(unique.values())[:12]


class KnowledgeCaptureAgent(Agent):
    name = "Knowledge Capture Agent"
    description = "Extracts tacit decisions, risks and heuristics from an artifact."

    def handle(self, state: AgentState):
        text = state.get("redacted_content") or state["raw_content"]
        baseline = extract(text, state.get("domain", "Architecture"))
        enriched = complete_json(
            system=(
                "You extract tacit engineering knowledge. Return "
                '{"items":[{"title","kind","summary","tags","confidence"}]} where kind is one of '
                "decision, risk, best_practice, heuristic, incident."
            ),
            user=text[:6000],
            fallback={"items": baseline},
        )
        items = enriched.get("items") or baseline
        for item in items:
            item.setdefault("domain", state.get("domain", "Architecture"))
            item.setdefault("evidence", "")
            item.setdefault("tags", [])
            item["confidence"] = float(item.get("confidence", 0.6))
        state["candidates"] = items
        by_kind: dict[str, int] = {}
        for item in items:
            by_kind[item["kind"]] = by_kind.get(item["kind"], 0) + 1
        return (
            state,
            f"Extracted {len(items)} knowledge candidates from {len(text.split())} words.",
            {"count": len(items), "by_kind": by_kind},
        )
