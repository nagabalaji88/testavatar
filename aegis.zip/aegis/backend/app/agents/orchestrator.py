"""LangGraph-style linear pipeline for ethical capture.

Order matters: privacy runs before extraction so no agent downstream of the
gate ever sees raw PII.
"""
from __future__ import annotations

from .base import AgentState
from .capture import KnowledgeCaptureAgent
from .embedding import EmbeddingAgent
from .privacy import PrivacyAgent
from .structuring import KnowledgeStructuringAgent
from .validation import ValidationAgent

PIPELINE = [
    PrivacyAgent(),
    KnowledgeCaptureAgent(),
    KnowledgeStructuringAgent(),
    ValidationAgent(),
    EmbeddingAgent(),
]


def run_capture_pipeline(state: AgentState) -> AgentState:
    state.setdefault("trace", [])
    for agent in PIPELINE:
        state = agent.run(state)
        if state.get("blocked"):
            state["status"] = "blocked"
            return state
    state["status"] = "awaiting_validation"
    return state
