"""Agent 5 — Embedding. Vectors for retrieval plus knowledge-graph nodes and edges."""
from __future__ import annotations

from ..services.vector_store import embed
from .base import Agent, AgentState

NODE_TYPE_FOR_KIND = {
    "decision": "decision",
    "risk": "dependency",
    "incident": "incident",
    "best_practice": "architecture",
    "heuristic": "architecture",
}


def build_graph_fragment(candidates: list[dict], expert: str) -> dict:
    nodes = [{"key": f"expert::{expert}", "label": expert, "node_type": "expert", "meta": {}}]
    edges: list[dict] = []
    seen_tech: set[str] = set()
    for candidate in candidates:
        key = f"item::{candidate['title'][:60]}"
        nodes.append(
            {
                "key": key,
                "label": candidate["title"],
                "node_type": NODE_TYPE_FOR_KIND.get(candidate["kind"], "decision"),
                "meta": {"kind": candidate["kind"], "domain": candidate["domain"]},
            }
        )
        edges.append({"source": f"expert::{expert}", "target": key, "relation": "authored"})
        for tag in candidate.get("tags", [])[:3]:
            tech_key = f"tech::{tag}"
            if tech_key not in seen_tech:
                seen_tech.add(tech_key)
                nodes.append({"key": tech_key, "label": tag, "node_type": "technology", "meta": {}})
            edges.append({"source": key, "target": tech_key, "relation": "involves"})
    return {"nodes": nodes, "edges": edges}


class EmbeddingAgent(Agent):
    name = "Embedding Agent"
    description = "Writes vectors to the index and projects nodes into the knowledge graph."

    def handle(self, state: AgentState):
        candidates = state.get("candidates", [])
        for candidate in candidates:
            text = f"{candidate['title']} {candidate.get('summary','')} {' '.join(candidate.get('tags', []))}"
            candidate["embedding"] = embed(text)
        fragment = build_graph_fragment(candidates, state.get("expert_name", "Unattributed"))
        state["graph_fragment"] = fragment
        return (
            state,
            f"Indexed {len(candidates)} vectors and projected "
            f"{len(fragment['nodes'])} graph nodes / {len(fragment['edges'])} edges.",
            {"vectors": len(candidates), "nodes": len(fragment["nodes"])},
        )
