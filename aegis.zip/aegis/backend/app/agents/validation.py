"""Agent 4 — Validation. Builds human review cards and calibrates confidence."""
from __future__ import annotations

from .base import Agent, AgentState

MIN_EVIDENCE_WORDS = 8


def calibrate(candidate: dict) -> tuple[float, list[str]]:
    """Adjust model confidence with evidence-based penalties and bonuses."""
    score = candidate.get("confidence", 0.6)
    reasons: list[str] = []
    evidence_words = len((candidate.get("evidence") or "").split())
    if evidence_words < MIN_EVIDENCE_WORDS:
        score -= 0.15
        reasons.append("thin supporting evidence")
    if len(candidate.get("tags", [])) >= 4:
        score += 0.05
        reasons.append("well anchored to known topics")
    if candidate["kind"] in {"risk", "incident"}:
        score -= 0.05
        reasons.append("risk claims need expert sign-off")
    return round(max(0.05, min(score, 0.97)), 2), reasons


class ValidationAgent(Agent):
    name = "Validation Agent"
    description = "Creates reviewer cards; nothing is published without a human decision."

    def handle(self, state: AgentState):
        needs_review = 0
        for candidate in state.get("candidates", []):
            confidence, reasons = calibrate(candidate)
            candidate["confidence"] = confidence
            candidate["review_reasons"] = reasons
            candidate["status"] = "pending"
            needs_review += 1
        return (
            state,
            f"{needs_review} cards queued for expert validation. Auto-publish is disabled by design.",
            {"pending": needs_review},
        )
