"""Runtime configuration. Everything is overridable via environment variables."""
from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_name: str = "Project AEGIS"
    api_prefix: str = "/api"
    database_url: str = "sqlite:///./aegis.db"
    secret_key: str = "aegis-dev-secret-change-me"
    token_ttl_seconds: int = 60 * 60 * 12

    # AI stack. When no key is present the app falls back to the deterministic
    # local engine so the whole pipeline still runs offline (demo/hackathon mode).
    openai_api_key: str = ""
    openai_base_url: str = "https://api.openai.com/v1"
    openai_model: str = "gpt-4o-mini"

    # Knowledge health tuning
    decay_half_life_days: int = 120
    stale_threshold: float = 0.45

    cors_origins: str = "http://localhost:5173,http://127.0.0.1:5173"

    model_config = SettingsConfigDict(env_file=".env", env_prefix="AEGIS_", extra="ignore")

    @property
    def cors_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]

    @property
    def llm_enabled(self) -> bool:
        return bool(self.openai_api_key)


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
